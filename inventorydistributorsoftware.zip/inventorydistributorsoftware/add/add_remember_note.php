<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
session_regenerate_id(TRUE);
include_once('../db.php');
include_once('../method.php');
$read="1";
$status="1";
		
if(!empty($_POST['rememberdatepicker'])){
	$rememberdatepicker=$_POST['rememberdatepicker'];
}else{
	$rememberdatepicker="";
}

if(!empty($_POST['remembernote'])){
	$remembernote=$_POST['remembernote'];
}else{
	$remembernote="";
}
if(!empty($_POST['company'])){
	$company=$_POST['company'];
}else{
	$company="";
}
if(!empty($_POST['operator'])){
	$operator=$_POST['operator'];
}else{
	$operator="";
}
if(!empty($_POST['superemail'])){
	$superemail=$_POST['superemail'];
}else{
	$superemail="";
}
if(!empty($_POST['entrydate'])){
	$entrydate=$_POST['entrydate'];
}else{
	$entrydate="";
}
	$note_insert=new data;
				$note_insert->insert(
				"note_onserial",
				['entry_date'=>"$entrydate",
				'date_for_note'=>"$rememberdatepicker",
				'note'=>"$remembernote",
				'company_username'=>"$company",
				'sub_user'=>"$operator",
				'super_email'=>"$superemail",
				'read_status'=>"$read",
				'status'=>"$status"],
				"ssssssss",
				['Added Successfully',
				'Added Failed']);
?>