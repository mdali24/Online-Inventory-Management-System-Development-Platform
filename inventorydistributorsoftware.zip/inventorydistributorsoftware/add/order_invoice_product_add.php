<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include_once('../db.php');
include_once('../method.php');
$invoice_type="purchase_invoice";
//$update_date_time_hag62DF447382=date("Y-m-d H:i:s");
if(!empty($_POST['super_user'])){
	$super_user=$_POST['super_user'];
}else{
	$super_user="";
}
if(!empty($_POST['company_use'])){
	$company_use=$_POST['company_use'];
}else{
	$company_use="";
}
if(!empty($_POST['operator'])){
	$operator=$_POST['operator'];
}else{
	$operator="";
}
if(!empty($_POST['invoice_no_add'])){
	$invoice_no_add=$_POST['invoice_no_add'];
}else{

}
if ($stmt = $mysqli->prepare("SELECT * FROM invoice_summary_onserial WHERE company_username=? and invoice_type=?")) {
		$stmt->bind_param("ss", $company_use,$invoice_type);
		$stmt->execute();
		$stmt->store_result();
		$rows_num=$stmt->num_rows;
		if($rows_num > 0){
			$stmt_sql = $mysqli->prepare("SELECT invoice_no FROM invoice_summary_onserial WHERE company_username=? and  invoice_type=? and sub_user=? ORDER BY invoice_no DESC");
			$stmt_sql->bind_param("sss", $company_use,$invoice_type,$operator);
			$stmt_sql->execute();
			$stmt_sql->store_result();
			$num_of_rows = $stmt_sql->num_rows;
			$stmt_sql->bind_result($invoice_no);
			$stmt_sql->fetch();
			$new_invoice=$invoice_no;
		}else{
			$new_invoice=$invoice_no_add;
		}
	}
	$invoice_no_add=$new_invoice;
if(!empty($_POST['invoice_date_add'])){
	$invoice_date_add=$_POST['invoice_date_add'];
}else{
	date_default_timezone_set('Asia/Dhaka');//problem
	$var_date= date('y/m/d') ;
	$invoice_date_add=$var_date;
}
if(!empty($_POST['vendor_id_add'])){
	$vendor_id_add=$_POST['vendor_id_add'];
}else{
	$vendor_id_add=0;
}
if(!empty($_POST['vendor_email_add'])){
	$vendor_email_add=$_POST['vendor_email_add'];
}else{
	$vendor_email_add="";
}
if(!empty($_POST['mobile_no_add'])){
	$mobile_no_add=$_POST['mobile_no_add'];
}else{
	$mobile_no_add="";
}
if(!empty($_POST['telephone_no_add'])){
	$telephone_no_add=$_POST['telephone_no_add'];
}else{
	$telephone_no_add="";
}
if(!empty($_POST['product_name_view'])){
	$product_name_view=$_POST['product_name_view'];
}else{
	$product_name_view="";
}
if(!empty($_POST['product_id_view'])){
	$product_id_view=$_POST['product_id_view'];
	$image_name=$product_id_view.'.png';
	if (file_exists('../barcode_images/'.$image_name)) {
 }else{
 	include_once('../Barcode39.php');

	$bc = new Barcode39("$product_id_view"); 
	
	$bc->barcode_text_size = 1; 
	
	$bc->barcode_bar_thick = 2; 
	
	$bc->barcode_bar_thin = 1;
	
	$bc->draw("../barcode_images/$product_id_view.png");
 }
}else{
	if ($stmt = $mysqli->prepare("SELECT product_id FROM products_details_onserial WHERE company_username=?")) {
    $stmt->bind_param("s", $company_use);
    $stmt->execute();
	$stmt->store_result();
	$rows_num=$stmt->num_rows;
	if($rows_num > 0){
		$stmt_sql = $mysqli->prepare("SELECT product_id FROM products_details_onserial WHERE company_username=? ORDER BY sn DESC");
		$stmt_sql->bind_param("s", $company_use);
		$stmt_sql->execute();
		$stmt_sql->store_result();
		$num_of_rows = $stmt_sql->num_rows;
		$stmt_sql->bind_result($product_id);
		$stmt_sql->fetch();
	
			$last_product_id=$product_id;
			if($last_product_id<100000001){
				$new_product_id=100000000+1;
			}else{
				$new_product_id=$last_product_id+1;
			}
	}else{
		$new_product_id=100000001;
	}
	$product_id_view=$new_product_id;
	$image_name=$product_id_view.'.png';
	if (file_exists('../barcode_images/'.$image_name)) {
 }else{
 	include_once('../Barcode39.php');

	$bc = new Barcode39("$product_id_view"); 
	
	$bc->barcode_text_size = 1; 
	
	$bc->barcode_bar_thick = 2; 
	
	$bc->barcode_bar_thin = 1;
	
	$bc->draw("../barcode_images/$product_id_view.png");
 }
	
}
}

if(!empty($_POST['products_company_view'])){
	$products_company_view=$_POST['products_company_view'];
}else{
	$products_company_view="";
}
if(!empty($_POST['quantity_view'])){
	$quantity_view=$_POST['quantity_view'];
}else{
	$quantity_view="";
}
if(!empty($_POST['size_view'])){
	$size_view=$_POST['size_view'];
}else{
	$size_view="";
}
$product_title_view=$product_name_view." ".$size_view;
if(!empty($_POST['unit_price_view'])){
	$unit_price_view=$_POST['unit_price_view'];
}else{
	$unit_price_view="";
}
if(!empty($_POST['sub_total_view'])){
	$sub_total_view=$_POST['sub_total_view']; 
}else{
	$sub_total_view="";
}
if(!empty($_POST['discount_view'])){
	$discount_view=$_POST['discount_view']; 
}else{
	$discount_view="";
}
if(!empty($_POST['sub_net_view'])){
	$sub_net_view=$_POST['sub_net_view'];
}else{
	$sub_net_view="";
}
if(!empty($_POST['tax_view'])){
	$tax_view=$_POST['tax_view'];
	
}else{
	$tax_view="";
}
if(!empty($_POST['tax_percent_view'])){
	$tax_percent=$_POST['tax_percent_view'];
	
}else{
	$tax_percent="";
}
if(!empty($_POST['sell_price_view'])){
	$sell_price_view=$_POST['sell_price_view'];
}else{
	$sell_price_view="";
}
if(!empty($_POST['warranty_guarantee_days_view'])){
	$warranty_guarantee_days_view=$_POST['warranty_guarantee_days_view'];
}else{
	$warranty_guarantee_days_view="";
}
if(!empty($_POST['warranty_guarantee_type_view'])){
	$warranty_guarantee_type_view=$_POST['warranty_guarantee_type_view'];
}else{
	$warranty_guarantee_type_view="";
}
if(!empty($_POST['serial_key_length_view'])){
	$serial_key_length_view=$_POST['serial_key_length_view'];
}else{
	$serial_key_length_view="";
}
if(!empty($_POST['remarks_p_view'])){
	$remarks_p_view=$_POST['remarks_p_view'];
}else{
	$remarks_p_view="";
}

if(!empty($_POST['payment_type_view'])){
	$payment_type_view=$_POST['payment_type_view'];
}else{
	$payment_type_view="";
}
if(!empty($_POST['total_pack_view'])){
	$total_pack_view=$_POST['total_pack_view'];
}else{
	$total_pack_view="";
}
if(!empty($_POST['pack_size_view'])){
	$pack_size_view=$_POST['pack_size_view'];
}else{
	$pack_size_view="";
}
if(!empty($_POST['loose_quantity_view'])){
	$loose_quantity_view=$_POST['loose_quantity_view'];
}else{
	$loose_quantity_view="";
}
$query = "SELECT vendor_primary_key FROM companies_onserial WHERE company_username=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$company_use);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($vendor_primary_key);
	$stmt->fetch();
	if($vendor_primary_key=='Email'){
		$vendor_primary_key='markenter_email';
		$vendor_select=$vendor_email_add;
	}else if($vendor_primary_key=='Mobile'){
		$vendor_primary_key='vendor_mobile_no';
		$vendor_select=$mobile_no_add;
	}else if($vendor_primary_key=='Telephone'){
		$vendor_primary_key='vendor_telephone_no';
		$vendor_select=$telephone_no_add;
	}
	}
	if($vendor_id_add<1){
		$query_vendor = "SELECT sn FROM company_markenter_onserial WHERE company_username=? and $vendor_primary_key=? and type='vendor'"; 
			if($stmt_vendor = $mysqli->prepare($query_vendor)){
				if($vendor_primary_key=='markenter_email'){
					$stmt_vendor->bind_param('ss',$company_use,$vendor_select);
				}else{
					$stmt_vendor->bind_param('si',$company_use,$vendor_select);
				}
			$stmt_vendor->execute();
			$stmt_vendor->store_result();
			$num_of_rows = $stmt_vendor->num_rows;
			$stmt_vendor->bind_result($vendor_serial);
			$stmt_vendor->fetch();
			$vendor_id_add=$vendor_serial;
			}
	}

	if($stmt_sql = $mysqli->prepare("SELECT * FROM products_details_onserial WHERE (product_id=? and company_username=?) or (product_title=? and company_username=?)")){
		
		$stmt_sql->bind_param("isss",$product_id_view,$company_use,$product_title_view,$company_use);
		$stmt_sql->execute();
		$stmt_sql->store_result();
		$rows_num=$stmt_sql->num_rows;
		
		if($rows_num > 0){
		$stmt = $mysqli->prepare("UPDATE products_details_onserial SET 
			`product_title`=?,
			`product_name`=?,
			`products_company`=?,
			`size`=?,
			`unit_price`=?,
			`tax`=?,
			`vendor_serial`=?,
			`sell_price`=?,
			`warenty_days`=?,
			`warenty_type`=?,
			`serial_length`=?
			 WHERE `product_id`=? and `company_username`=?");
					
			$stmt->bind_param('ssssssisssiis', $product_title_view
			, $product_name_view, $products_company_view,$size_view, $unit_price_view, $tax_percent,$vendor_id_add, $sell_price_view,$warranty_guarantee_days_view, $warranty_guarantee_type_view,$serial_key_length_view, $product_id_view, $company_use);
				$update_status = $stmt->execute();
				if($update_status==1){
					echo "";
				}
		
		}else{
		    $product_status=1;
			$products_details_add=new data;
			$products_details_add->insert(
			"products_details_onserial",
			['product_title'=>"$product_title_view",
			'product_name'=>"$product_name_view",
			'status'=>"$product_status",
			'product_id'=>"$product_id_view",
			'products_company'=>"$products_company_view",
			'size'=>"$size_view",
			'unit_price'=>"$unit_price_view",
			'tax'=>"$tax_percent",
			'vendor_serial'=>"$vendor_id_add",
			'sell_price'=>"$sell_price_view",
			'warenty_days'=>"$warranty_guarantee_days_view",
			'warenty_type'=>"$warranty_guarantee_type_view",
			'serial_length'=>"$serial_key_length_view",
			'super_email'=>"$super_user",
			'company_username'=>"$company_use"],
			"ssiissssisssiss",
			['',
			'']);
						
		}
	}
	
	$invoice_products_details_add=new data;
	$invoice_products_details_add->insert(
	"invoice_products_details_onserial",
	['vendor_serial'=>"$vendor_id_add",
	'invoice_no'=>"$invoice_no_add",
	'debit_or_credit'=>"debit",
	'product_name'=>"$product_name_view",
	'product_id'=>"$product_id_view",
	'quantity'=>"$quantity_view",
	'size'=>"$size_view",
	'total_pack'=>"$total_pack_view",
	'pack_size'=>"$pack_size_view",
	'loose_quantity'=>"$loose_quantity_view",
	'payment_type'=>"$payment_type_view",	
	'products_company'=>"$products_company_view",
	'unit_price'=>"$unit_price_view",
	'sub_total'=>"$sub_total_view",
	'discount'=>"$discount_view",
	'net'=>"$sub_net_view",
	'tax'=>"$tax_view",
	'sell_price'=>"$sell_price_view",
	'warranty_days'=>"$warranty_guarantee_days_view",	
	'warranty_days_type'=>"$warranty_guarantee_type_view",
	'serial_key_length'=>"$serial_key_length_view",
	'date'=>"$invoice_date_add",
	'sub_user'=>"$operator",
	'super_email'=>"$super_user",
	'invoice_type'=>"$invoice_type",
	'company_username'=>"$company_use"
	],
	"iisssisiiisssisissssisssss",
	['',
	'Products Added Failed']);
	if ($stmt = $mysqli->prepare("SELECT * FROM stock_now_onserial WHERE product_id=? and company_username=?")) {
		$stmt->bind_param("is", $product_id_view,$company_use);
		$stmt->execute();
		$stmt->store_result();
		$rows_num=$stmt->num_rows;
		if($rows_num > 0){
			$stmt_sql = $mysqli->prepare("SELECT total_purchase,current_stock FROM stock_now_onserial WHERE product_id=? and company_username=?");
			$stmt_sql->bind_param("is",$product_id_view,$company_use);
			$stmt_sql->execute();
			$stmt_sql->store_result();
			$num_of_rows = $stmt_sql->num_rows;
			$stmt_sql->bind_result($total_purchase,$current_stock);
			$stmt_sql->fetch();
			$total_purchase=$total_purchase;
			$current_stock=$current_stock;
			$total_purchase_now=$total_purchase+$quantity_view;
			$current_stock_now=$current_stock+$quantity_view;
			$stmt = $mysqli->prepare("UPDATE stock_now_onserial SET 
							  `total_purchase`=?,
							  `vendor_sn`=?,
							  `current_stock`=?
							   WHERE `product_id`=? and `company_username`=?");
					
			$stmt->bind_param('iiiss', $total_purchase_now, $vendor_id_add, $current_stock_now, $product_id_view, $company_use);
			$update_status = $stmt->execute();
			if($update_status==1){
				echo "";
			}
		}else{
			$new_stock_add=new data;
			$new_stock_add->insert(
			"stock_now_onserial",
			['product_id'=>"$product_id_view",
			'total_purchase'=>"$quantity_view",
			'current_stock'=>"$quantity_view",
			'super_email'=>"$super_user",
			'vendor_sn'=>"$vendor_id_add",
			'company_username'=>"$company_use"],
			"iiisis",
			['',
			'Stock Added Failed']);
						
		}  
	}
	if ($stmt = $mysqli->prepare("SELECT * FROM stock_pack_details WHERE stock_sn=? and pack_size=?  and company_username=?")) {
		$stmt->bind_param("sss",$product_id_view,$pack_size_view,$company_use);
		$stmt->execute();
		$stmt->store_result();
		$rows_num=$stmt->num_rows;
		if($rows_num > 0){
			$stmt_sql = $mysqli->prepare("SELECT total_pack FROM stock_pack_details WHERE stock_sn=? and pack_size=? and  company_username=?");
			$stmt_sql->bind_param("sss",$product_id_view,$pack_size_view,$company_use);
			$stmt_sql->execute();
			$stmt_sql->store_result();
			$num_of_rows = $stmt_sql->num_rows;
			$stmt_sql->bind_result($total_pack);
			$stmt_sql->fetch();
			$total_pack=$total_pack;
			$total_pack_now=$total_pack+$total_pack_view;
			$stmt = $mysqli->prepare("UPDATE stock_pack_details SET 
							  `total_pack`=?,
							  `pack_size`=?,
							  `vendor_sn`=?
							   WHERE `stock_sn`=? and `pack_size`=? and `company_username`=?");
					
			$stmt->bind_param('isisss', $total_pack_now, $pack_size_view, $vendor_id_add, $product_id_view, $pack_size_view, $company_use);
			$update_status = $stmt->execute();
			if($update_status==1){
				echo "";
			}
		}else{
			$new_pack_stock_add=new data;
			$new_pack_stock_add->insert(
			"stock_pack_details",
			['stock_sn'=>"$product_id_view",
			'pack_size'=>"$pack_size_view",
			'total_pack'=>"$total_pack_view",
			'piches_per_pack'=>"$super_user",
			'vendor_sn'=>"$vendor_id_add",
			'super_email'=>"$super_user",
			'company_username'=>"$company_use"],
			"ssiiiss",
			['',
			'Stock Added Failed']);
						
		}  
	}

?>