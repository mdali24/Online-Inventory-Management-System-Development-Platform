<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include_once('../db.php');
include_once('../method.php');
$invoice_type="purchase_invoice";

if(!empty($_POST['super_user'])){
	$super_user=$_POST['super_user'];
}else{
	$super_user="";
}
if(!empty($_POST['company_use'])){
	$company_use=$_POST['company_use'];
}else{
	$company_use="";
}
if(!empty($_POST['operator'])){
	$operator=$_POST['operator'];
}else{
	$operator="";
}
if(!empty($_POST['invoice_no_add'])){
	$invoice_no_add=$_POST['invoice_no_add'];
}else{
	
}
$stmt_sql = $mysqli->prepare("SELECT invoice_no FROM invoice_summary_onserial WHERE sub_user=? and company_username=? and invoice_type=? ORDER BY sn DESC");
	$stmt_sql->bind_param("sss",$operator,$company_use,$invoice_type);
	$stmt_sql->execute();
	$stmt_sql->store_result();
	$num_of_rows = $stmt_sql->num_rows;
	$stmt_sql->bind_result($invoice_no);
	$stmt_sql->fetch();
	
	$invoice_no_add=$invoice_no;
if(!empty($_POST['invoice_date_add'])){
	$invoice_date_add=$_POST['invoice_date_add'];
}else{
	$invoice_date_add="";
}
if(!empty($_POST['vendor_id_add'])){
	$vendor_id_add=$_POST['vendor_id_add'];
}else{
	$vendor_id_add="";
}
if(!empty($_POST['product_id_find'])){
	$product_id_find=$_POST['product_id_find'];
}else{
	$empty_check[]="";
}
if(!empty($_POST['serial_key_find'])){
	$serial_key_find=$_POST['serial_key_find'];
	$serial_key_find=str_replace("X","","$serial_key_find");
	
}else{
	$empty_check[]="";
}
if(empty($empty_check)){
$new_serial_add=new data;
	$new_serial_add->insert(
	"invoice_products_serial_details_onserial",
	['invoice_no'=>"$invoice_no_add",
	'product_id'=>"$product_id_find",
	'serial_key'=>"$serial_key_find",
	'vendor_id'=>"$vendor_id_add",
	'company_username'=>"$company_use",
	'super_email'=>"$super_user",
	'subuser'=>"$operator",	
	'invoice_type'=>"$invoice_type",	
	'date'=>"$invoice_date_add"],
	"iisisssss",
	['',
	'']);
}else{
echo "Empty Fields";
}
?>