<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
session_regenerate_id(TRUE);
include_once('../db.php');
include_once('../method.php');
$invoice_type="sell_invoice";
$type="customer";
$status="1";
if(!empty($_POST['token_five'])){
	$token_five=$_POST['token_five'];
	if (isset($_SESSION['csrf_token']) and $token_five==$_SESSION['csrf_token']) {
		
if(!empty($_POST['super_user'])){
	$super_user=$_POST['super_user'];
}else{
	$super_user="";
}
if(!empty($_POST['company_use'])){
	$company_use=$_POST['company_use'];
}else{
	$company_use="";
}
if(!empty($_POST['operator'])){
	$operator=$_POST['operator'];
}else{
	$operator="";
}
if(!empty($_POST['invoice_no_add'])){
	$order_no_add=$_POST['invoice_no_add'];
}else{
	
}
	if ($stmt = $mysqli->prepare("SELECT * FROM invoice_summary_onserial WHERE company_username=? and invoice_type=?")) {
		$stmt->bind_param("ss", $company_use,$invoice_type);
		$stmt->execute();
		$stmt->store_result();
		$rows_num=$stmt->num_rows;
		
		if($rows_num > 0){
			$stmt_sql = $mysqli->prepare("SELECT invoice_no FROM invoice_summary_onserial WHERE company_username=? and invoice_type=? ORDER BY invoice_no DESC");
			$stmt_sql->bind_param("ss", $company_use,$invoice_type);
			$stmt_sql->execute();
			$stmt_sql->store_result();
			$num_of_rows = $stmt_sql->num_rows;
			$stmt_sql->bind_result($invoice_no);
			$stmt_sql->fetch();
			$new_invoice=$invoice_no+1;
		}else{
			$new_invoice=100000001;
		}
	}
	$invoice_no_add=$new_invoice;
	echo "Invoice No : ".$invoice_no_add;

if(!empty($_POST['invoice_date_add'])){
	$invoice_date_add=$_POST['invoice_date_add'];
}else{
	$invoice_date_add="";
}
if(!empty($_POST['vendor_id_add'])){
	$customer_id_add=$_POST['vendor_id_add'];
}else{
	$vendor_id_add=0;
	$customer_id_add=0;
}
if(!empty($_POST['vendor_email_add'])){
	$vendor_email_add=$_POST['vendor_email_add'];
}else{
	$vendor_email_add="";
}
if(!empty($_POST['mobile_no_add'])){
	$mobile_no_add=$_POST['mobile_no_add'];
}else{
	$mobile_no_add="";
}
if(!empty($_POST['telephone_no_add'])){
	$telephone_no_add=$_POST['telephone_no_add'];
}else{
	$telephone_no_add="";
}
if(!empty($_POST['full_name_add'])){
	$full_name_add=$_POST['full_name_add'];
}else{
	$full_name_add="";
}
if(!empty($_POST['vendor_address_add'])){
	$vendor_address_add=$_POST['vendor_address_add'];
}else{
	$vendor_address_add="";
}
if(!empty($_POST['company_name_add'])){
	$company_name_add=$_POST['company_name_add'];
}else{
	$company_name_add=0;
}
if(!empty($_POST['debit_limit_add'])){
	$debit_limit_add=$_POST['debit_limit_add'];
}else{
	$debit_limit_add="";
}
if(!empty($_POST['debit_days_add'])){
	$debit_days_add=$_POST['debit_days_add'];
}else{
	$debit_days_add="";
}
if(!empty($_POST['delivary_date_add'])){
	$delivary_date_add=$_POST['delivary_date_add'];
}else{
	$delivary_date_add="";
}
if(!empty($_POST['grand_total_add'])){
	$grand_total_add=$_POST['grand_total_add'];
}else{
	$grand_total_add=0;
}
if(!empty($_POST['discount_total_add'])){
	$discount_total_add=$_POST['discount_total_add'];
}else{
	$discount_total_add=0;
}
if(!empty($_POST['total_add'])){
	$total_add=$_POST['total_add'];
}else{
	$total_add=0;
}
if(!empty($_POST['now_payment_add'])){
	$now_payment_add=$_POST['now_payment_add'];
}else{
	$now_payment_add=0;
}
if(!empty($_POST['payment_method_add'])){
	$payment_method_add=$_POST['payment_method_add'];
}else{
	$payment_method_add="";
}
if(!empty($_POST['bank_name_add'])){
	$bank_name_add=$_POST['bank_name_add'];
}else{
	$bank_name_add="";
}
if(!empty($_POST['account_no_add'])){
	$account_no_add=$_POST['account_no_add'];
}else{
	$account_no_add="";
}
if(!empty($_POST['due_add'])){
	$due_add=$_POST['due_add'];
}else{
	$due_add=0;
}
if(!empty($_POST['due_payment_date_add'])){
	$due_payment_date_add=$_POST['due_payment_date_add'];
}else{
	$due_payment_date_add="";
}
if(!empty($_POST['tax_add'])){
	$tax_add=$_POST['tax_add'];
}else{
	$tax_add="";
}
if(!empty($_POST['caring_cost_add'])){
	$caring_cost_add=$_POST['caring_cost_add'];
}else{
	$caring_cost_add=0;
}
if(!empty($_POST['others_cost_add'])){
	$others_cost_add=$_POST['others_cost_add'];
}else{
	$others_cost_add=0;
}
if(!empty($_POST['insentive_add'])){
	$insentive_add=$_POST['insentive_add'];
}else{
	$insentive_add=0;
}
if(!empty($_POST['total_net_add'])){
	$total_net_add=$_POST['total_net_add'];
}else{
	$total_net_add=0;
}
if(!empty($_POST['remarks'])){
	$remarks=$_POST['remarks'];
}else{
	$remarks="";
}

	if ($stmt = $mysqli->prepare("SELECT * FROM company_markenter_onserial WHERE sn=? and company_username=?")) {
		$stmt->bind_param("is", $customer_id_add,$company_use);
		$stmt->execute();
		$stmt->store_result();
		$rows_num=$stmt->num_rows;
		if($rows_num > 0){
			$stmt = $mysqli->prepare("UPDATE company_markenter_onserial SET 
                      `markenter_email`=?,
                      `vendor_mobile_no`=?,
                      `vendor_telephone_no`=?,
                      `full_name`=?,
                      `vendor_address`=?,
                      `vendor_company_name`=?,
                      `vendor_debit_limit`=?,
                      `vendor_debit_days`=?
                       WHERE `sn`=? and `company_username`=?");
			
			$stmt->bind_param('siisssiiis', $vendor_email_add, $mobile_no_add, $telephone_no_add, $full_name_add,$vendor_address_add, $company_name_add, $debit_limit_add, $debit_days_add,$customer_id_add, $company_use);
			$update_status = $stmt->execute();
				if($update_status==1){
					echo "";
				}
		}else{
		$vendor_status=1;	
		$new_vendor_add=new data;
			$new_vendor_add->insert(
			"company_markenter_onserial",
			['markenter_email'=>"$vendor_email_add",
			'vendor_mobile_no'=>"$mobile_no_add",
			'vendor_telephone_no'=>"$telephone_no_add",
			'full_name'=>"$full_name_add",
			'vendor_address'=>"$vendor_address_add",
			'vendor_company_name'=>"$company_name_add",
			'vendor_debit_limit'=>"$debit_limit_add",
			'vendor_debit_days'=>"$debit_days_add",	
			'super_admin_email'=>"$super_user",
			'date'=>"$invoice_date_add",
			'status'=>"$vendor_status",
			'type'=>"$type",
			'company_username'=>"$company_use"],
			"siisssiississ",
			['',
			'']);
		}  
	}
	$query = "SELECT customer_primary_key FROM companies_onserial WHERE company_username=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$company_use);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($customer_primary_key);
	$stmt->fetch();
	if($customer_primary_key=='Email'){
		$customer_primary_key='markenter_email';
		$customer_select=$vendor_email_add;
	}else if($customer_primary_key=='Mobile'){
		$customer_primary_key='vendor_mobile_no';
		$customer_select=$mobile_no_add;
	}else if($customer_primary_key=='Telephone'){
		$customer_primary_key='vendor_telephone_no';
		$customer_select=$telephone_no_add;
	}
	}
	if($customer_id_add<1){
		$query_vendor = "SELECT sn FROM company_markenter_onserial WHERE company_username=? and $customer_primary_key=? and type='customer'"; 
			if($stmt_vendor = $mysqli->prepare($query_vendor)){
				if($customer_primary_key=='markenter_email'){
					$stmt_vendor->bind_param('ss',$company_use,$customer_select);
				}else{
					$stmt_vendor->bind_param('si',$company_use,$customer_select);
				}
			$stmt_vendor->execute();
			$stmt_vendor->store_result();
			$num_of_rows = $stmt_vendor->num_rows;
			$stmt_vendor->bind_result($customer_serial);
			$stmt_vendor->fetch();
			$customer_id_add=$customer_serial;
			}
	}
	$order_invoice="sell_order_invoice";
	if ($stmt = $mysqli->prepare("SELECT * FROM invoice_summary_onserial WHERE order_no=? and company_username=? and invoice_type=?")) {
		$stmt->bind_param("iss", $order_no_add,$company_use,$order_invoice);
		$stmt->execute();
		$stmt->store_result();
		$rows_num=$stmt->num_rows;
		if($rows_num > 0){
			if ($stmt_new = $mysqli->prepare("SELECT net FROM invoice_summary_onserial WHERE order_no=? and company_username=? and invoice_type=?")) {
				$stmt_new->bind_param("iss", $order_no_add,$company_use,$order_invoice);
				$stmt_new->execute();
				
				$stmt_new->store_result();
				$num_of_rows = $stmt_new->num_rows;
				$stmt_new->bind_result($net);
				$stmt_new->fetch();
				
				
			}
			$order_to_invoice_status="1";
			$stmt = $mysqli->prepare("UPDATE invoice_summary_onserial SET customer_serial=?,order_to_invoice_status=?,last_update_date=?,last_update_user=? WHERE order_no=? and company_username=? and invoice_type=?");
			$stmt->bind_param('isssiss', $customer_id_add,$order_to_invoice_status, $invoice_date_add, $operator, $order_no_add,$company_use,$order_invoice);
			$update_status = $stmt->execute();
			if($update_status==1){
				echo "";
			}
			$new_insert=new data;
			$new_insert->insert(
			"invoice_summary_onserial",
			['invoice_no'=>"$invoice_no_add",
			'super_email'=>"$super_user",
			'date'=>"$invoice_date_add",
			'customer_serial'=>"$customer_id_add",
			'delivary_date'=>"$delivary_date_add",
			'bill'=>"$grand_total_add",
			'discount'=>"$discount_total_add",	
			'total'=>"$total_add",
			'payment'=>"$now_payment_add",
			'payment_method'=>"$payment_method_add",
			'bank_name'=>"$bank_name_add",
			'account_no'=>"$account_no_add",
			'due'=>"$due_add",
			'due_payment_date'=>"$due_payment_date_add",
			'tax'=>"$tax_add",
			'carring_cost'=>"$caring_cost_add",
			'others_cost'=>"$others_cost_add",	
			'intensive'=>"$insentive_add",
			'net'=>"$total_net_add",
			'remarks'=>"$remarks",
			'company_username'=>"$company_use",
			'invoice_type'=>"$invoice_type",
			'debit_or_credit'=>"credit",
			'status'=>"$status",
			'sub_user'=>"$operator"],
			"issisisiisssissiissssssss",
			['',
			'']);
				
		}else{
			
			
			
		}
		
	}
	}else{
		?>
	  <script>alert("Unautorized Request");</script>
	  <?php
	}
}else{
	?>
	  <script>alert("Unautorized Request");</script>
	  <?php
}
if (isset($_SESSION['csrf_token'])){
		unset($_SESSION['csrf_token']);
	}

?>