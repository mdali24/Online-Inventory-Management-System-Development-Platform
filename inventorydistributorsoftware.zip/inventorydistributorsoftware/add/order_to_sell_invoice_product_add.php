<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include_once('../db.php');
include_once('../method.php');
$invoice_type="sell_invoice";
//$update_date_time_hag62DF447382=date("Y-m-d H:i:s");
if(!empty($_POST['super_user'])){
	$super_user=$_POST['super_user'];
}else{
	$super_user="";
}
if(!empty($_POST['company_use'])){
	$company_use=$_POST['company_use'];
}else{
	$company_use="";
}
if(!empty($_POST['operator'])){
	$operator=$_POST['operator'];
}else{
	$operator="";
}
if(!empty($_POST['invoice_no_add'])){
	$invoice_no_add=$_POST['invoice_no_add'];
}else{
	
}
if ($stmt = $mysqli->prepare("SELECT * FROM invoice_summary_onserial WHERE company_username=? and invoice_type=?")) {
		$stmt->bind_param("ss", $company_use,$invoice_type);
		$stmt->execute();
		$stmt->store_result();
		$rows_num=$stmt->num_rows;
		if($rows_num > 0){
			$stmt_sql = $mysqli->prepare("SELECT invoice_no FROM invoice_summary_onserial WHERE company_username=? and  invoice_type=? and sub_user=? ORDER BY invoice_no DESC");
			$stmt_sql->bind_param("sss", $company_use,$invoice_type,$operator);
			$stmt_sql->execute();
			$stmt_sql->store_result();
			$num_of_rows = $stmt_sql->num_rows;
			$stmt_sql->bind_result($invoice_no);
			$stmt_sql->fetch();
			$new_invoice=$invoice_no;
		}else{
			$new_invoice=$invoice_no_add;
		}
	}
	$invoice_no_add=$new_invoice;


if(!empty($_POST['invoice_date_add'])){
	$invoice_date_add=$_POST['invoice_date_add'];
}else{
	date_default_timezone_set('Asia/Dhaka');//problem
	$var_date= date('y/m/d') ;
	$invoice_date_add=$var_date;
}
if(!empty($_POST['vendor_id_add'])){
	$customer_id_add=$_POST['vendor_id_add'];
}else{
	$vendor_id_add=0;
	$customer_id_add=0;
}

if(!empty($_POST['vendor_email_add'])){
	$vendor_email_add=$_POST['vendor_email_add'];
}else{
	$vendor_email_add="";
}
if(!empty($_POST['mobile_no_add'])){
	$mobile_no_add=$_POST['mobile_no_add'];
}else{
	$mobile_no_add="";
}
if(!empty($_POST['telephone_no_add'])){
	$telephone_no_add=$_POST['telephone_no_add'];
}else{
	$telephone_no_add="";
}


if(!empty($_POST['product_name_view'])){
	$product_name_view=$_POST['product_name_view'];
}else{
	$product_name_view="";
}
if(!empty($_POST['product_id_view'])){
	$product_id_view=$_POST['product_id_view'];
	
}else{
	$product_id_view=0;
}

if(!empty($_POST['products_company_view'])){
	$products_company_view=$_POST['products_company_view'];
}else{
	$products_company_view="";
}
if(!empty($_POST['quantity_view'])){
	$quantity_view=$_POST['quantity_view'];
}else{
	$quantity_view="";
}
if(!empty($_POST['size_view'])){
	$size_view=$_POST['size_view'];
}else{
	$size_view="";
}
$product_title_view=$product_name_view." ".$size_view;
if(!empty($_POST['unit_price_view'])){
	$unit_price_view=$_POST['unit_price_view'];
}else{
	$unit_price_view="";
}
if(!empty($_POST['sub_total_view'])){
	$sub_total_view=$_POST['sub_total_view']; 
}else{
	$sub_total_view="";
}
if(!empty($_POST['discount_view'])){
	$discount_view=$_POST['discount_view']; 
}else{
	$discount_view="";
}
if(!empty($_POST['sub_net_view'])){
	$sub_net_view=$_POST['sub_net_view'];
}else{
	$sub_net_view="";
}
if(!empty($_POST['tax_view'])){
	$tax_view=$_POST['tax_view'];
	
}else{
	$tax_view="";
}
if(!empty($_POST['tax_percent_view'])){
	$tax_percent=$_POST['tax_percent_view'];
	
}else{
	$tax_percent="";
}
if(!empty($_POST['sell_price_view'])){
	$sell_price_view=$_POST['sell_price_view'];
}else{
	$sell_price_view="";
}
if(!empty($_POST['warranty_guarantee_days_view'])){
	$warranty_guarantee_days_view=$_POST['warranty_guarantee_days_view'];
}else{
	$warranty_guarantee_days_view="";
}
if(!empty($_POST['warranty_guarantee_type_view'])){
	$warranty_guarantee_type_view=$_POST['warranty_guarantee_type_view'];
}else{
	$warranty_guarantee_type_view="";
}
if(!empty($_POST['serial_key_length_view'])){
	$serial_key_length_view=$_POST['serial_key_length_view'];
}else{
	$serial_key_length_view="";
}
if(!empty($_POST['remarks_p_view'])){
	$remarks_p_view=$_POST['remarks_p_view'];
}else{
	$remarks_p_view="";
}
	$query = "SELECT customer_primary_key FROM companies_onserial WHERE company_username=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$company_use);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($customer_primary_key);
	$stmt->fetch();
	if($customer_primary_key=='Email'){
		$customer_primary_key='markenter_email';
		$customer_select=$vendor_email_add;
	}else if($customer_primary_key=='Mobile'){
		$customer_primary_key='vendor_mobile_no';
		$customer_select=$mobile_no_add;
	}else if($customer_primary_key=='Telephone'){
		$customer_primary_key='vendor_telephone_no';
		$customer_select=$telephone_no_add;
	}
	}
	if($customer_id_add<1){
		$query_vendor = "SELECT sn FROM company_markenter_onserial WHERE company_username=? and $customer_primary_key=? and type='customer'"; 
			if($stmt_vendor = $mysqli->prepare($query_vendor)){
				if($customer_primary_key=='markenter_email'){
					$stmt_vendor->bind_param('ss',$company_use,$customer_select);
				}else{
					$stmt_vendor->bind_param('si',$company_use,$customer_select);
				}
			$stmt_vendor->execute();
			$stmt_vendor->store_result();
			$num_of_rows = $stmt_vendor->num_rows;
			$stmt_vendor->bind_result($customer_serial);
			$stmt_vendor->fetch();
			$customer_id_add=$customer_serial;
			}
	}
	$new_vendor_add=new data;
	$new_vendor_add->insert(
	"invoice_products_details_onserial",
	['customer_serial'=>"$customer_id_add",
	'invoice_no'=>"$invoice_no_add",
	'debit_or_credit'=>"credit",
	'product_name'=>"$product_name_view",
	'product_id'=>"$product_id_view",
	'quantity'=>"$quantity_view",
	'size'=>"$size_view",	
	'products_company'=>"$products_company_view",
	'unit_price'=>"$unit_price_view",
	'sub_total'=>"$sub_total_view",
	'discount'=>"$discount_view",
	'net'=>"$sub_net_view",
	'tax'=>"$tax_view",
	'sell_price'=>"$sell_price_view",
	'warranty_days'=>"$warranty_guarantee_days_view",	
	'warranty_days_type'=>"$warranty_guarantee_type_view",
	'serial_key_length'=>"$serial_key_length_view",
	'date'=>"$invoice_date_add",
	'sub_user'=>"$operator",
	'super_email'=>"$super_user",
	'invoice_type'=>"$invoice_type",
	'company_username'=>"$company_use"
	],
	"iissiissiisisississsss",
	['',
	'Products Added Failed']);
	if ($stmt = $mysqli->prepare("SELECT * FROM stock_now_onserial WHERE product_id=? and company_username=?")) {
		$stmt->bind_param("is", $product_id_view,$company_use);
		$stmt->execute();
		$stmt->store_result();
		$rows_num=$stmt->num_rows;
		if($rows_num > 0){
			$stmt_sql = $mysqli->prepare("SELECT total_sell,current_stock FROM stock_now_onserial WHERE product_id=? and company_username=?");
			$stmt_sql->bind_param("is",$product_id_view,$company_use);
			$stmt_sql->execute();
			$stmt_sql->store_result();
			$num_of_rows = $stmt_sql->num_rows;
			$stmt_sql->bind_result($total_sell,$current_stock);
			$stmt_sql->fetch();
			$total_sell=$total_sell;
			$current_stock=$current_stock;
			$total_sell_now=$total_sell+$quantity_view;
			$current_stock_now=$current_stock-$quantity_view;
			$stmt = $mysqli->prepare("UPDATE stock_now_onserial SET 
							  `total_sell`=?,
							  `current_stock`=?
							   WHERE `product_id`=? and `company_username`=?");
					
			$stmt->bind_param('iiis', $total_sell_now, $current_stock_now, $product_id_view, $company_use);
			$update_status = $stmt->execute();
			if($update_status==1){
				echo "";
			}
		}else{
			
						
		}  
	}

?>