<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
session_regenerate_id(TRUE);
include_once('../db.php');
include_once('../method.php');
$invoice_type="sell_service";
$type="customer";
$status="1";
if(!empty($_POST['token_five'])){
	$token_five=$_POST['token_five'];
	if (isset($_SESSION['csrf_token']) and $token_five==$_SESSION['csrf_token']) {
		
if(!empty($_POST['super_user'])){
	$super_user=$_POST['super_user'];
}else{
	$super_user="";
}
if(!empty($_POST['company_use'])){
	$company_use=$_POST['company_use'];
}else{
	$company_use="";
}
if(!empty($_POST['operator'])){
	$operator=$_POST['operator'];
}else{
	$operator="";
}
if(!empty($_POST['invoice_no_add'])){
	$invoice_no_add=$_POST['invoice_no_add'];
}else{
	if ($stmt = $mysqli->prepare("SELECT * FROM invoice_summary_onserial WHERE company_username=? and invoice_type=?")) {
		$stmt->bind_param("ss", $company_use,$invoice_type);
		$stmt->execute();
		$stmt->store_result();
		$rows_num=$stmt->num_rows;
		
		if($rows_num > 0){
			$stmt_sql = $mysqli->prepare("SELECT invoice_no FROM invoice_summary_onserial WHERE company_username=? and invoice_type=? ORDER BY invoice_no DESC");
			$stmt_sql->bind_param("ss", $company_use,$invoice_type);
			$stmt_sql->execute();
			$stmt_sql->store_result();
			$num_of_rows = $stmt_sql->num_rows;
			$stmt_sql->bind_result($invoice_no);
			$stmt_sql->fetch();
			$new_invoice=$invoice_no+1;
		}else{
			$new_invoice=100000001;
		}
	}
	$invoice_no_add=$new_invoice;
	echo "Invoice No : ".$invoice_no_add;
}
if(!empty($_POST['invoice_date_add'])){
	$invoice_date_add=$_POST['invoice_date_add'];
}else{
	$invoice_date_add="";
}
if(!empty($_POST['vendor_id_add'])){
	$customer_id_add=$_POST['vendor_id_add'];
}else{
	$vendor_id_add=0;
	$customer_id_add=0;
}
if(!empty($_POST['vendor_email_add'])){
	$vendor_email_add=$_POST['vendor_email_add'];
}else{
	$vendor_email_add="";
}
if(!empty($_POST['mobile_no_add'])){
	$mobile_no_add=$_POST['mobile_no_add'];
}else{
	$mobile_no_add="";
}
if(!empty($_POST['telephone_no_add'])){
	$telephone_no_add=$_POST['telephone_no_add'];
}else{
	$telephone_no_add="";
}
if(!empty($_POST['full_name_add'])){
	$full_name_add=$_POST['full_name_add'];
}else{
	$full_name_add="";
}
if(!empty($_POST['vendor_address_add'])){
	$vendor_address_add=$_POST['vendor_address_add'];
}else{
	$vendor_address_add="";
}
if(!empty($_POST['company_name_add'])){
	$company_name_add=$_POST['company_name_add'];
}else{
	$company_name_add=0;
}
if(!empty($_POST['debit_limit_add'])){
	$debit_limit_add=$_POST['debit_limit_add'];
}else{
	$debit_limit_add="";
}
if(!empty($_POST['debit_days_add'])){
	$debit_days_add=$_POST['debit_days_add'];
}else{
	$debit_days_add="";
}
if(!empty($_POST['delivary_date_add'])){
	$delivary_date_add=$_POST['delivary_date_add'];
}else{
	$delivary_date_add="";
}
if(!empty($_POST['grand_total_add'])){
	$grand_total_add=$_POST['grand_total_add'];
}else{
	$grand_total_add=0;
}
if(!empty($_POST['discount_total_add'])){
	$discount_total_add=$_POST['discount_total_add'];
}else{
	$discount_total_add=0;
}
if(!empty($_POST['total_add'])){
	$total_add=$_POST['total_add'];
}else{
	$total_add=0;
}
if(!empty($_POST['now_payment_add'])){
	$now_payment_add=$_POST['now_payment_add'];
}else{
	$now_payment_add=0;
}
if(!empty($_POST['payment_method_add'])){
	$payment_method_add=$_POST['payment_method_add'];
}else{
	$payment_method_add="";
}
if(!empty($_POST['bank_name_add'])){
	$bank_name_add=$_POST['bank_name_add'];
}else{
	$bank_name_add="";
}
if(!empty($_POST['account_no_add'])){
	$account_no_add=$_POST['account_no_add'];
}else{
	$account_no_add="";
}
if(!empty($_POST['due_add'])){
	$due_add=$_POST['due_add'];
}else{
	$due_add=0;
}
if(!empty($_POST['due_payment_date_add'])){
	$due_payment_date_add=$_POST['due_payment_date_add'];
}else{
	$due_payment_date_add="";
}
if(!empty($_POST['tax_add'])){
	$tax_add=$_POST['tax_add'];
}else{
	$tax_add="";
}
if(!empty($_POST['caring_cost_add'])){
	$caring_cost_add=$_POST['caring_cost_add'];
}else{
	$caring_cost_add=0;
}
if(!empty($_POST['others_cost_add'])){
	$others_cost_add=$_POST['others_cost_add'];
}else{
	$others_cost_add=0;
}
if(!empty($_POST['insentive_add'])){
	$insentive_add=$_POST['insentive_add'];
}else{
	$insentive_add=0;
}
if(!empty($_POST['total_net_add'])){
	$total_net_add=$_POST['total_net_add'];
}else{
	$total_net_add=0;
}
if(!empty($_POST['remarks'])){
	$remarks=$_POST['remarks'];
}else{
	$remarks="";
}

	if ($stmt = $mysqli->prepare("SELECT * FROM company_markenter_onserial WHERE sn=? and company_username=?")) {
		$stmt->bind_param("is", $customer_id_add,$company_use);
		$stmt->execute();
		$stmt->store_result();
		$rows_num=$stmt->num_rows;
		if($rows_num > 0){
			$stmt = $mysqli->prepare("UPDATE company_markenter_onserial SET 
                      `markenter_email`=?,
                      `vendor_mobile_no`=?,
                      `vendor_telephone_no`=?,
                      `full_name`=?,
                      `vendor_address`=?,
                      `vendor_company_name`=?,
                      `vendor_debit_limit`=?,
                      `vendor_debit_days`=?
                       WHERE `sn`=? and `company_username`=?");
			
			$stmt->bind_param('siisssiiis', $vendor_email_add, $mobile_no_add, $telephone_no_add, $full_name_add,$vendor_address_add, $company_name_add, $debit_limit_add, $debit_days_add,$customer_id_add, $company_use);
			$update_status = $stmt->execute();
				if($update_status==1){
					echo "";
				}
		}else{
		$vendor_status=1;	
		$new_vendor_add=new data;
			$new_vendor_add->insert(
			"company_markenter_onserial",
			['markenter_email'=>"$vendor_email_add",
			'vendor_mobile_no'=>"$mobile_no_add",
			'vendor_telephone_no'=>"$telephone_no_add",
			'full_name'=>"$full_name_add",
			'vendor_address'=>"$vendor_address_add",
			'vendor_company_name'=>"$company_name_add",
			'vendor_debit_limit'=>"$debit_limit_add",
			'vendor_debit_days'=>"$debit_days_add",	
			'super_admin_email'=>"$super_user",
			'date'=>"$invoice_date_add",
			'status'=>"$vendor_status",
			'type'=>"$type",
			'company_username'=>"$company_use"],
			"siisssiississ",
			['',
			'']);
		}  
	}
	$query = "SELECT customer_primary_key FROM companies_onserial WHERE company_username=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$company_use);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($customer_primary_key);
	$stmt->fetch();
	if($customer_primary_key=='Email'){
		$customer_primary_key='markenter_email';
		$customer_select=$vendor_email_add;
	}else if($customer_primary_key=='Mobile'){
		$customer_primary_key='vendor_mobile_no';
		$customer_select=$mobile_no_add;
	}else if($customer_primary_key=='Telephone'){
		$customer_primary_key='vendor_telephone_no';
		$customer_select=$telephone_no_add;
	}
	}
	if($customer_id_add<1){
		$query_vendor = "SELECT sn FROM company_markenter_onserial WHERE company_username=? and $customer_primary_key=? and type='customer'"; 
			if($stmt_vendor = $mysqli->prepare($query_vendor)){
				if($customer_primary_key=='markenter_email'){
					$stmt_vendor->bind_param('ss',$company_use,$customer_select);
				}else{
					$stmt_vendor->bind_param('si',$company_use,$customer_select);
				}
			$stmt_vendor->execute();
			$stmt_vendor->store_result();
			$num_of_rows = $stmt_vendor->num_rows;
			$stmt_vendor->bind_result($customer_serial);
			$stmt_vendor->fetch();
			$customer_id_add=$customer_serial;
			}
	}
	if ($stmt = $mysqli->prepare("SELECT * FROM invoice_summary_onserial WHERE invoice_no=? and company_username=? and invoice_type=?")) {
		$stmt->bind_param("iss", $invoice_no_add,$company_use,$invoice_type);
		$stmt->execute();
		$stmt->store_result();
		$rows_num=$stmt->num_rows;
		if($rows_num > 0){
			if ($stmt_new = $mysqli->prepare("SELECT net FROM invoice_summary_onserial WHERE invoice_no=? and company_username=? and invoice_type=?")) {
				$stmt_new->bind_param("iss", $invoice_no_add,$company_use,$invoice_type);
				$stmt_new->execute();
				
				$stmt_new->store_result();
				$num_of_rows = $stmt_new->num_rows;
				$stmt_new->bind_result($net);
				$stmt_new->fetch();
				
				$previus_net=$net;
				$balance=$total_net_add-$previus_net;
				$update="update";
				$update_status=1;
				if($balance>1){
					$debit_or_credit_status="credit";
					$balance=$total_net_add-$previus_net;
				}else{
					$debit_or_credit_status="debit";
					$balance=$previus_net-$total_net_add;
				}
				 date_default_timezone_set('Asia/Dhaka');//problem
                $var_date= date('y/m/d') ;
				if($balance!==0){
				$update_balance_insert=new data;
				$update_balance_insert->insert(
				"invoice_summary_onserial",
				['update_invoice_no'=>"$invoice_no_add",
				'update_for_invoice_type'=>"$invoice_type",
				'net'=>"$balance",
				'invoice_type'=>"$update",
				'date'=>"$var_date",
				'sub_user'=>"$operator",
				'company_username'=>"$company_use",
				'super_email'=>"$super_user",
				'debit_or_credit'=>"$debit_or_credit_status",
				'status'=>"$update_status"],
				"issssssssi",
				['',
				'']);
				}
			}
			$stmt = $mysqli->prepare("UPDATE invoice_summary_onserial SET customer_serial=?,delivary_date=?,bill=?,discount=?,total=?,payment=?,payment_method=?,bank_name=?,account_no=?,due=?,due_payment_date=?,tax=?,carring_cost=?,others_cost=?,intensive=?,net=?,remarks=?,last_update_date=?,last_update_user=? WHERE invoice_no=? and company_username=? and invoice_type=?");
			$stmt->bind_param('isisiissiissiisssssiss', $customer_id_add, $delivary_date_add, $grand_total_add, $discount_total_add, $total_add, $now_payment_add, $payment_method_add, $bank_name_add, $account_no_add, $due_add, $due_payment_date_add, $tax_add, $caring_cost_add, $others_cost_add, $insentive_add, $total_net_add, $remarks, $invoice_date_add, $operator, $invoice_no_add,$company_use,$invoice_type);
			$update_status = $stmt->execute();
			if($update_status==1){
				echo "";
			}
			
			if ($stmt = $mysqli->prepare("SELECT product_id,quantity FROM invoice_products_details_onserial WHERE invoice_no=? and company_username=? and invoice_type=?")) {
				$stmt->bind_param("iss", $invoice_no_add,$company_use,$invoice_type);
				$stmt->execute();
				$stmt->store_result();
				$num_of_rows = $stmt->num_rows;
				$stmt->bind_result($product_id,$quantity);
				
				while($stmt->fetch()){
						$product_id_view=$product_id;
						$previus_quantity=$quantity;
						if ($stmt_stock = $mysqli->prepare("SELECT * FROM stock_now_onserial WHERE product_id=? and company_username=?")) {
						$stmt_stock->bind_param("is", $product_id_view,$company_use);
						$stmt_stock->execute();
						$stmt_stock->store_result();
						$rows_num=$stmt_stock->num_rows;
							if($rows_num > 0){
								$stmt_sql = $mysqli->prepare("SELECT total_sell,current_stock,sell_warranty FROM stock_now_onserial WHERE product_id=? and company_username=?");
								$stmt_sql->bind_param("is",$product_id_view,$company_use);
								$stmt_sql->execute();
								$stmt_sql->store_result();
								$num_of_rows = $stmt_sql->num_rows;
								$stmt_sql->bind_result($total_sell,$current_stock,$sell_warranty);
								$stmt_sql->fetch();
								$total_sell=$total_sell;
								$current_stock=$current_stock;
								$sell_warranty=$sell_warranty;	
								$total_sell_now=$total_sell-$previus_quantity;
								$current_stock_now=$current_stock+$previus_quantity;
								$sell_warranty_now=$sell_warranty-$previus_quantity;
								$stmt_update = $mysqli->prepare("UPDATE stock_now_onserial SET 
												  `sell_warranty`=?
												   WHERE `product_id`=? and `company_username`=?");
										
								$stmt_update->bind_param('iis', $sell_warranty_now, $product_id_view, $company_use);
								$update_status = $stmt_update->execute();
								if($update_status==1){
									echo "updated";
								}
								if ($stmt_delete = $mysqli->prepare("DELETE FROM invoice_products_details_onserial WHERE invoice_no=? and company_username=? and invoice_type=?")) {
								$stmt_delete->bind_param("iss",$invoice_no_add,$company_use,$invoice_type);
								$delete_status=$stmt_delete->execute();
									if($delete_status==1){
											echo "";
									}
								}
								
							} 
						}
					}
					
					if ($stmt = $mysqli->prepare("DELETE FROM invoice_products_serial_details_onserial WHERE invoice_no=? and company_username=? and invoice_type=?")) {
					$stmt->bind_param("iss",$invoice_no_add,$company_use,$invoice_type);
					$delete_status=$stmt->execute();
						if($delete_status==1){
							echo "";
						}
					}
					
			}
				
		}else{
			$new_insert=new data;
			$new_insert->insert(
			"invoice_summary_onserial",
			['invoice_no'=>"$invoice_no_add",
			'super_email'=>"$super_user",
			'date'=>"$invoice_date_add",
			'customer_serial'=>"$customer_id_add",
			'delivary_date'=>"$delivary_date_add",
			'bill'=>"$grand_total_add",
			'discount'=>"$discount_total_add",	
			'total'=>"$total_add",
			'payment'=>"$now_payment_add",
			'payment_method'=>"$payment_method_add",
			'bank_name'=>"$bank_name_add",
			'account_no'=>"$account_no_add",
			'due'=>"$due_add",
			'due_payment_date'=>"$due_payment_date_add",
			'tax'=>"$tax_add",
			'carring_cost'=>"$caring_cost_add",
			'others_cost'=>"$others_cost_add",	
			'intensive'=>"$insentive_add",
			'net'=>"$total_net_add",
			'remarks'=>"$remarks",
			'company_username'=>"$company_use",
			'invoice_type'=>"$invoice_type",
			'debit_or_credit'=>"credit",
			'status'=>"$status",
			'sub_user'=>"$operator"],
			"issisisiisssissiissssssss",
			['',
			'']);
			
			
			
		}
		
	}
	}else{
		?>
	  <script>alert("Unautorized Request");</script>
	  <?php
	}
}else{
	?>
	  <script>alert("Unautorized Request");</script>
	  <?php
}
if (isset($_SESSION['csrf_token'])){
		unset($_SESSION['csrf_token']);
	}

?>