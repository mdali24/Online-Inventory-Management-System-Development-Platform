<?php 
if(!empty($_POST['serial_key_barcode'])){
	$serial_key_barcode=$_POST['serial_key_barcode'];
	echo " "."<div class=\"serial_class\">".$serial_key_barcode."<span class=\"serial_class_remove\">X</span></div>";
}else{
	$serial_key_barcode="";
}
?>