<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
session_regenerate_id(TRUE);
include_once('../db.php');
include_once('../method.php');
$invoice_type="property_invest_capital";
$type="vendor";
$status="1";
if(!empty($_POST['token_five'])){
	$token_five=$_POST['token_five'];
	if (isset($_SESSION['csrf_token']) and $token_five==$_SESSION['csrf_token']) {
		
if(!empty($_POST['super_user'])){
	$super_user=$_POST['super_user'];
}else{
	$super_user="";
}
if(!empty($_POST['company_use'])){
	$company_use=$_POST['company_use'];
}else{
	$company_use="";
}
if(!empty($_POST['operator'])){
	$operator=$_POST['operator'];
}else{
	$operator="";
}
if(!empty($_POST['invoice_no_add'])){
	$invoice_no_add=$_POST['invoice_no_add'];
}else{
	if ($stmt = $mysqli->prepare("SELECT * FROM invoice_summary_onserial WHERE company_username=? and invoice_type=? and debit_credit_invoice>0")) {
		$stmt->bind_param("ss", $company_use,$invoice_type);
		$stmt->execute();
		$stmt->store_result();
		$rows_num=$stmt->num_rows;
		
		if($rows_num > 0){
			$stmt_sql = $mysqli->prepare("SELECT debit_credit_invoice FROM invoice_summary_onserial WHERE company_username=? and invoice_type=? and debit_credit_invoice>0 ORDER BY debit_credit_invoice DESC");
			$stmt_sql->bind_param("ss", $company_use,$invoice_type);
			$stmt_sql->execute();
			$stmt_sql->store_result();
			$num_of_rows = $stmt_sql->num_rows;
			$stmt_sql->bind_result($invoice_no);
			$stmt_sql->fetch();
			$new_invoice=$invoice_no+1;
		}else{
			$new_invoice=100000001;
		}
	}
	$invoice_no_add=$new_invoice;
	
}
echo "Invoice No : ".$invoice_no_add;
if(!empty($_POST['invoice_date_add'])){
	$invoice_date_add=$_POST['invoice_date_add'];
}else{
	$invoice_date_add="";
}
if(!empty($_POST['cause'])){
	$cause=$_POST['cause'];
}else{
	$cause=0;
}
if(!empty($_POST['amount'])){
	$amount=$_POST['amount'];
}else{
	$amount="";
}
if(!empty($_POST['current_market_value'])){
	$current_market_value=$_POST['current_market_value'];
}else{
	$current_market_value="";
}
$debit_or_credit='debit';

if(!empty($_POST['remarks_add'])){
	$remarks_add=$_POST['remarks_add'];
}else{
	$remarks_add="";
}

	
	if ($stmt = $mysqli->prepare("SELECT * FROM invoice_summary_onserial WHERE debit_credit_invoice=? and company_username=? and invoice_type=?")) {
		$stmt->bind_param("iss", $invoice_no_add,$company_use,$invoice_type);
		$stmt->execute();
		$stmt->store_result();
		$rows_num=$stmt->num_rows;
		if($rows_num > 0){
			if ($stmt_new = $mysqli->prepare("SELECT net,debit_or_credit FROM invoice_summary_onserial WHERE debit_credit_invoice=? and company_username=? and invoice_type=?")) {
				$stmt_new->bind_param("iss", $invoice_no_add,$company_use,$invoice_type);
				$stmt_new->execute();
				
				$stmt_new->store_result();
				$num_of_rows = $stmt_new->num_rows;
				$stmt_new->bind_result($net,$previous_debit_or_credit);
				$stmt_new->fetch();
				
				$previus_net=$net;
				$balance=$total_net_add-$previus_net;
				$update="update";
				$update_status=1;
				if($previous_debit_or_credit==$debit_or_credit){
					if($debit_credit=='debit'){
					if($balance>1){
							$debit_or_credit_status="debit";
							$balance=$total_net_add-$previus_net;
						}else{
							$debit_or_credit_status="credit";
							$balance=$previus_net-$total_net_add;
						}
					}else if($debit_credit=='credit'){
						if($balance>1){
							$debit_or_credit_status="credit";
							$balance=$total_net_add-$previus_net;
						}else{
							$debit_or_credit_status="debit";
							$balance=$previus_net-$total_net_add;
						}
					}
					
				}else{
					if($debit_credit=='debit'){
					if($balance>1){
							$debit_or_credit_status="debit";
							$balance=$total_net_add+$previus_net;
						}else{
							$debit_or_credit_status="credit";
							$balance=$previus_net-$total_net_add;
						}
					}else if($debit_credit=='credit'){
						if($balance>1){
							$debit_or_credit_status="credit";
							$balance=$total_net_add+$previus_net;
						}else{
							$debit_or_credit_status="debit";
							$balance=$previus_net-$total_net_add;
						}
					}
				}
				 date_default_timezone_set('Asia/Dhaka');//problem
                $var_date= date('y/m/d') ;
				if($balance!==0){
					$update_balance_insert=new data;
					$update_balance_insert->insert(
					"invoice_summary_onserial",
					['update_invoice_no'=>"$invoice_no_add",
					'update_for_invoice_type'=>"$invoice_type",
					'net'=>"$balance",
					'invoice_type'=>"$update",
					'date'=>"$var_date",
					'sub_user'=>"$operator",
					'company_username'=>"$company_use",
					'super_email'=>"$super_user",
					'debit_or_credit'=>"$debit_or_credit_status",
					'status'=>"$update_status"],
					"isssssssss",
					['',
					'']);
					}
					$stmt = $mysqli->prepare("UPDATE invoice_summary_onserial SET net=?,remarks=?,debit_or_credit=?,last_update_date=?,last_update_user=?,cause=? WHERE debit_credit_invoice=? and company_username=? and invoice_type=?");
					$stmt->bind_param('ssssssiss', $amount, $remarks_add, $debit_or_credit,$invoice_date_add, $operator,$cause, $invoice_no_add,$company_use,$invoice_type);
					$update_status = $stmt->execute();
					if($update_status==1){
						echo "Updated";
					}
				
				
				
			}
			
				
		}else{
			$new_insert=new data;
			$new_insert->insert(
			"invoice_summary_onserial",
			['debit_credit_invoice'=>"$invoice_no_add",
			'super_email'=>"$super_user",
			'date'=>"$invoice_date_add",
			'net'=>"$amount",
			'remarks'=>"$remarks_add",
			'company_username'=>"$company_use",
			'invoice_type'=>"$invoice_type",
			'debit_or_credit'=>"$debit_or_credit",
			'status'=>"$status",
			'cause'=>"$cause",
			'current_market_value'=>"$current_market_value",
			'sub_user'=>"$operator"],
			"isssssssssis",
			['',
			'']);
			
			
			
		}
		
	}
	}else{
		?>
	  <script>alert("Unautorized Request");</script>
	  <?php
	}
}else{
	?>
	  <script>alert("Unautorized Request");</script>
	  <?php
}
if (isset($_SESSION['csrf_token'])){
		unset($_SESSION['csrf_token']);
	}

?>