<?php 

?>
<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Customer Login Form</title>
  	<!-- Bootstrap -->
    	<link href="css/bootstrap.min.css" rel="stylesheet">
      <link rel="stylesheet" href="design.css">
     
</head>

<body>
  <?php include_once('client_header.php');?>
<?php 
include_once('db.php');
include_once('method.php');
session_start();
session_regenerate_id(TRUE);
if(isset($_SESSION['user_email_session']) and isset($_SESSION['user_type_session'])){
	$user_email=$_SESSION['user_email_session'];
	$user_type=$_SESSION['user_type_session'];
$var_date=date('y/m/d');
$empty_check=array();
if(!empty($_POST['company_name'])){
$company_name=$_POST['company_name'];
}else{
$empty_check[]="Empty Company Name";
}
if(!empty($_POST['company_username'])){
$company_username=$_POST['company_username'];
}else{
$empty_check[]="Empty Company Username";
}
if(!empty($_POST['barcode'])){
$barcode=$_POST['barcode'];
}else{
$empty_check[]="Empty barcode";
}
if(!empty($_POST['serial_key'])){
$serial_key=$_POST['serial_key'];
}else{
$empty_check[]="Empty serial_key";
}
if(!empty($_POST['vendor_register_required'])){
$vendor_register_required=$_POST['vendor_register_required'];
}else{
$empty_check[]="Empty vendor_register_required";
}
if(!empty($_POST['customer_register_required'])){
$customer_register_required=$_POST['customer_register_required'];
}else{
$empty_check[]="Empty customer_register_required";
}
if(!empty($_POST['customer_product_discount'])){
$customer_product_discount=$_POST['customer_product_discount'];
}else{
$empty_check[]="Empty customer_product_discount";
}
if(!empty($_POST['customer_final_discount'])){
$customer_final_discount=$_POST['customer_final_discount'];
}else{
$empty_check[]="Empty customer_final_discount";
}
if(!empty($_POST['vendor_tax'])){
$vendor_tax=$_POST['vendor_tax'];
}else{
$empty_check[]="Empty vendor_tax";
}
if(!empty($_POST['customer_tax'])){
$customer_tax=$_POST['customer_tax'];
}else{
$empty_check[]="Empty customer_tax";
}

if(!empty($_POST['vendor_primary_key'])){
$vendor_primary_key=$_POST['vendor_primary_key'];
}else{
$empty_check[]="Empty vendor_primary_key";
}
if(!empty($_POST['customer_primary_key'])){
$customer_primary_key=$_POST['customer_primary_key'];
}else{
$empty_check[]="Empty customer_primary_key";
}
if(!empty($_POST['customer_debit_limit'])){
$customer_debit_limit=$_POST['customer_debit_limit'];
}else{
$empty_check[]="Empty customer_debit_limit";
}
if(!empty($_POST['customer_debit_days'])){
$customer_debit_days=$_POST['customer_debit_days'];
}else{
$empty_check[]="Empty customer_debit_days";
}

if(!empty($_POST['customer_online_order_on'])){
$customer_online_order_on=$_POST['customer_online_order_on'];
}else{
$empty_check[]="Empty customer_online_order_on";
}
if(!empty($_POST['customer_online_auto_approved'])){
$customer_online_auto_approved=$_POST['customer_online_auto_approved'];
}else{
$empty_check[]="Empty customer_online_auto_approved";
}

if(!empty($_POST['company_timezone'])){
$company_timezone=$_POST['company_timezone'];
}else{
$empty_check[]="Empty company_timezone";
}
$status=1;

if(empty($empty_check)){

	if($stmt_sql = $mysqli->prepare("SELECT * FROM login_onserial WHERE user_type=? and email=? and status=?")){
		
		$stmt_sql->bind_param("ssi",$user_type,$user_email,$status);
		$stmt_sql->execute();
		$stmt_sql->store_result();
		$rows_num=$stmt_sql->num_rows;
		if($rows_num>0){
			if($stmt_company_check = $mysqli->prepare("SELECT * FROM companies_onserial WHERE company_username=?")){
			$stmt_company_check->bind_param("s",$company_username);
			$stmt_company_check->execute();
			$stmt_company_check->store_result();
			$rows_number_check=$stmt_company_check->num_rows;
			}
			if($rows_number_check<1){
				if($stmt_company = $mysqli->prepare("SELECT * FROM companies_onserial WHERE email=?")){
				$stmt_company->bind_param("s",$user_email);
				$stmt_company->execute();
				$stmt_company->store_result();
				$rows_number=$stmt_company->num_rows;
				}
				$query = "SELECT pakage,year,date FROM login_onserial WHERE email=?"; 
				if($stmt = $mysqli->prepare($query)){
					   $stmt->bind_param('s',$user_email);
					   $stmt->execute();
					   $stmt->store_result();
					   $num_of_rows = $stmt->num_rows;
					   $stmt->bind_result($pakage,$year,$date);
					   $stmt->fetch();
					   $softpakage=$pakage;
					   $year=$year;
					   $date=$date;
					   $yearto=substr($date,0,4);
					   $monthto=substr($date,5,2);
					   $dateto=substr($date,8,2);
					   $year_num=(int)$yearto;
					   $year_up=$year_num+$year;
					   if($monthto==2 and $dateto==29){
					   	$monthto=03;
					   	 $dateto=01;
					   }
					   $up_date="$year_up"."/"."$monthto"."/"."$dateto";
					   $up_to_time=strtotime($up_date);
					   $expired_date=date('Y-m-d',$up_to_time);
					   
					   $today=date('Y-m-d');
					   $today_strtotime=strtotime($today);
					   $expired_strtotime=strtotime($expired_date);
					   if($softpakage=='Free'){
						   $warehouse=1;
					   }else if($softpakage=='Silver'){
						   $warehouse=1;
					   }else if($softpakage=='Gold'){
						   $warehouse=5;
					   }else if($softpakage=='Diamond'){
						   $warehouse=50;
					   }
					   $stmt->free_result();
					   $stmt->close();
					}
				if($today_strtotime<$expired_strtotime){
					if($rows_number<$warehouse){
						$new_companies_add=new data;
						$new_companies_add->insert(
							"companies_onserial",
							['email'=>"$user_email",
							'company_name'=>"$company_name",
							'company_username'=>"$company_username",
							'status'=>"$status",
							'date'=>"$date",
							'barcode'=>"$barcode",
							'serial_key'=>"$serial_key",
							'vendor_register_required'=>"$vendor_register_required",
							'customer_register_required'=>"$customer_register_required",
							'customer_product_discount'=>"$customer_product_discount",
							'customer_final_discount'=>"$customer_final_discount",
							'vendor_tax'=>"$vendor_tax",
							'customer_tax'=>"$customer_tax",
							'vendor_primary_key'=>"$vendor_primary_key",
							'customer_primary_key'=>"$customer_primary_key",
							'customer_debit_limit'=>"$customer_debit_limit",
							'customer_debit_days'=>"$customer_debit_days",
							'customer_online_order_on'=>"$customer_online_order_on",
							'customer_online_auto_approved'=>"$customer_online_auto_approved",
							'company_timezone'=>"$company_timezone"],
							"sssissssssssssssssss",
							["<h1 class=\"client_login_title\">Created Successfully.Wait Sometime</h1>",
							'']);
					}else{
						echo "<h1 class=\"client_login_title\">You can not add more company in this pakage.Please Update your pakage</h1>";
					}
				}else{
						echo "<h1 class=\"client_login_title\">Your software is expired. Please update year</h1>";
					}
			}else{
				echo "<h1 class=\"client_login_title\">This company username is already use.Please try another one</h1>";
			}
			
		}
	}
}else{
   echo "<h1 class=\"client_login_title\">Some Fields Empty</h1>";
}
header( "refresh:2;url=super_admin.php" );
}else{
    echo "Please <a href=\"login.php\" >Login</a>";
}
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="javascript.js"></script>
</body>
</html>