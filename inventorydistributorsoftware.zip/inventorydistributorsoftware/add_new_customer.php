<?php 
include_once('db.php');
include_once('method.php');
session_start();
session_start();
session_regenerate_id(TRUE);
if(isset($_SESSION['user_email_session']) and isset($_SESSION['user_type_session'])){
	$user_email=$_SESSION['user_email_session'];
	$user_type=$_SESSION['user_type_session'];
$var_date=date('y/m/d');
$empty_check=array();
if(!empty($_POST['company_select_customer'])){
$company_select=$_POST['company_select_customer'];
}else{
$empty_check[]="Empty company_select";
}
if(!empty($_POST['customer_email'])){
$customer_email=$_POST['customer_email'];
$user_type="Customer";
}else{
$empty_check[]="Empty vendor_email";
}

$status=1;

if(empty($empty_check)){
	
		if($stmt_sql = $mysqli->prepare("SELECT * FROM customer_onserial WHERE user_type=? and email=? and status=?")){
			
			$stmt_sql->bind_param("ssi",$user_type,$customer_email,$status);
			$stmt_sql->execute();
			$stmt_sql->store_result();
			$rows_num=$stmt_sql->num_rows;
			if($rows_num>0){
				
					$query = "SELECT pakage,year,date FROM login_onserial WHERE email=?"; 
					if($stmt = $mysqli->prepare($query)){
						   $stmt->bind_param('s',$user_email);
						   $stmt->execute();
						   $stmt->store_result();
						   $num_of_rows = $stmt->num_rows;
						   $stmt->bind_result($pakage,$year,$date);
						   $stmt->fetch();
						   $softpakage=$pakage;
						   $year=$year;
						   $date=$date;
						   $yearto=substr($date,0,4);
						   $monthto=substr($date,5,2);
						   $dateto=substr($date,8,2);
						   $year_num=(int)$yearto;
						   $year_up=$year_num+$year;
						   if($monthto==2 and $dateto==29){
						   	$monthto=03;
						   	 $dateto=01;
						   }
						   $up_date="$year_up"."/"."$monthto"."/"."$dateto";
						   $up_to_time=strtotime($up_date);
						   $expired_date=date('Y-m-d',$up_to_time);
						   
						   $today=date(Y-m-d);
						   $today_strtotime=strtotime($today);
						   $expired_strtotime=strtotime($expired_date);
						   
						   $stmt->free_result();
						   $stmt->close();
						}
				if($today_strtotime<$expired_strtotime){
					
					$new_companies_add=new data;
					$new_companies_add->insert(
						"company_customer_onserial",
						['super_admin_email'=>"$user_email",
						'company_username'=>"$company_select",
						'customer_email'=>"$customer_email",
						'status'=>"$status",
						'date'=>"$var_date"],
						"sssis",
						['Customer Added Successfully',
						'']);
					
				}else{
					echo "Your software is expired. Please update year";
				}
				
				
			}else{
				echo "No Markenter in used this email";
			}
		}
	
}else{
   echo "Some Fields Empty";
}

header( "refresh:2;url=super_admin.php" );
}else{
    echo "Please <a href=\"login.php\" >Login</a>";
}
?>