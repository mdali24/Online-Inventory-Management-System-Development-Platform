<?php 

?>
<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Customer Login Form</title>
  	<!-- Bootstrap -->
    	<link href="css/bootstrap.min.css" rel="stylesheet">
      <link rel="stylesheet" href="design.css">
     
</head>

<body>
  <?php include_once('client_header.php');?>
<?php 
include_once('db.php');
include_once('method.php');
session_start();
session_start();
session_regenerate_id(TRUE);
if(isset($_SESSION['user_email_session']) and isset($_SESSION['user_type_session'])){
	$user_email=$_SESSION['user_email_session'];
	$user_type=$_SESSION['user_type_session'];
$var_date=date('y/m/d');
$empty_check=array();
if(!empty($_POST['name'])){
$name=$_POST['name'];
}else{
$empty_check[]="Empty Name";
}
if(!empty($_POST['company'])){
$company=$_POST['company'];
}else{
$empty_check[]="Empty Company";
}
if(!empty($_POST['post'])){
$post=$_POST['post'];
}else{
$empty_check[]="Empty post";
}
if(!empty($_POST['id_no'])){
$id_no=$_POST['id_no'];
}else{
$empty_check[]="Empty id_no";
}
if(!empty($_POST['user_type'])){
$sub_user_type=$_POST['user_type'];
}else{
$empty_check[]="Empty user_type";
}
if(!empty($_POST['sub_username'])){
$sub_username=$_POST['sub_username'];
}else{
$empty_check[]="Empty sub_username";
}
if(!empty($_POST['password'])){
$password=$_POST['password'];
}else{
$empty_check[]="Empty password";
}
if(!empty($_POST['password_confirmation'])){
$password_confirmation=$_POST['password_confirmation'];
}else{
$empty_check[]="Empty password_confirmation";
}
$status=1;

if(empty($empty_check)){
	if($password==$password_confirmation){
	$password=md5($password);
		if($stmt_sql = $mysqli->prepare("SELECT * FROM login_onserial WHERE user_type=? and email=? and status=?")){
			
			$stmt_sql->bind_param("ssi",$user_type,$user_email,$status);
			$stmt_sql->execute();
			$stmt_sql->store_result();
			$rows_num=$stmt_sql->num_rows;
			if($rows_num>0){
				
					if($stmt_company = $mysqli->prepare("SELECT * FROM company_users_onserial WHERE email=? and company_username=?")){
					$stmt_company->bind_param("ss",$user_email,$company);
					$stmt_company->execute();
					$stmt_company->store_result();
					$rows_number=$stmt_company->num_rows;
					}
					$query = "SELECT pakage,year,date FROM login_onserial WHERE email=?"; 
					if($stmt = $mysqli->prepare($query)){
						   $stmt->bind_param('s',$user_email);
						   $stmt->execute();
						   $stmt->store_result();
						   $num_of_rows = $stmt->num_rows;
						   $stmt->bind_result($pakage,$year,$date);
						   $stmt->fetch();
						   $softpakage=$pakage;
						   $year=$year;
						   $date=$date;
						   $yearto=substr($date,0,4);
						   $monthto=substr($date,5,2);
						   $dateto=substr($date,8,2);
						   $year_num=(int)$yearto;
						   $year_up=$year_num+$year;
						   if($monthto==2 and $dateto==29){
						   	$monthto=03;
						   	 $dateto=01;
						   }
						   $up_date="$year_up"."/"."$monthto"."/"."$dateto";
						   $up_to_time=strtotime($up_date);
						   $expired_date=date('Y-m-d',$up_to_time);
						   
						   $today=date('Y-m-d');
						   $today_strtotime=strtotime($today);
						   $expired_strtotime=strtotime($expired_date);
						   if($softpakage=='Free'){
							   $users=1;
						   }else if($softpakage=='Silver'){
							   $users=5;
						   }else if($softpakage=='Gold'){
							   $users=10;
						   }else if($softpakage=='Diamond'){
							   $users=20;
						   }
						   $stmt->free_result();
						   $stmt->close();
						}
				if($today_strtotime<$expired_strtotime){
					if($rows_number<$users){
						$new_companies_add=new data;
						$new_companies_add->insert(
							"company_users_onserial",
							['email'=>"$user_email",
							'company_username'=>"$company",
							'user_type'=>"$sub_user_type",
							'sub_username'=>"$sub_username",
							'password'=>"$password",
							'status'=>"$status",
							'name'=>"$name",
							'post'=>"$post",
							'id_no'=>"$id_no",
							'date'=>"$var_date"],
							"sssssissss",
							["<h1 class=\"client_login_title\">User Added Successfully</h1>",
							'']);
					}else{
						echo "<h1 class=\"client_login_title\">You can not add more user in this pakage.Please update your pakage</h1>";
						
					}
				}else{
					echo "<h1 class=\"client_login_title\">Your software is expired. Please update year</h1>";
				
				}
				
				
			}else{
				
				echo "<h1 class=\"client_login_title\">No client</h1>";
			}
		}
	}else{
	 echo "<h1 class=\"client_login_title\">Password not match</h1>";
	}
}else{
    echo "<h1 class=\"client_login_title\">Some Fields Empty</h1>";
}

header( "refresh:2;url=super_admin.php" );
}else{
	echo "<h1 class=\"client_login_title\">Please <a href=\"login.php\" >Login</a></h1>";
}
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="javascript.js"></script>
</body>
</html>