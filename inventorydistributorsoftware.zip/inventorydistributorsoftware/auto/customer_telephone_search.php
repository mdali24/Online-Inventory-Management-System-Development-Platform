<?php
include_once('db.php');
$zero=0;
if (isset($_GET['term'])){
	$term=$_GET['term'];
	$company=$_GET['company'];
	$term=substr($term,1,10);
	$return_arr = array();

	try {
		$conn = new PDO("mysql:host=localhost;dbname=$db", $user, $pass);
		
	    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	    
	    $stmt = $conn->prepare("SELECT vendor_telephone_no FROM company_markenter_onserial WHERE company_username=$company and status=1 and type='customer' and  vendor_telephone_no LIKE :term limit 0,10");
	    $stmt->execute(array('term' => '%'.$_GET['term'].'%'));
	    
	    while($row = $stmt->fetch()) {
	        $return_arr[] = $zero.$row['vendor_telephone_no'];
	    }

	} catch(PDOException $e) {
	    echo 'ERROR: ' . $e->getMessage();
	}


    /* Toss back results as json encoded array. */
    echo json_encode($return_arr);
}


?>