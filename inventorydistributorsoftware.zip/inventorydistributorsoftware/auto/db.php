<?php 
$user='itbangladiller';
$pass='peu7tl6sr';
$db='itbanglainventorydistributorsoftware';
?>