<div class="container-fluid header_class">
		<div class="row">
			<div class="col-md-6 col-sm-6">
				
					<h1 class="main_h1">itBangla Inventory</h1>
				
				
			</div>
			<div class="col-md-6  col-sm-6">
				<p class="tagline">Outstanding Business Management</p>
			</div>
			
			
		</div>
	</div>
	<div class="container-fluid border_bottom">
			
	</div>