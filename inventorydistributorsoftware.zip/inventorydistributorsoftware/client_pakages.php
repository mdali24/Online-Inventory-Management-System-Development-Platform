<?php 

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Choose Your Plan</title>
 
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
   
     <link href="design.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="../inventory-software.png">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
	<div class="container-fluid header_class_2">
		<div class="row">
			<div class="col-md-6 col-sm-6">
				
					<h1 class="main_h1_2">itBangla Inventory</h1>
				
				
			</div>
			<div class="col-md-6  col-sm-6">
				<p style="color:#fff;" class="tagline">Outstanding Business Management</p>
			</div>
			
			
		</div>
	</div>
    <div class="container-fluid border">
		<div class="row">
			<div class="col-md-3 col-sm-3">
				<div class="pakage">
					<h3 class="pakage_title">Free Edition</h3>
					<h4 class="pakage_sub_title">Features</h4>
					<ol class="create_account_feature">
						<li>Upto 10 purchase invoice per month</li>
						<li>Upto 10 sell invoice per month</li>
						<li>Unlimited order</li>
						<li>1 users</li>
						<li>1 warehouse</li>
						<li>Unlimited access</li>
						
					</ol>
					
					<h4 class="pakage_sub_title">Price : <span class="software_price">Free</span></h4>
					<div class="form-group style_class">
						<label for="year" class="years" >Select Years:</label>
						<select class="form-control" id="free_year">
							<option>1</option>
							<option>2</option>
							<option>3</option>
							<option>4</option>
							<option>5</option>
							<option>6</option>
							<option>7</option>
							<option>8</option>
							<option>9</option>
							<option>10</option>
							<option>11</option>
							<option>12</option>
							<option>13</option>
							<option>14</option>
							<option>15</option>
							<option>16</option>
							<option>17</option>
							<option>18</option>
							<option>19</option>
							<option>20</option>
						</select>
					</div>
					<div class="select_button_container"><button type="button" class="btn btn-outline-primary button_select free_edition" data-toggle="modal" data-target="#myModal">Select</button></div>
				</div>
			</div>
			<div class="col-md-3 col-sm-3">
				<div class="pakage">
					<h3 class="pakage_title">Silver</h3>
					<h4 class="pakage_sub_title">Features</h4>
					<ol class="create_account_feature">
						<li>Upto 3000 purchase invoice per month</li>
						<li>Upto 3000 sell invoice per month</li>
						<li>Unlimited order</li>
						<li>Upto 5 users</li>
						<li>1 warehouse</li>
						<li>Unlimited access</li>
					
					</ol>
					
					<h4 class="pakage_sub_title">Price : <span class="software_price">$299</span>/per year</h4>
					<div class="form-group style_class">
						<label for="year" class="years">Select Years:</label>
						<select class="form-control" id="standard_year">
							<option>1</option>
							<option>2</option>
							<option>3</option>
							<option>4</option>
							<option>5</option>
							<option>6</option>
							<option>7</option>
							<option>8</option>
							<option>9</option>
							<option>10</option>
							<option>11</option>
							<option>12</option>
							<option>13</option>
							<option>14</option>
							<option>15</option>
							<option>16</option>
							<option>17</option>
							<option>18</option>
							<option>19</option>
							<option>20</option>
						</select>
					</div>
					<div class="select_button_container"><button type="button" class="btn btn-outline-primary button_select standard_edition" data-toggle="modal" data-target="#myModal">Select</button></div>
				</div>
			</div>
			<div class="col-md-3 col-sm-3">
				<div class="pakage">
					<h3 class="pakage_title">Gold</h3>
					<h4  class="pakage_sub_title">Features</h4>
					<ol class="create_account_feature">
						<li>Upto 30000 purchase invoice per month</li>
						<li>Upto 30000 sell invoice per month</li>
						<li>Unlimited order</li>
						<li>Upto 50 users</li>
						<li>Upto 5 warehouse</li>
						<li>Unlimited access</li>
						
					</ol>
					
					<h4 class="pakage_sub_title">Fee : <span class="software_price">$599</span>/per year</h4>
					<div class="form-group style_class">
						<label for="year" class="years">Select Years:</label>
						<select class="form-control" id="extended_year">
							<option>1</option>
							<option>2</option>
							<option>3</option>
							<option>4</option>
							<option>5</option>
							<option>6</option>
							<option>7</option>
							<option>8</option>
							<option>9</option>
							<option>10</option>
							<option>11</option>
							<option>12</option>
							<option>13</option>
							<option>14</option>
							<option>15</option>
							<option>16</option>
							<option>17</option>
							<option>18</option>
							<option>19</option>
							<option>20</option>
						</select>
					</div>
					<div class="select_button_container"><button type="button" class="btn btn-outline-primary button_select extended_edition" data-toggle="modal" data-target="#myModal">Select</button></div>
				</div>
			</div>
			<div class="col-md-3 col-sm-3">
				<div class="pakage">
					<h3 class="pakage_title">Diamond</h3>
					<h4 class="pakage_sub_title">Features</h4>
					<ol class="create_account_feature">
						<li>Upto 1000000 purchase invoice per month</li>
						<li>Upto 1000000 sell invoice per month</li>
						<li>Unlimited order</li>
						<li>Upto 50 warehourse</li>
						<li>Upto 1000 users</li>
						<li>Unlimited access</li>
						
					</ol>
					
					<h4 class="pakage_sub_title">Price : <span class="software_price">$999</span>/per year</h4>
					
					<div class="form-group style_class">
						<label for="year" class="years">Select Years:</label>
						<select class="form-control" id="expand_year">
							<option>1</option>
							<option>2</option>
							<option>3</option>
							<option>4</option>
							<option>5</option>
							<option>6</option>
							<option>7</option>
							<option>8</option>
							<option>9</option>
							<option>10</option>
							<option>11</option>
							<option>12</option>
							<option>13</option>
							<option>14</option>
							<option>15</option>
							<option>16</option>
							<option>17</option>
							<option>18</option>
							<option>19</option>
							<option>20</option>
						</select>
					</div>
					<div class="select_button_container"><button type="button" class="btn btn-outline-primary button_select expand_edition" data-toggle="modal" data-target="#myModal">Select</button></div>
				</div>
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<!-- Modal -->
		<div class="modal fade" id="myModal" role="dialog">
			<div class="modal-dialog">
			
				<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h6 class="modal-title">Total : $ <span  class="total_cost"></span> Discount : $ <span  class="total_discout">0%</span> Net : $  <span  class="net_cost">0</span> </h6>
					</div>
					<div class="modal-body">
						<!--<div class="panel-heading">
			    		<h3 class="panel-title"></h3>
			 			</div>-->
			 			<div class="panel-body">
			    		<form action="payments.php" role="form" method="POST">
							<div class="row">
			    				<input type="hidden" name="total_cost" class="total_cost_input" >
								<input type="hidden" name="total_discout" class="total_discout_input">
								<input type="hidden" name="net_cost" class="net_cost_input">
								<input type="hidden" name="year" class="year_input">
								<input type="hidden" name="software_pakage" class="software_pakage_input">
			    			</div>
							<div class="row">
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<h6>Software Pakage : <span class="pakage_name"></span></h6>
			    				</div>
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<h6>For year : <span class="pakage_year"></span></h6>
			    				</div>
			    			</div>
			    			<div class="row">
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
			                <input type="text" name="first_name" id="first_name" class="form-control input-sm" placeholder="First Name">
			    					</div>
			    				</div>
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
			    						<input type="text" name="last_name" id="last_name" class="form-control input-sm" placeholder="Last Name">
			    					</div>
			    				</div>
			    			</div>

							<div class="form-group">
			    				<input type="text" name="address" id="address" class="form-control input-sm" placeholder="Short Address">
			    			</div>
							
			    			<div class="form-group">
			    				<input type="email" name="email" id="email" class="form-control input-sm" placeholder="Email Address">
			    			</div>

			    			<div class="row">
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
			    						<input type="password" name="password" id="password" class="form-control input-sm" placeholder="Password">
			    					</div>
			    				</div>
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
			    						<input type="password" name="password_confirmation" id="password_confirmation" class="form-control input-sm" placeholder="Confirm Password">
			    					</div>
			    				</div>
			    			</div>
			    			
			    			<input type="submit" value="Register" class="btn btn-info btn-block register_account">
			    		
			    		</form>
			    	</div>
	    		</div>
				</div>
			</div>
		</div>
	</div>
	
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="border_outsite">
					<h5 class="key_msg">Your business smartness is one of the main key to your business success</h5>
					
				</div>
			</div>
		</div>
	</div>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<script src="javascript.js"></script>
  </body>
</html>