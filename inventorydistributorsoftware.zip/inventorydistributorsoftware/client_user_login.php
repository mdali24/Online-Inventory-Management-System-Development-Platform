<?php 

?>
<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>User Login Form</title>
  	<!-- Bootstrap -->
    	<link href="css/bootstrap.min.css" rel="stylesheet">
      <link rel="stylesheet" href="design.css">
     
</head>

<body>
  <div class="container-fluid header_class_2">
		<div class="row">
			<div class="col-md-6 col-sm-6">
				
					<h1 class="main_h1_2">itBangla Inventory</h1>
				
				
			</div>
			<div class="col-md-6  col-sm-6">
				<p style="color:#fff;" class="tagline">Outstanding Business Management</p>
			</div>
			
			
		</div>
	</div>
	<div class="container-fluid border_bottom">
			
	</div>
  <h1 style="visibility:hidden;" class="client_login_title">User Login</h1>
<form  action="software.php" method="POST" class="login">
<input type="text"  class="client_login_input  "  name="company_username" placeholder="Company username">
<input type="text"  class="client_login_input  "  name="sub_username" placeholder="Username">
<input type="password"  class="client_login_input  "  name="user_pass" placeholder="Password">
<input type="submit" value="Login"   class="client_login_submit">
</form>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="javascript.js"></script>
</body>
</html>