<?php 
include_once('db.php');
session_start();
session_regenerate_id(TRUE);
if(isset($_SESSION['customer_email_session']) and isset($_SESSION['customer_type_session'])){
	$customer_email=$_SESSION['customer_email_session'];
	$customer_type=$_SESSION['customer_type_session'];
	echo "Customer dashboard";
?>
<?php 
}else{
    echo "Please <a href=\"markenter_login.php\" >Login</a>";
}
?>