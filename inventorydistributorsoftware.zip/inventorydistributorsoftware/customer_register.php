<?php 

?>
<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Customer Create Account</title>
  	<!-- Bootstrap -->
    	<link href="css/bootstrap.min.css" rel="stylesheet">
      <link rel="stylesheet" href="design.css">
     
</head>

<body>
  <?php include_once('client_header.php');?>
  <h1 class="client_login_title">Customer create account : Free</h1>
<form  action="customer_register_action.php" method="POST" class="login">
<input type="email"  class="client_login_input"  name="customer_email" placeholder="Email">
<input type="password"  class="client_login_input"  name="customer_pass" placeholder="Password">
<input type="password"  class="client_login_input"  name="customer_pass_con" placeholder="Password Confarmation">
<input type="submit" value="Register"   class="client_login_submit">
</form>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="javascript.js"></script>
</body>
</html>

