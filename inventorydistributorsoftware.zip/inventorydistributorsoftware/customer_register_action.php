<?php 
include_once('db.php');
include_once('method.php');
$var_date=date('y/m/d');
$empty_check=array();
if(!empty($_POST['customer_email'])){
$customer_email=$_POST['customer_email'];
}else{
$empty_check[]="empty customer_email";
}
if(!empty($_POST['customer_pass'])){
$customer_pass=$_POST['customer_pass'];
}else{
$empty_check[]="empty customer_pass";
}
if(!empty($_POST['customer_pass_con'])){
$customer_pass_con=$_POST['customer_pass_con'];
}else{
$empty_check[]="empty customer_pass_con";
}

if($customer_pass==$customer_pass_con){
$customer_pass=md5($customer_pass);
if(empty($empty_check)){
if($stmt_sql = $mysqli->prepare("SELECT * FROM customer_onserial WHERE email=?")){
		
		$stmt_sql->bind_param("s",$customer_email);
		$stmt_sql->execute();
		$stmt_sql->store_result();
		$rows_num=$stmt_sql->num_rows;
		$f=0;
		if($rows_num<1){
		
		$email_c=md5($customer_email.time());
		$new_customer_add=new data;
		$new_customer_add->insert(
		"customer_onserial",
		['user_type'=>"Customer",
		'email'=>"$customer_email",
		'password'=>"$customer_pass",
		'email_con'=>"$email_c",
		'forgot_pass'=>"0",
		'status'=>"$f",
		'date'=>"$var_date"],
		"sssssis",
		['',
		'']);
			$c_url="http://inventorysoftwareservices.com/new/customer_emailconfarmation.php?token=$email_c";
			$msg="Confirm your email $c_url";
			if(mail($customer_email,"inventorysoftwareservices.com email confarmation",$msg,"Do not Reply")){
					echo "You are registered Successfully"."<br/>";
					echo "Please confirm your email";
					
				}
		}else{
		  echo "This email already has an account. Please <a href=\"markenter_login.php\">login</a>";
		}
	}

	}else{
		 echo "Some fields empty";
	}
}else{
	
	echo "Password is not match";
	}
?>