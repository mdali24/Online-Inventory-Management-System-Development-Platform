<?php
define("SERVERNAME", "localhost");
define("USERNAME", "itbangladiller");
define("PASSWORD", "peu7tl6sr");
define("DBNAME", "itbanglainventorydistributorsoftware");
global $mysqli;
$mysqli = new mysqli(SERVERNAME, USERNAME, PASSWORD, DBNAME);

if ($mysqli->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
?>