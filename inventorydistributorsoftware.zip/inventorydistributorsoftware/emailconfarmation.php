<?php
include_once('db.php');
if(isset($_GET['token'])){
$email_c=$_GET['token'];
if($stmt_sql = $mysqli->prepare("SELECT * FROM login_onserial WHERE email_c=?")){
		
		$stmt_sql->bind_param("s",$email_c);
		$stmt_sql->execute();
		$stmt_sql->store_result();
		$rows_num=$stmt_sql->num_rows;
		if($rows_num>0){
			$stmt = $mysqli->prepare("UPDATE login_onserial SET 
			status=?
			 WHERE email_c=?");
			$ok=1;		
			$stmt->bind_param('is', $ok, $email_c);
				$update_status = $stmt->execute();
				if($update_status==1){
					 echo "Payment Successfully.Please <a href=\"login.php\">login</a>";
				}
		}else{
			echo "Wrong Token";
		}
}
}else{
	echo "Please Register";
}

?>