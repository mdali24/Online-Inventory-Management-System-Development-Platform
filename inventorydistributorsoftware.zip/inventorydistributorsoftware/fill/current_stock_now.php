<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include_once('../db.php');

if(!empty($_POST['company_use'])){
	$company_use=$_POST['company_use'];

if(!empty($_POST['product_id'])){
	$product_id=$_POST['product_id'];

    	if($stmt_sql = $mysqli->prepare("SELECT product_id,total_purchase,current_stock,total_sell,purchase_return,sell_return,damage,warranty,sell_warranty FROM stock_now_onserial WHERE company_username=? and  product_id=?")){
						
					$stmt_sql->bind_param("ss",$company_use,$product_id);
					$stmt_sql->execute();
					$stmt_sql->store_result();
					$num_of_rows_now = $stmt_sql->num_rows;
					
					$stmt_sql->bind_result($product_id,$total_purchase,$current_stock,$total_sell,$purchase_return,$sell_return,$damage,$warranty,$sell_warranty);
					$total_product_value=0;
					if($num_of_rows_now > 0){
					    $stmt_sql->fetch();
					    echo $current_stock;
					}
					
    	}

}
}

?>