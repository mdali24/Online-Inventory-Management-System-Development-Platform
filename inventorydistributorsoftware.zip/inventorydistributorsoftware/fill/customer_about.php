<?php 
header('Content-Type: text/html; charset=utf-8');
include('../db.php');
session_start();
session_regenerate_id(TRUE);
if(!empty($_POST['key'])){
	$token_one=$_POST['token_one'];
	if (isset($_SESSION['csrf_token']) and $token_one==$_SESSION['csrf_token']) {

	$key=htmlspecialchars($_POST['key']);
	$focus=htmlspecialchars($_POST['focus']);
	$company=htmlspecialchars($_POST['company']);
	$company_now=$company;
	if($focus=='mobile_no'){
	$field='vendor_mobile_no';
	}else if($focus=='vendor_email'){
	$field='markenter_email';
	}else if($focus=='telephone_no'){
	$field='vendor_telephone_no';
	}else{
	
	}
	$type="customer";
	$status=1;
	$query = "SELECT markenter_email,vendor_mobile_no,vendor_telephone_no,full_name,vendor_address,vendor_company_name,vendor_debit_limit,vendor_debit_days,sn,dsr_code,dsr_name,market FROM company_markenter_onserial WHERE company_username=? and $field=? and status=? and type=?"; 

	if($stmt = $mysqli->prepare($query)){
	if($focus=='vendor_email'){
	    	$stmt->bind_param("ssis", $company,$key,$status,$type);
	    }else{
	    	$stmt->bind_param("siis", $company,$key,$status,$type);
	    	
	    }
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($markenter_email,$vendor_mobile_no,$vendor_telephone_no,$full_name,$vendor_address,$vendor_company_name,$vendor_debit_limit,$vendor_debit_days,$sn,$dsr_code,$dsr_name,$market);
	$stmt->fetch();
	if($num_of_rows>0){
		echo "<span id=\"email_get\">".$markenter_email."</span>";
		echo "<span id=\"mobile_get\">".$vendor_mobile_no."</span>";
		echo "<span id=\"telephone_get\">".$vendor_telephone_no."</span>";
		echo "<span id=\"name_get\">".$full_name."</span>";
		echo "<span id=\"address_get\">".$vendor_address."</span>";
		echo "<span id=\"company_get\">".$vendor_company_name."</span>";
		echo "<span id=\"debit_limit_get\">".$vendor_debit_limit."</span>";
		echo "<span id=\"debit_days_get\">".$vendor_debit_days."</span>";
		echo "<span id=\"dsr_code_get\">".$dsr_code."</span>";
		echo "<span id=\"dsr_name_get\">".$dsr_name."</span>";
		echo "<span id=\"market_get\">".$market."</span>";
		echo "<span id=\"serial_id_get\">".$sn."</span>";
	}
	
	$stmt->free_result();
		$stmt->close();
	}
	}else{
	  ?>
	  <script>alert("Unautorized Request");</script>
	  <?php
	}
	
}else{
	echo "Empty key";
}
if (isset($_SESSION['csrf_token'])){
		unset($_SESSION['csrf_token']);
	}
?>

  <?php
	$query = "SELECT customer_primary_key FROM companies_onserial WHERE company_username=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$company_now);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($customer_primary_key);
	$stmt->fetch();
	if($customer_primary_key=='Email'){
		$customer_primary_key='markenter_email';
	}else if($customer_primary_key=='Mobile'){
		$customer_primary_key='vendor_mobile_no';
	}else if($customer_primary_key=='Telephone'){
		$customer_primary_key='vendor_telephone_no';
	}
	}
	
	
		$invoice_type_filter="(invoice_type='sell_invoice' or invoice_type='sell_payment' or invoice_type='sell_return_invoice')";
	
	
			$query_vendor = "SELECT sn FROM company_markenter_onserial WHERE company_username=? and $customer_primary_key=? and type='customer'";

			if($stmt_vendor = $mysqli->prepare($query_vendor)){
				if($customer_primary_key=='markenter_email'){
					$stmt_vendor->bind_param('ss',$company_now,$key);
				}else{
					$stmt_vendor->bind_param('si',$company_now,$key);
				}
			$stmt_vendor->execute();
			$stmt_vendor->store_result();
			$num_of_rows = $stmt_vendor->num_rows;
			$stmt_vendor->bind_result($customer_serial);
			$stmt_vendor->fetch();
			$customer_filter="and  customer_serial=$customer_serial";
			}
	
	$num_of_rows_now=0;

				 
					
					if($stmt_sql = $mysqli->prepare("SELECT total,payment,due,net FROM invoice_summary_onserial WHERE company_username=? and status=1 and $invoice_type_filter $customer_filter ORDER BY sn DESC")){
						
					$stmt_sql->bind_param("s",$company_now);
					$stmt_sql->execute();
					$stmt_sql->store_result();
					$num_of_rows_now = $stmt_sql->num_rows;
					
					$stmt_sql->bind_result($total,$payment,$due,$net);
					if($num_of_rows_now > 0){
						$sn=1;
						$grand_total=0;
						$grand_payment=0;
						$grand_due=0;
						$grand_net=0;
						while($stmt_sql->fetch()){
							$grand_total+=$total;
							$grand_payment+=$payment;
							$grand_due+=$due;
							$grand_net+=$net;
							$sn++;
							}
					}else{
						echo "";
					}
					
					}
					
	$invoice_type_filter="(invoice_type='sell_order_invoice' and order_to_invoice_status='no')";
	if($stmt_order = $mysqli->prepare("SELECT invoice_no,invoice_type,bill,discount,total,payment,date,due,due_payment_date,net FROM invoice_summary_onserial WHERE company_username=? and status=1 and $invoice_type_filter $customer_filter ORDER BY sn DESC")){
	$stmt_order->bind_param("s",$company_now);
	$stmt_order->execute();
	$stmt_order->store_result();
	$num_of_order_rows = $stmt_order->num_rows;
	$stmt_order->bind_result($order_no,$invoice_type,$bill,$discount,$total,$payment,$date,$due,$due_payment_date,$net);
		$grand_payment_order=0;
		if($num_of_order_rows > 0){
			while($stmt_order->fetch()){
				$grand_payment_order+=$payment;
			}
		}
	}
	?>
	
			<?php 
			if($num_of_rows_now > 0){
				$total_payment=$grand_payment_order+$grand_payment;
				if($grand_total<$total_payment){
					$balance=$total_payment-$grand_total;
				}else{
					$balance=0;
				}
				echo "<span class=\"previous_business\"><h5 class=\"purchase_brief\">"."Total Sell : ".$grand_total." and Order Payment : ".$grand_payment_order." and Payment : ".$total_payment." and Due: ".$grand_due." and Balance: ".$balance."</h5></span>";
				
			}else{
				echo "";
			}
			?>
	