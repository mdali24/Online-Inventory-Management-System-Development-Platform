<?php 
session_start();
session_regenerate_id(TRUE);
include('../db.php');

if(!empty($_POST['key'])){
	$token_two=$_POST['token_two'];
	if (isset($_SESSION['csrf_token']) and $token_two==$_SESSION['csrf_token']) {
	$key=$_POST['key'];
	$focus=$_POST['focus'];
	$company=$_POST['company'];
	$vendor=$_POST['vendor'];
	if($focus=='invoice_edit'){
	$field='invoice_no';
	}
	$invoice_type="sell_payment";
	$query = "SELECT date,customer_serial,delivary_date,bill,discount,total,payment,payment_method,bank_name,account_no,due,due_payment_date,tax,carring_cost,others_cost,intensive,net,remarks,sub_user FROM invoice_summary_onserial WHERE company_username=? and $field=? and invoice_type=?"; 

	if($stmt = $mysqli->prepare($query)){
	
	   $stmt->bind_param("sss", $company,$key,$invoice_type);
	    
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($date,$customer_serial,$delivary_date,$bill,$discount,$total,$payment,$payment_method,$bank_name,$account_no,$due,$due_payment_date,$tax,$carring_cost,$others_cost,$intensive,$net,$remarks,$sub_user);
	$stmt->fetch();
	
	if($num_of_rows>0){
		echo "<span id=\"date_take\">".$date."</span>";
		$customer_serial=$customer_serial;
		echo "<span id=\"delivary_date_take\">".$delivary_date."</span>";
		echo "<span id=\"bill_take\">".$bill."</span>";
		echo "<span id=\"discount_take\">".$discount."</span>";
		echo "<span id=\"total_take\">".$total."</span>";
		echo "<span id=\"payment_take\">".$payment."</span>";
		echo "<span id=\"payment_method_take\">".$payment_method."</span>";
		echo "<span id=\"bank_name_take\">".$bank_name."</span>";
		echo "<span id=\"account_no_take\">".$account_no."</span>";
		echo "<span id=\"due_take\">".$due."</span>";
		echo "<span id=\"due_payment_date_take\">".$due_payment_date ."</span>";
		echo "<span id=\"tax_take\">".$tax."</span>";
		
		echo "<span id=\"carring_cost_take\">".$carring_cost."</span>";
		echo "<span id=\"others_cost_take\">".$others_cost."</span>";
		echo "<span id=\"intensive_take\">".$intensive."</span>";
		echo "<span id=\"net_take\">".$net."</span>";
		echo "<span id=\"remarks_take\">".$remarks."</span>";
		echo "<span id=\"sub_user_take\">".$sub_user."</span>";
		$status_ok=1;
		$query_vendor = "SELECT markenter_email,vendor_mobile_no,vendor_telephone_no,full_name,vendor_address,vendor_company_name,	vendor_debit_limit,vendor_debit_days FROM company_markenter_onserial WHERE company_username=? and status=? and sn=?"; 
		if($stmt_vendor = $mysqli->prepare($query_vendor)){
		$stmt_vendor->bind_param("sii", $company,$status_ok,$customer_serial);
	    $stmt_vendor->execute();
		$stmt_vendor->store_result();
		$num_of_rows = $stmt_vendor->num_rows;
		$stmt_vendor->bind_result($markenter_email,$vendor_mobile_no,$vendor_telephone_no,$full_name,$vendor_address,$vendor_company_name,$vendor_debit_limit,$vendor_debit_days);
		$stmt_vendor->fetch();
		echo "<span id=\"markenter_email_took\">".$markenter_email."</span>";
		echo "<span id=\"vendor_mobile_no_took\">".$vendor_mobile_no."</span>";
		echo "<span id=\"vendor_telephone_no_took\">".$vendor_telephone_no."</span>";
		echo "<span id=\"full_name_took\">".$full_name."</span>";
		echo "<span id=\"vendor_address_took\">".$vendor_address."</span>";
		echo "<span id=\"vendor_company_name_took\">".$vendor_company_name."</span>";
		echo "<span id=\"vendor_debit_limit_took\">".$vendor_debit_limit."</span>";
		echo "<span id=\"vendor_debit_days_took\">".$vendor_debit_days."</span>";
		echo "<span id=\"vendor_id_took\">".$customer_serial."</span>";
		}
		$query_products = "SELECT product_name,product_id,quantity,size,products_company,	unit_price,sub_total,discount,net,tax,sell_price, warranty_days,warranty_days_type,serial_key_length,remarks FROM invoice_products_details_onserial WHERE company_username=? and invoice_no=? and invoice_type=?";
		if($stmt_products = $mysqli->prepare($query_products)){
		$stmt_products->bind_param("sis", $company,$key,$invoice_type);
	    $stmt_products->execute();
		$stmt_products->store_result();
		$num_of_rows = $stmt_products->num_rows;
		$stmt_products->bind_result($product_name,$product_id,$quantity,$size,$products_company,$unit_price,$sub_total,$discount,$net,$tax,$sell_price,$warranty_days,$warranty_days_type,$serial_key_length,$remarks);
		if($num_of_rows>0){
		echo "<div class='product_details_take'>";
		$serial=1;
		while($stmt_products->fetch()){
			echo "<div class='product_wrapper'>";
			echo "<div class='col-md-12 col-sm-12  product_title_heading'><span class='sn'>".$serial."</span><span class=''> Product Title : </span><span class='product_title_view'>".$product_name." ".$size."</span></div>";
			echo "<div class='col-md-6 col-sm-6'><div class='title_heading'>Product Name : </div><div class='product_name_view'>".$product_name."</div></div>";
			$product_id_current=$product_id;
			echo "<div class='col-md-6 col-sm-6'><div class='title_heading'>Product Id : </div><div class='product_id_view'>".$product_id."</div></div>";
			echo "<div class='col-md-6 col-sm-6 '><div class='title_heading'>Quantity : </div><input class='quantity_view' value='".$quantity."'></div>";
			$product_tax=($tax/$net)*100;
			echo "<input type='hidden' class='tax_percent_view' value='".$product_tax."'>";
			echo "<div class='col-md-6 col-sm-6'><div class='title_heading'>Size : </div><div class='size_view'>".$size."</div></div>";
			echo "<div class='col-md-6 col-sm-6'><div class='title_heading'>Products Company : </div><div class='products_company_view'>".$products_company."</div></div>";
			echo "<div class='col-md-6 col-sm-6'><div class='title_heading'>Unit Price : </div><div class='unit_price_view'>".$unit_price."</div></div>";
			echo "<div class='col-md-6 col-sm-6'><div class='title_heading'>Sub Total : </div><div class='sub_total_view'>".$sub_total."</div></div>";
			echo "<div class='col-md-6 col-sm-6'><div class='title_heading'>Discount : </div><div class='discount_view'>".$discount."</div></div>";
			echo "<div class='col-md-6 col-sm-6'><div class='title_heading'>Sub Net : </div><div class='sub_net_view'>".$net."</div></div>";
			echo "<div class='col-md-6 col-sm-6'><div class='title_heading'>Tax: </div><div class='tax_view'>".$tax."</div></div>";
			echo "<div class='col-md-6 col-sm-6'><div class='title_heading'>Sell Price : </div><div class='sell_price_view'>".$sell_price."</div></div>";
			echo "<div class='col-md-6 col-sm-6'><div class='title_heading'>Service days : </div><div class='warranty_guarantee_days_view'>".$warranty_days."</div></div>";
			echo "<div class='col-md-6 col-sm-6'><div class='title_heading'>Service Type : </div><div class='warranty_guarantee_type_view'>".$warranty_days_type."</div></div>";
			$remarks_len=strlen($remarks);
			if($remarks_len<0){
				$remarks="Empty";
			}
			echo "<div class='col-md-6 col-sm-6'><div class='title_heading'>Remarks : </div><div class='remarks_view'>".$remarks."</div></div>";
			echo "<div class='col-md-6 col-sm-6'><div class='title_heading'>Serial key length : </div>"."<div class='serial_key_length_view'>".$serial_key_length."</div>"."</div>"."<div class='col-md-5 col-sm-5 serial_key_add_view'>Add new Serial : </div>"."<input type='text' class='col-md-7 col-sm-7 serial_key_add'>";
			
			$serial++;
			$query_serials = "SELECT serial_key FROM invoice_products_serial_details_onserial WHERE product_id=? and company_username=? and invoice_no=? and invoice_type=?";
			if($stmt_serials = $mysqli->prepare($query_serials)){
			$stmt_serials->bind_param("isis",$product_id_current,$company,$key,$invoice_type);
			$stmt_serials->execute();
			$stmt_serials->store_result();
			$num_of_rows = $stmt_serials->num_rows;
			$stmt_serials->bind_result($serial_key);
			if($num_of_rows>0){
				$all_serials="";
				$serials_count=0;
				while($stmt_serials->fetch()){
					$all_serials=$all_serials."<div class='serial_add'>"."<span class='serial'>".$serial_key."</span>"."<span class='serial_remove_view'>"."X"."</span>"."</div>";
					$serials_count++;
				}
				echo "<div class='serials_view'><div class='col-md-12 col-sm-12'><div class='title_heading'>Serial keys : </div><div class='all_serials_view'><div class='serials_insert'>".$serials_count."</div>".$all_serials."</div></div></div>";
			}
			
			}
			echo "<a class='col-md-12 col-sm-12 remove_product'>Remove</a>";
			echo "</div>";
		}
		echo "</div>";
		}
		}
	}
	
	$stmt->free_result();
		$stmt->close();
	}
	}else{
	  ?>
	  <script> alert("Unauthorized Request");</script>
	  <?php
	}
}else{
	echo "Empty key";
}
if (isset($_SESSION['csrf_token'])){
		unset($_SESSION['csrf_token']);
	}
?>