<script>
	$(".search_vendor_class").click(function(){
	var serial=$(this).find(".serial").html();
	var name_pickup=$(this).find(".name_pickup").html();
	$("#full_name").val(name_pickup);
	var email_pickup=$(this).find(".email_pickup").html();
	$("#vendor_email").val(email_pickup);
	var mobile_pickup=$(this).find(".mobile_pickup").html();
	$("#mobile_no").val(mobile_pickup);
	var telephone_pickup=$(this).find(".telephone_pickup").html();
	$("#telephone_no").val(telephone_pickup);
	var company_pickup=$(this).find(".company_pickup").html();
	$("#company_name").val(company_pickup);
	var address_pickup=$(this).find(".address_pickup").html();
	$("#vendor_address").val(address_pickup);
	var debit_limit_pickup=$(this).find(".debit_limit_pickup").html();
	$("#debit_limit").val(debit_limit_pickup);
	var debit_days_pickup=$(this).find(".debit_days_pickup").html();
	$("#debit_days").val(debit_days_pickup);
	var serial_pickup=$(this).find(".serial_pickup").val();
	$("#serial_id").val(serial_pickup);
	$("#search_details").html("");
	$("#search_name").val("");
	$("#search_company").val("");
	$("#search_address").val("");
	$('#vendor_search').click();
	$(".overflow_top_left").scrollTop(0);
	var n=0;
	$(".about_vendor").find(":input:enabled").each(function() {
	if($(this).val() === ""){
	var i=$(this).attr('id');
	n++;
	}
	});
	if(n==0){
	$("#product_name").focus();
	}else{
	$(".about_vendor").find("input:enabled").filter(function () {
	return this.value.trim() == "";
	}).first().focus();
	}
	});				
</script>
<?php 
include('../db.php');

if(!empty($_POST['key'])){
	$key=$_POST['key'];
	$focus=$_POST['focus'];
	$company=$_POST['company'];
	
	if($focus=='search_name'){
	$field='full_name';
	}else if($focus=='search_company'){
	$field='vendor_company_name';
	}else if($focus=='search_address'){
	$field='vendor_address';
	}else{
	
	}
	$type="customer";
	$status=1;
	$query = "SELECT sn,full_name,markenter_email,vendor_mobile_no,vendor_telephone_no,vendor_company_name,vendor_address,vendor_debit_limit,vendor_debit_days FROM company_markenter_onserial WHERE company_username=? and $field=? and status=? and type=?"; 

	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param("ssis", $company,$key,$statu,$type);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($sn,$full_name,$markenter_email,$vendor_mobile_no,$vendor_telephone_no,$vendor_company_name,$vendor_address,$vendor_debit_limit,$vendor_debit_days);
	$serial=0;
	echo "<h3>Total :<span  id=\"total\"></span></h3>";
	if($num_of_rows>0){
		while ($stmt->fetch()){
			$serial++;
			echo "<button class=\"search_vendor_class vendor_view_button\">";
			echo "<div class=\"serial\">".$serial."</div>";
			echo "<div class=\"name_pickup\">".$full_name."</div>";
			echo "<div class=\"email_pickup\">".$markenter_email."</div>";
			echo "<div class=\"mobile_pickup\">".$vendor_mobile_no."</div>";
			echo "<div class=\"telephone_pickup\">".$vendor_telephone_no."</div>";
			echo "<div class=\"company_pickup\">".$vendor_company_name."</div>";
			echo "<div class=\"address_pickup\">".$vendor_address."</div>";
			echo "<div class=\"debit_limit_pickup\">".$vendor_debit_limit."</div>";
			echo "<div class=\"debit_days_pickup\">".$vendor_debit_days."</div>";
			echo "<input type=\"hidden\" class=\"serial_pickup\" value=\"$sn\">";
			echo "</button>";
		}
	}
	echo "<input type=\"hidden\" value=\"$serial\" id=\"total_pickup\">";
	
	
		$stmt->close();
	}
	
}else{
	echo "Empty key";
}

?>