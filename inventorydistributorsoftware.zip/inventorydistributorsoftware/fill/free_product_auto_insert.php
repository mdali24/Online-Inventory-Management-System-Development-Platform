<?php 
session_start();
session_regenerate_id(TRUE);
include('../db.php');

/*if(!empty($_POST['key'])){
	$token_four=$_POST['token_four'];
	if (isset($_SESSION['csrf_token']) and $token_four==$_SESSION['csrf_token']) {*/
	if(!empty($_POST['super_user_now'])){
		$super_user=$_POST['super_user_now'];
	}
	if(!empty($_POST['company_use_now'])){
		$company_use=$_POST['company_use_now'];
	}
	if(!empty($_POST['operator_now'])){
		$operator=$_POST['operator_now'];
	}
	if(!empty($_POST['product_id'])){
		$product_id=$_POST['product_id'];
	}
	if(!empty($_POST['quantity'])){
		$quantity=$_POST['quantity'];
	}
	if(!empty($_POST['product_id'])){
		$query_product_title = "SELECT product_name,size FROM products_details_onserial WHERE product_id=? and  company_username=?";
		if($stmt_free_with = $mysqli->prepare($query_product_title)){
	
		$stmt_free_with->bind_param("ss",$product_id,$company_use);
	    
		$stmt_free_with->execute();
		$stmt_free_with->store_result();
		$num_of_rows_free_with = $stmt_free_with->num_rows;
		$stmt_free_with->bind_result($product_name_free_with,$size_free_with);
		$stmt_free_with->fetch();
		$free_with=$product_name_free_with." ".$size_free_with;
		}
		$query = "SELECT sn,product_quantity,free_product_id,free_product_quantity FROM free_products_onserial WHERE product_id=? and  company_username=?"; 

	if($stmt_free = $mysqli->prepare($query)){
	
	   $stmt_free->bind_param("ss",$product_id,$company_use);
	    
	$stmt_free->execute();
	$stmt_free->store_result();
	$num_of_rows_free = $stmt_free->num_rows;
	$stmt_free->bind_result($sn,$product_quantity,$free_product_id,$free_product_quantity);
	//echo "free ".$num_of_rows_free;
	if($num_of_rows_free>0){
		$stmt_free->fetch();
		$free_product_now=$free_product_quantity/$product_quantity;
		$free_product_count=$free_product_now*$quantity;
		$free_product_count=round($free_product_count);
		$status=1;
	$query = "SELECT sn,product_name,rack_no,product_id,products_company,size,unit_price,tax,default_discount,sell_price,warenty_days,warenty_type,serial_length,remarks,pack_size FROM products_details_onserial WHERE company_username=? and product_id=? and status=?"; 

	if($stmt = $mysqli->prepare($query)){
	
	   $stmt->bind_param("sss", $company_use,$free_product_id,$status);
	    
		$stmt->execute();
		$stmt->store_result();
		$num_of_rows = $stmt->num_rows;
		$stmt->bind_result($sn,$product_name,$rack_no,$product_id,$products_company,$size,$unit_price,$tax,$default_discount,$sell_price,$warenty_days,$warenty_type,$serial_length,$remarks,$pack_size);
		//echo "product".$num_of_rows;
		//$product_id=$product_id;
		$serial="";
		if($num_of_rows>0){
			while($stmt->fetch()){
				if($num_of_rows<2){
					echo "<div class='product_wrapper'>";
			echo "<div class='col-md-12 col-sm-12  product_title_heading'><span class='sn'>".$serial."</span><span class=''> Product Title : </span><span class='product_title_view'>".$product_name." ".$size."</span></div>";
			echo "<div class='col-md-6 col-sm-6'><div class='title_heading'>Product Name : </div><div class='product_name_view'>".$product_name."</div></div>";
			$product_id_current=$product_id;
			echo "<div class='col-md-6 col-sm-6'><div class='title_heading'>Product Id : </div><div class='product_id_view'>".$product_id."</div></div>";
			echo "<div class='col-md-6 col-sm-6 '><div class='title_heading'>Quantity : </div><input class='quantity_view' value='".$free_product_count."'></div>";
			echo "<div class='col-md-6 col-sm-6'><div class='title_heading'>Free Product : </div><div class='free_product_view'>".""."</div></div>";
			echo "<div class='col-md-6 col-sm-6'><div class='title_heading'>Free With : </div><div class='free_with_view'>".$free_with."</div></div>";
			
			//$product_tax=($tax/$net)*100;
			$product_tax="";
			echo "<input type='hidden' class='tax_percent_view' value='".""."'>";
			echo "<div class='col-md-6 col-sm-6'><div class='title_heading'>Size : </div><div class='size_view'>".$size."</div></div>";
			echo "<div class='col-md-6 col-sm-6'><div class='title_heading'>Total Pack : </div><div class='total_pack_view'>".""."</div></div>";
			echo "<div class='col-md-6 col-sm-6'><div class='title_heading'>Pack Size : </div><div class='pack_size_view'>".""."</div></div>";
			echo "<div class='col-md-6 col-sm-6'><div class='title_heading'>loose Quantity : </div><div class='loose_quantity_view'>".$free_product_count."</div></div>";
			echo "<div class='col-md-6 col-sm-6'><div class='title_heading'>Payment Type : </div><div class='payment_type_view'>"."Free"."</div></div>";
			echo "<div class='col-md-6 col-sm-6'><div class='title_heading'>Products Company : </div><div class='products_company_view'>".$products_company."</div></div>";
			echo "<div class='col-md-6 col-sm-6'><div class='title_heading'>Unit Price : </div><div class='unit_price_view'>".$unit_price."</div></div>";
			$sub_total_now=$free_product_count*$unit_price;
			$sub_net_now=$free_product_count*$unit_price;
			echo "<div class='col-md-6 col-sm-6'><div class='title_heading'>Sub Total : </div><div class='sub_total_view'>".$sub_total_now."</div></div>";
			echo "<div class='col-md-6 col-sm-6'><div class='title_heading'>Discount : </div><div class='discount_view'>".""."</div></div>";
			echo "<div class='col-md-6 col-sm-6'><div class='title_heading'>Sub Net : </div><div class='sub_net_view'>".$sub_net_now."</div></div>";
			echo "<div class='col-md-6 col-sm-6'><div class='title_heading'>Tax: </div><div class='tax_view'>".""."</div></div>";
			echo "<div class='col-md-6 col-sm-6'><div class='title_heading'>Sell Price : </div><div class='sell_price_view'>".$sell_price."</div></div>";
			echo "<div class='col-md-6 col-sm-6'><div class='title_heading'>Service days : </div><div class='warranty_guarantee_days_view'>".$warenty_days."</div></div>";
			echo "<div class='col-md-6 col-sm-6'><div class='title_heading'>Service Type : </div><div class='warranty_guarantee_type_view'>".$warenty_type."</div></div>";
			$remarks_len=strlen($remarks);
			if($remarks_len<0){
				$remarks="Empty";
			}
			echo "<div class='col-md-6 col-sm-6'><div class='title_heading'>Remarks : </div><div class='remarks_view'>".""."</div></div>";
			echo "<div class='col-md-6 col-sm-6'><div class='title_heading'>Serial key length : </div>"."<div class='serial_key_length_view'>".$serial_length."</div>"."</div>"."<div class='col-md-5 col-sm-5 serial_key_add_view'>Add new Serial : </div>"."<input type='text' class='col-md-7 col-sm-7 serial_key_add'>";
			
			$serial++;
			$query_serials = "SELECT serial_key FROM invoice_products_serial_details_onserial WHERE product_id=? and company_username=? and invoice_no=? and invoice_type=?";
			if($stmt_serials = $mysqli->prepare($query_serials)){
			$stmt_serials->bind_param("isis",$product_id_current,$company,$key,$invoice_type);
			$stmt_serials->execute();
			$stmt_serials->store_result();
			$num_of_rows = $stmt_serials->num_rows;
			$stmt_serials->bind_result($serial_key);
			if($num_of_rows>0){
				$all_serials="";
				$serials_count=0;
				while($stmt_serials->fetch()){
					$all_serials=$all_serials."<div class='serial_add'>"."<span class='serial'>".$serial_key."</span>"."<span class='serial_remove_view'>"."X"."</span>"."</div>";
					$serials_count++;
				}
				echo "<div class='serials_view'><div class='col-md-12 col-sm-12'><div class='title_heading'>Serial keys : </div><div class='all_serials_view'><div class='serials_insert'>".$serials_count."</div>".$all_serials."</div></div></div>";
			}
			
			}
			echo "<a class='col-md-12 col-sm-12 remove_product'>Remove</a>";
			echo "</div>";
					
				} else{
				//	echo "<button id=\"$sn\" class=\"product_title_get\">".$product_name." ".$size"</button>";
				}
			}
		}
		$stmt->free_result();
			$stmt->close();
		}
	
	
	}
	}
	}
	
	/*}else{
	  ?>
	  <script> alert("Unauthorized Request");</script>
	  <?php
	}
	
}else{
	echo "Empty key";
}
if (isset($_SESSION['csrf_token'])){
		unset($_SESSION['csrf_token']);
	}*/
?>