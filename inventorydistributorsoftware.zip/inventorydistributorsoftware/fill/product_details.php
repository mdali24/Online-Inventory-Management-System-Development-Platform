<?php 
session_start();
session_regenerate_id(TRUE);
include('../db.php');

if(!empty($_POST['key'])){
	$token_four=$_POST['token_four'];
	if (isset($_SESSION['csrf_token']) and $token_four==$_SESSION['csrf_token']) {
	$key=$_POST['key'];
	$focus=$_POST['focus'];
	$company=$_POST['company'];
	$vendor=$_POST['vendor'];
	if($focus=='product_title'){
	$field='product_title';
	}else if($focus=='product_id'){
	$field='product_id';
	}else{
	
	}
	$status=1;
	$query = "SELECT sn,product_name,rack_no,product_id,products_company,size,unit_price,tax,default_discount,sell_price,warenty_days,warenty_type,serial_length,remarks,pack_size FROM products_details_onserial WHERE company_username=? and $field=? and status=?"; 

	if($stmt = $mysqli->prepare($query)){
	
	   $stmt->bind_param("sss", $company,$key,$status);
	    
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($sn,$product_name,$rack_no,$product_id,$products_company,$size,$unit_price,$tax,$default_discount,$sell_price,$warenty_days,$warenty_type,$serial_length,$remarks,$pack_size);
	
	//$product_id=$product_id;
	if($num_of_rows>0){
		while($stmt->fetch()){
			if($num_of_rows<2){
				//$stmt->fetch();
				echo "<span id=\"product_name_get\">".$product_name."</span>";
				echo "<span id=\"rack_no_get\">".$rack_no."</span>";
				echo "<span id=\"product_id_get\">".$product_id."</span>";
				echo "<span id=\"quantity_get\">"."1"."</span>";
				echo "<span id=\"size_get\">".$size."</span>";
				echo "<span id=\"products_company_get\">".$products_company."</span>";
				echo "<span id=\"unit_price_get\">".$unit_price."</span>";
				echo "<span id=\"product_tax_get\">".$tax."%</span>";
				echo "<span id=\"discount_get\">".$default_discount."</span>";
				echo "<span id=\"sell_price_get\">".$sell_price."</span>";
				echo "<span id=\"warranty_guarantee_days_get\">".$warenty_days."</span>";
				echo "<span id=\"warranty_guarantee_type_get\">".$warenty_type."</span>";
				echo "<span id=\"remarks_get\">".$remarks ."</span>";
				echo "<span id=\"serial_key_length_get\">".$serial_length."</span>";
				echo "<span id=\"pack_size_get\">".$pack_size."</span>";
				
				$query = "SELECT sn,product_quantity,free_product_id,free_product_quantity FROM free_products_onserial WHERE product_id=? and  company_username=?"; 

				if($stmt_free = $mysqli->prepare($query)){
				
				   $stmt_free->bind_param("ss",$product_id,$company);
					
				$stmt_free->execute();
				$stmt_free->store_result();
				$num_of_rows_free = $stmt_free->num_rows;
				$stmt_free->bind_result($sn,$product_quantity,$free_product_id,$free_product_quantity);
				//echo "free ".$num_of_rows_free;
				if($num_of_rows_free>0){
					$stmt_free->fetch();
					$query_free_product = "SELECT product_name,size FROM products_details_onserial WHERE company_username=? and product_id=?"; 
					if($stmt_free_product = $mysqli->prepare($query_free_product)){
						$stmt_free_product->bind_param("ss", $company,$free_product_id);
						$stmt_free_product->execute();
						$stmt_free_product->store_result();
						$num_of_rows_free_product = $stmt_free_product->num_rows;
						$stmt_free_product->bind_result($product_name_free_product,$size_free_product);
						if($num_of_rows_free_product>0){
							$stmt_free_product->fetch();
							echo "<span id=\"free_product_get\">".$product_name_free_product." ".$size_free_product."</span>";
						}else{
							echo "<span id=\"free_product_get\">$free_product_id</span>";
						}
					}
					
				}else{
					echo "<span id=\"free_product_get\"></span>";
				}
				}
				
			} else{
			//	echo "<button id=\"$sn\" class=\"product_title_get\">".$product_name." ".$size"</button>";
			}
		}
	}
	$stmt->free_result();
		$stmt->close();
	}
	}else{
	  ?>
	  <script> alert("Unauthorized Request");</script>
	  <?php
	}
	
}else{
	echo "Empty key";
}
if (isset($_SESSION['csrf_token'])){
		unset($_SESSION['csrf_token']);
	}
?>