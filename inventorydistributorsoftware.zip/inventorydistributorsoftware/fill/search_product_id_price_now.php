<?php 
include('../db.php');
if(!empty($_POST['product_id'])){
	$product_search=$_POST['product_id'];
}
if(!empty($_POST['company'])){
	$company_now=$_POST['company'];
}
if($stmt_sql = $mysqli->prepare("SELECT sell_price FROM products_details_onserial WHERE company_username=? and product_id=?")){
						
					$stmt_sql->bind_param("ss",$company_now,$product_search);
					$stmt_sql->execute();
					$stmt_sql->store_result();
					$num_of_rows_now = $stmt_sql->num_rows;
					
					$stmt_sql->bind_result($sell_price);
					if($num_of_rows_now > 0){
					$stmt_sql->fetch();
					echo $sell_price;
					}
					}
?>