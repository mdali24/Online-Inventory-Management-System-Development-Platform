<?php 
include('../db.php');
if(!empty($_POST['product_search'])){
	$product_search=$_POST['product_search'];
}
if(!empty($_POST['company'])){
	$company_now=$_POST['company'];
}
if(!empty($_POST['search_type'])){
	$search_type=$_POST['search_type'];
	if($search_type=="name"){
	 	$stmt_name = $mysqli->prepare("SELECT product_id FROM 	products_details_onserial WHERE company_username=? and  product_title=?"); 
		$stmt_name->bind_param("ss",$company_now,$product_search);
		$stmt_name->execute();
		$stmt_name->store_result();
		$num_of_rows = $stmt_name->num_rows;
		$stmt_name->bind_result($product_id );
		$stmt_name->fetch();
		$product_id=$product_id;
	}else{
		$product_id=$product_search;
	}
}
?>

	<div class="search_product_now"></div>
				  <div class="wrapper">
				  
					  <div class="table">
						
						<?php 
					if(isset($_GET["page"])){
						$page = intval($_GET["page"]);
					}else{
						$page=1;
					}
					$range=10;
					$start=($page*$range)-$range;
					$next=$page+1;
					$previus=$page-1;
					if($stmt_sql = $mysqli->prepare("SELECT product_id,total_purchase,current_stock,total_sell,purchase_return,sell_return,damage,warranty FROM stock_now_onserial WHERE company_username=? and product_id=? ORDER BY sn DESC  limit $start,$range")){
					
					$stmt_sql->bind_param("si",$company_now,$product_id);
					$stmt_sql->execute();
					$stmt_sql->store_result();
					$num_of_rows = $stmt_sql->num_rows;
					$stmt_sql->bind_result($product_id,$total_purchase,$current_stock,$total_sell,$purchase_return,$sell_return,$damage,$warranty);
					if($num_of_rows > 0){
						?>
					
						<div class="tb_header">
						  <div class="cell">
							Sn
						  </div>
						  <div class="cell">
							Product id
						  </div>
						  <div class="cell">
							Product title
						  </div>
						  <div class="cell">
							Buy
						  </div>
						  <div class="cell">
							Stock
						  </div>
						  <div class="cell">
							Sell
						  </div>
						  
						  <div class="cell">
							P.Return
						  </div>
						  <div class="cell">
							S.Return
						  </div>
						  <div class="cell">
							Damage
						  </div>
						  <div class="cell">
							Service
						  </div>
						</div>
						<?php
						$sn=1;
						while($stmt_sql->fetch()){
							echo "<div class=\"tb_row\">";
							echo "<div class=\"cell\">".$sn."</div>";
							echo "<div class=\"cell\">".$product_id."</div>";
							
							if($stmt_name = $mysqli->prepare("SELECT product_title FROM products_details_onserial WHERE company_username=? and  product_id=? ORDER BY sn DESC")) {
							$stmt_name->bind_param("ss",$company_now,$product_id);
							$stmt_name->execute();
							$stmt_name->store_result();
							$num_of_rows = $stmt_name->num_rows;
							$stmt_name->bind_result($product_title);
							$stmt_name->fetch();
							
							echo "<div class=\"cell\">".$product_title."</div>";
							}
							echo "<div class=\"cell\">".$total_purchase."</div>";
							echo "<div class=\"cell\">".$current_stock."</div>";
							echo "<div class=\"cell\">".$total_sell."</div>";
							echo "<div class=\"cell\">".$purchase_return."</div>";
							echo "<div class=\"cell\">".$sell_return."</div>";
							echo "<div class=\"cell\">".$damage."</div>";
							echo "<div class=\"cell\">".$warranty."</div>";
							echo "</div>";
							$sn++;
							}
					}else{
						echo "<div class=\"no_products\">";
							echo "Product '".$product_search."'  is not in stock";
						echo "</div>";
					}
					}
						?>
					  
					</div>
				  
				</div>