<?php 
include('../db.php');
if(!empty($_POST['product_title'])){
	$product_title=$_POST['product_title'];
}
if(!empty($_POST['company'])){
	$company_now=$_POST['company'];
}
if(!empty($_POST['vendor_key'])){
	$vendor_primary_key=$_POST['vendor_key'];
}

?>
	<div class="wrapper">
					  <div class="table">
						
						
					<?php 
					if($stmt_sql = $mysqli->prepare("SELECT product_title,product_id,products_company,unit_price,vendor_serial,	sell_price,warenty_type,warenty_days FROM products_details_onserial WHERE company_username=? and status=1 and product_title='$product_title' ORDER BY sn DESC")){
						
					$stmt_sql->bind_param("s",$company_now);
					$stmt_sql->execute();
					$stmt_sql->store_result();
					$num_of_rows_now = $stmt_sql->num_rows;
					
					$stmt_sql->bind_result($product_title,$product_id,$products_company,$unit_price,$vendor_serial,$sell_price,$warenty_type,$warenty_days);
					if($num_of_rows_now > 0){
					?>
					<div class="tb_header">
						  <div class="cell">
							Sn
						  </div>
						  <div class="cell">
							Product Title
						  </div>
						  <div class="cell">
							Product Id
						  </div>
						  <div class="cell">
							Products Company
						  </div>
						  <div class="cell">
							Unit Price
						  </div>
						  <div class="cell">
							Sell Price
						  </div>
						  <div class="cell">
							Servicing Type
						  </div>
						  <div class="cell">
							Servicing Days
						  </div>
						  <div class="cell">
							Vendor
						  </div>
						</div>
					<?php
						$sn=1;
						
						while($stmt_sql->fetch()){
							echo "<div class=\"tb_row\">";
							echo "<div class=\"cell\">".$sn."</div>";
							echo "<div class=\"cell\">".$product_title."</div>";
							echo "<div class=\"cell\">".$product_id."</div>";
							echo "<div class=\"cell\">".$products_company."</div>";
							echo "<div class=\"cell\">".$unit_price."</div>";
							echo "<div class=\"cell\">".$sell_price."</div>";
							echo "<div class=\"cell\">".$warenty_type."</div>";
							echo "<div class=\"cell\">".$warenty_days."</div>";
							if($stmt_name = $mysqli->prepare("SELECT full_name,$vendor_primary_key FROM company_markenter_onserial WHERE company_username=? and status='1' and sn=? ORDER BY sn DESC")) {
							$stmt_name->bind_param("si",$company_now,$vendor_serial);
							$stmt_name->execute();
							$stmt_name->store_result();
							$stmt_name->bind_result($full_name,$vendor_primary);
							echo "<div class=\"cell\">";
							while($stmt_name->fetch()){
								echo $full_name."<br/>";
								echo $vendor_primary."<br/>";
							}
							echo "</div>";
							}
							$sn++;
							echo "</div>";
							}
					}else{
						echo "<div class=\"tb_row\">";
							echo "None report created";
						echo "</div>";
					}
					}
						?>
					  
					</div>
				  
				</div>