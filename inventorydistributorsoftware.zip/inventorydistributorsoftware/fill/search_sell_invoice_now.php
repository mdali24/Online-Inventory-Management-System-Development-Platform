<?php 
include('../db.php');
if(!empty($_POST['invoice_no'])){
	$invoice_no=$_POST['invoice_no'];
}
if(!empty($_POST['company'])){
	$company_now=$_POST['company'];
}
?>

	<div class="wrapper">
					  <div class="table">
						
						
						<?php 
					
					$invoice_type="(invoice_type='sell_invoice' or invoice_type='sell_payment' or invoice_type='sell_return_invoice')";
					if($stmt_sql = $mysqli->prepare("SELECT invoice_no,invoice_type,bill,discount,total,payment,date,due,due_payment_date,net FROM invoice_summary_onserial WHERE company_username=? and invoice_no=? and status='1' and $invoice_type")){
						
					$stmt_sql->bind_param("si",$company_now,$invoice_no);
					$stmt_sql->execute();
					$stmt_sql->store_result();
					$num_of_rows = $stmt_sql->num_rows;
					$stmt_sql->bind_result($invoice_no,$invoice_type,$bill,$discount,$total,$payment,$date,$due,$due_payment_date,$net);
					if($num_of_rows > 0){
					?>
					<div class="tb_header">
						  <div class="cell">
							Sn
						  </div>
						  <div class="cell">
							Invoice No
						  </div>
						  <div class="cell">
							Type
						  </div>
						  <div class="cell">
							Products
						  </div>
						  <div class="cell">
							Bill
						  </div>
						  <div class="cell">
							Discount
						  </div>
						  
						  <div class="cell">
							Total
						  </div>
						  <div class="cell">
							Payment
						  </div>
						  <div class="cell">
							Date
						  </div>
						  <div class="cell">
							Due
						  </div>
						  
						  <div class="cell">
							Due Date
						  </div>
						  <div class="cell">
							Net
						  </div>
						</div>
					<?php
						$sn=1;
						while($stmt_sql->fetch()){
							echo "<div class=\"tb_row\">";
							echo "<div class=\"cell\">".$sn."</div>";
							//echo "<div class=\"cell\">"."<a class=\"software_purchase_details_link\" //href=\"software_purchase_details.php?invoice=$invoice_no\">".$invoice_no."</a>"."</div>";
							echo "<div class=\"cell\">".$invoice_no."</div>";
							if($invoice_type=='purchase_invoice'){
								$type="Purchase";
							}else if($invoice_type=='purchase_payment'){
								$type="Payment";
							}else if($invoice_type=='purchase_return_invoice'){
								$type="Return";
							}
							echo "<div class=\"cell\">".$type."</div>";
							
							if($stmt_name = $mysqli->prepare("SELECT product_name,size,quantity FROM invoice_products_details_onserial WHERE company_username=? and invoice_no=? and $invoice_type  ORDER BY sn DESC")) {
							$stmt_name->bind_param("si",$company_now,$invoice_no);
							$stmt_name->execute();
							$stmt_name->store_result();
							$num_of_rows = $stmt_name->num_rows;
							$stmt_name->bind_result($product_name,$size,$quantity);
							echo "<div class=\"cell\">";
							while($stmt_name->fetch()){
								echo $product_name." ".$size.",".$quantity."<br>";
							}
							echo "</div>";
							}
							
							echo "<div class=\"cell\">".$bill."</div>";
							echo "<div class=\"cell\">".$discount."</div>";
							echo "<div class=\"cell\">".$total."</div>";
							echo "<div class=\"cell\">".$payment."</div>";
							echo "<div class=\"cell\">".$date."</div>";
							echo "<div class=\"cell\">".$due."</div>";
							echo "<div class=\"cell\">".$due_payment_date."</div>";
							echo "<div class=\"cell\">".$net."</div>";
							echo "</div>";
							$sn++;
							}
					}else{
						echo "<div class=\"tb_row\">";
							echo "None report created";
						echo "</div>";
					}
					}
						?>
					  
					</div>
				  
				</div>