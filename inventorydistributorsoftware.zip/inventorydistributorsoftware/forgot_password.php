<?php 

?>
<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>User Forgot Password Form</title>
  
      <link rel="stylesheet" href="css/style.css">
      <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400,700">
      
</head>

<body>
  <html lang="en-US">
  <div class="container-fluid header_class">
	<div class="row">
		<div class="col-md-12">
			<h1><span class="soft">Soft19</span> Inventory</h1>
		</div>
	</div>
   </div>
   <div class="container-fluid border_bottom">
	<h2>For your business management , analysis and marketing</h2>		
   </div>
    <div id="login">
      <form name='form-login' action="forgot_password_email.php" method="POST">
		
        <span class="fontawesome-user"></span>
          <input type="text" id="user" name="user_email" placeholder="Email">
       
        <input type="submit" value="Send">
	
</form>

</body>
</html>
