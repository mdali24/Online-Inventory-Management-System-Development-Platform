<?php 
ob_start();
include_once('db.php');
include_once('method.php');
$var_date=date('y/m/d');
$empty_check=array();
if(!empty($_POST['user_email'])){
$user_email=$_POST['user_email'];
$user_type="Super";
}else{
$empty_check[]="empty Email";
}

$status=1;
if(empty($empty_check)){
	if($stmt_sql = $mysqli->prepare("SELECT * FROM login_onserial WHERE user_type=? and email=?")){
		
		$stmt_sql->bind_param("ss",$user_type,$user_email);
		$stmt_sql->execute();
		$stmt_sql->store_result();
		$rows_num=$stmt_sql->num_rows;
		if($rows_num>0){
			$email_c=md5($user_email.time());
			$stmt = $mysqli->prepare("UPDATE login_onserial SET 
			forgot_password=?
			 WHERE email=?");
			$ok=1;		
			$stmt->bind_param('ss', $email_c, $user_email);
				$update_status = $stmt->execute();
				if($update_status==1){
					 echo "";
				}
			$c_url="http://inventorysoftwareservices.com/new/forgot_password_action.php?token=$email_c";
			$msg="Click hree $c_url";
			if(mail($user_email,"inventorysoftwareservices.com email confarmation",$msg,"Do not Reply")){
					
					echo "Please go to your email.It may take sometime to receive your link";
					
				}
		}
	}
}else{
   echo "Some Fields Empty";
}
?>