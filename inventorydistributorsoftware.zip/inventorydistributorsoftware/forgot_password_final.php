<?php 
ob_start();
include_once('db.php');
include_once('method.php');
$var_date=date('y/m/d');
$empty_check=array();

if(!empty($_POST['user_pass'])){
$user_pass=md5($_POST['user_pass']);
}else{
$empty_check[]="empty user_pass";
}
if(!empty($_POST['forgot_pass'])){
$forgot_pass=$_POST['forgot_pass'];
}else{
$empty_check[]="Empty token";
}
$status=1;
if(empty($empty_check)){
	if($stmt_sql = $mysqli->prepare("SELECT * FROM login_onserial WHERE forgot_password=?")){
		
		$stmt_sql->bind_param("s",$forgot_pass);
		$stmt_sql->execute();
		$stmt_sql->store_result();
		$rows_num=$stmt_sql->num_rows;
		if($rows_num>0){
			$stmt = $mysqli->prepare("UPDATE login_onserial SET 
			password=?
			 WHERE forgot_password=?");
			$ok=1;		
			$stmt->bind_param('ss', $user_pass, $forgot_pass);
				$update_status = $stmt->execute();
				if($update_status==1){
					 echo "Password Change Successfully.Please <a href=\"login.php\">login</a>";
				}
		}
	}
}else{
   echo "Some Fields Empty";
}
?>