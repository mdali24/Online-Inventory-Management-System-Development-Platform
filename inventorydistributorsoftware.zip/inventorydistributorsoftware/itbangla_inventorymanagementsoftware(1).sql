-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 19, 2017 at 03:48 PM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `itbangla_inventorymanagementsoftware`
--

-- --------------------------------------------------------

--
-- Table structure for table `client_details_onserial`
--

CREATE TABLE `client_details_onserial` (
  `sn` int(11) NOT NULL,
  `email` varchar(32) NOT NULL,
  `first_name` varchar(32) NOT NULL,
  `last_name` varchar(32) NOT NULL,
  `address` varchar(128) NOT NULL,
  `date` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `client_details_onserial`
--

INSERT INTO `client_details_onserial` (`sn`, `email`, `first_name`, `last_name`, `address`, `date`) VALUES
(19, 'alphaomegafred@gmail.com', 'fred', 'alpha', 'alpha', '2017-08-31'),
(18, 'julioalfaror@hotmail.com', 'Julio', 'Alfaro', 'JirÃ³n Huancayo 177 Cercado de Lima', '2017-08-26'),
(17, 'globalbdjobs@gmqil.com', 'Habibd', 'Vi', 'Dhaka', '2017-07-25'),
(15, 'mdalibd100@gmail.com', 'Al', 'Hasnat', 'Dolgram', '2017-06-28'),
(16, 'ferdaus5028@gmail.com', 'Ujjol', 'vi', 'Dolgram', '2017-07-20'),
(14, 'mdaliceous@gmail.com', 'Mohammad', 'Ali', 'Rangpur', '2017-06-28'),
(20, 'behindthebadge523@gmail.com', 'Emily', 'Segura', 'P.O. Box 11631', '2017-09-03'),
(21, 'Info@uniqueent.in', 'info', 'Unique', 'Info@uniqueent.in', '2017-09-06'),
(22, 'anilshah999@hotmail.com', 'ANIL', 'SHAH', 'MUMBAI', '2017-09-06'),
(23, 'globalbdjobs@gmail.com', 'Habib', 'Rahman', 'Dhaka', '2017-09-07'),
(24, 'imti.anash@hotmail.com', 'IMTIYAZ', 'ALAM', 'doha', '2017-09-14'),
(25, 'mahesh.bhanderi13@gmail.com', 'mahesh', 'patel', 'jamnagar', '2017-09-14'),
(26, 'tipstricks99@gmail.com', 'Ali', 'Raza', 'lahore', '2017-09-15'),
(27, 'saravanan_kandasamy@outlook.com', 'Saravanan', 'K', '463 Jaya Nagar', '2017-09-16'),
(28, 'adilisohb95@gmail.com', 'adiyl', 'hb', 'zanzibar', '2017-09-18'),
(29, 'ntnatlosc@gmail.com', 'Neil', 'Ng.', 'ntnaltosc@gmail.com', '2017-09-25'),
(30, 'almadhakhobar@gmail.com', 'Hazif', 'Saj', 'Al Khobar Al Shamalia', '2017-09-28'),
(31, 'flowerpalace386@gmail.com', 'aung', 'win', 'yangon /myanmar', '2017-10-02');

-- --------------------------------------------------------

--
-- Table structure for table `companies_onserial`
--

CREATE TABLE `companies_onserial` (
  `sn` int(11) NOT NULL,
  `email` varchar(32) NOT NULL,
  `company_name` varchar(128) NOT NULL,
  `company_username` varchar(32) NOT NULL,
  `company_email` varchar(32) NOT NULL,
  `company_mobile` varchar(15) NOT NULL,
  `company_telephone` varchar(15) NOT NULL,
  `address` varchar(200) NOT NULL,
  `currency` varchar(32) NOT NULL,
  `status` int(1) NOT NULL,
  `date` date NOT NULL,
  `barcode` varchar(3) NOT NULL,
  `serial_key` varchar(3) NOT NULL,
  `vendor_register_required` varchar(3) NOT NULL,
  `customer_register_required` varchar(3) NOT NULL,
  `customer_product_discount` varchar(3) NOT NULL,
  `customer_final_discount` varchar(3) NOT NULL,
  `vendor_tax` varchar(32) NOT NULL,
  `customer_tax` varchar(32) NOT NULL,
  `vendor_primary_key` varchar(32) NOT NULL,
  `customer_primary_key` varchar(32) NOT NULL,
  `customer_debit_limit` varchar(3) NOT NULL,
  `customer_debit_days` varchar(32) NOT NULL,
  `company_timezone` varchar(64) NOT NULL,
  `customer_online_order_on` varchar(3) NOT NULL,
  `customer_online_auto_approved` varchar(3) NOT NULL,
  `purchase_invoice_msg` varchar(128) NOT NULL,
  `customer_invoice_msg` varchar(128) NOT NULL,
  `purchase_default_cursor` varchar(32) NOT NULL,
  `after_purchase_service` varchar(3) NOT NULL,
  `after_sell_service` varchar(3) NOT NULL,
  `sell_default_cursor` varchar(32) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `companies_onserial`
--

INSERT INTO `companies_onserial` (`sn`, `email`, `company_name`, `company_username`, `company_email`, `company_mobile`, `company_telephone`, `address`, `currency`, `status`, `date`, `barcode`, `serial_key`, `vendor_register_required`, `customer_register_required`, `customer_product_discount`, `customer_final_discount`, `vendor_tax`, `customer_tax`, `vendor_primary_key`, `customer_primary_key`, `customer_debit_limit`, `customer_debit_days`, `company_timezone`, `customer_online_order_on`, `customer_online_auto_approved`, `purchase_invoice_msg`, `customer_invoice_msg`, `purchase_default_cursor`, `after_purchase_service`, `after_sell_service`, `sell_default_cursor`) VALUES
(32, 'mdalibd100@gmail.com', 'Hasnat', 'hasnat', '', '0', '0', 'B.AD College', '', 1, '2017-06-28', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Mobile', 'Mobile', 'Yes', 'Yes', 'Asia/Dhaka', 'Yes', 'Yes', '', '', '', '', '', ''),
(31, 'mdaliceous@gmail.com', 'Amar Bangla', 'amar', '', '0', '0', '', '', 1, '2017-06-28', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Mobile', 'Mobile', 'Yes', 'Yes', 'Asia/Dhaka', 'Yes', 'Yes', '', '', '', '', '', ''),
(33, 'ferdaus5028@gmail.com', 'Ujjol', 'ujjol', '', '', '', '', '', 1, '2017-07-20', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Mobile', 'Mobile', 'Yes', 'Yes', 'Asia/Dhaka', 'Yes', 'Yes', '', '', '', '', '', ''),
(34, 'alphaomegafred@gmail.com', 'alpha', 'alpha', '', '', '', '', '', 1, '2017-08-31', 'Yes', 'Yes', 'No', 'No', 'No', 'No', 'No', 'No', 'Email', 'Email', 'No', 'No', 'America/New_York', 'No', 'No', '', '', '', '', '', ''),
(35, 'behindthebadge523@gmail.com', 'Behind The Badge Jewelry Gifts & More ', 'behindthebadge', '', '', '', '', '', 1, '2017-09-03', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'Email', 'Email', 'No', 'No', 'America/La_Paz', 'Yes', 'No', '', '', '', '', '', ''),
(36, 'anilshah999@hotmail.com', 'GANDHI TRADING CO', 'GTC', '', '', '', '', '', 1, '2017-09-06', 'Yes', 'Yes', 'No', 'No', 'Yes', 'No', 'Yes', 'Yes', 'Mobile', 'Mobile', 'Yes', 'No', 'Asia/Kolkata', 'No', 'No', '', '', '', '', '', ''),
(37, 'imti.anash@hotmail.com', 'QEMC', 'anash', '', '', '', '', '', 1, '2017-09-14', 'No', 'Yes', 'Yes', 'Yes', 'No', 'No', 'No', 'No', 'Mobile', 'Email', 'No', 'No', 'Asia/Qatar', 'Yes', 'No', '', '', '', '', '', ''),
(38, 'mr.farooq.ok@gmail.com', 'Hameed Sweets', 'hameed', '', '', '', '', '', 1, '2017-10-03', 'Yes', 'Yes', 'No', 'No', 'Yes', 'Yes', 'No', 'No', 'Mobile', 'Mobile', 'No', 'No', 'Asia/Karachi', 'No', 'No', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `company_markenter_onserial`
--

CREATE TABLE `company_markenter_onserial` (
  `sn` int(11) NOT NULL,
  `super_admin_email` varchar(32) NOT NULL,
  `company_username` varchar(32) NOT NULL,
  `markenter_email` varchar(32) NOT NULL,
  `status` int(1) NOT NULL,
  `date` date NOT NULL,
  `full_name` varchar(32) NOT NULL,
  `vendor_mobile_no` int(16) NOT NULL,
  `vendor_telephone_no` int(16) NOT NULL,
  `vendor_company_name` varchar(64) NOT NULL,
  `vendor_address` varchar(128) NOT NULL,
  `vendor_debit_limit` int(11) NOT NULL,
  `vendor_debit_days` int(11) NOT NULL,
  `sub_username` varchar(32) NOT NULL,
  `markenter_status` int(1) NOT NULL,
  `type` varchar(32) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company_markenter_onserial`
--

INSERT INTO `company_markenter_onserial` (`sn`, `super_admin_email`, `company_username`, `markenter_email`, `status`, `date`, `full_name`, `vendor_mobile_no`, `vendor_telephone_no`, `vendor_company_name`, `vendor_address`, `vendor_debit_limit`, `vendor_debit_days`, `sub_username`, `markenter_status`, `type`) VALUES
(149, 'mdalibd100@gmail.com', 'hasnat', '', 1, '2017-10-19', '', 1793858397, 0, '0', '', 0, 0, '', 0, 'customer'),
(148, 'mdalibd100@gmail.com', 'hasnat', 'mehedi222@gmail.com', 1, '2017-10-19', 'mehedi', 1792822459, 554652, 'btcrl,telicom company', 'dhap,ct,bazr', 0, 0, '', 0, 'vendor'),
(147, 'mdalibd100@gmail.com', 'hasnat', 'marufrabbi38583@gmail.com', 1, '2017-10-19', 'ashik', 1724389834, 5565532, 'RFL', 'dhap,co,bazar.', 0, 0, '', 0, 'vendor'),
(146, 'mdalibd100@gmail.com', 'hasnat', 'habib783758926@gmail.com', 1, '2017-10-19', 'limon', 1788177003, 553216, 'mrl limon', 'sio bajar,rangpur.', 0, 0, '', 0, 'vendor'),
(145, 'mdalibd100@gmail.com', 'hasnat', 'marufrabbi3858@gmail.com', 1, '2017-10-19', 'maruf', 1793858397, 558532, 'mrl', 'dhap.gel rod', 0, 0, '', 0, 'vendor');

-- --------------------------------------------------------

--
-- Table structure for table `company_users_onserial`
--

CREATE TABLE `company_users_onserial` (
  `sn` int(11) NOT NULL,
  `email` varchar(32) NOT NULL,
  `company_username` varchar(32) NOT NULL,
  `user_type` varchar(32) NOT NULL,
  `sub_username` varchar(32) NOT NULL,
  `user_ip` varchar(64) NOT NULL,
  `password` varchar(32) NOT NULL,
  `status` int(1) NOT NULL,
  `date` date NOT NULL,
  `name` varchar(32) NOT NULL,
  `post` varchar(32) NOT NULL,
  `id_no` varchar(32) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company_users_onserial`
--

INSERT INTO `company_users_onserial` (`sn`, `email`, `company_username`, `user_type`, `sub_username`, `user_ip`, `password`, `status`, `date`, `name`, `post`, `id_no`) VALUES
(13, 'anilshah999@hotmail.com', 'GTC', 'Master', 'ANIL', '', 'b4118f94f69dc29ceec1c6b6b83793ac', 1, '2017-09-06', 'ANIL', 'MANAGER', '001'),
(12, 'alphaomegafred@gmail.com', 'alpha', 'Master', 'alpha', '', '2c1743a391305fbf367df8e4f069f9f9', 1, '2017-08-31', 'alpha', 'alpha', 'alpha'),
(11, 'ferdaus5028@gmail.com', 'ujjol', 'Master', 'ali', '', 'c20ad4d76fe97759aa27a0c99bff6710', 1, '2017-07-20', 'Ali', 'None', '13'),
(10, 'mdalibd100@gmail.com', 'hasnat', 'Master', 'al', '3d5f26438973a3d90b630a57c59a2f98', '202cb962ac59075b964b07152d234b70', 1, '2017-06-28', 'Al Hasnat', 'None', '12345'),
(9, 'mdaliceous@gmail.com', 'amar', 'Master', 'imran', '', '827ccb0eea8a706c4c34a16891f84e7b', 1, '2017-06-28', 'Imran Hasan', 'None', '123');

-- --------------------------------------------------------

--
-- Table structure for table `employee_attendance_onserial`
--

CREATE TABLE `employee_attendance_onserial` (
  `sn` int(11) NOT NULL,
  `sub_user` varchar(32) NOT NULL,
  `company_username` varchar(32) NOT NULL,
  `super_email` varchar(32) NOT NULL,
  `intime` varchar(32) NOT NULL,
  `outtime` varchar(32) NOT NULL,
  `present` varchar(32) NOT NULL,
  `office_off_on` varchar(32) NOT NULL,
  `off_on_reason` varchar(64) NOT NULL,
  `date` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `invoice_products_details_onserial`
--

CREATE TABLE `invoice_products_details_onserial` (
  `sn` int(11) NOT NULL,
  `order_no` int(11) NOT NULL,
  `invoice_no` int(11) NOT NULL,
  `debit_credit_invoice` int(11) NOT NULL,
  `vendor_serial` int(11) NOT NULL,
  `super_email` varchar(32) NOT NULL,
  `customer_serial` int(11) NOT NULL,
  `debit_or_credit` varchar(12) NOT NULL,
  `invoice_type` varchar(32) NOT NULL,
  `product_name` varchar(32) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `size` varchar(32) NOT NULL,
  `products_company` varchar(32) NOT NULL,
  `unit_price` int(11) NOT NULL,
  `sub_total` int(11) NOT NULL,
  `discount` int(11) NOT NULL,
  `net` int(11) NOT NULL,
  `tax` varchar(11) NOT NULL,
  `sell_price` int(11) NOT NULL,
  `warranty_days` varchar(32) NOT NULL,
  `warranty_days_type` varchar(32) NOT NULL,
  `date` date NOT NULL,
  `company_username` varchar(32) NOT NULL,
  `sub_user` varchar(32) NOT NULL,
  `last_update_date` date NOT NULL,
  `last_updater` varchar(32) NOT NULL,
  `serial_key_length` int(11) NOT NULL,
  `update_date_time` datetime NOT NULL,
  `remarks` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invoice_products_details_onserial`
--

INSERT INTO `invoice_products_details_onserial` (`sn`, `order_no`, `invoice_no`, `debit_credit_invoice`, `vendor_serial`, `super_email`, `customer_serial`, `debit_or_credit`, `invoice_type`, `product_name`, `product_id`, `quantity`, `size`, `products_company`, `unit_price`, `sub_total`, `discount`, `net`, `tax`, `sell_price`, `warranty_days`, `warranty_days_type`, `date`, `company_username`, `sub_user`, `last_update_date`, `last_updater`, `serial_key_length`, `update_date_time`, `remarks`) VALUES
(5, 0, 100000001, 0, 145, 'mdalibd100@gmail.com', 0, 'debit', 'purchase_invoice', 'Lux', 100000001, 120, '90 mg', '', 150, 18000, 0, 18000, '', 200, '', 'None', '0000-00-00', 'hasnat', 'al', '0000-00-00', '', 0, '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `invoice_products_serial_details_onserial`
--

CREATE TABLE `invoice_products_serial_details_onserial` (
  `sn` int(11) NOT NULL,
  `order_no` int(11) NOT NULL,
  `invoice_no` int(11) NOT NULL,
  `vendor_serial` int(11) NOT NULL,
  `customer_serial` int(11) NOT NULL,
  `super_email` varchar(32) NOT NULL,
  `debit_or_credit` varchar(12) NOT NULL,
  `invoice_type` varchar(32) NOT NULL,
  `product_id` int(11) NOT NULL,
  `serial_key` varchar(32) NOT NULL,
  `vendor_id` int(11) NOT NULL,
  `company_username` varchar(32) NOT NULL,
  `subuser` varchar(32) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `invoice_summary_onserial`
--

CREATE TABLE `invoice_summary_onserial` (
  `sn` int(11) NOT NULL,
  `order_no` int(11) NOT NULL,
  `invoice_no` int(11) NOT NULL,
  `update_invoice_no` int(11) NOT NULL,
  `update_for_invoice_type` varchar(32) NOT NULL,
  `debit_credit_invoice` int(11) NOT NULL,
  `invest_debit_credit` int(11) NOT NULL,
  `bank_invoice` int(11) NOT NULL,
  `date` date NOT NULL,
  `vendor_serial` int(11) NOT NULL,
  `super_email` varchar(32) NOT NULL,
  `customer_serial` int(11) NOT NULL,
  `delivary_date` date NOT NULL,
  `bill` int(11) NOT NULL,
  `discount` varchar(11) NOT NULL,
  `total` int(11) NOT NULL,
  `payment` int(11) NOT NULL,
  `payment_method` varchar(32) NOT NULL,
  `bank_name` varchar(32) NOT NULL,
  `account_no` varchar(32) NOT NULL,
  `due` int(11) NOT NULL,
  `due_payment_date` date NOT NULL,
  `tax` varchar(32) NOT NULL,
  `carring_cost` int(11) NOT NULL,
  `others_cost` int(11) NOT NULL,
  `intensive` varchar(11) NOT NULL,
  `net` varchar(11) NOT NULL,
  `remarks` varchar(32) NOT NULL,
  `user_company` varchar(32) NOT NULL,
  `sub_user` varchar(32) NOT NULL,
  `status` varchar(32) NOT NULL,
  `purchase_date` date NOT NULL,
  `company_username` varchar(32) NOT NULL,
  `last_update_date` date NOT NULL,
  `last_update_user` varchar(32) NOT NULL,
  `invoice_type` varchar(32) NOT NULL,
  `order_to_invoice_status` varchar(32) NOT NULL,
  `debit_or_credit` varchar(10) NOT NULL,
  `cause` varchar(128) NOT NULL,
  `current_market_value` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invoice_summary_onserial`
--

INSERT INTO `invoice_summary_onserial` (`sn`, `order_no`, `invoice_no`, `update_invoice_no`, `update_for_invoice_type`, `debit_credit_invoice`, `invest_debit_credit`, `bank_invoice`, `date`, `vendor_serial`, `super_email`, `customer_serial`, `delivary_date`, `bill`, `discount`, `total`, `payment`, `payment_method`, `bank_name`, `account_no`, `due`, `due_payment_date`, `tax`, `carring_cost`, `others_cost`, `intensive`, `net`, `remarks`, `user_company`, `sub_user`, `status`, `purchase_date`, `company_username`, `last_update_date`, `last_update_user`, `invoice_type`, `order_to_invoice_status`, `debit_or_credit`, `cause`, `current_market_value`) VALUES
(4, 0, 100000001, 0, '', 0, 0, 0, '2017-10-19', 145, 'mdalibd100@gmail.com', 0, '0000-00-00', 0, '', 0, 0, '', '', '', 0, '0000-00-00', '', 0, 0, '', '20000', '', '', 'al', '1', '0000-00-00', 'hasnat', '0000-00-00', '', 'vendor_opening_amount', '', 'debit', '', 0),
(5, 0, 100000002, 0, '', 0, 0, 0, '2017-10-19', 146, 'mdalibd100@gmail.com', 0, '0000-00-00', 0, '', 0, 0, '', '', '', 0, '0000-00-00', '', 0, 0, '', '10000', '', '', 'al', '1', '0000-00-00', 'hasnat', '0000-00-00', '', 'vendor_opening_amount', '', 'credit', '', 0),
(6, 0, 100000003, 0, '', 0, 0, 0, '2017-10-19', 147, 'mdalibd100@gmail.com', 0, '0000-00-00', 0, '', 0, 0, '', '', '', 0, '0000-00-00', '', 0, 0, '', '15000', '', '', 'al', '1', '0000-00-00', 'hasnat', '0000-00-00', '', 'vendor_opening_amount', '', 'debit', '', 0),
(7, 0, 100000004, 0, '', 0, 0, 0, '2017-10-19', 148, 'mdalibd100@gmail.com', 0, '0000-00-00', 0, '', 0, 0, '', '', '', 0, '0000-00-00', '', 0, 0, '', '35000', '', '', 'al', '1', '0000-00-00', 'hasnat', '0000-00-00', '', 'vendor_opening_amount', '', 'credit', '', 0),
(8, 0, 100000001, 0, '', 0, 0, 0, '2017-10-19', 149, 'mdalibd100@gmail.com', 0, '0000-00-00', 0, '', 0, 0, '', '', '', 0, '0000-00-00', '', 0, 0, '', '5000', '', '', 'al', '1', '0000-00-00', 'hasnat', '0000-00-00', '', 'customer_opening_amount', '', 'credit', '', 0),
(9, 0, 100000001, 0, '', 0, 0, 0, '2017-10-19', 145, 'mdalibd100@gmail.com', 0, '2017-10-19', 18000, '0', 18000, 12000, 'Cash Payment', '', '', 6000, '2017-10-19', '', 0, 0, '0', '18000', '', '', 'al', '1', '0000-00-00', 'hasnat', '0000-00-00', '', 'purchase_invoice', '', 'debit', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `login_onserial`
--

CREATE TABLE `login_onserial` (
  `sn` int(11) NOT NULL,
  `user_type` varchar(32) NOT NULL,
  `pakage` varchar(32) NOT NULL,
  `email` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `status` int(1) NOT NULL,
  `date` date NOT NULL,
  `year` int(2) NOT NULL,
  `email_c` varchar(64) NOT NULL,
  `forgot_password` varchar(64) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_onserial`
--

INSERT INTO `login_onserial` (`sn`, `user_type`, `pakage`, `email`, `password`, `status`, `date`, `year`, `email_c`, `forgot_password`) VALUES
(38, 'Super', 'Free', 'tipstricks99@gmail.com', '1708fa76725fd38898b0bf047f9db530', 1, '2017-09-15', 1, 'c63c7048753bdb6d33dde70a9c8f4171', ''),
(37, 'Super', 'Free', 'mahesh.bhanderi13@gmail.com', '49bb197bec17b7d20b2df6b1f3c3434a', 1, '2017-09-14', 17, 'f7f640e401de130543b56a0bde24154f', ''),
(36, 'Super', 'Free', 'imti.anash@hotmail.com', '16461e0fab828b8a10be3c74eec4557e', 1, '2017-09-14', 5, '29ab3309479adfacc749031b218b144f', ''),
(35, 'Super', 'Free', 'globalbdjobs@gmail.com', '350af85d8ec533f5f725fa1e5dc3553d', 0, '2017-09-07', 1, '77680d109e188fe77d39ab28c4b50758', ''),
(34, 'Super', 'Free', 'anilshah999@hotmail.com', 'b4118f94f69dc29ceec1c6b6b83793ac', 1, '2017-09-06', 20, '7b225541a345b7111afe94bbb44d9f42', ''),
(33, 'Super', 'Free', 'Info@uniqueent.in', 'a57a6ba0b748ab9fb1857d330f012cb4', 1, '2017-09-06', 20, '9ebbaaf064ec8a5cec149c8a846cf916', ''),
(32, 'Super', 'Free', 'behindthebadge523@gmail.com', 'c6e9483745bea9f1385799d00edba726', 1, '2017-09-03', 20, '52c2a39f8daf5ded5a325458697dc854', ''),
(31, 'Super', 'Free', 'alphaomegafred@gmail.com', '570a90bfbf8c7eab5dc5d4e26832d5b1', 1, '2017-08-31', 1, '653e9dfa34f63b37a70b2f8d6e06ac7d', ''),
(30, 'Super', 'Free', 'julioalfaror@hotmail.com', 'd6679b6df130fa6a6bd0bab33fff95bd', 0, '2017-08-26', 1, '3ea023e6fd4dea4e91b8147ee8a8c950', ''),
(29, 'Super', 'Free', 'globalbdjobs@gmqil.com', '202cb962ac59075b964b07152d234b70', 0, '2017-07-25', 1, 'bc45714797ec497db317dbb79a30188b', ''),
(28, 'Super', 'Free', 'ferdaus5028@gmail.com', '202cb962ac59075b964b07152d234b70', 1, '2017-07-20', 1, '68e566fa84aa5339044aa7c01e7fdfe9', ''),
(27, 'Super', 'Free', 'mdalibd100@gmail.com', '202cb962ac59075b964b07152d234b70', 1, '2017-06-28', 1, '018a8e99e6a88577298d988b32b786c7', ''),
(26, 'Super', 'Free', 'mdaliceous@gmail.com', '202cb962ac59075b964b07152d234b70', 1, '2017-06-28', 1, 'b77ac702a8811e4f3fad1b5948ba3d0d', ''),
(39, 'Super', 'Free', 'saravanan_kandasamy@outlook.com', '4a68bcd8704ffc4c92777897e883ce07', 1, '2017-09-16', 3, 'ca6a2275e19610569ba896f2c5d06206', ''),
(40, 'Super', 'Free', 'adilisohb95@gmail.com', 'bf10f7fcb21779bfeef23e1b276d54a9', 1, '2017-09-18', 2, '05b7d6c1176d001e138d86aaa8d9fc59', ''),
(41, 'Super', 'Free', 'ntnatlosc@gmail.com', '638c32f633289070bdb270d1e8b05be3', 1, '2017-09-25', 5, 'f35d312f71ebdbb50d85b1f49471e3fa', ''),
(42, 'Super', 'Free', 'anowersanitary@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 0, '2017-09-28', 1, '62ef21de08c2067be0d0ef6e66c0ebbc', ''),
(43, 'Super', 'Free', 'almadhakhobar@gmail.com', '61f01dc783f5ac78b8f72abb410ab967', 1, '2017-09-28', 10, 'e161be249aff3273b5179e86759b7cea', ''),
(44, 'Super', 'Free', 'wqaex20@gmail.com', '61a4faf71bc86280ccd6ba1448668ec7', 0, '2017-10-02', 1, '09a2e4f0d8b061958264c9cbcb3f9cd7', ''),
(45, 'Super', 'Free', 'flowerpalace386@gmail.com', 'f99e3012d9f42eb68eefe964486d5d1f', 0, '2017-10-02', 1, '20b1af9b5261df63c604cbe158fc130e', ''),
(46, 'Super', 'Free', 'mr.farooq.ok@gmail.com', 'a45fdb1e4ac646c9e65a1769663e5704', 1, '2017-10-03', 6, '55d25e1be7dfe48d31c4cc4a4771aa87', '');

-- --------------------------------------------------------

--
-- Table structure for table `note_onserial`
--

CREATE TABLE `note_onserial` (
  `sn` int(11) NOT NULL,
  `entry_date` date NOT NULL,
  `date_for_note` date NOT NULL,
  `note` varchar(200) NOT NULL,
  `company_username` varchar(32) NOT NULL,
  `sub_user` varchar(32) NOT NULL,
  `super_email` varchar(32) NOT NULL,
  `read_status` varchar(3) NOT NULL,
  `status` varchar(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `products_details_onserial`
--

CREATE TABLE `products_details_onserial` (
  `sn` int(11) NOT NULL,
  `product_title` varchar(64) NOT NULL,
  `product_name` varchar(64) NOT NULL,
  `product_id` varchar(32) NOT NULL,
  `status` int(1) NOT NULL,
  `products_company` varchar(32) NOT NULL,
  `size` varchar(32) NOT NULL,
  `unit_price` int(11) NOT NULL,
  `tax` varchar(5) NOT NULL,
  `net_unit_price` int(11) NOT NULL,
  `vendor_serial` int(11) NOT NULL,
  `sell_price` int(11) NOT NULL,
  `warenty_days` int(11) NOT NULL,
  `warenty_type` varchar(32) NOT NULL,
  `serial_length` int(11) NOT NULL,
  `company_username` varchar(32) NOT NULL,
  `sub_username` varchar(32) NOT NULL,
  `super_email` varchar(32) NOT NULL,
  `default_discount` varchar(8) NOT NULL,
  `remarks` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products_details_onserial`
--

INSERT INTO `products_details_onserial` (`sn`, `product_title`, `product_name`, `product_id`, `status`, `products_company`, `size`, `unit_price`, `tax`, `net_unit_price`, `vendor_serial`, `sell_price`, `warenty_days`, `warenty_type`, `serial_length`, `company_username`, `sub_username`, `super_email`, `default_discount`, `remarks`) VALUES
(3, 'Lux 90 mg', 'Lux', '100000001', 1, '', '90 mg', 150, '', 0, 145, 200, 0, 'None', 0, 'hasnat', '', 'mdalibd100@gmail.com', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `stock_audit_adjust_onserial`
--

CREATE TABLE `stock_audit_adjust_onserial` (
  `sn` int(11) NOT NULL,
  `product_title` varchar(64) NOT NULL,
  `product_id` varchar(32) NOT NULL,
  `stock_adjust` int(11) NOT NULL,
  `lost_insentive_type` varchar(32) NOT NULL,
  `company_username` varchar(32) NOT NULL,
  `subuser` varchar(32) NOT NULL,
  `date` date NOT NULL,
  `super_email` varchar(32) NOT NULL,
  `remarks` varchar(400) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `stock_now_onserial`
--

CREATE TABLE `stock_now_onserial` (
  `sn` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `opening_stock` int(11) NOT NULL,
  `total_purchase` int(11) NOT NULL,
  `current_stock` int(11) NOT NULL,
  `stock_check` int(11) NOT NULL,
  `audit_adjust` int(11) NOT NULL,
  `total_sell` int(11) NOT NULL,
  `purchase_return` int(11) NOT NULL,
  `sell_return` int(11) NOT NULL,
  `damage` int(11) NOT NULL,
  `intensive` int(11) NOT NULL,
  `warranty` int(11) NOT NULL,
  `sell_warranty` int(11) NOT NULL,
  `company_username` varchar(32) NOT NULL,
  `super_email` varchar(32) NOT NULL,
  `vendor_sn` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stock_now_onserial`
--

INSERT INTO `stock_now_onserial` (`sn`, `product_id`, `opening_stock`, `total_purchase`, `current_stock`, `stock_check`, `audit_adjust`, `total_sell`, `purchase_return`, `sell_return`, `damage`, `intensive`, `warranty`, `sell_warranty`, `company_username`, `super_email`, `vendor_sn`) VALUES
(2, 100000001, 0, 120, 120, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'hasnat', 'mdalibd100@gmail.com', 145);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `client_details_onserial`
--
ALTER TABLE `client_details_onserial`
  ADD PRIMARY KEY (`sn`);

--
-- Indexes for table `companies_onserial`
--
ALTER TABLE `companies_onserial`
  ADD PRIMARY KEY (`sn`);

--
-- Indexes for table `company_markenter_onserial`
--
ALTER TABLE `company_markenter_onserial`
  ADD PRIMARY KEY (`sn`);

--
-- Indexes for table `company_users_onserial`
--
ALTER TABLE `company_users_onserial`
  ADD PRIMARY KEY (`sn`);

--
-- Indexes for table `employee_attendance_onserial`
--
ALTER TABLE `employee_attendance_onserial`
  ADD PRIMARY KEY (`sn`);

--
-- Indexes for table `invoice_products_details_onserial`
--
ALTER TABLE `invoice_products_details_onserial`
  ADD PRIMARY KEY (`sn`);

--
-- Indexes for table `invoice_products_serial_details_onserial`
--
ALTER TABLE `invoice_products_serial_details_onserial`
  ADD PRIMARY KEY (`sn`);

--
-- Indexes for table `invoice_summary_onserial`
--
ALTER TABLE `invoice_summary_onserial`
  ADD PRIMARY KEY (`sn`);

--
-- Indexes for table `login_onserial`
--
ALTER TABLE `login_onserial`
  ADD PRIMARY KEY (`sn`);

--
-- Indexes for table `note_onserial`
--
ALTER TABLE `note_onserial`
  ADD PRIMARY KEY (`sn`);

--
-- Indexes for table `products_details_onserial`
--
ALTER TABLE `products_details_onserial`
  ADD PRIMARY KEY (`sn`);

--
-- Indexes for table `stock_audit_adjust_onserial`
--
ALTER TABLE `stock_audit_adjust_onserial`
  ADD PRIMARY KEY (`sn`);

--
-- Indexes for table `stock_now_onserial`
--
ALTER TABLE `stock_now_onserial`
  ADD PRIMARY KEY (`sn`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `client_details_onserial`
--
ALTER TABLE `client_details_onserial`
  MODIFY `sn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `companies_onserial`
--
ALTER TABLE `companies_onserial`
  MODIFY `sn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
--
-- AUTO_INCREMENT for table `company_markenter_onserial`
--
ALTER TABLE `company_markenter_onserial`
  MODIFY `sn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=150;
--
-- AUTO_INCREMENT for table `company_users_onserial`
--
ALTER TABLE `company_users_onserial`
  MODIFY `sn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `employee_attendance_onserial`
--
ALTER TABLE `employee_attendance_onserial`
  MODIFY `sn` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `invoice_products_details_onserial`
--
ALTER TABLE `invoice_products_details_onserial`
  MODIFY `sn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `invoice_products_serial_details_onserial`
--
ALTER TABLE `invoice_products_serial_details_onserial`
  MODIFY `sn` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `invoice_summary_onserial`
--
ALTER TABLE `invoice_summary_onserial`
  MODIFY `sn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `login_onserial`
--
ALTER TABLE `login_onserial`
  MODIFY `sn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;
--
-- AUTO_INCREMENT for table `note_onserial`
--
ALTER TABLE `note_onserial`
  MODIFY `sn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `products_details_onserial`
--
ALTER TABLE `products_details_onserial`
  MODIFY `sn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `stock_audit_adjust_onserial`
--
ALTER TABLE `stock_audit_adjust_onserial`
  MODIFY `sn` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `stock_now_onserial`
--
ALTER TABLE `stock_now_onserial`
  MODIFY `sn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
