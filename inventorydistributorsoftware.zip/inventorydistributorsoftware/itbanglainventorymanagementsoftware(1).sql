-- phpMyAdmin SQL Dump
-- version 4.0.10.18
-- https://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Oct 23, 2017 at 11:52 PM
-- Server version: 5.6.36-cll-lve
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `itbanglainventorymanagementsoftware`
--

-- --------------------------------------------------------

--
-- Table structure for table `client_details_onserial`
--

CREATE TABLE IF NOT EXISTS `client_details_onserial` (
  `sn` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(32) NOT NULL,
  `first_name` varchar(32) NOT NULL,
  `last_name` varchar(32) NOT NULL,
  `address` varchar(128) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`sn`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=38 ;

--
-- Dumping data for table `client_details_onserial`
--

INSERT INTO `client_details_onserial` (`sn`, `email`, `first_name`, `last_name`, `address`, `date`) VALUES
(19, 'alphaomegafred@gmail.com', 'fred', 'alpha', 'alpha', '2017-08-31'),
(18, 'julioalfaror@hotmail.com', 'Julio', 'Alfaro', 'JirÃ³n Huancayo 177 Cercado de Lima', '2017-08-26'),
(17, 'globalbdjobs@gmqil.com', 'Habibd', 'Vi', 'Dhaka', '2017-07-25'),
(15, 'mdalibd100@gmail.com', 'Al', 'Hasnat', 'Dolgram', '2017-06-28'),
(16, 'ferdaus5028@gmail.com', 'Ujjol', 'vi', 'Dolgram', '2017-07-20'),
(14, 'mdaliceous@gmail.com', 'Mohammad', 'Ali', 'Rangpur', '2017-06-28'),
(20, 'behindthebadge523@gmail.com', 'Emily', 'Segura', 'P.O. Box 11631', '2017-09-03'),
(21, 'Info@uniqueent.in', 'info', 'Unique', 'Info@uniqueent.in', '2017-09-06'),
(22, 'anilshah999@hotmail.com', 'ANIL', 'SHAH', 'MUMBAI', '2017-09-06'),
(23, 'globalbdjobs@gmail.com', 'Habib', 'Rahman', 'Dhaka', '2017-09-07'),
(24, 'imti.anash@hotmail.com', 'IMTIYAZ', 'ALAM', 'doha', '2017-09-14'),
(25, 'mahesh.bhanderi13@gmail.com', 'mahesh', 'patel', 'jamnagar', '2017-09-14'),
(26, 'tipstricks99@gmail.com', 'Ali', 'Raza', 'lahore', '2017-09-15'),
(27, 'saravanan_kandasamy@outlook.com', 'Saravanan', 'K', '463 Jaya Nagar', '2017-09-16'),
(28, 'adilisohb95@gmail.com', 'adiyl', 'hb', 'zanzibar', '2017-09-18'),
(29, 'ntnatlosc@gmail.com', 'Neil', 'Ng.', 'ntnaltosc@gmail.com', '2017-09-25'),
(30, 'almadhakhobar@gmail.com', 'Hazif', 'Saj', 'Al Khobar Al Shamalia', '2017-09-28'),
(31, 'flowerpalace386@gmail.com', 'aung', 'win', 'yangon /myanmar', '2017-10-02'),
(32, 'r@soft19.com', 'M', 'A', 'R', '2017-10-22'),
(33, 'rd@soft19.com', 'M', 'A', 'R', '2017-10-22'),
(34, 'rda@soft19.com', 'm', 'A', 'RD', '2017-10-22'),
(35, 'rdad@soft19.com', 'm', 'A', 'RD', '2017-10-22'),
(36, 'rdcf@soft19.com', 'M', 'A', 'R', '2017-10-22'),
(37, 'marufrabbi3858@gmail.com', 'Maruf', 'Rabbi', 'CEO Bazar', '2017-10-23');

-- --------------------------------------------------------

--
-- Table structure for table `companies_onserial`
--

CREATE TABLE IF NOT EXISTS `companies_onserial` (
  `sn` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(32) NOT NULL,
  `company_name` varchar(128) NOT NULL,
  `company_username` varchar(32) NOT NULL,
  `company_email` varchar(32) NOT NULL,
  `company_mobile` varchar(15) NOT NULL,
  `company_telephone` varchar(15) NOT NULL,
  `address` varchar(200) NOT NULL,
  `currency` varchar(32) NOT NULL,
  `status` int(1) NOT NULL,
  `date` date NOT NULL,
  `barcode` varchar(3) NOT NULL,
  `serial_key` varchar(3) NOT NULL,
  `vendor_register_required` varchar(3) NOT NULL,
  `customer_register_required` varchar(3) NOT NULL,
  `customer_product_discount` varchar(3) NOT NULL,
  `customer_final_discount` varchar(3) NOT NULL,
  `vendor_tax` varchar(32) NOT NULL,
  `customer_tax` varchar(32) NOT NULL,
  `vendor_primary_key` varchar(32) NOT NULL,
  `customer_primary_key` varchar(32) NOT NULL,
  `customer_debit_limit` varchar(3) NOT NULL,
  `customer_debit_days` varchar(32) NOT NULL,
  `company_timezone` varchar(64) NOT NULL,
  `customer_online_order_on` varchar(3) NOT NULL,
  `customer_online_auto_approved` varchar(3) NOT NULL,
  `purchase_invoice_msg` varchar(128) NOT NULL,
  `customer_invoice_msg` varchar(128) NOT NULL,
  `purchase_default_cursor` varchar(32) NOT NULL,
  `after_purchase_service` varchar(3) NOT NULL,
  `after_sell_service` varchar(3) NOT NULL,
  `sell_default_cursor` varchar(32) NOT NULL,
  PRIMARY KEY (`sn`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=40 ;

--
-- Dumping data for table `companies_onserial`
--

INSERT INTO `companies_onserial` (`sn`, `email`, `company_name`, `company_username`, `company_email`, `company_mobile`, `company_telephone`, `address`, `currency`, `status`, `date`, `barcode`, `serial_key`, `vendor_register_required`, `customer_register_required`, `customer_product_discount`, `customer_final_discount`, `vendor_tax`, `customer_tax`, `vendor_primary_key`, `customer_primary_key`, `customer_debit_limit`, `customer_debit_days`, `company_timezone`, `customer_online_order_on`, `customer_online_auto_approved`, `purchase_invoice_msg`, `customer_invoice_msg`, `purchase_default_cursor`, `after_purchase_service`, `after_sell_service`, `sell_default_cursor`) VALUES
(32, 'mdalibd100@gmail.com', 'Hasnat', 'hasnat', '', '0', '0', 'B.AD College', '', 1, '2017-06-28', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Mobile', 'Mobile', 'Yes', 'Yes', 'Asia/Dhaka', 'Yes', 'Yes', '', '', '', '', '', ''),
(31, 'mdaliceous@gmail.com', 'Amar Bangla', 'amar', '', '0', '0', '', '', 1, '2017-06-28', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Mobile', 'Mobile', 'Yes', 'Yes', 'Asia/Dhaka', 'Yes', 'Yes', '', '', '', '', '', ''),
(33, 'ferdaus5028@gmail.com', 'Ujjol', 'ujjol', '', '', '', '', '', 1, '2017-07-20', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Mobile', 'Mobile', 'Yes', 'Yes', 'Asia/Dhaka', 'Yes', 'Yes', '', '', '', '', '', ''),
(34, 'alphaomegafred@gmail.com', 'alpha', 'alpha', '', '', '', '', '', 1, '2017-08-31', 'Yes', 'Yes', 'No', 'No', 'No', 'No', 'No', 'No', 'Email', 'Email', 'No', 'No', 'America/New_York', 'No', 'No', '', '', '', '', '', ''),
(35, 'behindthebadge523@gmail.com', 'Behind The Badge Jewelry Gifts & More ', 'behindthebadge', '', '', '', '', '', 1, '2017-09-03', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'Email', 'Email', 'No', 'No', 'America/La_Paz', 'Yes', 'No', '', '', '', '', '', ''),
(36, 'anilshah999@hotmail.com', 'GANDHI TRADING CO', 'GTC', '', '', '', '', '', 1, '2017-09-06', 'Yes', 'Yes', 'No', 'No', 'Yes', 'No', 'Yes', 'Yes', 'Mobile', 'Mobile', 'Yes', 'No', 'Asia/Kolkata', 'No', 'No', '', '', '', '', '', ''),
(37, 'imti.anash@hotmail.com', 'QEMC', 'anash', '', '', '', '', '', 1, '2017-09-14', 'No', 'Yes', 'Yes', 'Yes', 'No', 'No', 'No', 'No', 'Mobile', 'Email', 'No', 'No', 'Asia/Qatar', 'Yes', 'No', '', '', '', '', '', ''),
(38, 'mr.farooq.ok@gmail.com', 'Hameed Sweets', 'hameed', '', '', '', '', '', 1, '2017-10-03', 'Yes', 'Yes', 'No', 'No', 'Yes', 'Yes', 'No', 'No', 'Mobile', 'Mobile', 'No', 'No', 'Asia/Karachi', 'No', 'No', '', '', '', '', '', ''),
(39, 'marufrabbi3858@gmail.com', 'Twinkle', 'Twinkle', '', '', '', '', '', 1, '2017-10-23', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Mobile', 'Mobile', 'Yes', 'Yes', 'Asia/Dhaka', 'Yes', 'Yes', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `company_markenter_onserial`
--

CREATE TABLE IF NOT EXISTS `company_markenter_onserial` (
  `sn` int(11) NOT NULL AUTO_INCREMENT,
  `super_admin_email` varchar(32) NOT NULL,
  `company_username` varchar(32) NOT NULL,
  `markenter_email` varchar(32) NOT NULL,
  `status` int(1) NOT NULL,
  `date` date NOT NULL,
  `full_name` varchar(32) NOT NULL,
  `vendor_mobile_no` int(16) NOT NULL,
  `vendor_telephone_no` int(16) NOT NULL,
  `vendor_company_name` varchar(64) NOT NULL,
  `vendor_address` varchar(128) NOT NULL,
  `vendor_debit_limit` int(11) NOT NULL,
  `vendor_debit_days` int(11) NOT NULL,
  `sub_username` varchar(32) NOT NULL,
  `markenter_status` int(1) NOT NULL,
  `type` varchar(32) NOT NULL,
  PRIMARY KEY (`sn`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=169 ;

--
-- Dumping data for table `company_markenter_onserial`
--

INSERT INTO `company_markenter_onserial` (`sn`, `super_admin_email`, `company_username`, `markenter_email`, `status`, `date`, `full_name`, `vendor_mobile_no`, `vendor_telephone_no`, `vendor_company_name`, `vendor_address`, `vendor_debit_limit`, `vendor_debit_days`, `sub_username`, `markenter_status`, `type`) VALUES
(161, 'marufrabbi3858@gmail.com', 'Twinkle', 'murad123@gmail.com', 1, '2017-10-23', 'murad ', 1725486487, 88962055, 'nita enter praij', 'jahaj companir mor ,rongpur.', 0, 0, '', 0, 'vendor'),
(160, 'mdalibd100@gmail.com', 'hasnat', '', 1, '2017-10-22', '', 1792969677, 0, '0', '', 0, 0, '', 0, 'customer'),
(159, 'mdalibd100@gmail.com', 'hasnat', '', 1, '2017-10-22', '', 1722038493, 0, '0', '', 0, 0, '', 0, 'customer'),
(158, 'mdalibd100@gmail.com', 'hasnat', '', 1, '2017-10-22', 'Monzila', 1792785572, 0, '0', '', 0, 0, '', 0, 'vendor'),
(157, 'mdalibd100@gmail.com', 'hasnat', '', 1, '2017-10-22', 'Star', 1684466802, 0, '0', '', 0, 0, '', 0, 'vendor'),
(155, 'mdalibd100@gmail.com', 'hasnat', '', 1, '2017-10-22', 'Ali', 1722038493, 0, '0', '', 0, 0, '', 0, 'vendor'),
(156, 'mdalibd100@gmail.com', 'hasnat', '', 1, '2017-10-22', 'Mahamuda', 1792969677, 0, '0', '', 0, 0, '', 0, 'vendor'),
(162, 'marufrabbi3858@gmail.com', 'Twinkle', 'jahid123@gmail.com', 1, '2017-10-23', 'jahid', 1635468497, 6465448, 'rua electronix', 'taj hat mor rongpur.', 100000, 365, '', 0, 'vendor'),
(163, 'marufrabbi3858@gmail.com', 'Twinkle', 'hakim125@gmail.com', 1, '2017-10-23', 'hakim vai', 1924646536, 2147483647, 'ato light house', 'payra chottor,rongpor.', 0, 0, '', 0, 'vendor'),
(164, 'marufrabbi3858@gmail.com', 'Twinkle', 'joshim369@gmail.com', 1, '2017-10-23', 'joshim', 1883030284, 5596350, 'treet electrik.', 'jahaj companir mor ,rongpur.', 0, 0, '', 0, 'vendor'),
(165, 'marufrabbi3858@gmail.com', 'Twinkle', 'kamrul125@gmail.com', 1, '2017-10-23', 'niki', 1765645879, 0, '0', 'jgf['',t;htjkhw,fahfh.', 0, 0, '', 0, 'customer'),
(166, 'marufrabbi3858@gmail.com', 'Twinkle', 'rubel456@gmail.com', 1, '2017-10-23', 'rubel', 1638468356, 554684, '0', 'kjbj,kwlgh.', 0, 0, '', 0, 'customer'),
(167, 'marufrabbi3858@gmail.com', 'Twinkle', '', 1, '2017-10-23', '', 0, 0, '0', '', 0, 0, '', 0, 'vendor'),
(168, 'marufrabbi3858@gmail.com', 'Twinkle', '', 1, '2017-10-23', 'maruf rabbi limon', 1793858397, 0, '0', 'jkdllgkg', 0, 0, '', 0, 'customer');

-- --------------------------------------------------------

--
-- Table structure for table `company_users_onserial`
--

CREATE TABLE IF NOT EXISTS `company_users_onserial` (
  `sn` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(32) NOT NULL,
  `company_username` varchar(32) NOT NULL,
  `user_type` varchar(32) NOT NULL,
  `sub_username` varchar(32) NOT NULL,
  `user_ip` varchar(64) NOT NULL,
  `password` varchar(32) NOT NULL,
  `status` int(1) NOT NULL,
  `date` date NOT NULL,
  `name` varchar(32) NOT NULL,
  `post` varchar(32) NOT NULL,
  `id_no` varchar(32) NOT NULL,
  PRIMARY KEY (`sn`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `company_users_onserial`
--

INSERT INTO `company_users_onserial` (`sn`, `email`, `company_username`, `user_type`, `sub_username`, `user_ip`, `password`, `status`, `date`, `name`, `post`, `id_no`) VALUES
(13, 'anilshah999@hotmail.com', 'GTC', 'Master', 'ANIL', '', 'b4118f94f69dc29ceec1c6b6b83793ac', 1, '2017-09-06', 'ANIL', 'MANAGER', '001'),
(12, 'alphaomegafred@gmail.com', 'alpha', 'Master', 'alpha', '', '2c1743a391305fbf367df8e4f069f9f9', 1, '2017-08-31', 'alpha', 'alpha', 'alpha'),
(11, 'ferdaus5028@gmail.com', 'ujjol', 'Master', 'ali', '', 'c20ad4d76fe97759aa27a0c99bff6710', 1, '2017-07-20', 'Ali', 'None', '13'),
(10, 'mdalibd100@gmail.com', 'hasnat', 'Master', 'al', '3d5f26438973a3d90b630a57c59a2f98', '202cb962ac59075b964b07152d234b70', 1, '2017-06-28', 'Al Hasnat', 'None', '12345'),
(9, 'mdaliceous@gmail.com', 'amar', 'Master', 'imran', '', '827ccb0eea8a706c4c34a16891f84e7b', 1, '2017-06-28', 'Imran Hasan', 'None', '123');

-- --------------------------------------------------------

--
-- Table structure for table `employee_attendance_onserial`
--

CREATE TABLE IF NOT EXISTS `employee_attendance_onserial` (
  `sn` int(11) NOT NULL AUTO_INCREMENT,
  `sub_user` varchar(32) NOT NULL,
  `company_username` varchar(32) NOT NULL,
  `super_email` varchar(32) NOT NULL,
  `intime` varchar(32) NOT NULL,
  `outtime` varchar(32) NOT NULL,
  `present` varchar(32) NOT NULL,
  `office_off_on` varchar(32) NOT NULL,
  `off_on_reason` varchar(64) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`sn`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `invoice_products_details_onserial`
--

CREATE TABLE IF NOT EXISTS `invoice_products_details_onserial` (
  `sn` int(11) NOT NULL AUTO_INCREMENT,
  `order_no` int(11) NOT NULL,
  `invoice_no` int(11) NOT NULL,
  `debit_credit_invoice` int(11) NOT NULL,
  `vendor_serial` int(11) NOT NULL,
  `super_email` varchar(32) NOT NULL,
  `customer_serial` int(11) NOT NULL,
  `debit_or_credit` varchar(12) NOT NULL,
  `invoice_type` varchar(32) NOT NULL,
  `product_name` varchar(32) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `size` varchar(32) NOT NULL,
  `products_company` varchar(32) NOT NULL,
  `unit_price` int(11) NOT NULL,
  `sub_total` int(11) NOT NULL,
  `discount` int(11) NOT NULL,
  `net` int(11) NOT NULL,
  `tax` varchar(11) NOT NULL,
  `sell_price` int(11) NOT NULL,
  `warranty_days` varchar(32) NOT NULL,
  `warranty_days_type` varchar(32) NOT NULL,
  `date` date NOT NULL,
  `company_username` varchar(32) NOT NULL,
  `sub_user` varchar(32) NOT NULL,
  `last_update_date` date NOT NULL,
  `last_updater` varchar(32) NOT NULL,
  `serial_key_length` int(11) NOT NULL,
  `update_date_time` datetime NOT NULL,
  `remarks` varchar(128) NOT NULL,
  PRIMARY KEY (`sn`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=582 ;

--
-- Dumping data for table `invoice_products_details_onserial`
--

INSERT INTO `invoice_products_details_onserial` (`sn`, `order_no`, `invoice_no`, `debit_credit_invoice`, `vendor_serial`, `super_email`, `customer_serial`, `debit_or_credit`, `invoice_type`, `product_name`, `product_id`, `quantity`, `size`, `products_company`, `unit_price`, `sub_total`, `discount`, `net`, `tax`, `sell_price`, `warranty_days`, `warranty_days_type`, `date`, `company_username`, `sub_user`, `last_update_date`, `last_updater`, `serial_key_length`, `update_date_time`, `remarks`) VALUES
(543, 100000001, 0, 0, 155, 'mdalibd100@gmail.com', 0, 'debit', 'order_invoice', 'Lux', 100000001, 15, '90 mg', '', 20, 300, 0, 300, '', 25, '', 'None', '0000-00-00', 'hasnat', 'al', '0000-00-00', '', 0, '0000-00-00 00:00:00', ''),
(546, 0, 100000001, 0, 155, 'mdalibd100@gmail.com', 0, 'debit', 'purchase_service', 'Lux', 100000001, 1, '90 mg', '', 0, 0, 0, 0, '', 25, '', 'None', '0000-00-00', 'hasnat', 'al', '0000-00-00', '', 0, '0000-00-00 00:00:00', ''),
(547, 0, 100000001, 0, 0, 'mdalibd100@gmail.com', 0, 'credit', 'opening_products', 'Lux', 100000001, 10, '90 mg', '', 20, 200, 0, 200, '', 25, '', 'None', '0000-00-00', 'hasnat', 'al', '0000-00-00', '', 0, '0000-00-00 00:00:00', ''),
(549, 0, 100000001, 0, 155, 'mdalibd100@gmail.com', 0, 'credit', 'purchase_return_invoice', 'Lux', 100000001, 5, '90 mg', '', 20, 100, 0, 100, '', 25, '', 'None', '0000-00-00', 'hasnat', 'al', '0000-00-00', '', 0, '0000-00-00 00:00:00', ''),
(550, 0, 100000001, 0, 155, 'mdalibd100@gmail.com', 0, 'debit', 'purchase_invoice', 'Lux', 100000001, 20, '90 mg', '', 20, 400, 0, 400, '', 25, '', 'None', '0000-00-00', 'hasnat', 'al', '0000-00-00', '', 0, '0000-00-00 00:00:00', ''),
(551, 100000001, 0, 0, 0, 'mdalibd100@gmail.com', 159, 'credit', 'sell_order_invoice', 'Lux', 100000001, 5, '90 mg', '', 25, 125, 0, 125, '', 25, '', 'None', '0000-00-00', 'hasnat', 'al', '0000-00-00', '', 0, '0000-00-00 00:00:00', ''),
(558, 100000002, 0, 0, 156, 'mdalibd100@gmail.com', 0, 'debit', 'order_invoice', 'Lux', 100000001, 100, '90 mg', '', 50, 5000, 0, 5000, '', 25, '', 'None', '0000-00-00', 'hasnat', 'al', '0000-00-00', '', 0, '0000-00-00 00:00:00', ''),
(559, 0, 100000003, 0, 156, 'mdalibd100@gmail.com', 0, 'debit', 'purchase_invoice', 'Lux', 100000001, 1000, '90 mg', '', 50, 50000, 0, 50000, '', 25, '', 'None', '0000-00-00', 'hasnat', 'al', '0000-00-00', '', 0, '0000-00-00 00:00:00', ''),
(560, 100000003, 0, 0, 156, 'mdalibd100@gmail.com', 0, 'debit', 'order_invoice', 'Lux', 100000001, 10, '90 mg', '', 50, 500, 0, 500, '', 25, '', 'None', '0000-00-00', 'hasnat', 'al', '0000-00-00', '', 0, '0000-00-00 00:00:00', ''),
(561, 0, 100000004, 0, 156, 'mdalibd100@gmail.com', 0, 'debit', 'purchase_invoice', 'Lux', 100000001, 10, '90 mg', '', 50, 500, 0, 500, '', 25, '', 'None', '0000-00-00', 'hasnat', 'al', '0000-00-00', '', 0, '0000-00-00 00:00:00', ''),
(562, 100000002, 0, 0, 0, 'mdalibd100@gmail.com', 160, 'credit', 'sell_order_invoice', 'Lux', 100000001, 4, '90 mg', '', 25, 100, 0, 100, '', 25, '', 'None', '0000-00-00', 'hasnat', 'al', '0000-00-00', '', 0, '0000-00-00 00:00:00', ''),
(563, 0, 100000002, 0, 0, 'mdalibd100@gmail.com', 160, 'credit', 'sell_invoice', 'Lux', 100000001, 4, '90 mg', '', 25, 100, 0, 100, '', 25, '', 'None', '0000-00-00', 'hasnat', 'al', '0000-00-00', '', 0, '0000-00-00 00:00:00', ''),
(564, 0, 100000001, 0, 0, 'mdalibd100@gmail.com', 159, 'credit', 'sell_invoice', 'Lux', 100000001, 4, '90 mg', '', 25, 100, 0, 100, '', 25, '', 'None', '0000-00-00', 'hasnat', 'al', '0000-00-00', '', 0, '0000-00-00 00:00:00', ''),
(565, 0, 100000002, 0, 155, 'mdalibd100@gmail.com', 0, 'debit', 'purchase_invoice', 'Lux', 100000001, 100, '90 mg', '', 20, 2000, 0, 2000, '', 25, '', 'None', '0000-00-00', 'hasnat', 'al', '0000-00-00', '', 0, '0000-00-00 00:00:00', ''),
(567, 100000004, 0, 0, 155, 'mdalibd100@gmail.com', 0, 'debit', 'order_invoice', 'Lux', 100000001, 15, '90 mg', '', 20, 300, 0, 300, '', 25, '', 'None', '0000-00-00', 'hasnat', 'al', '0000-00-00', '', 0, '0000-00-00 00:00:00', ''),
(568, 0, 100000005, 0, 155, 'mdalibd100@gmail.com', 0, 'debit', 'purchase_invoice', 'Lux', 100000001, 15, '90 mg', '', 20, 300, 0, 300, '', 25, '', 'None', '0000-00-00', 'hasnat', 'al', '0000-00-00', '', 0, '0000-00-00 00:00:00', ''),
(569, 0, 100000003, 0, 0, 'mdalibd100@gmail.com', 159, 'credit', 'sell_invoice', 'Lux', 100000001, 100, '90 mg', '', 25, 2500, 0, 2500, '', 25, '', 'None', '0000-00-00', 'hasnat', 'al', '0000-00-00', '', 0, '0000-00-00 00:00:00', ''),
(570, 0, 100000001, 0, 0, 'marufrabbi3858@gmail.com', 0, 'credit', 'opening_products', 'dish tar', 100000005, 100, 'good', '', 12, 1200, 0, 1200, '', 18, '', 'None', '0000-00-00', 'Twinkle', 'marufrabbi3858@gmail.com', '0000-00-00', '', 0, '0000-00-00 00:00:00', ''),
(571, 0, 100000001, 0, 0, 'marufrabbi3858@gmail.com', 0, 'credit', 'opening_products', 'dish tar', 100000004, 100, 'normal', '', 10, 1000, 0, 1000, '', 15, '', 'None', '0000-00-00', 'Twinkle', 'marufrabbi3858@gmail.com', '0000-00-00', '', 0, '0000-00-00 00:00:00', ''),
(572, 0, 100000001, 0, 0, 'marufrabbi3858@gmail.com', 0, 'credit', 'opening_products', 'tar', 100000003, 300, '36', '', 570, 171000, 0, 171000, '', 1150, '', 'None', '0000-00-00', 'Twinkle', 'marufrabbi3858@gmail.com', '0000-00-00', '', 0, '0000-00-00 00:00:00', ''),
(573, 0, 100000001, 0, 0, 'marufrabbi3858@gmail.com', 0, 'credit', 'opening_products', 'tar', 100000002, 100, '2nn', '', 350, 35000, 0, 35000, '', 700, '', 'None', '0000-00-00', 'Twinkle', 'marufrabbi3858@gmail.com', '0000-00-00', '', 0, '0000-00-00 00:00:00', ''),
(574, 100000001, 0, 0, 164, 'marufrabbi3858@gmail.com', 0, 'debit', 'order_invoice', 'dish tar', 100000004, 100, 'normal', '', 10, 1000, 0, 1000, '', 15, '', 'None', '0000-00-00', 'Twinkle', 'marufrabbi3858@gmail.com', '0000-00-00', '', 0, '0000-00-00 00:00:00', ''),
(575, 100000001, 0, 0, 164, 'marufrabbi3858@gmail.com', 0, 'debit', 'order_invoice', 'lamp bati', 100000001, 100, 'mini', '', 150, 15000, 0, 15000, '', 250, '', 'None', '0000-00-00', 'Twinkle', 'marufrabbi3858@gmail.com', '0000-00-00', '', 0, '0000-00-00 00:00:00', ''),
(576, 100000001, 0, 0, 164, 'marufrabbi3858@gmail.com', 0, 'debit', 'order_invoice', 'tar', 100000002, 10, '2nn', '', 350, 3500, 0, 3500, '', 700, '', 'None', '0000-00-00', 'Twinkle', 'marufrabbi3858@gmail.com', '0000-00-00', '', 0, '0000-00-00 00:00:00', ''),
(577, 0, 100000001, 0, 164, 'marufrabbi3858@gmail.com', 0, 'debit', 'purchase_invoice', 'dish tar', 100000004, 100, 'normal', '', 10, 1000, 0, 1000, '', 15, '', 'None', '0000-00-00', 'Twinkle', 'marufrabbi3858@gmail.com', '0000-00-00', '', 0, '0000-00-00 00:00:00', ''),
(578, 0, 100000001, 0, 164, 'marufrabbi3858@gmail.com', 0, 'debit', 'purchase_invoice', 'lamp bati', 100000001, 100, 'mini', '', 150, 15000, 0, 15000, '', 250, '', 'None', '0000-00-00', 'Twinkle', 'marufrabbi3858@gmail.com', '0000-00-00', '', 0, '0000-00-00 00:00:00', ''),
(579, 0, 100000001, 0, 164, 'marufrabbi3858@gmail.com', 0, 'debit', 'purchase_invoice', 'tar', 100000002, 100, '2nn', '', 350, 35000, 0, 35000, '', 700, '', 'None', '0000-00-00', 'Twinkle', 'marufrabbi3858@gmail.com', '0000-00-00', '', 0, '0000-00-00 00:00:00', ''),
(580, 0, 100000002, 0, 167, 'marufrabbi3858@gmail.com', 0, 'debit', 'purchase_invoice', 'dish tar', 100000004, 0, 'normal', '', 10, 1000, 0, 1000, '', 15, '', 'None', '0000-00-00', 'Twinkle', 'marufrabbi3858@gmail.com', '0000-00-00', '', 0, '0000-00-00 00:00:00', ''),
(581, 0, 100000001, 0, 0, 'marufrabbi3858@gmail.com', 168, 'credit', 'sell_invoice', 'lamp bati', 100000001, 1, 'mini', '', 250, 250, 0, 250, '', 250, '', 'None', '0000-00-00', 'Twinkle', 'marufrabbi3858@gmail.com', '0000-00-00', '', 0, '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `invoice_products_serial_details_onserial`
--

CREATE TABLE IF NOT EXISTS `invoice_products_serial_details_onserial` (
  `sn` int(11) NOT NULL AUTO_INCREMENT,
  `order_no` int(11) NOT NULL,
  `invoice_no` int(11) NOT NULL,
  `vendor_serial` int(11) NOT NULL,
  `customer_serial` int(11) NOT NULL,
  `super_email` varchar(32) NOT NULL,
  `debit_or_credit` varchar(12) NOT NULL,
  `invoice_type` varchar(32) NOT NULL,
  `product_id` int(11) NOT NULL,
  `serial_key` varchar(32) NOT NULL,
  `vendor_id` int(11) NOT NULL,
  `company_username` varchar(32) NOT NULL,
  `subuser` varchar(32) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`sn`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `invoice_summary_onserial`
--

CREATE TABLE IF NOT EXISTS `invoice_summary_onserial` (
  `sn` int(11) NOT NULL AUTO_INCREMENT,
  `order_no` int(11) NOT NULL,
  `invoice_no` int(11) NOT NULL,
  `update_invoice_no` int(11) NOT NULL,
  `update_for_invoice_type` varchar(32) NOT NULL,
  `debit_credit_invoice` int(11) NOT NULL,
  `invest_debit_credit` int(11) NOT NULL,
  `bank_invoice` int(11) NOT NULL,
  `date` date NOT NULL,
  `vendor_serial` int(11) NOT NULL,
  `super_email` varchar(32) NOT NULL,
  `customer_serial` int(11) NOT NULL,
  `delivary_date` date NOT NULL,
  `bill` int(11) NOT NULL,
  `discount` varchar(11) NOT NULL,
  `total` int(11) NOT NULL,
  `payment` int(11) NOT NULL,
  `payment_method` varchar(32) NOT NULL,
  `bank_name` varchar(32) NOT NULL,
  `account_no` varchar(32) NOT NULL,
  `due` int(11) NOT NULL,
  `due_payment_date` date NOT NULL,
  `tax` varchar(32) NOT NULL,
  `carring_cost` int(11) NOT NULL,
  `others_cost` int(11) NOT NULL,
  `intensive` varchar(11) NOT NULL,
  `net` varchar(11) NOT NULL,
  `remarks` varchar(32) NOT NULL,
  `user_company` varchar(32) NOT NULL,
  `sub_user` varchar(32) NOT NULL,
  `status` varchar(32) NOT NULL,
  `purchase_date` date NOT NULL,
  `company_username` varchar(32) NOT NULL,
  `last_update_date` date NOT NULL,
  `last_update_user` varchar(32) NOT NULL,
  `invoice_type` varchar(32) NOT NULL,
  `order_to_invoice_status` varchar(32) NOT NULL,
  `debit_or_credit` varchar(10) NOT NULL,
  `cause` varchar(128) NOT NULL,
  `current_market_value` int(11) NOT NULL,
  PRIMARY KEY (`sn`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=553 ;

--
-- Dumping data for table `invoice_summary_onserial`
--

INSERT INTO `invoice_summary_onserial` (`sn`, `order_no`, `invoice_no`, `update_invoice_no`, `update_for_invoice_type`, `debit_credit_invoice`, `invest_debit_credit`, `bank_invoice`, `date`, `vendor_serial`, `super_email`, `customer_serial`, `delivary_date`, `bill`, `discount`, `total`, `payment`, `payment_method`, `bank_name`, `account_no`, `due`, `due_payment_date`, `tax`, `carring_cost`, `others_cost`, `intensive`, `net`, `remarks`, `user_company`, `sub_user`, `status`, `purchase_date`, `company_username`, `last_update_date`, `last_update_user`, `invoice_type`, `order_to_invoice_status`, `debit_or_credit`, `cause`, `current_market_value`) VALUES
(519, 0, 100000001, 0, '', 0, 0, 0, '2017-10-22', 155, 'mdalibd100@gmail.com', 0, '0000-00-00', 0, '', 0, 0, '', '', '', 0, '0000-00-00', '', 0, 0, '', '10000', '', '', 'al', '1', '0000-00-00', 'hasnat', '0000-00-00', '', 'vendor_opening_amount', '', 'debit', '', 0),
(520, 0, 100000002, 0, '', 0, 0, 0, '2017-10-22', 156, 'mdalibd100@gmail.com', 0, '0000-00-00', 0, '', 0, 0, '', '', '', 0, '0000-00-00', '', 0, 0, '', '5000', '', '', 'al', '1', '0000-00-00', 'hasnat', '0000-00-00', '', 'vendor_opening_amount', '', 'debit', '', 0),
(521, 0, 100000003, 0, '', 0, 0, 0, '2017-10-22', 157, 'mdalibd100@gmail.com', 0, '0000-00-00', 0, '', 0, 0, '', '', '', 0, '0000-00-00', '', 0, 0, '', '3000', '', '', 'al', '1', '0000-00-00', 'hasnat', '0000-00-00', '', 'vendor_opening_amount', '', 'credit', '', 0),
(522, 0, 100000004, 0, '', 0, 0, 0, '2017-10-22', 158, 'mdalibd100@gmail.com', 0, '0000-00-00', 0, '', 0, 0, '', '', '', 0, '0000-00-00', '', 0, 0, '', '500', '', '', 'al', '1', '0000-00-00', 'hasnat', '0000-00-00', '', 'vendor_opening_amount', '', 'credit', '', 0),
(523, 100000001, 0, 0, '', 0, 0, 0, '2017-10-22', 155, 'mdalibd100@gmail.com', 0, '0000-00-00', 300, '0', 300, 300, 'Cash Payment', '', '', 0, '0000-00-00', '', 0, 0, '0', '300', '', '', 'al', '1', '0000-00-00', 'hasnat', '0000-00-00', '', 'order_invoice', '0', 'debit', '', 0),
(524, 0, 100000001, 0, '', 0, 0, 0, '2017-10-22', 155, 'mdalibd100@gmail.com', 0, '0000-00-00', 400, '0', 400, 400, 'Cash Payment', '', '0', 0, '0000-00-00', '', 0, 0, '0', '400', '', '', 'al', '1', '0000-00-00', 'hasnat', '2017-10-22', 'al', 'purchase_invoice', '', 'debit', '', 0),
(525, 0, 100000001, 0, '', 0, 0, 0, '2017-10-22', 155, 'mdalibd100@gmail.com', 0, '0000-00-00', 100, '0', 100, 100, 'Cash Payment', '', '0', 0, '0000-00-00', '', 0, 0, '0', '100', '', '', 'al', '1', '0000-00-00', 'hasnat', '2017-10-22', 'al', 'purchase_return_invoice', '', 'credit', '', 0),
(526, 0, 100000001, 0, '', 0, 0, 0, '2017-10-22', 155, 'mdalibd100@gmail.com', 0, '0000-00-00', 0, '', 0, 1000, 'Cash Payment', '', '', 0, '0000-00-00', '', 0, 0, '', '1000', '', '', 'al', '1', '0000-00-00', 'hasnat', '0000-00-00', '', 'purchase_payment', '', 'debit', '', 0),
(527, 0, 100000001, 0, '', 0, 0, 0, '2017-10-22', 155, 'mdalibd100@gmail.com', 0, '0000-00-00', 0, '0', 0, 0, 'Cash Payment', '', '', 0, '0000-00-00', '', 0, 0, '0', '0', '', '', 'al', '1', '0000-00-00', 'hasnat', '0000-00-00', '', 'purchase_service', '', 'debit', '', 0),
(528, 0, 0, 0, '', 0, 100000001, 0, '2017-10-22', 0, 'mdalibd100@gmail.com', 0, '0000-00-00', 0, '', 0, 0, '', '', '', 0, '0000-00-00', '', 0, 0, '', '2000', '', '', 'al', '1', '0000-00-00', 'hasnat', '0000-00-00', '', 'cash_invest_capital', '', 'credit', '0', 0),
(529, 0, 100000001, 0, '', 0, 0, 0, '2017-10-22', 0, 'mdalibd100@gmail.com', 0, '0000-00-00', 0, '', 200, 0, '', '', '', 0, '0000-00-00', '', 0, 0, '', '200', '', '', 'al', '1', '0000-00-00', 'hasnat', '0000-00-00', '', 'opening_products', '', 'credit', '', 0),
(530, 100000001, 0, 0, '', 0, 0, 0, '2017-10-22', 0, 'mdalibd100@gmail.com', 159, '0000-00-00', 125, '0', 125, 125, 'Cash Payment', '', '', 0, '0000-00-00', '', 0, 0, '0', '125', '', '', 'al', '1', '0000-00-00', 'hasnat', '2017-10-22', 'al', 'sell_order_invoice', '1', 'credit', '', 0),
(531, 0, 100000001, 0, '', 0, 0, 0, '2017-10-22', 0, 'mdalibd100@gmail.com', 159, '0000-00-00', 100, '0', 100, 100, 'Cash Payment', '', '0', 0, '0000-00-00', '', 0, 0, '0', '100', '', '', 'al', '1', '0000-00-00', 'hasnat', '2017-10-22', 'al', 'sell_invoice', '', 'credit', '', 0),
(532, 0, 100000002, 0, '', 0, 0, 0, '2017-10-22', 155, 'mdalibd100@gmail.com', 0, '0000-00-00', 2000, '0', 2000, 2000, 'Cash Payment', '', '0', 0, '0000-00-00', '', 0, 0, '0', '2000', '', '', 'al', '1', '0000-00-00', 'hasnat', '2017-10-22', 'al', 'purchase_invoice', '', 'debit', '', 0),
(533, 100000002, 0, 0, '', 0, 0, 0, '2017-10-22', 156, 'mdalibd100@gmail.com', 0, '0000-00-00', 5000, '10%', 4500, 0, 'Cash Payment', '', '', 4500, '0000-00-00', '', 0, 0, '0', '4500', '', '', 'al', '1', '0000-00-00', 'hasnat', '2017-10-22', 'al', 'order_invoice', '1', 'debit', '', 0),
(534, 0, 100000003, 0, '', 0, 0, 0, '2017-10-22', 156, 'mdalibd100@gmail.com', 0, '0000-00-00', 50000, '10%', 45000, 45000, 'Cash Payment', '', '', 0, '0000-00-00', '', 0, 0, '0', '45000', '', '', 'al', '1', '0000-00-00', 'hasnat', '0000-00-00', '', 'purchase_invoice', '', 'debit', '', 0),
(535, 100000003, 0, 0, '', 0, 0, 0, '2017-10-22', 156, 'mdalibd100@gmail.com', 0, '0000-00-00', 500, '0', 500, 500, 'Cash Payment', '', '', 0, '0000-00-00', '', 0, 0, '0', '500', '', '', 'al', '1', '0000-00-00', 'hasnat', '2017-10-22', 'al', 'order_invoice', '1', 'debit', '', 0),
(536, 0, 100000004, 0, '', 0, 0, 0, '2017-10-22', 156, 'mdalibd100@gmail.com', 0, '0000-00-00', 500, '0', 500, 500, 'Cash Payment', '', '', 0, '0000-00-00', '', 0, 0, '0', '500', '', '', 'al', '1', '0000-00-00', 'hasnat', '0000-00-00', '', 'purchase_invoice', '', 'debit', '', 0),
(537, 100000002, 0, 0, '', 0, 0, 0, '2017-10-22', 0, 'mdalibd100@gmail.com', 160, '0000-00-00', 100, '0', 100, 100, 'Cash Payment', '', '', 0, '0000-00-00', '', 0, 0, '0', '100', '', '', 'al', '1', '0000-00-00', 'hasnat', '2017-10-22', 'al', 'sell_order_invoice', '1', 'credit', '', 0),
(538, 0, 100000002, 0, '', 0, 0, 0, '2017-10-22', 0, 'mdalibd100@gmail.com', 160, '0000-00-00', 100, '0', 100, 100, 'Cash Payment', '', '', 0, '0000-00-00', '', 0, 0, '0', '100', '', '', 'al', '1', '0000-00-00', 'hasnat', '0000-00-00', '', 'sell_invoice', '', 'credit', '', 0),
(539, 0, 0, 100000001, 'sell_invoice', 0, 0, 0, '2017-10-22', 0, 'mdalibd100@gmail.com', 0, '0000-00-00', 0, '', 0, 0, '', '', '', 0, '0000-00-00', '', 0, 0, '', '25', '', '', 'al', '1', '0000-00-00', 'hasnat', '0000-00-00', '', 'update', '', 'debit', '', 0),
(540, 100000004, 0, 0, '', 0, 0, 0, '2017-10-22', 155, 'mdalibd100@gmail.com', 0, '0000-00-00', 300, '0', 300, 300, 'Cash Payment', '', '0', 0, '0000-00-00', '', 0, 0, '0', '300', '', '', 'al', '1', '0000-00-00', 'hasnat', '2017-10-22', 'al', 'order_invoice', '1', 'debit', '', 0),
(541, 0, 100000005, 0, '', 0, 0, 0, '2017-10-22', 155, 'mdalibd100@gmail.com', 0, '0000-00-00', 300, '0', 300, 300, 'Cash Payment', '', '', 0, '0000-00-00', '', 0, 0, '0', '300', '', '', 'al', '1', '0000-00-00', 'hasnat', '0000-00-00', '', 'purchase_invoice', '', 'debit', '', 0),
(542, 0, 100000003, 0, '', 0, 0, 0, '2017-10-22', 0, 'mdalibd100@gmail.com', 159, '0000-00-00', 2500, '0', 2500, 2500, 'Cash Payment', '', '', 0, '0000-00-00', '', 0, 0, '0', '2500', '', '', 'al', '1', '0000-00-00', 'hasnat', '0000-00-00', '', 'sell_invoice', '', 'credit', '', 0),
(543, 0, 100000001, 0, '', 0, 0, 0, '2017-10-23', 161, 'marufrabbi3858@gmail.com', 0, '0000-00-00', 0, '', 0, 0, '', '', '', 0, '0000-00-00', '', 0, 0, '', '7000', '', '', 'marufrabbi3858@gmail.com', '1', '0000-00-00', 'Twinkle', '0000-00-00', '', 'vendor_opening_amount', '', 'debit', '', 0),
(544, 0, 100000002, 0, '', 0, 0, 0, '2017-10-23', 162, 'marufrabbi3858@gmail.com', 0, '0000-00-00', 0, '', 0, 0, '', '', '', 0, '0000-00-00', '', 0, 0, '', '30000', '', '', 'marufrabbi3858@gmail.com', '1', '0000-00-00', 'Twinkle', '0000-00-00', '', 'vendor_opening_amount', '', 'credit', '', 0),
(545, 0, 100000003, 0, '', 0, 0, 0, '2017-10-23', 164, 'marufrabbi3858@gmail.com', 0, '0000-00-00', 0, '', 0, 0, '', '', '', 0, '0000-00-00', '', 0, 0, '', '5000', '', '', 'marufrabbi3858@gmail.com', '1', '0000-00-00', 'Twinkle', '0000-00-00', '', 'vendor_opening_amount', '', 'credit', '', 0),
(546, 0, 0, 0, '', 0, 100000001, 0, '2017-10-23', 0, 'marufrabbi3858@gmail.com', 0, '0000-00-00', 0, '', 0, 0, '', '', '', 0, '0000-00-00', '', 0, 0, '', '500000', '', '', 'marufrabbi3858@gmail.com', '1', '0000-00-00', 'Twinkle', '0000-00-00', '', 'cash_invest_capital', '', 'credit', '0', 0),
(547, 0, 0, 0, '', 0, 1, 0, '2017-10-23', 0, 'marufrabbi3858@gmail.com', 0, '0000-00-00', 0, '', 0, 0, '', '', '', 0, '0000-00-00', '', 0, 0, '', '500000', '', '', 'marufrabbi3858@gmail.com', '1', '0000-00-00', 'Twinkle', '0000-00-00', '', 'cash_invest_capital', '', 'credit', '0', 0),
(548, 0, 100000001, 0, '', 0, 0, 0, '2017-10-23', 0, 'marufrabbi3858@gmail.com', 0, '0000-00-00', 0, '', 208200, 0, '', '', '', 0, '0000-00-00', '', 0, 0, '', '208200', '', '', 'marufrabbi3858@gmail.com', '1', '0000-00-00', 'Twinkle', '0000-00-00', '', 'opening_products', '', 'credit', '', 0),
(549, 100000001, 0, 0, '', 0, 0, 0, '2017-10-23', 164, 'marufrabbi3858@gmail.com', 0, '0000-00-00', 19500, '0', 19500, 19500, 'Cash Payment', '', '', 0, '0000-00-00', '', 0, 0, '0', '19500', '', '', 'marufrabbi3858@gmail.com', '1', '0000-00-00', 'Twinkle', '2017-10-23', 'marufrabbi3858@gmail.com', 'order_invoice', '1', 'debit', '', 0),
(550, 0, 100000001, 0, '', 0, 0, 0, '2017-10-23', 164, 'marufrabbi3858@gmail.com', 0, '0000-00-00', 51000, '0', 51000, 51000, 'Cash Payment', '', '', 0, '0000-00-00', '', 0, 0, '0', '51000', '', '', 'marufrabbi3858@gmail.com', '1', '0000-00-00', 'Twinkle', '0000-00-00', '', 'purchase_invoice', '', 'debit', '', 0),
(551, 0, 100000002, 0, '', 0, 0, 0, '2017-10-23', 167, 'marufrabbi3858@gmail.com', 0, '0000-00-00', 0, '0', 0, 0, 'Cash Payment', '', '', 0, '0000-00-00', '', 0, 0, '0', '0', '', '', 'marufrabbi3858@gmail.com', '1', '0000-00-00', 'Twinkle', '0000-00-00', '', 'purchase_invoice', '', 'debit', '', 0),
(552, 0, 100000001, 0, '', 0, 0, 0, '2017-10-23', 0, 'marufrabbi3858@gmail.com', 168, '0000-00-00', 250, '0', 250, 250, 'Cash Payment', '', '', 0, '0000-00-00', '', 0, 0, '0', '250', '', '', 'marufrabbi3858@gmail.com', '1', '0000-00-00', 'Twinkle', '0000-00-00', '', 'sell_invoice', '', 'credit', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `login_onserial`
--

CREATE TABLE IF NOT EXISTS `login_onserial` (
  `sn` int(11) NOT NULL AUTO_INCREMENT,
  `user_type` varchar(32) NOT NULL,
  `pakage` varchar(32) NOT NULL,
  `email` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `status` int(1) NOT NULL,
  `date` date NOT NULL,
  `year` int(2) NOT NULL,
  `email_c` varchar(64) NOT NULL,
  `forgot_password` varchar(64) NOT NULL,
  PRIMARY KEY (`sn`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=53 ;

--
-- Dumping data for table `login_onserial`
--

INSERT INTO `login_onserial` (`sn`, `user_type`, `pakage`, `email`, `password`, `status`, `date`, `year`, `email_c`, `forgot_password`) VALUES
(38, 'Super', 'Free', 'tipstricks99@gmail.com', '1708fa76725fd38898b0bf047f9db530', 1, '2017-09-15', 1, 'c63c7048753bdb6d33dde70a9c8f4171', ''),
(37, 'Super', 'Free', 'mahesh.bhanderi13@gmail.com', '49bb197bec17b7d20b2df6b1f3c3434a', 1, '2017-09-14', 17, 'f7f640e401de130543b56a0bde24154f', ''),
(36, 'Super', 'Free', 'imti.anash@hotmail.com', '16461e0fab828b8a10be3c74eec4557e', 1, '2017-09-14', 5, '29ab3309479adfacc749031b218b144f', ''),
(35, 'Super', 'Free', 'globalbdjobs@gmail.com', '350af85d8ec533f5f725fa1e5dc3553d', 0, '2017-09-07', 1, '77680d109e188fe77d39ab28c4b50758', ''),
(34, 'Super', 'Free', 'anilshah999@hotmail.com', 'b4118f94f69dc29ceec1c6b6b83793ac', 1, '2017-09-06', 20, '7b225541a345b7111afe94bbb44d9f42', ''),
(33, 'Super', 'Free', 'Info@uniqueent.in', 'a57a6ba0b748ab9fb1857d330f012cb4', 1, '2017-09-06', 20, '9ebbaaf064ec8a5cec149c8a846cf916', ''),
(32, 'Super', 'Free', 'behindthebadge523@gmail.com', 'c6e9483745bea9f1385799d00edba726', 1, '2017-09-03', 20, '52c2a39f8daf5ded5a325458697dc854', ''),
(31, 'Super', 'Free', 'alphaomegafred@gmail.com', '570a90bfbf8c7eab5dc5d4e26832d5b1', 1, '2017-08-31', 1, '653e9dfa34f63b37a70b2f8d6e06ac7d', ''),
(30, 'Super', 'Free', 'julioalfaror@hotmail.com', 'd6679b6df130fa6a6bd0bab33fff95bd', 0, '2017-08-26', 1, '3ea023e6fd4dea4e91b8147ee8a8c950', ''),
(29, 'Super', 'Free', 'globalbdjobs@gmqil.com', '202cb962ac59075b964b07152d234b70', 0, '2017-07-25', 1, 'bc45714797ec497db317dbb79a30188b', ''),
(28, 'Super', 'Free', 'ferdaus5028@gmail.com', '202cb962ac59075b964b07152d234b70', 1, '2017-07-20', 1, '68e566fa84aa5339044aa7c01e7fdfe9', ''),
(27, 'Super', 'Free', 'mdalibd100@gmail.com', '202cb962ac59075b964b07152d234b70', 1, '2017-06-28', 1, '018a8e99e6a88577298d988b32b786c7', ''),
(26, 'Super', 'Free', 'mdaliceous@gmail.com', '202cb962ac59075b964b07152d234b70', 1, '2017-06-28', 1, 'b77ac702a8811e4f3fad1b5948ba3d0d', ''),
(39, 'Super', 'Free', 'saravanan_kandasamy@outlook.com', '4a68bcd8704ffc4c92777897e883ce07', 1, '2017-09-16', 3, 'ca6a2275e19610569ba896f2c5d06206', ''),
(40, 'Super', 'Free', 'adilisohb95@gmail.com', 'bf10f7fcb21779bfeef23e1b276d54a9', 1, '2017-09-18', 2, '05b7d6c1176d001e138d86aaa8d9fc59', ''),
(41, 'Super', 'Free', 'ntnatlosc@gmail.com', '638c32f633289070bdb270d1e8b05be3', 1, '2017-09-25', 5, 'f35d312f71ebdbb50d85b1f49471e3fa', ''),
(42, 'Super', 'Free', 'anowersanitary@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 0, '2017-09-28', 1, '62ef21de08c2067be0d0ef6e66c0ebbc', ''),
(43, 'Super', 'Free', 'almadhakhobar@gmail.com', '61f01dc783f5ac78b8f72abb410ab967', 1, '2017-09-28', 10, 'e161be249aff3273b5179e86759b7cea', ''),
(44, 'Super', 'Free', 'wqaex20@gmail.com', '61a4faf71bc86280ccd6ba1448668ec7', 0, '2017-10-02', 1, '09a2e4f0d8b061958264c9cbcb3f9cd7', ''),
(45, 'Super', 'Free', 'flowerpalace386@gmail.com', 'f99e3012d9f42eb68eefe964486d5d1f', 0, '2017-10-02', 1, '20b1af9b5261df63c604cbe158fc130e', ''),
(46, 'Super', 'Free', 'mr.farooq.ok@gmail.com', 'a45fdb1e4ac646c9e65a1769663e5704', 1, '2017-10-03', 6, '55d25e1be7dfe48d31c4cc4a4771aa87', ''),
(47, 'Super', 'Silver', 'r@soft19.com', '202cb962ac59075b964b07152d234b70', 0, '2017-10-22', 1, 'e1fca95a493aef8bffab330ff0920580', ''),
(48, 'Super', 'Silver', 'rd@soft19.com', '202cb962ac59075b964b07152d234b70', 0, '2017-10-22', 1, 'ed0f91a76660ff06a5c30cd57a155782', ''),
(49, 'Super', 'Free', 'rda@soft19.com', '202cb962ac59075b964b07152d234b70', 0, '2017-10-22', 1, '6d668a39d4b7237474237f27cdb0146f', ''),
(50, 'Super', 'Silver', 'rdad@soft19.com', '202cb962ac59075b964b07152d234b70', 0, '2017-10-22', 1, '8c779fcfdcca9a1e453eaea5063bc4eb', ''),
(51, 'Super', 'Silver', 'rdcf@soft19.com', '202cb962ac59075b964b07152d234b70', 0, '2017-10-22', 1, '9fc1cdae6a67020154f6338aa0cb0f23', ''),
(52, 'Super', 'Free', 'marufrabbi3858@gmail.com', '202cb962ac59075b964b07152d234b70', 1, '2017-10-23', 1, '10597de5546f4dd4efbccdac009c9cd0', '');

-- --------------------------------------------------------

--
-- Table structure for table `note_onserial`
--

CREATE TABLE IF NOT EXISTS `note_onserial` (
  `sn` int(11) NOT NULL AUTO_INCREMENT,
  `entry_date` date NOT NULL,
  `date_for_note` date NOT NULL,
  `note` varchar(200) NOT NULL,
  `company_username` varchar(32) NOT NULL,
  `sub_user` varchar(32) NOT NULL,
  `super_email` varchar(32) NOT NULL,
  `read_status` varchar(3) NOT NULL,
  `status` varchar(3) NOT NULL,
  PRIMARY KEY (`sn`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

-- --------------------------------------------------------

--
-- Table structure for table `products_details_onserial`
--

CREATE TABLE IF NOT EXISTS `products_details_onserial` (
  `sn` int(11) NOT NULL AUTO_INCREMENT,
  `product_title` varchar(64) NOT NULL,
  `product_name` varchar(64) NOT NULL,
  `product_id` varchar(32) NOT NULL,
  `status` int(1) NOT NULL,
  `products_company` varchar(32) NOT NULL,
  `size` varchar(32) NOT NULL,
  `unit_price` int(11) NOT NULL,
  `tax` varchar(5) NOT NULL,
  `net_unit_price` int(11) NOT NULL,
  `vendor_serial` int(11) NOT NULL,
  `sell_price` int(11) NOT NULL,
  `warenty_days` int(11) NOT NULL,
  `warenty_type` varchar(32) NOT NULL,
  `serial_length` int(11) NOT NULL,
  `company_username` varchar(32) NOT NULL,
  `sub_username` varchar(32) NOT NULL,
  `super_email` varchar(32) NOT NULL,
  `default_discount` varchar(8) NOT NULL,
  `remarks` varchar(128) NOT NULL,
  PRIMARY KEY (`sn`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=125 ;

--
-- Dumping data for table `products_details_onserial`
--

INSERT INTO `products_details_onserial` (`sn`, `product_title`, `product_name`, `product_id`, `status`, `products_company`, `size`, `unit_price`, `tax`, `net_unit_price`, `vendor_serial`, `sell_price`, `warenty_days`, `warenty_type`, `serial_length`, `company_username`, `sub_username`, `super_email`, `default_discount`, `remarks`) VALUES
(118, 'Lux 90 mg', 'Lux', '100000001', 1, '', '90 mg', 20, '', 0, 155, 25, 0, 'None', 0, 'hasnat', '', 'mdalibd100@gmail.com', '', ''),
(119, 'lamp bati mini', 'lamp bati', '100000001', 1, '', 'mini', 150, '', 0, 164, 250, 0, 'None', 0, 'Twinkle', '', 'marufrabbi3858@gmail.com', '', ''),
(120, 'tar 2nn', 'tar', '100000002', 1, '', '2nn', 350, '', 0, 164, 700, 0, 'None', 0, 'Twinkle', '', 'marufrabbi3858@gmail.com', '', ''),
(121, 'tar 36', 'tar', '100000003', 1, '', '36', 570, '', 0, 162, 1150, 0, '', 0, 'Twinkle', '', 'marufrabbi3858@gmail.com', '', ''),
(122, 'dish tar normal', 'dish tar', '100000004', 1, '', 'normal', 10, '', 0, 167, 15, 0, 'None', 0, 'Twinkle', '', 'marufrabbi3858@gmail.com', '', ''),
(123, 'dish tar good', 'dish tar', '100000005', 1, '', 'good', 12, '', 0, 164, 18, 0, '', 0, 'Twinkle', '', 'marufrabbi3858@gmail.com', '', ''),
(124, 'enarji light 100w', 'enarji light', '100000006', 1, '', '100w', 120, '', 0, 162, 180, 180, '', 0, 'Twinkle', '', 'marufrabbi3858@gmail.com', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `stock_audit_adjust_onserial`
--

CREATE TABLE IF NOT EXISTS `stock_audit_adjust_onserial` (
  `sn` int(11) NOT NULL AUTO_INCREMENT,
  `product_title` varchar(64) NOT NULL,
  `product_id` varchar(32) NOT NULL,
  `stock_adjust` int(11) NOT NULL,
  `lost_insentive_type` varchar(32) NOT NULL,
  `company_username` varchar(32) NOT NULL,
  `subuser` varchar(32) NOT NULL,
  `date` date NOT NULL,
  `super_email` varchar(32) NOT NULL,
  `remarks` varchar(400) NOT NULL,
  PRIMARY KEY (`sn`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `stock_now_onserial`
--

CREATE TABLE IF NOT EXISTS `stock_now_onserial` (
  `sn` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `opening_stock` int(11) NOT NULL,
  `total_purchase` int(11) NOT NULL,
  `current_stock` int(11) NOT NULL,
  `stock_check` int(11) NOT NULL,
  `audit_adjust` int(11) NOT NULL,
  `total_sell` int(11) NOT NULL,
  `purchase_return` int(11) NOT NULL,
  `sell_return` int(11) NOT NULL,
  `damage` int(11) NOT NULL,
  `intensive` int(11) NOT NULL,
  `warranty` int(11) NOT NULL,
  `sell_warranty` int(11) NOT NULL,
  `company_username` varchar(32) NOT NULL,
  `super_email` varchar(32) NOT NULL,
  `vendor_sn` int(11) NOT NULL,
  PRIMARY KEY (`sn`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=89 ;

--
-- Dumping data for table `stock_now_onserial`
--

INSERT INTO `stock_now_onserial` (`sn`, `product_id`, `opening_stock`, `total_purchase`, `current_stock`, `stock_check`, `audit_adjust`, `total_sell`, `purchase_return`, `sell_return`, `damage`, `intensive`, `warranty`, `sell_warranty`, `company_username`, `super_email`, `vendor_sn`) VALUES
(83, 100000001, 10, 1120, 1022, 0, 0, 108, 5, 0, 0, 0, 1, 0, 'hasnat', 'mdalibd100@gmail.com', 155),
(84, 100000005, 100, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Twinkle', 'marufrabbi3858@gmail.com', 0),
(85, 100000004, 100, 100, 200, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Twinkle', 'marufrabbi3858@gmail.com', 167),
(86, 100000003, 300, 0, 300, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Twinkle', 'marufrabbi3858@gmail.com', 0),
(87, 100000002, 100, 100, 200, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Twinkle', 'marufrabbi3858@gmail.com', 164),
(88, 100000001, 0, 100, 99, 0, 0, 1, 0, 0, 0, 0, 0, 0, 'Twinkle', 'marufrabbi3858@gmail.com', 164);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
