$(document).ready(function() {
	$('.free_edition').click(function(e) {
		var year = $("#free_year").val();
		$(".pakage_name").html("Free");
		var total=0;
		var discount=0;
		var net=0;
		$(".pakage_year").html(year);
		$(".total_cost").html(total);
		$(".total_discout").html(discount);
		$(".net_cost").html(net);
		$(".total_cost_input").val(total);
		$(".total_discout_input").val(discount);
		$(".net_cost_input").val(net);
		$(".software_pakage_input").val('Free');
		$(".year_input").val(year);
	})
	$('.standard_edition').click(function(e) {
		var year = $("#standard_year").val();
		$(".pakage_name").html("Silver");
		var total=299*year;
		var discount=total*(year/100 );
		var net=total-discount;
		$(".pakage_year").html(year);
		$(".total_cost").html(total);
		$(".total_discout").html(discount);
		$(".net_cost").html(net);
		$(".total_cost_input").val(total);
		$(".total_discout_input").val(discount);
		$(".net_cost_input").val(net);
		$(".software_pakage_input").val('Silver');
		$(".year_input").val(year);
	})
	$('.extended_edition').click(function(e) {
		var year = $("#extended_year").val();
		$(".pakage_name").html("Gold");
		var total=599*year;
		var discount=total*(year/100 );
		var net=total-discount;
		$(".pakage_year").html(year);
		$(".total_cost").html(total);
		$(".total_discout").html(discount);
		$(".net_cost").html(net);
		$(".total_cost_input").val(total);
		$(".total_discout_input").val(discount);
		$(".net_cost_input").val(net);
		$(".software_pakage_input").val('Gold');
		$(".year_input").val(year);
	})
	$('.expand_edition').click(function(e) {
		var year = $("#expand_year").val();
		$(".pakage_name").html("Diamond");
		var total=999*year;
		var discount=total*(year/100 );
		var net=total-discount;
		$(".pakage_year").html(year);
		$(".total_cost").html(total);
		$(".total_discout").html(discount);
		$(".net_cost").html(net);
		$(".total_cost_input").val(total);
		$(".total_discout_input").val(discount);
		$(".net_cost_input").val(net);
		$(".software_pakage_input").val('Diamond');
		$(".year_input").val(year);
	})
	/*$('.add_new_company').click(function() {
		var company_name = $("#company_name_add_com").val();
		var company_username=$("#company_username_add_com").val();
		alert('ok');
		var data_key='company_name='+ company_name+'&company_username='+ company_username;
		$.ajax({
		type: "POST",
		url: "add_new_company.php",
		data: data_key,
		success: function(html){
		
			$(".add_company_msg").html(html);
		     }		
		});
	})*/
})