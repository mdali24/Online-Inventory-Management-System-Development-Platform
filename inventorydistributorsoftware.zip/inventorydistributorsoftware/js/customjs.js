
	var docHeight = $('.content').height();
	if(docHeight<750){
		var footerHeight = $('.footer').height();
	var footerTop = $('.footer').position().top + footerHeight;

	if (footerTop < docHeight) {
		$('.footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
	} 
	}else{
		$('.footer').css('margin-top', 50 + 'px');
	}
	