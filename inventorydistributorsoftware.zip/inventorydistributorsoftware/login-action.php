<?php 
ob_start();
include_once('db.php');
include_once('method.php');
$var_date=date('y/m/d');
$empty_check=array();
if(!empty($_POST['user_email'])){
$user_email=$_POST['user_email'];
$user_type="Super";
}else{
$empty_check[]="Empty user email";
}
if(!empty($_POST['user_pass'])){
$user_pass=md5($_POST['user_pass']);
}else{
$empty_check[]="Empty user password";
}
$status=1;
if(empty($empty_check)){
	if($stmt_sql = $mysqli->prepare("SELECT * FROM login_onserial WHERE user_type=? and email=? and password=? and status=?")){
		
		$stmt_sql->bind_param("sssi",$user_type,$user_email,$user_pass,$status);
		$stmt_sql->execute();
		$stmt_sql->store_result();
		$rows_num=$stmt_sql->num_rows;
		if($rows_num>0){
			session_start();
			session_regenerate_id(TRUE);
			$_SESSION['user_email_session']=$user_email;
			$_SESSION['user_type_session']=$user_type;
			header("Location:super_admin.php");
		}else{
		     echo "Something wrong";
		}
	}
}else{
   echo "Some Fields Empty";
}
?>