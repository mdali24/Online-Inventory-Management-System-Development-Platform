<?php 
include_once('db.php');
session_start();
session_regenerate_id(TRUE);
if(isset($_SESSION['markenter_email_session']) and isset($_SESSION['markenter_type_session'])){
	$markenter_email=$_SESSION['markenter_email_session'];
	$markenter_type=$_SESSION['markenter_type_session'];
	
$empty_check=array();
$company_select=$_SESSION['company_username_session'];

if(!empty($_POST['full_name'])){
$full_name=$_POST['full_name'];
}else{
$empty_check[]="Empty full_name";
}
if(!empty($_POST['vendor_mobile_no'])){
$vendor_mobile_no=$_POST['vendor_mobile_no'];
}else{
$empty_check[]="Empty vendor_mobile_no";
}
if(!empty($_POST['vendor_telephone_no'])){
$vendor_telephone_no=$_POST['vendor_telephone_no'];
}else{
$vendor_telephone_no="";
}
if(!empty($_POST['vendor_company_name'])){
$vendor_company_name=$_POST['vendor_company_name'];
}else{
$empty_check[]="Empty vendor_email";
}
if(!empty($_POST['vendor_address'])){
$vendor_address=$_POST['vendor_address'];
}else{
$empty_check[]="Empty vendor_address";
}
if(!empty($_POST['vendor_debit_limit'])){
$vendor_debit_limit=$_POST['vendor_debit_limit'];
}else{
$vendor_debit_limit=1000000000;
}
if(!empty($_POST['vendor_debit_days'])){
$vendor_debit_days=$_POST['vendor_debit_days'];
}else{
$vendor_debit_days=3650;
}


$status=1;

if(empty($empty_check)){
	
		if($stmt_sql = $mysqli->prepare("SELECT * FROM markenter_onserial WHERE user_type=? and email=? and status=?")){
			
			$stmt_sql->bind_param("ssi",$markenter_type,$markenter_email,$status);
			$stmt_sql->execute();
			$stmt_sql->store_result();
			$rows_num=$stmt_sql->num_rows;
			if($rows_num>0){
				$stmt = $mysqli->prepare("UPDATE markenter_onserial  SET 
				full_name=?,
				vendor_company_name=?,
				vendor_mobile_no=?,
				vendor_telephone_no=?,
				vendor_address=?,
				vendor_debit_limit=?,
				vendor_debit_days=? 
				 WHERE email=?");
				$ok=1;		
				$stmt->bind_param('ssiisiis', $full_name, $vendor_company_name, $vendor_mobile_no, $vendor_telephone_no, $vendor_address, $vendor_debit_limit, $vendor_debit_days, $markenter_email);
					$update_status = $stmt->execute();
				if($update_status==1){
					 echo "Updated Successfully";
				}
			}else{
				echo "No Markenter in used this email";
			}
		}
	
}else{
   echo "Some Fields Empty";
}

header( "refresh:2;url=software_vendor.php" );
}else{
    echo "Please <a href=\"markenter_about.php\" >Login</a>";
}
?>