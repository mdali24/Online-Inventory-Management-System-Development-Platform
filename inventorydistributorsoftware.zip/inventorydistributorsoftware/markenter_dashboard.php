<?php 
include_once('db.php');
session_start();
session_regenerate_id(TRUE);
if(isset($_SESSION['markenter_email_session']) and isset($_SESSION['markenter_type_session'])){
	$markenter_email=$_SESSION['markenter_email_session'];
	$markenter_type=$_SESSION['markenter_type_session'];
	
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title><?php echo $company;?></title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="../inventory-software.png">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	<style>
	.menu{
		list-style:none;
		margin-top:50px;
		margin-bottom:0;
		padding-bottom:0;
	}
	.menu>li{
		display:inline-block;
		border-left:1px solid #55e353;
	}
	.menu>li>a{
		text-decoration:none;
		padding:15px;
		background-color:#e15226;
		border-radius:1px;
		color:#ffffff;
	}
	.color{
		color:#666;
		background-color:#eee;
	}
	.h1_color{
		color:#e040df;
	}
	.white_color{
		color:#ffffff;
	}
	.features{
		list-style:none;
	}
	.feature{
		color:#ffffff;
	}
	.company_border{
		border:1px solid #ffffff;
		padding-bottom:10px;
		width:140px;
		float:left;
		margin-right:5px;
	}
	.company_con{
		margin:2px;
		background-color:#888888;
	}
	.company{
		color:#ffffff;
		padding:5px;
	}
	.add_company{
		padding:7px;
		margin-top:15px;
		float:right;
	}
	.update{
		margin:10px;
		width:150px;
		text-align:center;
	}
	.vendor{
		background-color:#f6f6f6;
	}
	</style>
  </head>
  <body>
  
	<?php include_once('markenter_menu.php');?>
	
	<div class="container-fluid header_class">
		<div class="row">
			<div class="col-md-6 col-sm-6">
				<section class="main">
					<h2>Vendor Dashboard</h2>
				</section>
				<!--<h1 class="h1_color"></h1>-->
			</div>
			<div class="col-md-5 col-sm-5">
				<p style="color:#ffffff;margin-top:50px;font-size:18px;">Order management.</p>
			</div>
			<div class="col-md-1 col-sm-1">
				<a class="logout" href="logout.php">logout</a>
			</div>
			
		</div>
	</div>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-3 col-sm-3">
				You have 5 companies 
			</div>
			<div class="col-md-3 col-sm-3">
				You have 5 companies 
			</div>
			<div class="col-md-3 col-sm-3">
				You have 5 orders 
			</div>
			<div class="col-md-3 col-sm-3">
				You have 5 new orders 
			</div>
			<div class="col-md-3 col-sm-3">
				5 order request recived
			</div>
			<div class="col-md-3 col-sm-3">
				5 order request sent
			</div>
			<div class="col-md-3 col-sm-3">
				You have 5 invoices 
			</div>
			<div class="col-md-3 col-sm-3">
				You have 5 new invoices
			</div>
			<div class="col-md-3 col-sm-3">
				You have 5 products
			</div>
		</div>
	</div>
	
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<script src="javascript.js"></script>
  </body>
</html>
<?php 
}else{
    echo "Please <a href=\"markenter_login.php\" >Login</a>";
}
?>