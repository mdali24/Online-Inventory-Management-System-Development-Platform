<?php
include_once('db.php');
if(isset($_GET['token'])){
$email_c=$_GET['token'];

if($stmt_sql = $mysqli->prepare("SELECT * FROM markenter_onserial WHERE forgot_pass=?")){
		
		$stmt_sql->bind_param("s",$email_c);
		$stmt_sql->execute();
		$stmt_sql->store_result();
		$rows_num=$stmt_sql->num_rows;
		if($rows_num>0){
			?>
			
<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Login Form</title>
  
      <link rel="stylesheet" href="css/style.css">
      <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400,700">
      
</head>

<body>
  <html lang="en-US">
  <div class="container-fluid header_class">
	<div class="row">
		<div class="col-md-12">
			<h1><span class="soft">Soft19</span> Inventory</h1>
		</div>
	</div>
   </div>
   <div class="container-fluid border_bottom">
	<h2>For your business marketing</h2>		
   </div>
    <div id="login">
      <form name='form-login' action="markenter_forgot_password_final.php" method="POST">
		
        <span class="fontawesome-lock"></span>
          <input type="password" id="user_pass" name="user_pass" placeholder="Set new password">
       	<input type="hidden" id="forgot_pass" name="forgot_pass" value="<?php echo $email_c;?>">
        <input type="submit" value="Update">
	
</form>

</body>
</html>

			
			<?php
		}else{
			echo "Wrong Token";
		}
}
}else{
	echo "Please Register";
}

?>