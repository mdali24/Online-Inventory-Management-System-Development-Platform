<?php 

?>
<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>User Login Form</title>
  	<!-- Bootstrap -->
    	<link href="css/bootstrap.min.css" rel="stylesheet">
      <link rel="stylesheet" href="design.css">
     
</head>

<body>
  <?php include_once('client_header.php');?>
  <h1 class="client_login_title">Vendor Login</h1>
<form  action="markenter_login_action.php" method="POST" class="login">
<input type="email"  class="client_login_input"  name="user_email" placeholder="Email">
<input type="password"  class="client_login_input"  name="user_pass" placeholder="Password">
<input type="submit" value="Login"   class="client_login_submit">
</form>
<a href="markenter_forgot_password.php" class="forgot">Forgot Password</a>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="javascript.js"></script>
</body>
</html>
