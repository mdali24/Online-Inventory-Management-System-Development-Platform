<?php 

?>
<div class="container-fluid menu_con">
				<nav>
				  <ul>
				  	<li><a href="markenter_dashboard.php">Dashboard</a></li>
					<li><a href="markenter_about.php">About</a></li>
					<li><a href="#">Products</a></li>
					<li><a href="#">Companies</a></li>
					<li><a href="#">Orders</a></li>
					<li><a href="#">Invoices</a></li>
					
					<li><a href="#">Report</a></li>
					
				  </ul>
				</nav>
	</div>