<?php 
include_once('db.php');
include_once('method.php');
$var_date=date('y/m/d');
$empty_check=array();
if(!empty($_POST['markenter_email'])){
$markenter_email=$_POST['markenter_email'];
}else{
$empty_check[]="empty markenter_email";
}
if(!empty($_POST['markenter_pass'])){
$markenter_pass=$_POST['markenter_pass'];
}else{
$empty_check[]="empty markenter_pass";
}
if(!empty($_POST['markenter_pass_con'])){
$markenter_pass_con=$_POST['markenter_pass_con'];
}else{
$empty_check[]="empty markenter_pass_con";
}

if($markenter_pass==$markenter_pass_con){
$markenter_pass=md5($markenter_pass);
if(empty($empty_check)){
if($stmt_sql = $mysqli->prepare("SELECT * FROM markenter_onserial WHERE email=?")){
		
		$stmt_sql->bind_param("s",$markenter_email);
		$stmt_sql->execute();
		$stmt_sql->store_result();
		$rows_num=$stmt_sql->num_rows;
		$f=0;
		if($rows_num<1){
		$vendor_debit_limit=1000000000;
		$vendor_debit_days=3650;
		$email_c=md5($markenter_email.time());
		$new_markenter_add=new data;
		$new_markenter_add->insert(
		"markenter_onserial",
		['user_type'=>"Markenter",
		'email'=>"$markenter_email",
		'password'=>"$markenter_pass",
		'email_con'=>"$email_c",
		'forgot_pass'=>"0",
		'status'=>"$f",
		'vendor_debit_limit'=>"$vendor_debit_limit",
		'vendor_debit_days'=>"$vendor_debit_days",
		'date'=>"$var_date"],
		"sssssiiis",
		['',
		'']);
			$c_url="http://inventorysoftwareservices.com/new/markenter_emailconfarmation.php?token=$email_c";
			$msg="Confirm your email $c_url";
			if(mail($markenter_email,"inventorysoftwareservices.com email confarmation",$msg,"Do not Reply")){
					echo "You are registered Successfully"."<br/>";
					echo "Please confirm your email";
					
				}
		}else{
		  echo "This email already has an account. Please <a href=\"markenter_login.php\">login</a>";
		}
	}

	}else{
		 echo "Some fields empty";
	}
}else{
	
	echo "Password is not match";
	}
?>