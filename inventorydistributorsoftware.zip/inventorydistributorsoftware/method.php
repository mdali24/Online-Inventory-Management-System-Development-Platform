<?php 
include_once('db.php');
class data{
	public function insert($tbname,array $keyvalue,$type,array $message){
		$tkey=$tvalue=$u=$sqlinsert="";
		$this->tbname=$tbname;
		$this->keyvalue=$keyvalue;
		$this->type=$type;
		$this->message=$message;
		foreach($keyvalue as $key=>$value){
			$tkey.=",".$key;$tvalue.=",,"."$value";
		}
		
		$tkey=substr($tkey,1);
		
		$tvalue=substr($tvalue,2);
		$tvalue="$type".",,".$tvalue;
		$svalue=explode(",,",$tvalue);
		
		$length=sizeof($keyvalue);
		
		$u="?";
		for($i=1;$i<$length;$i++){
			$u.=","."?";
		}
		$abc="INSERT INTO $tbname($tkey)VALUES($u)";
		 
		global $mysqli;
		$sqlinsert=$mysqli->prepare("INSERT INTO $tbname($tkey)VALUES($u)");
		$ref = array();
		
		foreach($svalue as $key => $value) $ref[$key] = &$svalue[$key];
		
		call_user_func_array(array($sqlinsert, 'bind_param'), $ref);
		
		$sqlinsert->execute();
		if($sqlinsert==TRUE){
			echo $message[0];
		}else{
			echo $message[1];
		}
		
	}

}

?>