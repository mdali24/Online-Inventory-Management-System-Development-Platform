<?php 
session_destroy();
session_regenerate_id(TRUE);
  echo "Payment Cancel";
unset($_SESSION['email_token']);
session_destroy();
?>