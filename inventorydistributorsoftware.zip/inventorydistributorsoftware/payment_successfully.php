<?php
include_once('db.php');
session_start();
session_regenerate_id(TRUE);
if(isset($_SESSION['email_token'])){
$email=$_SESSION['email_token'];
if($stmt_sql = $mysqli->prepare("SELECT * FROM login_onserial WHERE email=?")){
		
		$stmt_sql->bind_param("s",$email);
		$stmt_sql->execute();
		$stmt_sql->store_result();
		$rows_num=$stmt_sql->num_rows;
		if($rows_num>0){
			$stmt = $mysqli->prepare("UPDATE login_onserial SET 
			status=?
			 WHERE email=?");
			$ok=1;		
			$stmt->bind_param('is', $ok, $email);
				$update_status = $stmt->execute();
				if($update_status==1){
					 echo "Payment Successfully.Please <a href=\"login.php\">login</a>";
				}
		}
}
}
unset($_SESSION['email_token']);
session_destroy();
?>
