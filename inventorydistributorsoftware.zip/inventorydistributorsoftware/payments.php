<?php 

?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Paypal Payments</title>
  	<!-- Bootstrap -->
    	<link href="css/bootstrap.min.css" rel="stylesheet">
      <link rel="stylesheet" href="design.css">
     
</head>
<body>
<?php include_once('client_header.php');?>
<?php 
include_once('db.php');
include_once('method.php');
$var_date=date('y/m/d');
$empty_check=array();
if(!empty($_POST['total_cost'])){
$total_cost=$_POST['total_cost'];
}else{
//$empty_check[]="empty total_cost";
}
if(!empty($_POST['total_discout'])){
$total_discout=$_POST['total_discout'];
}else{
//$empty_check[]="empty total_discout";
}
if(!empty($_POST['net_cost'])){
$net_cost=$_POST['net_cost'];
}else{
//$empty_check[]="empty net_cost";
}
if(!empty($_POST['year'])){
$year=$_POST['year'];
}else{
$empty_check[]="empty year";
}
if(!empty($_POST['software_pakage'])){
$software_pakage=$_POST['software_pakage'];
if($software_pakage=='Free'){
	$warehouse=1;
}else if($software_pakage=='Silver'){
	$warehouse=1;
}else if($software_pakage=='Gold'){
	$warehouse=5;
}else if($software_pakage=='Diamond'){
	$warehouse=50;
}else{
	$warehouse=0;
}
}else{
$empty_check[]="empty software_pakage";
}
if(!empty($_POST['first_name'])){
$first_name=$_POST['first_name'];
}else{
$empty_check[]="Empty first name";
}
if(!empty($_POST['last_name'])){
$last_name=$_POST['last_name'];
}else{
$empty_check[]="Empty last name";
}
if(!empty($_POST['address'])){
$address=$_POST['address'];
}else{
$empty_check[]="Empty address";
}
if(!empty($_POST['email'])){
$email=$_POST['email'];
$email_c=md5($email.time());
session_start();
session_regenerate_id(TRUE);
$_SESSION['email_token']=$email;
}else{
$empty_check[]="Empty email";
}
if(!empty($_POST['password'])){
$password=$_POST['password'];
}else{
$empty_check[]="Empty password";
}
if(!empty($_POST['password_confirmation'])){
$password_confirmation=$_POST['password_confirmation'];
}else{
$empty_check[]="Empty password confirmation";
}
if($password==$password_confirmation){
$password=md5($password);
if(empty($empty_check)){
if($stmt_sql = $mysqli->prepare("SELECT * FROM login_onserial WHERE email=?")){
		
		$stmt_sql->bind_param("s",$email);
		$stmt_sql->execute();
		$stmt_sql->store_result();
		$rows_num=$stmt_sql->num_rows;
		$f=0;
		if($rows_num<1){
		$new_client_add=new data;
		$new_client_add->insert(
		"login_onserial",
		['user_type'=>"Super",
		'email'=>"$email",
		'pakage'=>"$software_pakage",
		'year'=>"$year",
		'email_c'=>"$email_c",
		'password'=>"$password",
		'status'=>"$f",
		'date'=>"$var_date"],
		"sssissis",
		['',
		'']);
		$new_client_details_add=new data;
		$new_client_details_add->insert(
		"client_details_onserial",
		['email'=>"$email",
		'first_name'=>"$first_name",
		'last_name'=>"$last_name",
		'address'=>"$address",
		'date'=>"$var_date"],
		"sssss",
		['',
		'']);
		if($software_pakage=='Free'){
			$c_url="http://inventorysoftwareservices.com/inventorymanagementsoftware/emailconfarmation.php?token=$email_c";
			$msg="Confirm your email $c_url";
			if(mail($email,"inventorysoftwareservices.com email confarmation",$msg,"Do not Reply")){
			echo "<h1 class=\"client_login_title\">You are registered Successfully.Please confirm your email</h1>";
				
				}
		}else{
?>
<form action="https://www.paypal.com/cgi-bin/webscr" method="post">

  <input type="hidden" name="business" value="paytonow@gmail.com">

  <input type="hidden" name="cmd" value="_xclick">

  <input type="hidden" name="currency_code" value="USD">

  <input type="hidden" name="item_name" value="<?php echo $software_pakage;?>" />

  <input type="hidden" name="amount" value="<?php echo $net_cost;?>" />
  <!--<input type="hidden" name="notify_url" value="http://inventorysoftwareservices.com/new/listener.php">-->
  <input type="hidden" name="return" value="http://inventorysoftwareservices.com/inventorymanagementsoftware/payment_successfully.php">
  <input type="hidden" name="cancel_return" value="http://inventorysoftwareservices.com/inventorymanagementsoftware/payment_cancel.php">
  
  <input style="width:200px;margin:25px auto;display:block;" type="image" name="submit" border="0"
  src="Paypal-Button.jpg"
  alt="Buy Now">
  <img alt="" border="0" width="1" height="1"
  src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" >

</form>
<?php
		}
		}else{
		 echo "<h1 class=\"client_login_title\">This email already has an account. Please <a href=\"client_login.php\">login</a></h1>";
		 
		}
	}
		
	}else{
		echo "<h1 class=\"client_login_title\">Some fields empty</h1>";
	}
}else{

	echo "<h1 class=\"client_login_title\">Password is not match</h1>";
	}
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="javascript.js"></script>
</body>
</html>