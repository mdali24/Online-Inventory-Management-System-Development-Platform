<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include_once('../db.php');
//echo "find";
if(!empty($_POST['sn_del']) and !empty($_POST['company_find'])){
	$sn_del=$_POST['sn_del'];
	$company_find=$_POST['company_find'];
	if ($stmt = $mysqli->prepare("DELETE FROM free_products_onserial WHERE sn=? and company_username=?")) {
	$stmt->bind_param("is",$sn_del,$company_find);
	$delete_status=$stmt->execute();
	if($delete_status==1){
		echo "Remove Successfully";
		}
	}
}

?>