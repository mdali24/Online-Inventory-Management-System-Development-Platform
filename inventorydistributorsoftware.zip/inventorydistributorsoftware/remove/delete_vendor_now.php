<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include_once('../db.php');
if(!empty($_POST['sn_del']) and !empty($_POST['company_find'])){
	$sn_del=$_POST['sn_del'];
	$company_find=$_POST['company_find'];
	
		if ($stmt_delete = $mysqli->prepare("DELETE FROM company_markenter_onserial WHERE sn=? and company_username=?")) {
		$stmt_delete->bind_param("is",$sn_del,$company_find);
		$delete_status=$stmt_delete->execute();
		if($delete_status==1){
			echo "Remove Successfully";
			}
		}		
	
}

?>