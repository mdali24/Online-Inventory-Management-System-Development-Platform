<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include_once('db.php');
session_start();
session_regenerate_id(TRUE);
$empty_check=array();
if(!empty($_POST['company_username'])){
$company_username=$_POST['company_username'];
}else{
$empty_check[]="Empty company username";
}
if(!empty($_POST['sub_username'])){
$sub_username=$_POST['sub_username'];
}else{
$empty_check[]="Empty sub username";
}
if(!empty($_POST['user_pass'])){
$user_pass=md5($_POST['user_pass']);
}else{
$empty_check[]="Empty user password";
}

$user_ip =md5($_SERVER['HTTP_USER_AGENT']);

if(empty($empty_check)){
$status=1;
	if($stmt_sql = $mysqli->prepare("SELECT * FROM company_users_onserial WHERE company_username=? and sub_username=?  and password=? and status=?")){
		
		$stmt_sql->bind_param("sssi",$company_username,$sub_username,$user_pass,$status);
		$stmt_sql->execute();
		$stmt_sql->store_result();
		$rows_num=$stmt_sql->num_rows;
		if($rows_num>0){
			$query = "SELECT user_type FROM company_users_onserial WHERE company_username=? and sub_username=? and password=? and status=?"; 
			if($stmt = $mysqli->prepare($query)){
			$stmt->bind_param("sssi",$company_username,$sub_username,$user_pass,$status);
			$stmt->execute();
			$stmt->store_result();
			$num_of_rows = $stmt->num_rows;
			$stmt->bind_result($user_type);
			$stmt->fetch();
			$login_usertype=$user_type;
			}
			
			$_SESSION['user_session']=$login_usertype;
			$_SESSION['company_username_session']=$company_username;
			$_SESSION['sub_user_session']=$sub_username;
			
		}else{
		     echo "No user found";
		}
	}
}else{
	echo "";
}
if(isset($_REQUEST["go"])){
if(isset($_SESSION['user_email_session']) and isset($_SESSION['user_type_session'])){
	$user_email=$_SESSION['user_email_session'];
	$login_usertype=$_SESSION['user_type_session'];
	if(!empty($_POST['company_user'])){
	$company_user=$_POST['company_user'];
	$_SESSION['user_session']=$login_usertype;
	$_SESSION['company_username_session']=$company_user;
	$_SESSION['sub_user_session']="Super Admin";
	}else{
	echo "Please first logout as a super admin.Then login as a company user";
	}
	
 
}else{
    echo "";
}
}
if(isset($_SESSION['user_session']) and isset($_SESSION['company_username_session']) and isset($_SESSION['sub_user_session'])){
	$user_type_now=$_SESSION['user_session'];
	$company_now=$_SESSION['company_username_session'];
	$user_now=$_SESSION['sub_user_session'];
	$status=1;
	$query = "SELECT email,company_name,address,logo FROM companies_onserial WHERE company_username=? and status=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param("si",$company_now,$status);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($email,$company_name,$address,$logo);
	$stmt->fetch();
	$super_email=$email;
	$company=$company_name;
	$address=$address;
	$logo=$logo;
	$_SESSION['address']=$address;
	$_SESSION['logo']=$logo;
	}
	
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title><?php echo $company;?></title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="design.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="../inventory-software.png">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	<style>
	.menu{
		list-style:none;
		margin-top:50px;
		margin-bottom:0;
		padding-bottom:0;
	}
	.menu>li{
		display:inline-block;
		border-left:1px solid #55e353;
	}
	.menu>li>a{
		text-decoration:none;
		padding:15px;
		background-color:#e15226;
		border-radius:1px;
		color:#ffffff;
	}
	.color{
		color:#666;
		background-color:#eee;
	}
	.h1_color{
		color:#e040df;
	}
	.white_color{
		color:#ffffff;
	}
	.features{
		list-style:none;
	}
	.feature{
		color:#ffffff;
	}
	.company_border{
		border:1px solid #ffffff;
		padding-bottom:10px;
		width:140px;
		float:left;
		margin-right:5px;
	}
	.company_con{
		margin:2px;
		background-color:#888888;
	}
	.company{
		color:#ffffff;
		padding:5px;
	}
	.add_company{
		padding:7px;
		margin-top:15px;
		float:right;
	}
	.update{
		margin:10px;
		width:150px;
		text-align:center;
	}
	</style>
  </head>
  <body>
  <?php
	$query = "SELECT pakage,year,date FROM login_onserial WHERE email=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$super_email);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($pakage,$year,$date);
	$stmt->fetch();
	$softpakage=$pakage;
	$year=$year;
	$date=$date;
	$yearto=substr($date,0,4);
	$monthto=substr($date,5,2);
	$dateto=substr($date,8,2);
	$year_num=(int)$yearto;
	$year_up=$year_num+$year;
	if($monthto==2 and $dateto==29){
		$monthto=03;
		$dateto=01;
	}
	$up_date="$year_up"."/"."$monthto"."/"."$dateto";
	$up_to_time=strtotime($up_date);
	$expired_date=date('Y-m-d',$up_to_time);
	$today=date("Y-m-d");
	
	$today_strtotime=strtotime($today);
	$expired_strtotime=strtotime($expired_date);
	if($softpakage=='Free'){
		$warehouse=1;
		$users=1;
	}else if($softpakage=='Silver'){
		$warehouse=1;
		$users=5;
	}else if($softpakage=='Gold'){
		$warehouse=5;
		$users=10;
	}else if($softpakage=='Diamond'){
		$warehouse=50;
		$users=20;
	}
	$stmt->free_result();
		$stmt->close();
	}
	?>
	<?php include_once('software_menu.php');?>
	
	<?php include_once('software_header.php');?>
	<div class="container border">
		<div class="row">
			<h2 style="text-align:center;color:#756558;margin-bottom:0;">Company Name : <?php echo $company;?></h2>
			<h3 style="text-align:center;color:#756558;margin-top:10px;margin-bottom:0;">Current User :<?php echo $user_now;?></h3>
			<h4 style="text-align:center;color:#756558;">User Type: <?php echo $user_type_now;?></h4>
		</div>
		<div class="row">
			<div class="col-md-4 col-sm-4">
				<div style="margin-top:30px;margin-bottom:30px;" class="pakage">
					<h3 class="pakage_title">Today Notes</h3>
					<ol class="create_account_feature">
					<?php
					date_default_timezone_set('Asia/Dhaka');//problem
					$var_date= date('y/m/d') ;
					$datefrom=$var_date;
					$dateto=$var_date;
					$datebetween="(date_for_note BETWEEN '".$datefrom."'"." AND '". $dateto."') and";
						$stmt_name_new = $mysqli->prepare("SELECT note,date_for_note,entry_date FROM note_onserial WHERE $datebetween company_username=? and status='1'");
								$stmt_name_new->bind_param("s",$company_now);
								$stmt_name_new->execute();
								$stmt_name_new->store_result();
								$num_of_rows_now = $stmt_name_new->num_rows;
								$stmt_name_new->bind_result($note,$date_for_note,$entry_date);
								$sn=1;
								if($num_of_rows_now>0){
								while($stmt_name_new->fetch()){
									
								}
								
							}
						?>
						<li>You have <?php echo $num_of_rows_now;?> notes for this day</li>
					
					</ol>
				</div>
			</div>
			<div class="col-md-4 col-sm-4">
				<div style="margin-top:30px;margin-bottom:30px;" class="pakage">
					<h3 class="pakage_title">Vendors</h3>
					<ol class="create_account_feature">
					    <?php
					    $num_of_stmt_sql_num_rows=0;
					    if($stmt_sql_num_rows = $mysqli->prepare("SELECT *	FROM company_markenter_onserial WHERE  company_username=? and status=1 and type='vendor'")){
						
					$stmt_sql_num_rows->bind_param("s",$company_now);
					$stmt_sql_num_rows->execute();
					$stmt_sql_num_rows->store_result();
					$num_of_stmt_sql_num_rows = $stmt_sql_num_rows->num_rows;
					$stmt_sql_num_rows->fetch();
				
					}
					    ?>
						<li>You have <?php echo $num_of_stmt_sql_num_rows;?> vendors</li>
						<!--<li>Your  0 vendors have dues</li>
						<li>Your  0 vendors have balance</li>-->
					</ol>
				</div>
			</div>
			<div class="col-md-4 col-sm-4">
				<div style="margin-top:30px;margin-bottom:30px;" class="pakage">
					<h3 class="pakage_title">SR</h3>
					<ol class="create_account_feature">
					    <?php
					    $num_of_rows_number=0;
					    	if($stmt_sql_number = $mysqli->prepare("SELECT 	* FROM company_markenter_onserial WHERE  company_username=? and status=1 and type='customer'")){
						
					$stmt_sql_number->bind_param("s",$company_now);
					$stmt_sql_number->execute();
					$stmt_sql_number->store_result();
					$num_of_rows_number = $stmt_sql_number->num_rows;
					$stmt_sql_number->fetch();
				
					}
					    ?>
						<li>You have <?php echo $num_of_rows_number;?> sellsman</li>
						<!--<li>Your  0 customers have dues</li>
						<li>Your  0 customers have balance</li>-->
						
					</ol>
				</div>
			</div>
			
		</div>
		<div class="row">
			<div class="col-md-4 col-sm-4">
				<div style="margin-top:30px;margin-bottom:30px;" class="pakage">
					<h3 class="pakage_title">Products</h3>
					<ol class="create_account_feature">
					    <?php 
					    	$num_of_rows_now_all=0;
					    if($stmt_sql = $mysqli->prepare("SELECT * FROM products_details_onserial WHERE company_username=? and status=1")){
						
					$stmt_sql->bind_param("s",$company_now);
					$stmt_sql->execute();
					$stmt_sql->store_result();
					$num_of_rows_now_all = $stmt_sql->num_rows;
					$stmt_sql->fetch();
					
					}
					    ?>
						<li>You have <?php echo $num_of_rows_now_all;?> item of products</li>
						
					</ol>
				</div>
			</div>
			<div class="col-md-4 col-sm-4">
				<div style="margin-top:30px;margin-bottom:30px;" class="pakage">
					<h3 class="pakage_title">Stocks</h3>
					<ol class="create_account_feature">
					<?php
					if($stmt_sql_stocks = $mysqli->prepare("SELECT product_id,total_purchase,current_stock,total_sell,purchase_return,sell_return,damage,warranty,sell_warranty FROM stock_now_onserial WHERE company_username=?")){
						
					$stmt_sql_stocks->bind_param("s",$company_now);
					$stmt_sql_stocks->execute();
					$stmt_sql_stocks->store_result();
					$num_of_rows_stocks = $stmt_sql_stocks->num_rows;
					$stmt_sql_stocks->bind_result($product_id,$total_purchase,$current_stock,$total_sell,$purchase_return,$sell_return,$damage,$warranty,$sell_warranty);
					$total_piches_of_stoks=0;
					$empty_items=0;
					if($num_of_rows_stocks > 0){
						while($stmt_sql_stocks->fetch()){
							if($current_stock<1){
								$empty_items++;
							}
							$total_piches_of_stoks+=$current_stock;
							
					}
					}
}?>
<li><?php echo "Total items : ".$num_of_rows_stocks;?></li>
						<li><?php echo "Total piches : ".$total_piches_of_stoks;?></li>
	<li><?php echo "Total empty items : ".$empty_items;?></li>					
						
					</ol>
				</div>
			</div>
			<div class="col-md-4 col-sm-4">
				<div style="margin-top:30px;margin-bottom:30px;" class="pakage">
					<h3 class="pakage_title">Purchase Orders</h3>
					<ol class="create_account_feature">
					    <?php
					    $num_of_rows_purchase_order_now=0;
					    	$invoice_type_filter="(invoice_type='order_invoice')";
					    	if($stmt_sql = $mysqli->prepare("SELECT * FROM invoice_summary_onserial WHERE  company_username=? and status=1 and $invoice_type_filter and order_to_invoice_status='0'")){
						
					$stmt_sql->bind_param("s",$company_now);
					$stmt_sql->execute();
					$stmt_sql->store_result();
					$num_of_rows_purchase_order_now = $stmt_sql->num_rows;
					$stmt_sql->fetch();
				
					}
					    ?>
						<li>You have <?php echo $num_of_rows_purchase_order_now;?> purchase orders</li>
						<!--<li>Where 0 orders yet not delivered</li>
						<li>0 amount yet not invoiced</li>-->
					</ol>
				</div>
			</div>
			
		</div>
		<div class="row">
			<!--<div class="col-md-4 col-sm-4">
				<div style="margin-top:30px;margin-bottom:30px;" class="pakage">
					<h3 class="pakage_title">Sell Orders</h3>
					<ol class="create_account_feature">
					     <?php
					    /*$num_of_rows_sell_order_now=0;
					    	$invoice_type_filter="(invoice_type='sell_order_invoice')";
					    	if($stmt_sql = $mysqli->prepare("SELECT * FROM invoice_summary_onserial WHERE  company_username=? and status=1 and $invoice_type_filter and order_to_invoice_status='0'")){
						
					$stmt_sql->bind_param("s",$company_now);
					$stmt_sql->execute();
					$stmt_sql->store_result();
					$num_of_rows_sell_order_now = $stmt_sql->num_rows;
					$stmt_sql->fetch();
				
					}*/
					?>
						<li>You have <?php //echo $num_of_rows_sell_order_now;?> sell orders</li>
						<li>Where 0 orders yet not delivered</li>
						<li>0 amount yet not invoiced</li>
					</ol>
				</div>
			</div>-->
			<!--<div class="col-md-4 col-sm-4">
				<div style="margin-top:30px;margin-bottom:30px;" class="pakage">
					<h3 class="pakage_title">Purchase Invoices</h3>
					<ol class="create_account_feature">
						<li>You have 0 purchase invoices</li>
						<li>Total purchase amount 0</li>
						<li>Total payment amount 0</li>
					</ol>
				</div>
			</div>
			<div class="col-md-4 col-sm-4">
				<div style="margin-top:30px;margin-bottom:30px;" class="pakage">
					<h3 class="pakage_title">Sell Invoices</h3>
					<ol class="create_account_feature">
						<li>You have 0 sell invoices</li>
						<li>Total sell amount 0</li>
						<li>Total payment amount 0</li>
					</ol>
				</div>
			</div>-->
			
		</div>
		
		
	</div>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<script src="javascript.js"></script>
  </body>
</html>
<?php
}else{
    echo "Something wrong.Please <a href=\"index.php\">login</a>";
}
?>