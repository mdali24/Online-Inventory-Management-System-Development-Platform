<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include_once('db.php');
session_start();
session_regenerate_id(TRUE);
if(isset($_SESSION['user_session']) and isset($_SESSION['company_username_session']) and isset($_SESSION['sub_user_session'])){
	$user_type_now=$_SESSION['user_session'];
	$company_now=$_SESSION['company_username_session'];
	$user_now=$_SESSION['sub_user_session'];
	$status=1;
	$query = "SELECT email,company_name,company_timezone,vendor_primary_key FROM companies_onserial WHERE company_username=? and status=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param("si",$company_now,$status);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($email,$company_name,$company_timezone,$vendor_primary_key);
	$stmt->fetch();
	$super_email=$email;
	$company=$company_name;
	$company_timezone=$company_timezone;
	$vendor_primary_key=$vendor_primary_key;
	}
	if($user_type_now=='Super'){
	$user_now=$super_email;
	}
	
 date_default_timezone_set($company_timezone);//problem
 $var_date= date('y/m/d') ;
if($user_type_now=="Super" or $user_type_now=="Master" ){// Only Super Admin Hobe

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title><?php echo $company;?></title>
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<script src="auto/jquery-ui.min.js"></script>
	<link href="auto/jquery-ui.min.css" rel="stylesheet">
	
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="design.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="../inventory-software.png">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	
  </head>
  <body>
  <?php
	$query = "SELECT pakage,year,date FROM login_onserial WHERE email=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$super_email);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($pakage,$year,$date);
	$stmt->fetch();
	$softpakage=$pakage;
	$year=$year;
	$date=$date;
	$yearto=substr($date,0,4);
	$monthto=substr($date,5,2);
	$dateto=substr($date,8,2);
	$year_num=(int)$yearto;
	$year_up=$year_num+$year;
	if($monthto==2 and $dateto==29){
		$monthto=03;
		$dateto=01;
	}
	$up_date="$year_up"."/"."$monthto"."/"."$dateto";
	$up_to_time=strtotime($up_date);
	$expired_date=date('Y-m-d',$up_to_time);
	$today=date("Y-m-d");
	
	$today_strtotime=strtotime($today);
	$expired_strtotime=strtotime($expired_date);
	if($softpakage=='Free'){
		$warehouse=1;
		$users=1;
	}else if($softpakage=='Silver'){
		$warehouse=1;
		$users=1;
	}else if($softpakage=='Gold'){
		$warehouse=10;
		$users=20;
	}else if($softpakage=='Diamond'){
		$warehouse=50;
		$users=100;
	}
	$stmt->free_result();
		$stmt->close();
	}
	$query = "SELECT vendor_primary_key FROM companies_onserial WHERE company_username=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$company_now);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($vendor_primary_key);
	$stmt->fetch();
	if($vendor_primary_key=='Email'){
		$vendor_primary_key='markenter_email';
	}else if($vendor_primary_key=='Mobile'){
		$vendor_primary_key='vendor_mobile_no';
	}else if($vendor_primary_key=='Telephone'){
		$vendor_primary_key='vendor_telephone_no';
	}
	$stmt->free_result();
		$stmt->close();
	}
	
	$num_of_rows_now=0;
	?>
	<?php include_once('software_menu.php');?>
	<?php include_once('software_header.php');?>
	<div class="container-fluid border_bottom color z_index">
		<!--<h2>Vendor Management</h2>-->	
	</div>
	
	<div class="container-fluid">
		<div style="margin-top:25px;" class="row">
		
		
			<div class="col-md-12">
				<div class="search_purchase_invoice_now"></div>
				  <div class="wrapper">
					  <div class="table">
						
						
					<?php 
					
					if($stmt_sql = $mysqli->prepare("SELECT product_id,total_purchase,current_stock,total_sell,purchase_return,sell_return,damage,warranty,sell_warranty FROM stock_now_onserial WHERE company_username=? and current_stock>0 ORDER BY sn ASC")){
						
					$stmt_sql->bind_param("s",$company_now);
					$stmt_sql->execute();
					$stmt_sql->store_result();
					$num_of_rows_now = $stmt_sql->num_rows;
					$stmt_sql->fetch();
					echo "<p style=\"margin:0;padding:0;\">Products Item : ".$num_of_rows_now."</p>";
					}
					if($stmt_sql = $mysqli->prepare("SELECT product_id,total_purchase,current_stock,total_sell,purchase_return,sell_return,damage,warranty,sell_warranty FROM stock_now_onserial WHERE company_username=? and current_stock>0 ORDER BY sn ASC")){
						
					$stmt_sql->bind_param("s",$company_now);
					$stmt_sql->execute();
					$stmt_sql->store_result();
					$num_of_rows_now = $stmt_sql->num_rows;
					
					$stmt_sql->bind_result($product_id,$total_purchase,$current_stock,$total_sell,$purchase_return,$sell_return,$damage,$warranty,$sell_warranty);
					if($num_of_rows_now > 0){
					?>
					<div class="tb_header">
						  <div class="cell">
							Sn
						  </div>
						  <div class="cell">
							Product id
						  </div>
						  <div class="cell">
							Product title
						  </div>
						  <div class="cell">
							Stock
						  </div>
						  <div class="cell">
							Unit price
						  </div>
						  <div class="cell">
							Subtotal(Purchase)
						  </div>
						  <div class="cell">
							Sell Price
						  </div>
						  <div class="cell">
							Subtotal(Sell)
						  </div>
						 
						</div>
					<?php
						$sn=1;
						$purchase_total=0;
						$sell_total=0;
						while($stmt_sql->fetch()){
							echo "<div class=\"tb_row\">";
							echo "<div class=\"cell\">".$sn."</div>";
							echo "<div class=\"cell\">".$product_id."</div>";
							
							if($stmt_name = $mysqli->prepare("SELECT product_title,unit_price,sell_price FROM products_details_onserial WHERE company_username=? and  product_id=? ORDER BY sn ASC")) {
							$stmt_name->bind_param("ss",$company_now,$product_id);
							$stmt_name->execute();
							$stmt_name->store_result();
							$num_of_rows = $stmt_name->num_rows;
							$stmt_name->bind_result($product_title,$unit_price,$sell_price);
							$stmt_name->fetch();
							
							echo "<div class=\"cell\">".$product_title."</div>";
							}
							echo "<div class=\"cell\">".$current_stock."</div>";
							echo "<div class=\"cell\">".$unit_price."</div>";
							$purchase_sub_total=$current_stock*$unit_price;
							echo "<div class=\"cell\">".$purchase_sub_total."</div>";
							echo "<div class=\"cell\">".$sell_price."</div>";
							$sell_sub_total=$current_stock*$sell_price;
							echo "<div class=\"cell\">".$sell_sub_total."</div>";
							$purchase_total+=$purchase_sub_total;
							$sell_total+=$sell_sub_total;
							echo "</div>";
							$sn++;
							}
							echo "Total purchase value : ".$purchase_total."</br>";
							echo "Total sell value : ".$sell_total."</br>";
					}else{
						
					}
					}
						?>
					  
					</div>
				  
				</div>
			</div>
		</div>
	</div>
	<div class="container-fluid">
	<div class="row">
	<div class="div_padding">
			<div class="col-md-4">
				<div class="search_purchase_invoice_now"></div>
				  <div class="wrapper">
					  <div class="table">
						
					<?php 
					$invoice_type_filter="(invoice_type='purchase_invoice' or invoice_type='purchase_payment' or invoice_type='purchase_return_invoice' or invoice_type='purchase_service' or invoice_type='sell_invoice' or invoice_type='sell_payment' or invoice_type='sell_return_invoice' or invoice_type='sell_service')";
					$display = array();
							$stmt_name = $mysqli->prepare("SELECT DISTINCT bank_name,account_no FROM invoice_summary_onserial WHERE company_username=? and $invoice_type_filter  and bank_name!='' and account_no!='' ORDER BY sn ASC");
							$stmt_name->bind_param("s",$company_now);
							 
							$stmt_name->execute();
							$stmt_name->store_result();
							$num_of_rows = $stmt_name->num_rows;
							$stmt_name->bind_result($bank_name,$account_no);
							$balance_now_invoice=0;
							if($num_of_rows > 0){
								while($stmt_name->fetch()){
								$stmt_name_new = $mysqli->prepare("SELECT payment,invoice_type,debit_or_credit,order_to_invoice_status FROM invoice_summary_onserial WHERE company_username=? and bank_name=? and account_no=? and $invoice_type_filter ORDER BY sn DESC");
								$stmt_name_new->bind_param("sss",$company_now,$bank_name,$account_no);
								$stmt_name_new->execute();
								$stmt_name_new->store_result();
								$num_of_rows_now = $stmt_name_new->num_rows;
								$stmt_name_new->bind_result($payment,$invoice_type,$debit_or_credit,$order_to_invoice_status);
								$total_credit=0;
								$total_debit=0;
								while($stmt_name_new->fetch()){
									//if($invoice_type='general' or $invoice_type='p_adjusment'  or //$invoice_type='cash_adjusment' or $invoice_type='update' or ($invoice_type='order_invoice' and  $order_to_invoice_status='yes') or //($invoice_type='sell_order_invoice' and $order_to_invoice_status='yes')){
										
									//}else{
										if($debit_or_credit=='debit'){
										$total_debit+=$payment;
										}else{
											$total_credit+=$payment;
										}
									//}
									
								}
								$balance=$total_credit-$total_debit;
								
								$bank_account="Bank Name : ".$bank_name ." and Account No : ".$account_no;
								$display[$bank_account]=$balance;
								}
								if($asc_desc_check=="ASC"){
									asort($display);
								}else{
									arsort($display);
								}
								
								foreach ($display as $key => $value) {
									
									$balance_now_invoice+=$value;
									
								}
							}else{
								
							}
							?>
							<div class="tb_header">
							  <div class="cell">
								<?php echo "Invoice Bank Balance : ".$balance_now_invoice;?>
							  </div>
							  
							</div>
							
					</div>
				  
				</div>
			</div>
			<div class="col-md-4">
				<div class="search_purchase_invoice_now"></div>
				  <div class="wrapper">
					  <div class="table">
						
					<?php 
					$invoice_type_filter="((invoice_type='order_invoice' and  order_to_invoice_status='no') or (invoice_type='sell_order_invoice' and order_to_invoice_status='no'))";
					$display = array();
							$stmt_name = $mysqli->prepare("SELECT DISTINCT bank_name,account_no FROM invoice_summary_onserial WHERE company_username=? and $invoice_type_filter  and bank_name!='' and account_no!='' ORDER BY sn ASC");
							$stmt_name->bind_param("s",$company_now);
							 
							$stmt_name->execute();
							$stmt_name->store_result();
							$num_of_rows = $stmt_name->num_rows;
							$stmt_name->bind_result($bank_name,$account_no);
							$balance_now_order=0;
							if($num_of_rows > 0){
								while($stmt_name->fetch()){
								$stmt_name_new = $mysqli->prepare("SELECT payment,invoice_type,debit_or_credit,order_to_invoice_status FROM invoice_summary_onserial WHERE company_username=? and bank_name=? and account_no=? and $invoice_type_filter ORDER BY sn DESC");
								$stmt_name_new->bind_param("sss",$company_now,$bank_name,$account_no);
								$stmt_name_new->execute();
								$stmt_name_new->store_result();
								$num_of_rows_now = $stmt_name_new->num_rows;
								$stmt_name_new->bind_result($payment,$invoice_type,$debit_or_credit,$order_to_invoice_status);
								$total_credit=0;
								$total_debit=0;
								while($stmt_name_new->fetch()){
									//if($invoice_type='general' or $invoice_type='p_adjusment'  or //$invoice_type='cash_adjusment' or $invoice_type='update' or ($invoice_type='order_invoice' and  $order_to_invoice_status='yes') or //($invoice_type='sell_order_invoice' and $order_to_invoice_status='yes')){
										
									//}else{
										if($debit_or_credit=='debit'){
										$total_debit+=$payment;
										}else{
											$total_credit+=$payment;
										}
									//}
									
								}
								$balance=$total_credit-$total_debit;
								
								$bank_account="Bank Name : ".$bank_name ." and Account No : ".$account_no;
								$display[$bank_account]=$balance;
								}
								if($asc_desc_check=="ASC"){
									asort($display);
								}else{
									arsort($display);
								}
								
								
								foreach ($display as $key => $value) {
									
									$balance_now_order+=$value;
									
								}
							}else{
								
							}
							?>
							<div class="tb_header">
							  <div class="cell">
								<?php echo "Order Bank Balance : ".$balance_now_order;?>
							  </div>
							  
							</div>
							
					</div>
				  
				</div>
			</div>
			<div class="col-md-4">
				<div class="search_purchase_invoice_now"></div>
				  <div class="wrapper">
					  <div class="table">
						
						
					<?php 
					$invoice_type_filter="invoice_type='bank'";
					$display = array();
							$stmt_name = $mysqli->prepare("SELECT DISTINCT bank_name,account_no FROM invoice_summary_onserial WHERE company_username=? and $invoice_type_filter  and bank_name!='' and account_no!='' ORDER BY sn ASC");
							$stmt_name->bind_param("s",$company_now);
							 
							$stmt_name->execute();
							$stmt_name->store_result();
							$num_of_rows = $stmt_name->num_rows;
							$stmt_name->bind_result($bank_name,$account_no);
							$cash_to_bank=0;
							if($num_of_rows > 0){
								while($stmt_name->fetch()){
								$stmt_name_new = $mysqli->prepare("SELECT payment,invoice_type,debit_or_credit,order_to_invoice_status FROM invoice_summary_onserial WHERE company_username=? and bank_name=? and account_no=? and $invoice_type_filter ORDER BY sn DESC");
								$stmt_name_new->bind_param("sss",$company_now,$bank_name,$account_no);
								$stmt_name_new->execute();
								$stmt_name_new->store_result();
								$num_of_rows_now = $stmt_name_new->num_rows;
								$stmt_name_new->bind_result($payment,$invoice_type,$debit_or_credit,$order_to_invoice_status);
								$total_credit=0;
								$total_debit=0;
								while($stmt_name_new->fetch()){
									//if($invoice_type='general' or $invoice_type='p_adjusment'  or //$invoice_type='cash_adjusment' or $invoice_type='update' or ($invoice_type='order_invoice' and  $order_to_invoice_status='yes') or //($invoice_type='sell_order_invoice' and $order_to_invoice_status='yes')){
										
									//}else{
										if($debit_or_credit=='debit'){
										$total_debit+=$payment;
										}else{
											$total_credit+=$payment;
										}
									//}
									
								}
								$balance=$total_credit-$total_debit;
								
								$bank_account="Bank Name : ".$bank_name ." and Account No : ".$account_no;
								$display[$bank_account]=$balance;
								}
								
								asort($display);
								
								
								foreach ($display as $key => $value) {
									
									$cash_to_bank+=$value;
									
								}
							}else{
								
							}
							?>
							<div class="tb_header">
							  <div class="cell">
								<?php echo "Cash Vs Bank : ".$cash_to_bank;?>
							  </div>
							  
							</div>
					
					</div>
				  
				</div>
			</div>
			<div class="col-md-4">
				<div class="search_purchase_debit_credit_invoicew"></div>
				  <div class="wrapper">
					  <div class="table">
						
						
					<?php 
					$invoice_type_filter="(invoice_type='purchase_invoice' or invoice_type='purchase_payment' or invoice_type='purchase_return_invoice' or invoice_type='purchase_service' or invoice_type='sell_invoice' or invoice_type='sell_payment' or invoice_type='sell_return_invoice' or invoice_type='sell_service' or invoice_type='general' or invoice_type='p_adjusment'  or invoice_type='cash_adjusment')";
					
					if($stmt_sql = $mysqli->prepare("SELECT invoice_no,debit_credit_invoice,update_invoice_no,invoice_type,debit_or_credit,net,remarks,date FROM invoice_summary_onserial WHERE company_username=? and status=1 and $invoice_type_filter  ORDER BY sn ASC")){
						
					$stmt_sql->bind_param("s",$company_now);
					$stmt_sql->execute();
					$stmt_sql->store_result();
					$num_of_rows_now = $stmt_sql->num_rows;
					
					$stmt_sql->bind_result($invoice_no,$debit_credit_invoice,$update_invoice_no,$invoice_type,$debit_or_credit,$net,$remarks,$date);
					$cash_now_invoice=0;
					if($num_of_rows_now > 0){
					
						$total_debit=0;
						$total_credit=0;
						while($stmt_sql->fetch()){
							if($debit_or_credit=='debit'){
								$total_debit+=$net;
							}else if($debit_or_credit=='credit'){
								$total_credit+=$net;
							}
							}
							$cash_now_invoice=$total_credit-$total_debit;
							
					}else{
						
					}
					?>
					<div class="tb_header">
						  <div class="cell">
							Invoice Cash : <?php echo $cash_now_invoice;?>
						  </div>
						  
						</div>
					<?php
					}
						?>
					  
					</div>
				  
				</div>
			</div>
			<div class="col-md-4">
				<div class="search_purchase_debit_credit_invoicew"></div>
				  <div class="wrapper">
					  <div class="table">
						
						
					<?php 
					$invoice_type_filter="((invoice_type='order_invoice' and  order_to_invoice_status='no') or (invoice_type='sell_order_invoice' and order_to_invoice_status='no'))";
					
					if($stmt_sql = $mysqli->prepare("SELECT invoice_no,debit_credit_invoice,update_invoice_no,invoice_type,debit_or_credit,net,remarks,date FROM invoice_summary_onserial WHERE company_username=? and status=1 and $invoice_type_filter  ORDER BY sn ASC")){
						
					$stmt_sql->bind_param("s",$company_now);
					$stmt_sql->execute();
					$stmt_sql->store_result();
					$num_of_rows_now = $stmt_sql->num_rows;
					
					$stmt_sql->bind_result($invoice_no,$debit_credit_invoice,$update_invoice_no,$invoice_type,$debit_or_credit,$net,$remarks,$date);
					$cash_now_order=0;
					if($num_of_rows_now > 0){
					
						$total_debit=0;
						$total_credit=0;
						while($stmt_sql->fetch()){
							if($debit_or_credit=='debit'){
								$total_debit+=$net;
							}else if($debit_or_credit=='credit'){
								$total_credit+=$net;
							}
							
							}
							$cash_now_order=$total_credit-$total_debit;
					}else{
						
					}
					?>
					<div class="tb_header">
						  <div class="cell">
							Order Cash : <?php echo $cash_now_order;?>
						  </div>
						  
						</div>
					<?php
					}
						?>
					  
					</div>
				  
				</div>
			</div>
			
			</div>
		</div>
	</div>
	<?php
	$total_cash=$cash_now_invoice+$cash_now_order;
	$total_cash_now=$total_cash-$cash_to_bank;
	$total_bank=$balance_now_invoice+$balance_now_order+$cash_to_bank;
	$business_capital_with_orders=$purchase_total+$total_cash_now+$total_bank;
	$business_capital_without_orders=$business_capital_with_orders-($cash_now_order+$balance_now_order);
	?>
	<div class="container-fluid">
		<div class="row">
		
			<div class="col-md-12">
			<h3 style="text-align:center">Now Hand Cash and Bank Balance</h3>
		</div>
			<div class="col-md-12">
				<div class="search_purchase_debit_credit_invoicew"></div>
				  <div class="wrapper">
					  <div class="table">
				
					<div class="tb_header">
						  <div class="cell">
							Hand Cash : <?php echo $total_cash_now;?> and Bank Balance : <?php echo $total_bank;?> 
						  </div>
						  
						</div>
					
					  
					</div>
				  
				</div>
			</div>
		</div>
		
	</div>
	<div class="container-fluid">
		<div class="row">
		
			<div class="col-md-12">
			<h3 style="text-align:center">Business Capital</h3>
		</div>
			<div class="col-md-12">
				<div class="search_purchase_debit_credit_invoicew"></div>
				  <div class="wrapper">
					  <div class="table">
				
					<div class="tb_header">
						  <div class="cell">
							With Order Payments : <?php echo $business_capital_with_orders;?> and Without Order Payments: <?php echo $business_capital_without_orders;?> 
						  </div>
						  
						</div>
					
					  
					</div>
				  
				</div>
			</div>
		</div>
		
	</div>
  </body>
</html>
<?php
}else{
echo "You have not permit to access this page";
}
}else{
    echo "Something wrong.Please <a href=\"index.php\">login</a>";
}
?>