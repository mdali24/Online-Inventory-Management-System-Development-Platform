<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include_once('db.php');
session_start();
session_regenerate_id(TRUE);
if(isset($_SESSION['user_session']) and isset($_SESSION['company_username_session']) and isset($_SESSION['sub_user_session'])){
	$user_type_now=$_SESSION['user_session'];
	$company_now=$_SESSION['company_username_session'];
	$user_now=$_SESSION['sub_user_session'];
	$status=1;
	$query = "SELECT email,company_name,company_email,company_mobile,company_telephone,address,company_timezone,vendor_primary_key,purchase_invoice_msg FROM companies_onserial WHERE company_username=? and status=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param("si",$company_now,$status);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($email,$company_name,$company_email,$company_mobile,$company_telephone,$address,$company_timezone,$vendor_primary_key,$purchase_invoice_msg);
	$stmt->fetch();
	$super_email=$email;
	$company=$company_name;
	$company_email=$company_email;
	$company_mobile=$company_mobile;
	$company_telephone=$company_telephone;
	$address=$address;
	$company_timezone=$company_timezone;
	$vendor_primary_key=$vendor_primary_key;
	$purchase_invoice_msg=$purchase_invoice_msg;
	}
	if($user_type_now=='Super'){
	$user_now=$super_email;
	}
	
 date_default_timezone_set($company_timezone);//problem
 $var_date= date('y/m/d') ;
if($user_type_now=="Super" or $user_type_now=="Master"){

?>
<?php
	$query = "SELECT pakage,year,date FROM login_onserial WHERE email=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$super_email);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($pakage,$year,$date);
	$stmt->fetch();
	$softpakage=$pakage;
	$year=$year;
	$date=$date;
	$yearto=substr($date,0,4);
	$monthto=substr($date,5,2);
	$dateto=substr($date,8,2);
	$year_num=(int)$yearto;
	$year_up=$year_num+$year;
	if($monthto==2 and $dateto==29){
		$monthto=03;
		$dateto=01;
	}
	$up_date="$year_up"."/"."$monthto"."/"."$dateto";
	$up_to_time=strtotime($up_date);
	$expired_date=date('Y-m-d',$up_to_time);
	$today=date("Y-m-d");
	
	$today_strtotime=strtotime($today);
	$expired_strtotime=strtotime($expired_date);
	if($softpakage=='Free'){
		$warehouse=1;
		$users=1;
	}else if($softpakage=='Standard'){
		$warehouse=1;
		$users=1;
	}else if($softpakage=='Extend'){
		$warehouse=10;
		$users=20;
	}else if($softpakage=='Expand'){
		$warehouse=50;
		$users=100;
	}
	$stmt->free_result();
		$stmt->close();
	}
	$query = "SELECT vendor_primary_key,serial_key,barcode,after_purchase_service FROM companies_onserial WHERE company_username=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$company_now);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($purchase_default_cursor,$serial_key,$barcode,$after_purchase_service);
	$stmt->fetch();
	if($serial_key=='Yes'){
		$serial_use='Yes';
	}else{
		$serial_use='No';
	}
	if($purchase_default_cursor=='Email'){
		$onfocus='vendor_email';
	}else if($purchase_default_cursor=='Mobile'){
		$onfocus='mobile_no';
	}else if($purchase_default_cursor=='Telephone'){
		$onfocus='telephone_no';
	}
	$stmt->free_result();
		$stmt->close();
	}
	?>
	<?php if($after_purchase_service=="No"){
		$hide='hide_now';
		}else{
		$hide="";
	}
	?>
	<?php if($barcode=="No"){
		$bar_hide='hide_now';
	}else{
		$bar_hide="";
	}
	?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title><?php echo $company;?></title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="design.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="../inventory-software.png">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<script src="javascript.js"></script>
	<script src="auto/jquery-ui.min.js"></script>
	<link href="auto/jquery-ui.min.css" rel="stylesheet">
	<script type="text/javascript">
	$(document).ready(function() {
		var tk=0;
		var token='tk='+ tk;
		var validity_check=function(validity,character_length){
				if(validity<0 || (validity.length > character_length) || (validity.indexOf('/') > -1)|| (validity.indexOf('*') > -1)|| (validity.indexOf('<') > -1)|| (validity.indexOf('>') > -1)|| (validity.indexOf('var ') > -1)|| (validity.indexOf('$') > -1)|| (validity.indexOf('!') > -1)|| (validity.indexOf('script') > -1)|| (validity.indexOf('&') > -1)|| (validity.indexOf('+') > -1)|| (validity.indexOf('-') > -1)|| (validity.indexOf('(') > -1)|| (validity.indexOf(')') > -1)|| (validity.indexOf('{') > -1)|| (validity.indexOf('}') > -1)|| (validity.indexOf('()') > -1)|| (validity.indexOf('{}') > -1)|| (validity.indexOf('[') > -1)|| (validity.indexOf(']') > -1)|| (validity.indexOf('[]') > -1)|| (validity.indexOf('#') > -1)|| (validity.indexOf('^') > -1)|| (validity.indexOf('?') > -1)){
					alert("Invalid Character");
					throw new Error("An error");
				}else{
					return validity;
				}
			}
		
		$(".amount").focus();
		var count =0;
		$(document).keydown(function(e) {
			if (e.keyCode == '13'){
			var focus=$(':focus').attr('id');
			var company="<?php echo $company_now;?>";
			var key = $('#'+ focus).val();
			validity_check(key,32);
			if((focus=="invoice_edit")){
				$.ajax({
				type: "POST",
				url: "token/csrf_token.php",
				data: token,
				success: function(html){
					$("#token_two").val(html);
					var token_two=$("#token_two").val();
					var data='token_two='+ token_two+'&key='+ key+'&focus='+ focus+'&company='+ company;
				$.ajax({
				type: "POST",
				url: "fill/cash_debit_credit_edit_details.php",
				data: data,
				success: function(html){
					$(".invoice_edit_take").html(html);
					var date_take=$("#date_take").html();
					$(".invoice_date").val(date_take);
					var cause_take=$("#cause_take").html();
					$(".cause").val(cause_take);
					var amount_take=$("#amount_take").html();
					$(".amount").val(amount_take);
					var remarks_take=$("#remarks_take").html();
					$(".remarks").val(remarks_take);
					$(".invoice_edit_take").html("");
					load_effects();
					}		
					});
				}
				});
			}
			}
		})
		
		 var com_now= $('#com_now').val();
		$(document).keydown(function(e) {
		if(e.keyCode == '36'){
				 $('.invoice_no').focus();
			 }else if(e.keyCode == '17'){
				 $('.invoice_add').click();
			 }else if(e.keyCode == '46'){
				 $('input').val('');
				 $("#<?php echo $onfocus;?>").focus();
				 var today="<?php echo $var_date;?>";
				 $(".invoice_date").val(today);
			 }
		});
		$('.invoice_add').click(function() {
			$.ajax({
				type: "POST",
				url: "token/csrf_token.php",
				data: token,
				success: function(html){
					$("#token_five").val(html);
				var token_five=$("#token_five").val();
			var super_user="<?php echo $super_email;?>";
			validity_check(super_user,32);
			var company_use="<?php echo $company_now;?>";
			validity_check(company_use,32);
			var operator="<?php echo $user_now;?>";
			validity_check(operator,32);
			
			var invoice_no_add=$(".invoice_no").val();
			validity_check(invoice_no_add,32);
			var invoice_date_add=$(".invoice_date").val();
			
			var cause=$(".cause").val();
			validity_check(cause,32);
			var amount=$(".amount").val();
			validity_check(amount,32);
			
			var debit_credit=$(".debit_credit").val();
			validity_check(debit_credit,32);
			
			var remarks_add=$(".remarks").val();
			validity_check(remarks_add,32);
			
			var data_add='token_five='+ token_five+'&super_user='+ super_user+'&company_use='+ company_use+'&operator='+ operator+'&invoice_no_add='+ invoice_no_add+'&invoice_date_add='+ invoice_date_add+'&cause='+ cause+'&amount='+ amount+'&debit_credit='+ debit_credit+'&remarks_add='+ remarks_add;
			
			$.ajax({
			type: "POST",
			url: "add/software_cash_adjusments_invoice_data_add.php",
			data: data_add,
			success: function(html){
				$(".check").html(html);
					var msg=$(".check").html();
					$(".print_invoice_no").html(msg);
					alert(msg);
				}		
			});
			}
			});
			$(".print").click(function(e){
				e.preventDefault();
				var print_vendor_name=$("#full_name").val();
				$(".print_vendor_name").html(print_vendor_name);
				var print_vendor_address=$("#vendor_address").val();
				$(".print_vendor_address").html(print_vendor_name);
				var print_vendor_mobile=$("#mobile_no").val();
				$(".print_vendor_mobile").html(print_vendor_mobile);
				var print_vendor_email=$("#vendor_email").val();
				$(".print_vendor_email").html(print_vendor_email);
				var print_vendor_telephone=$("#telephone_no").val();
				$(".print_vendor_telephone").html(print_vendor_telephone);
				
				var print_grand_total=$(".grand_total").val();
				$(".print_grand_total").html(print_grand_total);
				var print_tax=$(".tax").val();
				$(".print_tax").html(print_tax);
				var print_discount_total=$(".discount_total").val();
				$(".print_discount_total").html(print_discount_total);
				var print_total=$(".total").val();
				$(".print_total").html(print_total);
				var print_now_payment=$(".now_payment").val();
				$(".print_now_payment").html(print_now_payment);
				var print_due=$(".due").val();
				$(".print_due").html(print_due);
				var print_total_net=$(".total_net").val();
				$(".print_total_net").html(print_total_net);
				
				window.print();
			   
				
			});
			$('.reset').click(function() {
				location.reload();
			});
		})
		
	});
	</script>
	
  </head>
  <body>
  <div class="check"></div>
  <div class="invoice_edit_take"></div>
  <input type="hidden" class="input" id="token_five">
	<span class="print_class_hide"><?php include_once('software_menu.php');?></span>
	<span class="print_class_hide"><?php include_once('software_header.php');?></span>
	<div id="serial_use"><?php echo $serial_use;?></div>
	<div class="container-fluid border_bottom color z_index print_class_hide">
		<input type="hidden" value="<?php echo $company_now?>" id="com_now">
	</div>
	<div class="container style print_class_hide">
		<div style="color:#f6f6f6;padding-top:15px;padding-bottom:15px;" class="row">
			<div class="col-md-8 col-sm-8 previous_business_show">
				
			</div>
			<div class="col-md-2  col-sm-2">
				<!--<label style="float:left;color:#f6f6f6;font-weight:200;" class="label_class_order">Invoice No : </label>-->
				<input style="width:120px;float:left;margin-left:10px;color:#000000" type="number" id="invoice_edit" class="invoice_no"  placeholder="Invoice No Auto">
				<input type="hidden" class="input" id="token_two">
			</div>
			<div class="col-md-2  col-sm-2">
				<!--<label  style="float:left;color:#f6f6f6;font-weight:200;" class="label_class_order">Date : </label>-->
				<input style="width:120px;float:left;margin-left:10px;color:#000000" type="text" class="invoice_date"  value="<?php echo $var_date;?>" readonly>
			</div>
		</div>
	</div>
	<div class="container border_style print_class_hide">
		<div class="row vendor_information">
			<div class="col-md-12 col-sm-12">
					Debit/Credit information
			</div>
		</div>
		<div class="row input_div_padding">
		<div class="col-md-12 col-sm-12 color">
		<div class="row padding">
			<div  class="col-md-6 col-sm-6">
				<label class="label_class">Amount</label>
				<input type="number" class="input amount" value="">
			</div>
			<div  class="col-md-6 col-sm-6">
				<!--<label class="label_class">Cause</label>-->
				<input type="hidden" class="input cause" value="">
			</div>
			<div class="col-md-6 col-sm-6">
				<label class="label_class">Debit/Credit</label>
				<select style="height:24px;" class="input debit_credit">
					<option class="debit_credit_one">Debit</option>
					<option class="debit_credit_two">Credit</option>
				</select>
			</div>
			<div class="col-md-6 col-sm-6">
				<label class="label_class">Remarks</label>
				<input type="text" class="input remarks">
			</div>
			<input type="hidden" class="input" id="token_four">
		</div>
		</div>
		</div>
	</div>
	
	<div class="container">
		<div class="row margin_top">
			<div class="col-md-5 col-sm-5 col-xs-3 print_class_hide">
				<button type="button" class="remove reset btn btn-primary">Reset</button>
			</div>
			<div class="col-md-3 col-sm-3 col-xs-4">
				<!--<button type="button" class="print print_class_hide Addtopurchase btn btn-primary">Print</button>-->
			</div>
			<div class="col-md-4 col-sm-4 col-xs-4 print_class_hide">
				<button type="button" class="add_order btn btn-primary invoice_add">Invoice</button>
			</div>
		</div>
		<!--<div class="row fixed_position">
			Net : <input type="text" class="input total_net" value="0" readonly>
		</div>-->
	</div>
	<div class="container print_class">
      <div class="row">
        <div class="col-xs-6">
          <h1>
            <h2><?php echo $company;?></h2>
            <img width="80px" height="80px" src="../inventory-software.png">
            
            </a>
          </h1>
        </div>
        <div class="col-xs-6 text-right">
          <h1>PURCHASE INVOICE</h1>
          <h1><small><span class="print_invoice_no"></span></small></h1>
        </div>
      </div>
      <div class="row">
        <div class="col-xs-5">
          <div class="panel panel-default">
            <div class="panel-heading">
              <h4>From: <span class="print_vendor_name"></span></h4>
            </div>
            <div class="panel-body">
			  <p>
                Mobile : <span class="print_vendor_mobile"></span><br>
                Email : <span class="print_vendor_email"></span><br>
				Telephone : <span class="print_vendor_telephone"></span><br>
				Address : <span class="print_vendor_address"></span><br>
              </p>
            </div>
          </div>
        </div>
        <div class="col-xs-5 col-xs-offset-2 text-right">
          <div class="panel panel-default">
            <div class="panel-heading">
              <h4>To : <?php echo $company;?></h4>
            </div>
            <div class="panel-body">
              <p>
                 Address :	<?php echo $address;?> <br>
              </p>
            </div>
          </div>
        </div>
      </div>
      <!-- / end client details section -->
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>
              <h4>Sn</h4>
            </th>
            <th>
              <h4>Description</h4>
            </th>
            <th>
              <h4>Hrs/Qty</h4>
            </th>
            <th>
              <h4>Rate/Price</h4>
            </th>
			<th>
              <h4>Discount</h4>
            </th>
			<th>
              <h4>Tax</h4>
            </th>
            <th>
              <h4>Sub Total</h4>
            </th>
			<th>
              <h4>Service Type</h4>
            </th>
            <th>
              <h4>Service Days</h4>
            </th>
          </tr>
        </thead>
        <tbody  class="print_products_details">
		<!--<span class="print_products_details"></span>-->
		
          
        </tbody>
      </table>
      <div class="row text-right">
        <div class="col-xs-2 col-xs-offset-8">
          <p>
            <strong>
            Sub Total : <br>
            TAX : <br>
			Discount : <br>
            Total : <br>
			Payments : <br>
			Due : <br>
			Net : <br>
            </strong>
          </p>
        </div>
        <div class="col-xs-2">
          <strong>
          <span class="print_grand_total"></span> <br>
         <span class="print_tax"></span> <br>
          <span class="print_discount_total"></span> <br>
		  <span class="print_total"></span> <br>
         <span class="print_now_payment"></span> <br>
          <span class="print_due"></span> <br>
		  <span class="print_total_net"></span> <br>
          </strong>
        </div>
      </div>
      <div class="row">
        <div class="col-xs-5">
          <div class="panel panel-info">
            <div class="panel-heading">
              <h4>Previous Business</h4>
            </div>
            <div class="panel_body">
              
            </div>
          </div>
        </div>
        <div class="col-xs-7">
          <div class="span7">
            <div class="panel panel-info">
              <div class="panel-heading">
                <h4>Contact Details</h4>
              </div>
              <div class="panel-body">
                <p>
                  Email : <?php echo $company_email;?> 
                  Mobile : <?php echo $company_mobile;?> 
				  Telephone : <?php echo $company_telephone;?> 
				
                </p>
                
              </div>
            </div>
          </div>
        </div>
      </div>
	  <div class="row">
		<h4 class="purchase_invoice_msg"><?php echo $purchase_invoice_msg;?></h4>
	  </div>
    </div>
	<!--<div class="container print_class_hide">
		<div class="row">
			<button class="print btn btn-success">Print</button> 
			
		</div>
	</div>-->
    
  </body>
</html>
<?php
}else{
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Please Login</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="design.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="../inventory-software.png">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<script src="javascript.js"></script>
	
	</head>
  <body>
  <?php include_once('client_header.php');?>
  <h1 class="client_login_title">You have not permit to access this page</h1>
  </body>
</html>
<?php
}
}else{
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Please Login</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="design.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="../inventory-software.png">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<script src="javascript.js"></script>
	
	</head>
  <body>
  <?php include_once('client_header.php');?>
  <h1 class="client_login_title">Something wrong.Please <a href="index.php">login</a></h1>
  </body>
</html>
<?php
}
?>