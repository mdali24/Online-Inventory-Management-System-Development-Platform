<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include_once('db.php');
session_start();
session_regenerate_id(TRUE);
if(isset($_SESSION['user_session']) and isset($_SESSION['company_username_session']) and isset($_SESSION['sub_user_session'])){
	$user_type_now=$_SESSION['user_session'];
	$company_now=$_SESSION['company_username_session'];
	$user_now=$_SESSION['sub_user_session'];
	$status=1;
	$query = "SELECT email,company_name,company_timezone,vendor_primary_key FROM companies_onserial WHERE company_username=? and status=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param("si",$company_now,$status);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($email,$company_name,$company_timezone,$vendor_primary_key);
	$stmt->fetch();
	$super_email=$email;
	$company=$company_name;
	$company_timezone=$company_timezone;
	$vendor_primary_key=$vendor_primary_key;
	}
	if($user_type_now=='Super'){
	$user_now=$super_email;
	}
	
 date_default_timezone_set($company_timezone);//problem
 $var_date= date('y/m/d') ;
if($user_type_now=="Super" or $user_type_now=="Master" or $user_type_now=="Purchase_Master" or $user_type_now=="Only_Purchase"){

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title><?php echo $company;?></title>
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<script src="auto/jquery-ui.min.js"></script>
	<link href="auto/jquery-ui.min.css" rel="stylesheet">
	<script>
	$(document).ready(function() {
		$(".search_invoice").click(function(e){
		e.preventDefault();
			var debit_credit_invoice=$(".debit_credit_invoice").val();
			
			var company="<?php echo $company_now;?>";
			var data_key='debit_credit_invoice='+ debit_credit_invoice+'&company='+ company;
			
			$.ajax({
				type: "POST",
				url: "fill/search_purchase_debit_credit_invoicew.php",
				data: data_key,
				success: function(html){
					$(".search_purchase_debit_credit_invoicew").html(html);
					
					}		
				});
		});
		$( function() {
		$( "#datepicker" ).datepicker({ dateFormat: 'yy-mm-dd' });
		$( "#datepickerto" ).datepicker({ dateFormat: 'yy-mm-dd' });
	  } );
		
	})
	</script>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="design.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="../inventory-software.png">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	
  </head>
  <body>
  <?php
	$query = "SELECT pakage,year,date FROM login_onserial WHERE email=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$super_email);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($pakage,$year,$date);
	$stmt->fetch();
	$softpakage=$pakage;
	$year=$year;
	$date=$date;
	$yearto=substr($date,0,4);
	$monthto=substr($date,5,2);
	$dateto=substr($date,8,2);
	$year_num=(int)$yearto;
	$year_up=$year_num+$year;
	if($monthto==2 and $dateto==29){
		$monthto=03;
		$dateto=01;
	}
	$up_date="$year_up"."/"."$monthto"."/"."$dateto";
	$up_to_time=strtotime($up_date);
	$expired_date=date('Y-m-d',$up_to_time);
	$today=date("Y-m-d");
	
	$today_strtotime=strtotime($today);
	$expired_strtotime=strtotime($expired_date);
	if($softpakage=='Free'){
		$warehouse=1;
		$users=1;
	}else if($softpakage=='Standard'){
		$warehouse=1;
		$users=1;
	}else if($softpakage=='Extend'){
		$warehouse=10;
		$users=20;
	}else if($softpakage=='Expand'){
		$warehouse=50;
		$users=100;
	}
	$stmt->free_result();
		$stmt->close();
	}
	$query = "SELECT vendor_primary_key FROM companies_onserial WHERE company_username=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$company_now);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($vendor_primary_key);
	$stmt->fetch();
	if($vendor_primary_key=='Email'){
		$vendor_primary_key='markenter_email';
	}else if($vendor_primary_key=='Mobile'){
		$vendor_primary_key='vendor_mobile_no';
	}else if($vendor_primary_key=='Telephone'){
		$vendor_primary_key='vendor_telephone_no';
	}
	$stmt->free_result();
		$stmt->close();
	}
	
	if(!empty($_POST['company'])){
	$company_filter=$_POST['company'];
	}else{
		$company_filter="empty";
	}
	if(!empty($_POST['datefrom'])and !empty($_POST['dateto'])){
	$datefrom=$_POST['datefrom'];
	$dateto=$_POST['dateto'];
	$datebetween="(date BETWEEN '".$datefrom."'"." AND '". $dateto."') and";
	}else{
		$datefrom="";
		$dateto="";
		$datebetween="";
	}
	if(!empty($_POST['invoice_type_now'])){
		$invoice_type_now=$_POST['invoice_type_now'];
		if($invoice_type_now=='All'){
			$invoice_type_filter="(invoice_type='purchase_invoice' or invoice_type='purchase_payment' or invoice_type='purchase_return_invoice' or invoice_type='purchase_service' or invoice_type='sell_invoice' or invoice_type='sell_payment' or invoice_type='sell_return_invoice' or invoice_type='sell_service' or invoice_type='general' or invoice_type='p_adjusment'  or invoice_type='cash_adjusment' or invoice_type='update' or invoice_type='cash_invest_capital' or (invoice_type='order_invoice' and  order_to_invoice_status='no') or (invoice_type='sell_order_invoice' and order_to_invoice_status='no'))";
		}else if($invoice_type_now=='General'){
			$invoice_type_filter="(invoice_type='general')";
		}else if($invoice_type_now=='P.Adjusment'){
			$invoice_type_filter="(invoice_type='adjusment')";
		}else if($invoice_type_now=='Cash Adjusment'){
			$invoice_type_filter="(invoice_type='cash_adjusment')";
		}else{
			$invoice_type_filter="(invoice_type='general' or invoice_type='adjusment')";
		}
	}else{
		$invoice_type_now="";
		$invoice_type_filter="(invoice_type='purchase_invoice' or invoice_type='purchase_payment' or invoice_type='purchase_return_invoice' or invoice_type='purchase_service' or invoice_type='sell_invoice' or invoice_type='sell_payment' or invoice_type='sell_return_invoice' or invoice_type='sell_service' or invoice_type='general' or invoice_type='p_adjusment'  or invoice_type='cash_adjusment' or invoice_type='update' or invoice_type='cash_invest_capital' or (invoice_type='order_invoice' and  order_to_invoice_status='no') or (invoice_type='sell_order_invoice' and order_to_invoice_status='no'))";
		
	}
	if(!empty($_POST['user'])){
		$user=$_POST['user'];
		if($user=='All Users'){
			$user_filter="";
		}else{
			$user_filter="and sub_user='".$user."'";
		}
	}else{
		$user="";
		$user_filter="";
		
	}
	
	if(!empty($_POST['vendor_select'])){
		$vendor_select=$_POST['vendor_select'];
		if($vendor_select=='All'){
			$vendor_filter="(debit_or_credit='debit' or debit_or_credit='credit')";
		}else if($invoice_type_now=='Debit'){
			$vendor_filter="(debit_or_credit='debit')";
		}else if($invoice_type_now=='Credit'){
			$vendor_filter="(debit_or_credit='credit')";
		}else{
			$vendor_filter="(debit_or_credit='debit' or debit_or_credit='credit')";
		}
	}else{
		$vendor_select="";
		$vendor_filter="(debit_or_credit='debit' or debit_or_credit='credit')";
		
	}
	if(!empty($_POST['display'])){
		$display=$_POST['display'];
		if($display=='Display All'){
			$display_check="";
		}else{
			$display_now=$display;
			$display_check="exist";
		}
	}else{
		$display="";
		$display_now=5;
		$display_check="exist";
		
	}
	if(!empty($_POST['page_no'])){
		$page_no=$_POST['page_no'];
	}else{
		$page_no=1;
		
	}
	if(!empty($_POST['page_filter'])){
		$page_filter=$_POST['page_filter'];
		if($page_filter=='Next'){
			$go=$page_no+1;
		}else if($page_filter=='Previous'){
			$go=$page_no-1;
		}else if($page_filter=='Reset'){
			$go=1;
		}else{
			$go=$page_no;
		}
	}else{
		$page_filter="";
		$go=1;
	}
	if($go<1){
		$go=1;
		$message="This is first page.Can not go to previous.";
	}else{
		$message="";
	}
	$num_of_rows_now=0;
	?>
	<?php include_once('software_menu.php');?>
	<?php include_once('software_header.php');?>
	<div class="container-fluid border_bottom color z_index">
		<!--<h2>Vendor Management</h2>-->	
	</div>
	
	<div class="container-fluid">
		<div class="row">
		<div class="div_padding">
		<div class="col-md-12 col-sm-12">
			<div class="webdesigntuts-workshop">
						<!--<form>		    
							<input type="number" class="debit_credit_invoice" placeholder="Search Invoice?">		    	
							<button class="search_invoice">Search</button>
						</form>-->
						
					</div>
		</div>
		</div>
		<div class="col-md-12 col-sm-12">
			<!--<a class="button_style" href="software_stock_low.php">Low</a>
			<a class="button_style" href="software_stock_high.php">High</a>-->
			<form action="software_cash_report.php" method="POST">
			<input type="hidden" name="company" value="<?php echo $company_now;?>">
			<div class="col-md-2">
				<input type="text" id="datepicker" name="datefrom" class="form-control purchase_filter_style" placeholder="Date from" value="<?php echo $datefrom;?>">
			</div>
			<div class="col-md-2">
				<input type="text"  id="datepickerto" name="dateto" class="form-control purchase_filter_style"  placeholder="Date to"  value="<?php echo $dateto;?>">
			</div>
			<select id="secuence" name="invoice_type_now"  class="purchase_filter_style" >
			<?php if(strlen($invoice_type_now)>0){
				echo "<option value=\"$invoice_type_now\">$invoice_type_now</option>";
			}?>
				<option value="All">All</option>
				<option value="General">General</option>
				<option value="P.Adjusment">P.Adjusment</option>
				<option value="Cash Adjusment">Cash Adjusment</option>
			</select>
			<select id="secuence" name="user"  class="purchase_filter_style" >
			<?php if(strlen($user)>0){
					echo "<option value=\"$user\">$user</option>";
			}?>
			<?php 
			if($user_type_now=="Super" or $user_type_now=="Master" or $user_type_now=="Purchase_Master" ){
				?>
				<option value="All Users">All Users</option>
				<?php 
				if($stmt_sql = $mysqli->prepare("SELECT sub_username FROM company_users_onserial WHERE company_username=? ORDER BY sn DESC")){
					
					$stmt_sql->bind_param("s",$company_now);
					$stmt_sql->execute();
					$stmt_sql->store_result();
					$num_of_rows = $stmt_sql->num_rows;
					$stmt_sql->bind_result($sub_username);
					if($num_of_rows > 0){
						while($stmt_sql->fetch()){
							echo "<option value=\"$sub_username\">$sub_username</option>";
							}
					}
					}
					?>
				<option value="Super Admin">Super Admin</option>
				<?php
			}else{
				echo "<option value=\"$user_now\">$user_now</option>";
			}
			?>
				
				
			</select>
			<select id="vendor_select" name="vendor_select"  class="purchase_filter_style" >
				<?php if(strlen($vendor_select)>0){
					echo "<option value=\"$vendor_select\">$vendor_select</option>";
				}?>
				<option value="All">All</option>
				<option value="Debit">Debit</option>
				<option value="Credit">Credit</option>
				</select>
				<select id="secuence" name="display"  class="purchase_filter_style" >
				<?php if(strlen($display)>0){
					echo "<option value=\"$display\">$display</option>";
				}?>
					
					<option value="20">20</option>
					<option value="50">50</option>
					<option value="100">100</option>
					<option value="Display All">Display All</option>
				</select>
				<input type="hidden" name="page_no" value="<?php echo $go;?>">
				<select id="secuence" name="page_filter"  class="purchase_filter_style" >
				<?php if(strlen($page_filter)>0){
					echo "<option value=\"$page_filter\">$page_filter</option>";
				}?>
					<option value="Current">Current</option>
					<option value="Next">Next</option>
					<option value="Previous">Previous</option>
					<option value="Reset">Reset</option>
					
				</select>
				
			<input type="submit" class="purchase_filter_style" value="Filter">
			</form>
		</div>
			<div class="col-md-12">
				<div class="search_purchase_debit_credit_invoicew"></div>
				  <div class="wrapper">
					  <div class="table">
						
						
					<?php 
					$page=$go;
					if(strlen($display_check)>0){
						$range=$display_now;
						$start=($page*$range)-$range;
						$next=$page+1;
						$previus=$page-1;
						$limit=" limit $start,$range";
					}else{
						$limit="";
					}
					$total_debit=0;
					$total_credit=0;
					$total_payment_debit=0;
					$total_payment_credit=0;
					if($stmt_sql = $mysqli->prepare("SELECT invoice_no,debit_credit_invoice,invest_debit_credit ,update_invoice_no,invoice_type,debit_or_credit,payment,net,remarks,date,order_to_invoice_status, 	update_for_invoice_type FROM invoice_summary_onserial WHERE $datebetween company_username=? and status=1 and $invoice_type_filter and  $vendor_filter $user_filter ORDER BY sn DESC $limit")){
						
					$stmt_sql->bind_param("s",$company_now);
					$stmt_sql->execute();
					$stmt_sql->store_result();
					$num_of_rows_now = $stmt_sql->num_rows;
					
					$stmt_sql->bind_result($invoice_no,$debit_credit_invoice,$invest_debit_credit,$update_invoice_no,$invoice_type,$debit_or_credit,$payment,$net,$remarks,$date,$order_to_invoice_status, 	$update_for_invoice_type);
					if($num_of_rows_now > 0){
					?>
					<div class="tb_header">
						  <div class="cell">
							Sn
						  </div>
						  <div class="cell">
							Invoice No
						  </div>
						  <div class="cell">
							Type
						  </div>
						  <div class="cell">
							Cash Type
						  </div>
						  <div class="cell">
							Net
						  </div>
						  <div class="cell">
							Payment
						  </div>
						  <div class="cell">
							Cash In
						  </div>
						  <div class="cell">
							Cash Out
						  </div>
						  <div class="cell">
							Update Adjusment
						  </div>
						  <div class="cell">
							Date
						  </div>
						  <div class="cell">
							Remarks
						  </div>
						</div>
					<?php
						$sn=1;
						$update_balance_adjusment_total=0;
						while($stmt_sql->fetch()){
							
							echo "<div class=\"tb_row\">";
							echo "<div class=\"cell\">".$sn."</div>";
							if($invoice_type=='general' or $invoice_type=='cash_adjusment' or $invoice_type=='p_adjusment' ){
								echo "<div class=\"cell\">".$debit_credit_invoice."</div>";
								$invoice_no_for_update=$debit_credit_invoice;
							}else if($invoice_type=='update'){
								echo "<div class=\"cell\">".$update_invoice_no."</div>";
								$invoice_no_for_update=$update_invoice_no;
							}else if($invoice_type=='cash_invest_capital'){
								echo "<div class=\"cell\">".$invest_debit_credit."</div>";
								$invoice_no_for_update=$invest_debit_credit;
							}else{
								echo "<div class=\"cell\">".$invoice_no."</div>";
								$invoice_no_for_update=$invoice_no;
							}
							if($invoice_type=='general'){
								$type="General";
							}else if($invoice_type=='p_adjusment'){
								$type="Product Adjusment";
							}else if($invoice_type=='cash_adjusment'){
								$type="Cash Adjusment";
							}else if($invoice_type=='update'){
								$type="Update";
							}else if($invoice_type=='purchase_invoice'){
								$type="Purchase Invoice";
							}else if($invoice_type=='purchase_payment'){
								$type="Vendor Payment";
							}else if($invoice_type=='purchase_return_invoice'){
								$type="Purchase Return";
							}else if($invoice_type=='purchase_service'){
								$type="Vendor Service";
							}else if($invoice_type=='sell_invoice'){
								$type="Sell Invoice";
							}else if($invoice_type=='sell_payment'){
								$type="Customer Payment";
							}else if($invoice_type=='sell_return_invoice'){
								$type="Sell Return";
							}else if($invoice_type=='sell_service'){
								$type="Customer Service";
							}else if($invoice_type=='order_invoice'){
								$type="Vendor Order";
							}else if($invoice_type=='sell_order_invoice'){
								$type="Customer Order";
							}
							else if($invoice_type=='cash_invest_capital'){
								$type="Cash Invest";
							}
							echo "<div class=\"cell\">".$type."</div>";
							if($debit_or_credit=='debit'){
								$debit_or_credit_type_now="Debit";
							}else if($debit_or_credit=='credit'){
								$debit_or_credit_type_now="Credit";
							}
							echo "<div class=\"cell\">".$debit_or_credit_type_now."</div>";
							
							echo "<div class=\"cell\">".$net."</div>";
							echo "<div class=\"cell\">".$payment."</div>";
							if($invoice_type=='purchase_invoice' or $invoice_type=='purchase_payment' or $invoice_type=='purchase_return_invoice' or $invoice_type=='purchase_service'or ($invoice_type=='order_invoice' and  $order_to_invoice_status=='no') or $invoice_type=='sell_invoice' or $invoice_type=='sell_payment' or $invoice_type=='sell_return_invoice' or $invoice_type=='sell_service' or ($invoice_type=='sell_order_invoice' and $order_to_invoice_status='no')){
								if($debit_or_credit=='debit'){
									echo "<div class=\"cell\">"."0"."</div>";
								}else if($debit_or_credit=='credit'){
									echo "<div class=\"cell\">".$payment."</div>";
								}
							}else {
								if($debit_or_credit=='debit'){
									echo "<div class=\"cell\">"."0"."</div>";
								}else if($debit_or_credit=='credit'){
									echo "<div class=\"cell\">".$net."</div>";
								}
							}
							if($invoice_type=='purchase_invoice' or $invoice_type=='purchase_payment' or $invoice_type=='purchase_return_invoice' or $invoice_type=='purchase_service'or ($invoice_type=='order_invoice' and  $order_to_invoice_status=='no') or $invoice_type=='sell_invoice' or $invoice_type=='sell_payment' or $invoice_type=='sell_return_invoice' or $invoice_type=='sell_service' or ($invoice_type=='sell_order_invoice' and $order_to_invoice_status='no')){
								if($debit_or_credit=='debit'){
									echo "<div class=\"cell\">".$payment."</div>";
								}else if($debit_or_credit=='credit'){
									echo "<div class=\"cell\">"."0"."</div>";
								}
							}else {
								if($debit_or_credit=='debit'){
									echo "<div class=\"cell\">".$net."</div>";
								}else if($debit_or_credit=='credit'){
									echo "<div class=\"cell\">"."0"."</div>";
								}
							}
							$update_credit=0;
							$update_debit=0;
							$update_balance_adjusment=0;
							if($stmt_up = $mysqli->prepare("SELECT debit_or_credit,net FROM invoice_summary_onserial WHERE $datebetween company_username=? and status=1 and update_invoice_no='$invoice_no_for_update' and update_for_invoice_type='$invoice_type' and  $vendor_filter $user_filter ORDER BY sn DESC $limit")){
						
							$stmt_up->bind_param("s",$company_now);
							$stmt_up->execute();
							$stmt_up->store_result();
							$num_of_rows_now_up = $stmt_up->num_rows;
							
							$stmt_up->bind_result($debit_or_credit_update,$net_update);
							if($num_of_rows_now_up > 0){
								while($stmt_up->fetch()){
								if($debit_or_credit_update=='debit'){
											$update_debit+=$net_update;
										}else if($debit_or_credit_update=='credit'){
											$update_credit+=$net_update;
										}
								
								}
							}
							}
							$update_balance_adjusment=$update_credit-$update_debit;
							echo "<div class=\"cell\">".$update_balance_adjusment."</div>";
							$update_balance_adjusment_total+=$update_balance_adjusment;
							
							
							echo "<div class=\"cell\">".$date."</div>";
							echo "<div class=\"cell\">".$remarks."</div>";
							echo "</div>";
							if($debit_or_credit=='debit'){
								$total_debit+=$net;
							}else if($debit_or_credit=='credit'){
								$total_credit+=$net;
							}
							if($invoice_type=='purchase_invoice' or $invoice_type=='purchase_payment' or $invoice_type=='purchase_return_invoice' or $invoice_type=='purchase_service'or ($invoice_type=='order_invoice' and  $order_to_invoice_status=='no') or $invoice_type=='sell_invoice' or $invoice_type=='sell_payment' or $invoice_type=='sell_return_invoice' or $invoice_type=='sell_service' or ($invoice_type=='sell_order_invoice' and $order_to_invoice_status='no')){
								if($debit_or_credit=='debit'){
									$total_payment_debit+=$payment;
								}else if($debit_or_credit=='credit'){
									$total_payment_credit+=$payment;
								}
							}else {
								if($debit_or_credit=='debit'){
									$total_payment_debit+=$net;
								}else if($debit_or_credit=='credit'){
									$total_payment_credit+=$net;
								}
							}
							
							$sn++;
							}
					}else{
						echo "<div class=\"tb_row\">";
							echo "None report created";
						echo "</div>";
					}
					}
						?>
					  
					</div>
				  
				</div>
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<div class="row ">
			<div  class="col-md-12">
			<?php 
			if($num_of_rows_now > 0){
				$balance_now=$total_payment_credit-$total_payment_debit;
				$balance=$balance_now-$update_balance_adjusment_total;
				/*echo "<h5 style=\"margin-left:20px;\" class=\"\">"."Cash In Report Total : ".$total_payment_credit." and Cash Out Report Total: ".$total_payment_debit." and Balance : ".$balance_now."</h5>";*/
				echo "<h5 style=\"margin-left:20px;\" class=\"\">"."Total Cash Net : ".$balance."</h5>";
				echo $message;
			}else{
				echo "<h5 style=\"margin-left:20px;\" class=\"\">"."Have no Report"."</h5>";
			}
			?>
			</div>
		</div>
	</div>
  </body>
</html>
<?php
}else{
echo "You have not permit to access this page";
}
}else{
    echo "Something wrong.Please <a href=\"index.php\">login</a>";
}
?>