<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include_once('db.php');
session_start();
session_regenerate_id(TRUE);
if(isset($_SESSION['user_session']) and isset($_SESSION['company_username_session']) and isset($_SESSION['sub_user_session'])){
	$user_type_now=$_SESSION['user_session'];
	$company_now=$_SESSION['company_username_session'];
	$user_now=$_SESSION['sub_user_session'];
	$status=1;
	$query = "SELECT email,company_name,company_timezone,vendor_primary_key FROM companies_onserial WHERE company_username=? and status=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param("si",$company_now,$status);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($email,$company_name,$company_timezone,$vendor_primary_key);
	$stmt->fetch();
	$super_email=$email;
	$company=$company_name;
	$company_timezone=$company_timezone;
	$vendor_primary_key=$vendor_primary_key;
	}
	if($user_type_now=='Super'){
	$user_now=$super_email;
	}
	
 date_default_timezone_set($company_timezone);//problem
 $var_date= date('y/m/d') ;
if($user_type_now=="Super" or $user_type_now=="Master" or $user_type_now=="Purchase_Master"){

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title><?php echo $company;?></title>
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<script src="auto/jquery-ui.min.js"></script>
	<link href="auto/jquery-ui.min.css" rel="stylesheet">
	<script>
	$(document).ready(function() {
		
		$( function() {
		$( "#datepicker" ).datepicker({ dateFormat: 'yy-mm-dd' });
		$( "#datepickerto" ).datepicker({ dateFormat: 'yy-mm-dd' });
	  } );
	 
		
	})
	</script>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="design.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="../inventory-software.png">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	
  </head>
  <body>
  <?php
	$query = "SELECT pakage,year,date FROM login_onserial WHERE email=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$super_email);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($pakage,$year,$date);
	$stmt->fetch();
	$softpakage=$pakage;
	$year=$year;
	$date=$date;
	$yearto=substr($date,0,4);
	$monthto=substr($date,5,2);
	$dateto=substr($date,8,2);
	$year_num=(int)$yearto;
	$year_up=$year_num+$year;
	if($monthto==2 and $dateto==29){
		$monthto=03;
		$dateto=01;
	}
	$up_date="$year_up"."/"."$monthto"."/"."$dateto";
	$up_to_time=strtotime($up_date);
	$expired_date=date('Y-m-d',$up_to_time);
	$today=date("Y-m-d");
	
	$today_strtotime=strtotime($today);
	$expired_strtotime=strtotime($expired_date);
	if($softpakage=='Free'){
		$warehouse=1;
		$users=1;
	}else if($softpakage=='Silver'){
		$warehouse=1;
		$users=1;
	}else if($softpakage=='Gold'){
		$warehouse=10;
		$users=20;
	}else if($softpakage=='Diamond'){
		$warehouse=50;
		$users=100;
	}
	$stmt->free_result();
		$stmt->close();
	}
	$query = "SELECT vendor_primary_key FROM companies_onserial WHERE company_username=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$company_now);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($vendor_primary_key);
	$stmt->fetch();
	if($vendor_primary_key=='Email'){
		$vendor_primary_key='markenter_email';
	}else if($vendor_primary_key=='Mobile'){
		$vendor_primary_key='vendor_mobile_no';
	}else if($vendor_primary_key=='Telephone'){
		$vendor_primary_key='vendor_telephone_no';
	}
	$stmt->free_result();
		$stmt->close();
	}
	
	if(!empty($_POST['company'])){
	$company_filter=$_POST['company'];
	}else{
		$company_filter="empty";
	}
	if(!empty($_POST['datefrom'])and !empty($_POST['dateto'])){
	$datefrom=$_POST['datefrom'];
	$dateto=$_POST['dateto'];
	$datebetween="(date BETWEEN '".$datefrom."'"." AND '". $dateto."') and";
	}else{
		$datefrom="";
		$dateto="";
		$datebetween="";
	}
	if(!empty($_POST['name_search'])){
		$name_search=$_POST['name_search'];
		$name_filter="and  full_name=$name_search";
	}else{
		$name_search="";
		$name_filter="";
	}
	if(!empty($_POST['mobile_search'])){
		$mobile_search=$_POST['mobile_search'];
		$mobile_filter="and  vendor_mobile_no=$mobile_search";
	}else{
		$mobile_search="";
		$mobile_filter="";
	}
	if(!empty($_POST['email_search'])){
		$email_search=$_POST['email_search'];
		$email_filter="and  markenter_email=$email_search";
	}else{
		$email_search="";
		$email_filter="";
	}
	if(!empty($_POST['telephone_search'])){
		$telephone_search=$_POST['telephone_search'];
		$telephone_filter="and  vendor_telephone_no=$telephone_search";
	}else{
		$telephone_search="";
		$telephone_filter="";
	}

	if(!empty($_POST['display'])){
		$display=$_POST['display'];
		if($display=='Display All'){
			$display_check="";
		}else{
			$display_now=$display;
			$display_check="exist";
		}
	}else{
		$display="";
		$display_now=20;
		$display_check="exist";
		
	}
	if(!empty($_POST['page_no'])){
		$page_no=$_POST['page_no'];
	}else{
		$page_no=1;
		
	}
	if(!empty($_POST['page_filter'])){
		$page_filter=$_POST['page_filter'];
		if($page_filter=='Next'){
			$go=$page_no+1;
		}else if($page_filter=='Previous'){
			$go=$page_no-1;
		}else if($page_filter=='Reset'){
			$go=1;
		}else{
			$go=$page_no;
		}
	}else{
		$page_filter="";
		$go=1;
	}
	if($go<1){
		$go=1;
		$message="This is first page.Can not go to previous.";
	}else{
		$message="";
	}
	$num_of_rows_now=0;
	?>
	<?php include_once('software_menu.php');?>
	<?php include_once('software_header.php');?>
	<div class="container-fluid border_bottom color z_index">
		<!--<h2>Vendor Management</h2>-->	
	</div>
	
	<div class="container-fluid">
		<div class="row">
		<div class="div_padding">
			
			<!--<a class="button_style" href="software_stock_low.php">Low</a>
			<a class="button_style" href="software_stock_high.php">High</a>-->
			<form action="software_vendor_list.php" method="POST">
			<input type="hidden" name="company" value="<?php echo $company_now;?>">
			<div class="col-md-2">
				<input type="text" id="datepicker" name="datefrom" class="form-control purchase_filter_style_input" placeholder="Date from" value="<?php echo $datefrom;?>">
			</div>
			<div class="col-md-2">
				<input type="text"  id="datepickerto" name="dateto" class="form-control purchase_filter_style_input"  placeholder="Date to"  value="<?php echo $dateto;?>">
			</div>
			<div class="col-md-1">
				<select id="secuence" name="display"  class="purchase_filter_style" >
				
					<option value="8 AM">8 AM</option>
					<option value="8 AM">9 AM</option>
					<option value="8 AM">10 AM</option>
					<option value="8 AM">11 AM</option>
					<option value="8 PM">12 PM</option>
					<option value="8 PM">1 PM</option>
					<option value="8 PM">2 PM</option>
					<option value="8 PM">3 PM</option>
					<option value="8 PM">4 PM</option>
					<option value="8 PM">5 PM</option>
					<option value="8 PM">6 PM</option>
					<option value="8 PM">7 PM</option>
					<option value="8 PM">8 PM</option>
					<option value="8 PM">9 PM</option>
					<option value="8 AM">10 PM</option>
					<option value="8 AM">11 PM</option>
					<option value="8 AM">1 AM</option>
					<option value="8 AM">2 AM</option>
					<option value="8 AM">3 AM</option>
					<option value="8 AM">4 AM</option>
					<option value="8 AM">5 AM</option>
					<option value="8 AM">6 AM</option>
					<option value="8 AM">7 AM</option>
				</select>
			</div>
			<div class="col-md-1">
				<select id="secuence" name="display"  class="purchase_filter_style" >
					<option value="1 Minit">0 Minit</option>
					<option value="1 Minit">1 Minit</option>
					<option value="1 Minit">2 Minit</option>
					<option value="1 Minit">3 Minit</option>
					<option value="1 Minit">4 Minit</option>
					<option value="1 Minit">5 Minit</option>
					<option value="1 Minit">6 Minit</option>
					<option value="1 Minit">7 Minit</option>
					<option value="1 Minit">8 Minit</option>
					<option value="1 Minit">9 Minit</option>
					<option value="1 Minit">10 Minit</option>
					<option value="1 Minit">11 Minit</option>
					<option value="1 Minit">12 Minit</option>
					<option value="1 Minit">13 Minit</option>
					<option value="1 Minit">14 Minit</option>
					<option value="1 Minit">15 Minit</option>
					<option value="1 Minit">16 Minit</option>
					<option value="1 Minit">17 Minit</option>
					<option value="1 Minit">18 Minit</option>
					<option value="1 Minit">19 Minit</option>
					<option value="1 Minit">20 Minit</option>
					<option value="1 Minit">21 Minit</option>
					<option value="1 Minit">22 Minit</option>
					<option value="1 Minit">23 Minit</option>
					<option value="1 Minit">24 Minit</option>
					<option value="1 Minit">25 Minit</option>
					<option value="1 Minit">26 Minit</option>
					<option value="1 Minit">27 Minit</option>
					<option value="1 Minit">28 Minit</option>
					<option value="1 Minit">29 Minit</option>
					<option value="1 Minit">30 Minit</option>
					<option value="1 Minit">31 Minit</option>
					<option value="1 Minit">32 Minit</option>
					<option value="1 Minit">33 Minit</option>
					<option value="1 Minit">34 Minit</option>
					<option value="1 Minit">35 Minit</option>
					<option value="1 Minit">36 Minit</option>
					<option value="1 Minit">37 Minit</option>
					<option value="1 Minit">38 Minit</option>
					<option value="1 Minit">39 Minit</option>
					<option value="1 Minit">40 Minit</option>
					<option value="1 Minit">41 Minit</option>
					<option value="1 Minit">42 Minit</option>
					<option value="1 Minit">43 Minit</option>
					<option value="1 Minit">44 Minit</option>
					<option value="1 Minit">45 Minit</option>
					<option value="1 Minit">46 Minit</option>
					<option value="1 Minit">47 Minit</option>
					<option value="1 Minit">48 Minit</option>
					<option value="1 Minit">49 Minit</option>
					<option value="1 Minit">50 Minit</option>
					<option value="1 Minit">51 Minit</option>
					<option value="1 Minit">52 Minit</option>
					<option value="1 Minit">53 Minit</option>
					<option value="1 Minit">54 Minit</option>
					<option value="1 Minit">55 Minit</option>
					<option value="1 Minit">56 Minit</option>
					<option value="1 Minit">57 Minit</option>
					<option value="1 Minit">58 Minit</option>
					<option value="1 Minit">59 Minit</option>
					
				</select>
			</div>
			<div class="col-md-2">
				<?php if(strlen($mobile_search)>0){
				?>
				<input type="text" id="mobile_search" name="mobile_search" class="form-control purchase_filter_style_input" placeholder="Out Time" value="<?php echo $name_search;?>">
				<?php
				}else{?>
				<input type="text" id="mobile_search" name="mobile_search" class="form-control purchase_filter_style_input" placeholder="Out Time" value="">
				<?php } ?>
			</div>
			<div class="col-md-2">
				<?php if(strlen($email_search)>0){
				?>
				<input type="text" id="email_search" name="email_search" class="form-control purchase_filter_style_input" placeholder="Leisure Out Time" value="<?php echo $email_search;?>">
				<?php
				}else{?>
				<input type="text" id="email_search" name="email_search" class="form-control purchase_filter_style_input" placeholder="Leisure Out Time" value="">
				<?php } ?>
			</div>
			<div class="col-md-2">
				<?php if(strlen($telephone_search)>0){
				?>
				<input type="text" id="telephone_search" name="telephone_search" class="form-control purchase_filter_style_input" placeholder="Leisure Out Time" value="<?php echo $telephone_search;?>">
				<?php
				}else{?>
				<input type="text" id="telephone_search" name="telephone_search" class="form-control purchase_filter_style_input" placeholder="Leisure In Time" value="">
				<?php } ?>
			</div>
			<div class="col-md-2">
				<?php if(strlen($telephone_search)>0){
				?>
				<input type="text" id="telephone_search" name="telephone_search" class="form-control purchase_filter_style_input" placeholder="Late Minit" value="<?php echo $telephone_search;?>">
				<?php
				}else{?>
				<input type="text" id="telephone_search" name="telephone_search" class="form-control purchase_filter_style_input" placeholder="Late Minit" value="">
				<?php } ?>
			</div>
			<div class="col-md-12 col-sm-12">
				<select id="secuence" name="display"  class="purchase_filter_style" >
				<?php if(strlen($display)>0){
					echo "<option value=\"$display\">$display</option>";
				}?>
					<option value="20">20</option>
					<option value="50">50</option>
					<option value="100">100</option>
					<option value="Display All">Display All</option>
				</select>
				<input type="hidden" name="page_no" value="<?php echo $go;?>">
				<select id="secuence" name="page_filter"  class="purchase_filter_style" >
				<?php if(strlen($page_filter)>0){
					echo "<option value=\"$page_filter\">$page_filter</option>";
				}?>
					<option value="Current">Current</option>
					<option value="Next">Next</option>
					<option value="Previous">Previous</option>
					<option value="Reset">Reset</option>
					
				</select>
				
			<input type="submit" class="purchase_filter_style" value="Filter">
			</form>
			<button style="float:right;" type="button" class="btn btn-outline-primary add_company purchase_filter_style" data-toggle="modal" data-target="#myModalVendors">Add New</button>	
		</div>
		</div>
		
			<div class="col-md-12">
				<div class="search_purchase_invoice_now"></div>
				  <div class="wrapper">
					  <div class="table">
						
						
					<?php 
					$page=$go;
					if(strlen($display_check)>0){
						$range=$display_now;
						$start=($page*$range)-$range;
						$next=$page+1;
						$previus=$page-1;
						$limit=" limit $start,$range";
					}else{
						$limit="";
					}
					
					if($stmt_sql = $mysqli->prepare("SELECT 	full_name,vendor_mobile_no,markenter_email,vendor_telephone_no,vendor_company_name,vendor_address,vendor_debit_limit,vendor_debit_days,date FROM 	company_markenter_onserial WHERE $datebetween company_username=? and status=1 and type='vendor' $name_filter $mobile_filter $email_filter $telephone_filter ORDER BY sn DESC $limit")){
						
					$stmt_sql->bind_param("s",$company_now);
					$stmt_sql->execute();
					$stmt_sql->store_result();
					$num_of_rows_now = $stmt_sql->num_rows;
					
					$stmt_sql->bind_result($full_name,$vendor_mobile_no,$markenter_email,$vendor_telephone_no,$vendor_company_name,$vendor_address,$vendor_debit_limit,$vendor_debit_days,$date);
					if($num_of_rows_now > 0){
					?>
					<div class="tb_header">
						  <div class="cell">
							Sn
						  </div>
						  <div class="cell">
							Date
						  </div>
						  <div class="cell">
							Off on Status
						  </div>
						  <div class="cell">
							Remarks
						  </div>
						  <div class="cell">
							In Time
						  </div>
						  <div class="cell">
							Out Time
						  </div>
						  <div class="cell">
							Leisure Out time
						  </div>
						  <div class="cell">
							Leisure In time
						  </div>
						  <div class="cell">
							Active Working Hours
						  </div>
						</div>
					<?php
						$sn=1;
						
						$grand_total=0;
						$grand_payment=0;
						$grand_due=0;
						$grand_net=0;
						while($stmt_sql->fetch()){
							echo "<div class=\"tb_row\">";
							echo "<div class=\"cell\">".$sn."</div>";
							echo "<div class=\"cell\">".$full_name."</div>";
							echo "<div class=\"cell\">".$vendor_mobile_no."</div>";
							echo "<div class=\"cell\">".$markenter_email."</div>";
							echo "<div class=\"cell\">".$vendor_telephone_no."</div>";
							echo "<div class=\"cell\">".$vendor_company_name."</div>";
							echo "<div class=\"cell\">".$vendor_address."</div>";
							echo "<div class=\"cell\">".$date."</div>";
							echo "<div class=\"cell\">".$date."</div>";
							echo "</div>";
							}
					}else{
						echo "<div class=\"tb_row\">";
							echo "None report created";
						echo "</div>";
					}
					}
						?>
					  
					</div>
				  
				</div>
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<div class="modal fade" id="myModalVendors" role="dialog">
			<div class="modal-dialog">
					<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h6 class="modal-title">Employee Information</h6>
					</div>
					<div class="modal-body">
			 			<div class="panel-body">
							<form action="software_vendor_add_list.php" role="form" method="POST">
								<div class="row">
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
											<input type="hidden" name="super_user" id="" class="form-control input-sm" value ="<?php echo $super_email;?>">
											<input type="hidden" name="company_use" id="" class="form-control input-sm" value ="<?php echo $company_now;?>">
											<input type="hidden" name="operator" id="" class="form-control input-sm" value ="<?php echo $user_now;?>">
											<input type="text" name="full_name_add" id="full_name" class="form-control input-sm" placeholder="Vendor Name">
										</div>
									</div>
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
											<input type="email" name="vendor_email_add" id="vendor_email" class="form-control input-sm" placeholder="Vendor Email">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
											<input type="number" name="mobile_no_add" id="vendor_mobile_no" class="form-control input-sm" placeholder="Vendor Mobile">
										</div>
									</div>
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
											<input type="number" name="telephone_no_add" id="vendor_telephone_no" class="form-control input-sm" placeholder="Vendor Telephone">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-xs-12 col-sm-12 col-md-12">
										<div class="form-group">
											<input type="text" name="company_name_add" id="vendor_company_name" class="form-control input-sm" placeholder="Vendor Company Name">
										</div>
									</div>
									
								</div>
								<div class="row">
									<div class="col-xs-12 col-sm-12 col-md-12">
										<div class="form-group">
											<input type="text" name="vendor_address_add" id="vendor_address" class="form-control input-sm" placeholder="Vendor Address">
										</div>
									</div>
									
								</div>
								<div class="row">
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
											<input type="number" name="debit_limit_add" id="vendor_debit_limit" class="form-control input-sm" placeholder="Vendor Debit limit">
										</div>
									</div>
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
											<input type="number" name="debit_days_add" id="vendor_debit_days" class="form-control input-sm" placeholder="Vendor Debit days">
										</div>
									</div>
								</div>
								<input type="submit" value="Add" class="btn btn-info btn-block new_vendor_Add">
							
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
  </body>
</html>
<?php
}else{
echo "You have not permit to access this page";
}
}else{
    echo "Something wrong.Please <a href=\"index.php\">login</a>";
}
?>