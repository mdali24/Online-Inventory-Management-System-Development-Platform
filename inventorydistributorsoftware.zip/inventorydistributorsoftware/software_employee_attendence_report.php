<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include_once('db.php');
session_start();
session_regenerate_id(TRUE);
if(isset($_SESSION['user_session']) and isset($_SESSION['company_username_session']) and isset($_SESSION['sub_user_session'])){
	$user_type_now=$_SESSION['user_session'];
	$company_now=$_SESSION['company_username_session'];
	$user_now=$_SESSION['sub_user_session'];
	$status=1;
	$query = "SELECT email,company_name,company_email,company_mobile,company_telephone,address,company_timezone,vendor_primary_key,purchase_invoice_msg FROM companies_onserial WHERE company_username=? and status=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param("si",$company_now,$status);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($email,$company_name,$company_email,$company_mobile,$company_telephone,$address,$company_timezone,$vendor_primary_key,$purchase_invoice_msg);
	$stmt->fetch();
	$super_email=$email;
	$company=$company_name;
	$company_email=$company_email;
	$company_mobile=$company_mobile;
	$company_telephone=$company_telephone;
	$address=$address;
	$company_timezone=$company_timezone;
	$vendor_primary_key=$vendor_primary_key;
	$purchase_invoice_msg=$purchase_invoice_msg;
	}
	if($user_type_now=='Super'){
	$user_now=$super_email;
	}
	
 date_default_timezone_set("$company_timezone");
 $var_date= date('y/m/d') ;
if($user_type_now=="Super" or $user_type_now=="Master"){

?>
<?php
	$query = "SELECT pakage,year,date FROM login_onserial WHERE email=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$super_email);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($pakage,$year,$date);
	$stmt->fetch();
	$softpakage=$pakage;
	$year=$year;
	$date=$date;
	$yearto=substr($date,0,4);
	$monthto=substr($date,5,2);
	$dateto=substr($date,8,2);
	$year_num=(int)$yearto;
	$year_up=$year_num+$year;
	if($monthto==2 and $dateto==29){
		$monthto=03;
		$dateto=01;
	}
	$up_date="$year_up"."/"."$monthto"."/"."$dateto";
	$up_to_time=strtotime($up_date);
	$expired_date=date('Y-m-d',$up_to_time);
	$today=date("Y-m-d");
	
	$today_strtotime=strtotime($today);
	$expired_strtotime=strtotime($expired_date);
	if($softpakage=='Free'){
		$warehouse=1;
		$users=1;
	}else if($softpakage=='Standard'){
		$warehouse=1;
		$users=1;
	}else if($softpakage=='Extend'){
		$warehouse=10;
		$users=20;
	}else if($softpakage=='Expand'){
		$warehouse=50;
		$users=100;
	}
	$stmt->free_result();
		$stmt->close();
	}
	$query = "SELECT vendor_primary_key,serial_key,barcode,after_purchase_service FROM companies_onserial WHERE company_username=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$company_now);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($purchase_default_cursor,$serial_key,$barcode,$after_purchase_service);
	$stmt->fetch();
	if($serial_key=='Yes'){
		$serial_use='Yes';
	}else{
		$serial_use='No';
	}
	if($purchase_default_cursor=='Email'){
		$onfocus='vendor_email';
	}else if($purchase_default_cursor=='Mobile'){
		$onfocus='mobile_no';
	}else if($purchase_default_cursor=='Telephone'){
		$onfocus='telephone_no';
	}
	$stmt->free_result();
		$stmt->close();
	}
	?>
	<?php if($after_purchase_service=="No"){
		$hide='hide_now';
		}else{
		$hide="";
	}
	?>
	<?php if($barcode=="No"){
		$bar_hide='hide_now';
	}else{
		$bar_hide="";
	}
	?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title><?php echo $company;?></title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="design.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="../inventory-software.png">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<script src="javascript.js"></script>
	<script src="auto/jquery-ui.min.js"></script>
	<link href="auto/jquery-ui.min.css" rel="stylesheet">
	<script type="text/javascript">
	$(document).ready(function() {
	$('.intime').click(function() {
	<?php $time=date('H:i');?>
	 var intime="<?php echo date('h:i: a', strtotime($time));?>";
	 
	 alert(intime);
	})	
	$('.outtime').click(function() {
	<?php $time=date('H:i');?>
	 var outtime="<?php echo date('h:i: a', strtotime($time));?>";
	 alert(outtime);
	})	
	})
	
	</script>
	
  </head>
  <body>
  <div class="check"></div>
  <div class="invoice_edit_take"></div>
  <input type="hidden" class="input" id="token_five">
	<span class="print_class_hide"><?php include_once('software_menu.php');?></span>
	<span class="print_class_hide"><?php include_once('software_header.php');?></span>
	<button class="intime">Employee Works In</button>
	<button class="outtime">Employee Works Out</button>
  </body>
</html>
<?php
}else{
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Please Login</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="design.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="../inventory-software.png">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<script src="javascript.js"></script>
	
	</head>
  <body>
  <?php include_once('client_header.php');?>
  <h1 class="client_login_title">You have not permit to access this page</h1>
  </body>
</html>
<?php
}
}else{
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Please Login</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="design.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="../inventory-software.png">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<script src="javascript.js"></script>
	
	</head>
  <body>
  <?php include_once('client_header.php');?>
  <h1 class="client_login_title">Something wrong.Please <a href="index.php">login</a></h1>
  </body>
</html>
<?php
}
?>