<?php 
ob_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include_once('db.php');
include_once('method.php');
session_start();
session_regenerate_id(TRUE);
?>
<?php
if(isset($_SESSION['user_session']) and isset($_SESSION['company_username_session']) and isset($_SESSION['sub_user_session'])){
	$user_type_now=$_SESSION['user_session'];
	$company_now=$_SESSION['company_username_session'];
	$user_now=$_SESSION['sub_user_session'];
	$status=1;
	$query = "SELECT email,company_name,company_timezone,vendor_primary_key FROM companies_onserial WHERE company_username=? and status=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param("si",$company_now,$status);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($email,$company_name,$company_timezone,$vendor_primary_key);
	$stmt->fetch();
	$super_email=$email;
	$company=$company_name;
	$company_timezone=$company_timezone;
	$vendor_primary_key=$vendor_primary_key;
	}
	if($user_type_now=='Super'){
	$user_now=$super_email;
	}
	
 date_default_timezone_set('Asia/Dhaka');//problem
 $var_date= date('y/m/d') ;
if($user_type_now=="Super" or $user_type_now=="Master" or $user_type_now=="Purchase_Master" or $user_type_now=="Only_Purchase"){
$type="vendor";
$status="1";
if(!empty($_POST['super_user'])){
	$super_user=$_POST['super_user'];
}else{
	$super_user="";
}
if(!empty($_POST['company_use'])){
	$company_use=$_POST['company_use'];
}else{
	$company_use="";
}
if(!empty($_POST['product_id_now'])){
	$product_id_now=$_POST['product_id_now'];
}else{
	$product_id_now="";
}

if(!empty($_POST['product_quantity_now'])){
	$product_quantity_now=$_POST['product_quantity_now'];
}else{
	$product_quantity_now="";
}
if(!empty($_POST['free_product_id_now'])){
	$free_product_id_now=$_POST['free_product_id_now'];
}else{
	$free_product_id_now="";
}

if(!empty($_POST['free_product_quantity_now'])){
	$free_product_quantity_now=$_POST['free_product_quantity_now'];
}else{
	$free_product_quantity_now="";
}
if(!empty($_POST['product_id_now']) and !empty($_POST['product_quantity_now']) and !empty($_POST['free_product_id_now']) and !empty($_POST['free_product_quantity_now'])){
	$product_status="1";
			$new_vendor_add=new data;
			$new_vendor_add->insert(
			"free_products_onserial",
			['product_id'=>"$product_id_now",
			'product_quantity'=>"$product_quantity_now",
			'free_product_id'=>"$free_product_id_now",
			'free_product_quantity'=>"$free_product_quantity_now",
			'status'=>"$product_status",
			'super_email'=>"$super_user",
			'company_username'=>"$company_use"],
			"sisisss",
			['Added Succesfully',
			'']);
}else{
	echo "Empty Fields";
}
		
}else{
echo "You have not permit to access this page";
}
}else{
    echo "Something wrong.Please <a href=\"index.php\">login</a>";
}
?>