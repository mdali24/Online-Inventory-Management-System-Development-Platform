<?php 

?>
<div class="container-fluid header_class">
		<div style="background-color:#0099ff;opacity:.9;" class="row">
			<div class="col-md-6 col-sm-6">
				<section class="main">
				<?php $logo=$_SESSION['logo'];
				
				$logo_length=strlen($logo);
				if($logo_length>1){
				
					?>
					<img style="width:40px;height:40px;float:left;border-radius:5px;margin-top:7px;margin-left:20px;margin-right:20px;" src="logo/<?php echo $logo;?>" alt="<?php echo $company;?>"/>
					<?php
				}
				?>
					<h1 style="color:#fff;float:left;" class="main_h1"><?php echo $company;?></h1>
				</section>
				<!--<h1 class="h1_color"></h1>-->
			</div>
			<div class="col-md-5 col-sm-5">
				<p style="margin-top:25px;font-size:18px;color:#fff;"><?php echo $_SESSION['address']?></p>
			</div>
			<div class="col-md-1 col-sm-1">
				<a class="logout" style="color:#fff;" href="logout.php">logout</a>
			</div>
			
		</div>
	</div>