<?php 

?>
<div class="container-fluid menu_con">
				<nav>
				  <ul>
					<li><a href="software.php">Dashboard</a></li>
					<!--<li><a href="software_page.php">Page</a></li>-->
					<!--<li><a href="#">Initial</a><span class="dropBottom"></span>
						<ul>
						<li><a href="#">Products</a></li>
						<li><a href="#">Cash</a></li>
						<li><a href="#">Debit</a></li>
						<li><a href="#">Credit</a></li>
						<li><a href="#">Balance</a></li>
					  </ul>
					</li>-->
					<li><a href="software_vendor_list.php">Distributor</a></li>
					<li><a href="#">
					Products</a><span class="dropBottom"></span>
						<ul>
						<!--<li><a href="software_product.php">Add</a></li>-->
						<li><a href="software_product_list.php">List</a></li>
						<li><a href="software_product_barcode.php">Barcode</a></li>
					  </ul>
					</li>
					<li><a href="#">Capital</a><span class="dropBottom"></span>
						<ul>
						<!--<li><a href="software_invest_capital_cash.php">Cash</a></li>-->
						<li><a href="software_invest_capital_products.php">Invest Products</a></li>
						<!--<li><a href="software_invest_capital_property.php">Invest Property</a></li>-->
						<!--<li><a href="software_invest_capital_withdrawal.php">Capital withdrawal</a></li>-->
					  </ul>
					</li>
					<li><a href="software_customer_list.php">Sellsman</a></li>
					<li><a href="software_stock_filter.php">Stock</a></li>
					<li><a href="#">Invoice</a><span class="dropBottom"></span>
						<ul>
						<li><a href="#">Sell</a><span class="dropRight"></span>
							<ul>
								<li><a href="software_sellsman_invoice.php">Sellsman</a>	     </li>
								<!--<li><a href="software_sell_order.php">Order</a>	     </li>
							   <li><a href="software_sell_invoice.php">Invoice</a>	     </li>
							   <li><a href="software_sell_return_invoice.php">Return</a></li>
							   <li><a href="software_customer_payment.php">Payment</a></li>
							   <li><a href="software_customer_service.php">Service</a>
								</li>-->
							</ul>
						 </li>
						<li><a href="#">Purchase</a><span class="dropRight"></span>
							<ul>
							   <li><a href="software_purchase_order.php">Order</a>	     </li>
							   <li><a href="software_purchase_invoice.php">Invoice</a>	     </li>
							   <!--<li><a href="software_purchase_return_invoice.php">Return</a></li>-->
							   <li><a href="software_vendor_payment.php">Payment</a></li>
							    <!--<li><a href="software_vendor_service.php">Service</a>
								</li>-->
							</ul>
						</li>
					  </ul>
					</li>
					
					<!--<li><a href="software_cash_debit_credit.php">Cash</a></li>-->
					
					<!--<li><a href="#">Cash</a><span class="dropBottom"></span>
						<ul>
						<li><a href="software_cash_debit.php">Debit</a></li>
						<li><a href="software_cash_debit.php">Credit</a></li>
						<li><a href="software_cash_report.php">Report</a></li>
					  </ul>
					</li>-->
					<!--<li><a href="#">Adjusments</a><span class="dropBottom"></span>
						<ul>
						<li><a href="#">Products</a><span class="dropRight"></span>
							<ul>
							<li><a href="software_products_adjusments_lost.php">Damage</a></li>
							<li><a href="software_products_adjusments_add.php">Intensive</a></li>
							</ul>
						 </li>
						<li><a href="software_cash_adjusments.php">Cash</a></li>
					  </ul>
					</li>-->
					<li><a href="#">Report</a><span class="dropBottom"></span>
						<ul>
						<li><a href="software_sellsman_report.php">Sellsman Report</a></li>
						<!--<li><a href="software_sell_order_report.php">Sell Order</a></li>-->
						<li><a href="software_purchase_report.php">Purchase Report</a></li>
						<li><a href="software_purchase_order_report.php">Purchase Order</a></li>
						<li><a href="software_stock_report.php">Stock Report</a></li>
						<!--<li><a href="tax_report.php">Tax Report</a></li>-->
						<!--<li><a href="software_cash_report.php">Cash Report</a></li>-->
						
						<li><a href="software_products_report.php">Products Report</a></li>
						<li><a href="software_bank_report.php">Bank Report</a></li>
						
						
					  </ul>
					</li>
					<li><a href="#">Audit</a><span class="dropBottom"></span>
						<ul>
						<li><a href="software_bank_balance.php">Bank Balance</a></li>
					  </ul>
					</li>
					<li><a href="#">
					Today</a><span class="dropBottom"></span>
						<ul>
						<li><a href="software_note.php">Note</a></li>
						<!--<li><a href="software_purchase_order_report.php">Purchase Order</a></li>
						<li><a href="software_sell_order_report.php">Sell Order</a></li>-->
						<li><a href="software_widget_products.php">Products Demands</a></li>
						<!--<li><a href="software_vendor_due.php">Due Payments</a></li>
						<li><a href="software_customer_due.php">Due Collections</a></li>-->
					  </ul>
					</li>
					<li><a href="software_bank_debit_credit.php">Bank</a></li>
					
					<!--<li><a href="#">Employee</a><span class="dropBottom"></span>
						<ul>
						<li><a href="software_employee_list.php">List</a></li>
						<li><a href="software_employee_attendence.php">Attendence</a></li>
						<li><a href="software_employee_attendence_report.php">Attendence Report</a></li>
						<li><a href="software_employee_salary.php">Salary</a></li>
						<li><a href="software_employee_business_report.php">Business Report</a></li>
					  </ul>
					</li>-->
				  </ul>
				</nav>
	</div>