<?php 
ob_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include_once('db.php');
include_once('method.php');
session_start();
session_regenerate_id(TRUE);
?>
<?php
if(isset($_SESSION['user_session']) and isset($_SESSION['company_username_session']) and isset($_SESSION['sub_user_session'])){
	$user_type_now=$_SESSION['user_session'];
	$company_now=$_SESSION['company_username_session'];
	$user_now=$_SESSION['sub_user_session'];
	$status=1;
	$query = "SELECT email,company_name,company_timezone,vendor_primary_key FROM companies_onserial WHERE company_username=? and status=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param("si",$company_now,$status);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($email,$company_name,$company_timezone,$vendor_primary_key);
	$stmt->fetch();
	$super_email=$email;
	$company=$company_name;
	$company_timezone=$company_timezone;
	$vendor_primary_key=$vendor_primary_key;
	}
	if($user_type_now=='Super'){
	$user_now=$super_email;
	}
	
 date_default_timezone_set('Asia/Dhaka');//problem
 $var_date= date('y/m/d') ;
if($user_type_now=="Super" or $user_type_now=="Master" or $user_type_now=="Purchase_Master" or $user_type_now=="Only_Purchase"){
$type="vendor";
$status="1";
if(!empty($_POST['super_user'])){
	$super_user=$_POST['super_user'];
}else{
	$super_user="";
}
if(!empty($_POST['company_use'])){
	$company_use=$_POST['company_use'];
}else{
	$company_use="";
}
if(!empty($_POST['operator'])){
	$operator=$_POST['operator'];
}else{
	$operator="";
}
$vendor_id_add=0;
if(!empty($_POST['vendor_primary_key_add'])){
	$vendor_primary_key_add=$_POST['vendor_primary_key_add'];
	$query = "SELECT sn FROM company_markenter_onserial WHERE company_username=? and $vendor_primary_key=? and status=? and type=?"; 

	if($stmt = $mysqli->prepare($query)){
	if($vendor_primary_key=='markenter_email'){
	    	$stmt->bind_param("ssis", $company_use,$vendor_primary_key_add,$status,$type);
	    }else{
	    	$stmt->bind_param("siis", $company_use,$vendor_primary_key_add,$status,$type);
	    	
	    }
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($sn);
	$stmt->fetch();
	if($num_of_rows>0){
		$vendor_id_add=$sn;
	}else{
		$vendor_id_add=0;
	}
	}
}else{
	$vendor_primary_key_add="";
}
if(!empty($_POST['product_name_view'])){
	$product_name_view=$_POST['product_name_view'];
}else{
	$product_name_view="";
}
if(!empty($_POST['rack_no'])){
	$rack_no=$_POST['rack_no'];
}else{
	$rack_no="";
}
if(!empty($_POST['product_id_view'])){
	$product_id_view=$_POST['product_id_view'];
	$image_name=$product_id_view.'.png';
	if (file_exists('barcode_images/'.$image_name)) {
	 }else{
		include_once('Barcode39.php');

		$bc = new Barcode39("$product_id_view"); 
		
		$bc->barcode_text_size = 1; 
		
		$bc->barcode_bar_thick = 2; 
		
		$bc->barcode_bar_thin = 1;
		
		$bc->draw("barcode_images/$product_id_view.png");
	 }
}else{
	/*if ($stmt = $mysqli->prepare("SELECT product_id FROM products_details_onserial WHERE company_username=?")) {
    $stmt->bind_param("s", $company_use);
    $stmt->execute();
	$stmt->store_result();
	$rows_num=$stmt->num_rows;
	if($rows_num > 0){
		$stmt_sql = $mysqli->prepare("SELECT product_id FROM products_details_onserial WHERE company_username=? ORDER BY sn DESC");
		$stmt_sql->bind_param("s", $company_use);
		$stmt_sql->execute();
		$stmt_sql->store_result();
		$num_of_rows = $stmt_sql->num_rows;
		$stmt_sql->bind_result($product_id);
		$stmt_sql->fetch();
	
			$last_product_id=$product_id;
			if($last_product_id<100000001){
				$new_product_id=100000000+1;
			}else{
				$new_product_id=$last_product_id+1;
			}
	}else{
		$new_product_id=100000001;
	}
	}*/
}
	//$product_id_view="";
	
	

if(!empty($_POST['products_company_view'])){
	$products_company_view=$_POST['products_company_view'];
}else{
	$products_company_view="";
}
if(!empty($_POST['size_view'])){
	$size_view=$_POST['size_view'];
}else{
	$size_view="";
}
$product_title_view=$product_name_view." ".$size_view;
if(!empty($_POST['unit_price_view'])){
	$unit_price_view=$_POST['unit_price_view'];
}else{
	$unit_price_view="";
}
if(!empty($_POST['tax_percent_view'])){
	$tax_percent=$_POST['tax_percent_view'];
	
}else{
	$tax_percent="";
}
if(!empty($_POST['sell_price_view'])){
	$sell_price_view=$_POST['sell_price_view'];
}else{
	$sell_price_view="";
}
if(!empty($_POST['pack_size'])){
	$pack_size=$_POST['pack_size'];
}else{
	$pack_size="";
}
if(!empty($_POST['warranty_guarantee_days_view'])){
	$warranty_guarantee_days_view=$_POST['warranty_guarantee_days_view'];
}else{
	$warranty_guarantee_days_view="";
}
if(!empty($_POST['warranty_guarantee_type_view'])){
	$warranty_guarantee_type_view=$_POST['warranty_guarantee_type_view'];
}else{
	$warranty_guarantee_type_view="";
}
if(!empty($_POST['serial_key_length_view'])){
	$serial_key_length_view=$_POST['serial_key_length_view'];
}else{
	$serial_key_length_view="";
}
if(!empty($_POST['remarks_p_view'])){
	$remarks_p_view=$_POST['remarks_p_view'];
}else{
	$remarks_p_view="";
}
if(!empty($_POST['product_id_view'])){
	

$query = "SELECT vendor_primary_key FROM companies_onserial WHERE company_username=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$company_use);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($vendor_primary_key);
	$stmt->fetch();
	if($vendor_primary_key=='Email'){
		$vendor_primary_key='markenter_email';
		
	}else if($vendor_primary_key=='Mobile'){
		$vendor_primary_key='vendor_mobile_no';
		
	}else if($vendor_primary_key=='Telephone'){
		$vendor_primary_key='vendor_telephone_no';
		
	}
	}
	$vendor_select=$vendor_primary_key_add;
	if($vendor_id_add<1){
		$query_vendor = "SELECT sn FROM company_markenter_onserial WHERE company_username=? and $vendor_primary_key=? and type='vendor'"; 
			if($stmt_vendor = $mysqli->prepare($query_vendor)){
				if($vendor_primary_key=='markenter_email'){
					$stmt_vendor->bind_param('ss',$company_use,$vendor_select);
				}else{
					$stmt_vendor->bind_param('si',$company_use,$vendor_select);
				}
			$stmt_vendor->execute();
			$stmt_vendor->store_result();
			$num_of_rows = $stmt_vendor->num_rows;
			$stmt_vendor->bind_result($vendor_serial);
			$stmt_vendor->fetch();
			$vendor_id_add=$vendor_serial;
			}
	}

	if($stmt_sql = $mysqli->prepare("SELECT * FROM products_details_onserial WHERE (product_id=? and company_username=?) or (product_title=? and company_username=?)")){
		
		$stmt_sql->bind_param("ssss",$product_id_view,$company_use,$product_title_view,$company_use);
		$stmt_sql->execute();
		$stmt_sql->store_result();
		$rows_num=$stmt_sql->num_rows;
		
		if($rows_num > 0){
		/*$stmt = $mysqli->prepare("UPDATE products_details_onserial SET 
			`product_title`=?,
			`product_name`=?,
			`rack_no`=?,
			`products_company`=?,
			`size`=?,
			`unit_price`=?,
			`tax`=?,
			`vendor_serial`=?,
			`sell_price`=?,
			`warenty_days`=?,
			`warenty_type`=?,
			`serial_length`=?
			 WHERE `product_id`=? and `company_username`=?");
					
			$stmt->bind_param('ssssssssssssss', $product_title_view
			, $product_name_view, $rack_no, $products_company_view,$size_view, $unit_price_view, $tax_percent,$vendor_id_add, $sell_price_view,$warranty_guarantee_days_view, $warranty_guarantee_type_view,$serial_key_length_view, $product_id_view, $company_use);
				$update_status = $stmt->execute();
				if($update_status==1){
					echo "Updated SuccessFully";
				}*/
				echo "Already Added This Product";
		}else{
		$product_status=1;
			$new_vendor_add=new data;
			$new_vendor_add->insert(
			"products_details_onserial",
			['product_title'=>"$product_title_view",
			'product_name'=>"$product_name_view",
			'rack_no'=>"$rack_no",
			'status'=>"$product_status",
			'product_id'=>"$product_id_view",
			'products_company'=>"$products_company_view",
			'size'=>"$size_view",
			'pack_size'=>"$pack_size",
			'unit_price'=>"$unit_price_view",
			'tax'=>"$tax_percent",
			'vendor_serial'=>"$vendor_id_add",
			'sell_price'=>"$sell_price_view",
			'warenty_days'=>"$warranty_guarantee_days_view",
			'warenty_type'=>"$warranty_guarantee_type_view",
			'serial_length'=>"$serial_key_length_view",
			'super_email'=>"$super_user",
			'company_username'=>"$company_use"],
			"sssssssssssssssss",
			['Added Succesfully',
			'']);
						
		}
	}
	//header( "refresh:2;url=software_product_list.php" );
}else{
	echo "Empty Product Id";
}
}else{
echo "You have not permit to access this page";
}
}else{
    echo "Something wrong.Please <a href=\"index.php\">login</a>";
}
?>
