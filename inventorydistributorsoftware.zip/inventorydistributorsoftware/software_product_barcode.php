<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include_once('db.php');
session_start();
session_regenerate_id(TRUE);
if(isset($_SESSION['user_session']) and isset($_SESSION['company_username_session']) and isset($_SESSION['sub_user_session'])){
	$user_type_now=$_SESSION['user_session'];
	$company_now=$_SESSION['company_username_session'];
	$user_now=$_SESSION['sub_user_session'];
	$status=1;
	$query = "SELECT email,company_name,company_timezone,vendor_primary_key FROM companies_onserial WHERE company_username=? and status=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param("si",$company_now,$status);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($email,$company_name,$company_timezone,$vendor_primary_key);
	$stmt->fetch();
	$super_email=$email;
	$company=$company_name;
	$company_timezone=$company_timezone;
	$vendor_primary_key=$vendor_primary_key;
	}
	if($user_type_now=='Super'){
	$user_now=$super_email;
	}
	
 date_default_timezone_set($company_timezone);//problem
 $var_date= date('y/m/d') ;
if($user_type_now=="Super" or $user_type_now=="Master" or $user_type_now=="Purchase_Master" or $user_type_now=="Only_Purchase"){
$query = "SELECT vendor_primary_key FROM companies_onserial WHERE company_username=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$company_now);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($vendor_primary_key);
	$stmt->fetch();
	if($vendor_primary_key=='Email'){
		$vendor_primary_key='markenter_email';
	}else if($vendor_primary_key=='Mobile'){
		$vendor_primary_key='vendor_mobile_no';
	}else if($vendor_primary_key=='Telephone'){
		$vendor_primary_key='vendor_telephone_no';
	}
	$stmt->free_result();
		$stmt->close();
	}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title><?php echo $company;?></title>
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<script src="auto/jquery-ui.min.js"></script>
	<link href="auto/jquery-ui.min.css" rel="stylesheet">
	<script>
	$(document).ready(function() {
	$(".search_product_id").focus();
		$(".search_product_title").click(function(e){
		e.preventDefault();
			var product_title=$(".product_title").val();
			
			var company="<?php echo $company_now;?>";
			var vendor_key="<?php echo $vendor_primary_key;?>";
			var data_key='product_title='+ product_title+'&vendor_key='+ vendor_key+'&company='+ company;
			
			$.ajax({
				type: "POST",
				url: "fill/search_product_title_now.php",
				data: data_key,
				success: function(html){
					$(".search_product_now").html(html);
					
					}		
				});
		});
		$(".search_product_id").click(function(e){
		e.preventDefault();
			var product_id=$(".product_id").val();
			var product_id_print_number=$(".product_id_print_number").val();
			var company="<?php echo $company_now;?>";
			var data_key='product_id='+ product_id+'&company='+ company;
			
			$.ajax({
				type: "POST",
				url: "fill/search_product_id_price_now.php",
				data: data_key,
				success: function(html){
					$(".search_price").html(html);
					var search_price=$(".search_price").html();
					var i=1;
					while (i <= product_id_print_number) {
						img = "<img src=\"barcode_images/"+product_id+".png\"/>";
						price = "<div  class=\"price\">"+search_price+"</div>";
						display=img+price;
						display_unit = "<div  class=\"col-md-2\">"+display+"</div>";
						$(".images").after(display_unit);
						i++;
					}
					}		
				});
			
			/*var company="<?php echo $company_now;?>";
			var vendor_key="<?php echo $vendor_primary_key;?>";
			var data_key='product_id='+ product_id+'&vendor_key='+ vendor_key+'&company='+ company;
			
			$.ajax({
				type: "POST",
				url: "fill/search_product_id_now.php",
				data: data_key,
				success: function(html){
					$(".search_product_now").html(html);
					
					}		
				});*/
		});
		var com_now="<?php echo $company_now;?>";
		$(function() {
			$("#product_title").autocomplete({
				source: "auto/vendor_product_title_search.php?company="+"'"+com_now+"'",
				minLength: 2
			});				
		});
		$('.print_barcode').click(function() {
				window.print();
			});
		
	})
	</script>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="design.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="../inventory-software.png">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	
  </head>
  <body>
  <?php
	$query = "SELECT pakage,year,date FROM login_onserial WHERE email=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$super_email);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($pakage,$year,$date);
	$stmt->fetch();
	$softpakage=$pakage;
	$year=$year;
	$date=$date;
	$yearto=substr($date,0,4);
	$monthto=substr($date,5,2);
	$dateto=substr($date,8,2);
	$year_num=(int)$yearto;
	$year_up=$year_num+$year;
	if($monthto==2 and $dateto==29){
		$monthto=03;
		$dateto=01;
	}
	$up_date="$year_up"."/"."$monthto"."/"."$dateto";
	$up_to_time=strtotime($up_date);
	$expired_date=date('Y-m-d',$up_to_time);
	$today=date("Y-m-d");
	
	$today_strtotime=strtotime($today);
	$expired_strtotime=strtotime($expired_date);
	if($softpakage=='Free'){
		$warehouse=1;
		$users=1;
	}else if($softpakage=='Silver'){
		$warehouse=1;
		$users=1;
	}else if($softpakage=='Gold'){
		$warehouse=10;
		$users=20;
	}else if($softpakage=='Diamond'){
		$warehouse=50;
		$users=100;
	}
	$stmt->free_result();
		$stmt->close();
	}
	
	
	if(!empty($_POST['company'])){
	$company_filter=$_POST['company'];
	}else{
		$company_filter="empty";
	}
	if(!empty($_POST['vendor_select'])){
		$vendor_select=$_POST['vendor_select'];
		if($vendor_select=='All Vendors'){
			$vendor_filter=" ";
		}else{
			$query_vendor = "SELECT sn FROM company_markenter_onserial WHERE company_username=? and $vendor_primary_key=? and type='vendor'"; 
			if($stmt_vendor = $mysqli->prepare($query_vendor)){
				if($vendor_primary_key=='markenter_email'){
					$stmt_vendor->bind_param('ss',$company_now,$vendor_select);
				}else{
					$stmt_vendor->bind_param('si',$company_now,$vendor_select);
				}
			$stmt_vendor->execute();
			$stmt_vendor->store_result();
			$num_of_rows = $stmt_vendor->num_rows;
			$stmt_vendor->bind_result($vendor_serial);
			$stmt_vendor->fetch();
			$vendor_filter="and  vendor_serial=$vendor_serial";
			}
		}
	}else{
		$vendor_select="";
		$vendor_filter="";
		
	}
	if(!empty($_POST['display'])){
		$display=$_POST['display'];
		if($display=='Display All'){
			$display_check="";
		}else{
			$display_now=$display;
			$display_check="exist";
		}
	}else{
		$display="";
		$display_now=20;
		$display_check="exist";
		
	}
	if(!empty($_POST['page_no'])){
		$page_no=$_POST['page_no'];
	}else{
		$page_no=1;
		
	}
	if(!empty($_POST['page_filter'])){
		$page_filter=$_POST['page_filter'];
		if($page_filter=='Next'){
			$go=$page_no+1;
		}else if($page_filter=='Previous'){
			$go=$page_no-1;
		}else if($page_filter=='Reset'){
			$go=1;
		}else{
			$go=$page_no;
		}
	}else{
		$page_filter="";
		$go=1;
	}
	if($go<1){
		$go=1;
		$message="This is first page.Can not go to previous.";
	}else{
		$message="";
	}
	$num_of_rows_now=0;
	?>
	<?php include_once('software_menu.php');?>
	<?php include_once('software_header.php');?>
	<div class="container-fluid border_bottom color z_index">
		<!--<h2>Vendor Management</h2>-->	
	</div>
	<div style="display:none;height:30px;" class="search_price"></div>
	<div style="height:30px;" class=""></div>
	<div class="container-fluid">
		<div class="row">
		<div class="div_padding">
		<!--<div class="col-md-6 col-sm-6">
			
				<form>		
				   
					<input type="text" class="product_title purchase_filter_style_input" id='product_title' placeholder="Search Product Title?">		  <input type="number" class="product_title_print_number purchase_filter_style" id='product_title_print_number' placeholder="Print Quantity?"> 
					<button class="search_product_title purchase_filter_style">Add</button>
				</form>
			
		</div>-->
		<div class="col-md-12 col-sm-12">
			
				<form>
				
					<input type="number" style="margin-left:20px;" class="product_id purchase_filter_style_input" id="product_id"  placeholder="Search Product Id?">		    	<input type="number" style="margin-left:20px;" class="product_id_print_number purchase_filter_style_input" id='product_id_print_number' placeholder="Product Quantity?">  
					<button class="search_product_id purchase_filter_style">Add</button>
				</form>
				<button style="float:right;margin-right:50px;" type="button" class="btn btn-outline-primary add_company purchase_filter_style print_barcode">Print</button>	
			
		</div>
		<div class="col-md-12 col-sm-12">
			<div class="image_container">
				<div style="height:35px;" class=""></div>
				<div class="images"></div>
			</div>
			</div>
		</div>
			
		</div>
	</div>
	
  </body>
</html>
<?php
}else{
echo "You have not permit to access this page";
}
}else{
    echo "Something wrong.Please <a href=\"index.php\">login</a>";
}
?>