<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include_once('db.php');
session_start();
session_regenerate_id(TRUE);
if(isset($_SESSION['user_session']) and isset($_SESSION['company_username_session']) and isset($_SESSION['sub_user_session'])){
	$user_type_now=$_SESSION['user_session'];
	$company_now=$_SESSION['company_username_session'];
	$user_now=$_SESSION['sub_user_session'];
	$status=1;
	$query = "SELECT email,company_name,company_timezone,vendor_primary_key FROM companies_onserial WHERE company_username=? and status=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param("si",$company_now,$status);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($email,$company_name,$company_timezone,$vendor_primary_key);
	$stmt->fetch();
	$super_email=$email;
	$company=$company_name;
	$company_timezone=$company_timezone;
	$vendor_primary_key=$vendor_primary_key;
	}
	if($user_type_now=='Super'){
	$user_now=$super_email;
	}
	
 date_default_timezone_set($company_timezone);//problem
 $var_date= date('y/m/d') ;
if($user_type_now=="Super" or $user_type_now=="Master" or $user_type_now=="Purchase_Master" or $user_type_now=="Only_Purchase"){
$query = "SELECT vendor_primary_key FROM companies_onserial WHERE company_username=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$company_now);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($vendor_primary_key);
	$stmt->fetch();
	if($vendor_primary_key=='Email'){
		$vendor_primary_key='markenter_email';
	}else if($vendor_primary_key=='Mobile'){
		$vendor_primary_key='vendor_mobile_no';
	}else if($vendor_primary_key=='Telephone'){
		$vendor_primary_key='vendor_telephone_no';
	}
	$stmt->free_result();
		$stmt->close();
	}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title><?php echo $company;?></title>
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<script src="auto/jquery-ui.min.js"></script>
	<link href="auto/jquery-ui.min.css" rel="stylesheet">
	<script>
	$(document).ready(function() {
		$(".search_product_title").click(function(e){
		e.preventDefault();
			var product_title=$(".product_title").val();
			
			var company="<?php echo $company_now;?>";
			var vendor_key="<?php echo $vendor_primary_key;?>";
			var data_key='product_title='+ product_title+'&vendor_key='+ vendor_key+'&company='+ company;
			
			$.ajax({
				type: "POST",
				url: "fill/search_product_title_now.php",
				data: data_key,
				success: function(html){
					$(".search_product_now").html(html);
					
					}		
				});
		});
		$(".search_product_id").click(function(e){
		e.preventDefault();
			var product_id=$(".product_id").val();
			
			var company="<?php echo $company_now;?>";
			var vendor_key="<?php echo $vendor_primary_key;?>";
			var data_key='product_id='+ product_id+'&vendor_key='+ vendor_key+'&company='+ company;
			
			$.ajax({
				type: "POST",
				url: "fill/search_product_id_now.php",
				data: data_key,
				success: function(html){
					$(".search_product_now").html(html);
					
					}		
				});
		});
		var com_now="<?php echo $company_now;?>";
		$(function() {
			$("#product_title").autocomplete({
				source: "auto/vendor_product_title_search.php?company="+"'"+com_now+"'",
				minLength: 2
			});				
		});
		
		$(".new_product_Add").click(function(e) {
			 e.preventDefault();
		 
			var super_user=$(".super_user").val();
			var company_use=$(".company_use").val();
			var operator=$(".operator").val();
			var vendor_primary_key_add=$("#vendor_primary_key_add").val();
			var product_name_view=$("#product_name_view").val();
			var size_view=$("#size_view").val();
			var rack_no=$("#rack_no").val();
			var pack_size=$("#pack_size").val();
			var product_id_view=$("#product_id_view").val();
			var products_company_view=$("#products_company_view").val();
			var unit_price_view=$("#unit_price_view").val();
			var tax_percent_view=$("#tax_percent_view").val();
			var sell_price_view=$("#sell_price_view").val();
			var warranty_guarantee_days_view=$("#warranty_guarantee_days_view").val();
			var warranty_guarantee_type_view=$("#warranty_guarantee_type_view").val();
			var serial_key_length_view=$("#serial_key_length_view").val();
			var remarks_p_view=$("#remarks_p_view").val();
			
					var data='super_user='+ super_user+'&company_use='+ company_use+'&operator='+ operator+'&vendor_primary_key_add='+ vendor_primary_key_add+'&product_name_view='+ product_name_view+'&size_view='+ size_view+'&rack_no='+ rack_no+'&pack_size='+ pack_size+'&product_id_view='+ product_id_view+'&products_company_view='+ products_company_view+'&unit_price_view='+ unit_price_view+'&tax_percent_view='+ tax_percent_view+'&sell_price_view='+ sell_price_view+'&warranty_guarantee_days_view='+ warranty_guarantee_days_view+'&warranty_guarantee_type_view='+ warranty_guarantee_type_view+'&serial_key_length_view='+ serial_key_length_view+'&remarks_p_view='+ remarks_p_view;
					
				
				$.ajax({
				type: "POST",
				url: "software_product_add_list.php",
				data: data,
				success: function(html){
					$('.close').click();
					alert(html);
					}		
			});	
		 })
		 
		 $(".free_new_product_Add").click(function(e) {
			 e.preventDefault();
		 
			var super_user=$(".super_user").val();
			var company_use=$(".company_use").val();
			var operator=$(".operator").val();
			var product_id_now=$("#product_id_now").val();
			var product_quantity_now=$("#product_quantity_now").val();
			var free_product_id_now=$("#free_product_id_now").val();
			var free_product_quantity_now=$("#free_product_quantity_now").val();
			
					var data='super_user='+ super_user+'&company_use='+ company_use+'&operator='+ operator+'&product_id_now='+ product_id_now+'&product_quantity_now='+ product_quantity_now+'&free_product_id_now='+ free_product_id_now+'&free_product_quantity_now='+ free_product_quantity_now;
				
				$.ajax({
				type: "POST",
				url: "software_free_product_add_list.php",
				data: data,
				success: function(html){
					$('.close').click();
					alert(html);
					}		
			});	
		 })
		
	})
	</script>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="design.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="../inventory-software.png">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	
  </head>
  <body>
  <?php
	$query = "SELECT pakage,year,date FROM login_onserial WHERE email=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$super_email);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($pakage,$year,$date);
	$stmt->fetch();
	$softpakage=$pakage;
	$year=$year;
	$date=$date;
	$yearto=substr($date,0,4);
	$monthto=substr($date,5,2);
	$dateto=substr($date,8,2);
	$year_num=(int)$yearto;
	$year_up=$year_num+$year;
	if($monthto==2 and $dateto==29){
		$monthto=03;
		$dateto=01;
	}
	$up_date="$year_up"."/"."$monthto"."/"."$dateto";
	$up_to_time=strtotime($up_date);
	$expired_date=date('Y-m-d',$up_to_time);
	$today=date("Y-m-d");
	
	$today_strtotime=strtotime($today);
	$expired_strtotime=strtotime($expired_date);
	if($softpakage=='Free'){
		$warehouse=1;
		$users=1;
	}else if($softpakage=='Silver'){
		$warehouse=1;
		$users=1;
	}else if($softpakage=='Gold'){
		$warehouse=10;
		$users=20;
	}else if($softpakage=='Diamond'){
		$warehouse=50;
		$users=100;
	}
	$stmt->free_result();
		$stmt->close();
	}
	
	
	if(!empty($_POST['company'])){
	$company_filter=$_POST['company'];
	}else{
		$company_filter="empty";
	}
	if(!empty($_POST['vendor_select'])){
		$vendor_select=$_POST['vendor_select'];
		if($vendor_select=='All Vendors'){
			$vendor_filter=" ";
		}else{
			$query_vendor = "SELECT sn FROM company_markenter_onserial WHERE company_username=? and $vendor_primary_key=? and type='vendor'"; 
			if($stmt_vendor = $mysqli->prepare($query_vendor)){
				if($vendor_primary_key=='markenter_email'){
					$stmt_vendor->bind_param('ss',$company_now,$vendor_select);
				}else{
					$stmt_vendor->bind_param('si',$company_now,$vendor_select);
				}
			$stmt_vendor->execute();
			$stmt_vendor->store_result();
			$num_of_rows = $stmt_vendor->num_rows;
			$stmt_vendor->bind_result($vendor_serial);
			$stmt_vendor->fetch();
			$vendor_filter="and  vendor_serial=$vendor_serial";
			}
		}
	}else{
		$vendor_select="";
		$vendor_filter="";
		
	}
	if(!empty($_POST['display'])){
		$display=$_POST['display'];
		if($display=='Display All'){
			$display_check="";
		}else{
			$display_now=$display;
			$display_check="exist";
		}
	}else{
		$display="";
		$display_now=50;
		$display_check="exist";
		
	}
	if(!empty($_POST['page_no'])){
		$page_no=$_POST['page_no'];
	}else{
		$page_no=1;
		
	}
	if(!empty($_POST['page_filter'])){
		$page_filter=$_POST['page_filter'];
		if($page_filter=='Next'){
			$go=$page_no+1;
		}else if($page_filter=='Previous'){
			$go=$page_no-1;
		}else if($page_filter=='Reset'){
			$go=1;
		}else{
			$go=$page_no;
		}
	}else{
		$page_filter="";
		$go=1;
	}
	if($go<1){
		$go=1;
		$message="This is first page.Can not go to previous.";
	}else{
		$message="";
	}
	$num_of_rows_now=0;
	?>
	<?php include_once('software_menu.php');?>
	<?php include_once('software_header.php');?>
	<div class="container-fluid border_bottom color z_index">
		<!--<h2>Vendor Management</h2>-->	
	</div>
	
	<div class="container-fluid">
		<div class="row">
		<div class="div_padding">
		<div class="col-md-6 col-sm-6">
			<div class="webdesigntuts-workshop">
				<form>		    
					<input type="text" class="product_title" id='product_title' placeholder="Search Product Title?">		    	
					<button class="search_product_title">Search</button>
				</form>
			</div>
		</div>
		<div class="col-md-6 col-sm-6">
			<div class="webdesigntuts-workshop">
				<form>
					<input type="number" class="product_id" placeholder="Search Product Id?">		    	
					<button class="search_product_id">Search</button>
				</form>
			</div>
		</div>
		<div class="col-md-12 col-sm-12">
		
			<form action="software_product_list.php" method="POST">
			<input type="hidden" name="company" value="<?php echo $company_now;?>">
			<select id="vendor_select" name="vendor_select"  class="purchase_filter_style" >
				<?php if(strlen($vendor_select)>0){
					echo "<option value=\"$vendor_select\">$vendor_select</option>";
				}?>
				<option value="All Vendors">All Vendors</option>
				<?php
				if($stmt_sql = $mysqli->prepare("SELECT $vendor_primary_key FROM company_markenter_onserial WHERE company_username=? and type='vendor' ORDER BY sn DESC")){
					
					$stmt_sql->bind_param("s",$company_now);
					$stmt_sql->execute();
					$stmt_sql->store_result();
					$num_of_rows = $stmt_sql->num_rows;
					$stmt_sql->bind_result($vendor_find);
					if($num_of_rows > 0){
						while($stmt_sql->fetch()){
							echo "<option value=\"$vendor_find\">$vendor_find</option>";
							}
					}
					}
					?>
				</select>
				<select id="secuence" name="display"  class="purchase_filter_style" >
				<?php if(strlen($display)>0){
					echo "<option value=\"$display\">$display</option>";
				}?>
					<option value="50">50</option>
					<option value="100">100</option>
					<option value="Display All">Display All</option>
				</select>
				<input type="hidden" name="page_no" value="<?php echo $go;?>">
				<select id="secuence" name="page_filter"  class="purchase_filter_style" >
				<?php if(strlen($page_filter)>0){
					echo "<option value=\"$page_filter\">$page_filter</option>";
				}?>
					<option value="Current">Current</option>
					<option value="Next">Next</option>
					<option value="Previous">Previous</option>
					<option value="Reset">Reset</option>
					
				</select>
				
			<input type="submit" class="purchase_filter_style" value="Filter">
			</form>
			<button style="float:right;" type="button" class="btn btn-outline-primary add_company purchase_filter_style" data-toggle="modal" data-target="#myModalProducts">Add Product</button>
			<button style="float:right;" type="button" class="btn btn-outline-primary add_company purchase_filter_style" data-toggle="modal" data-target="#myModalFreeProducts">Add Free Product</button>
			</div>
		</div>
			<div class="col-md-12">
				<div class="search_product_now"></div>
				  <div class="wrapper">
					  <div class="table">
						
						
					<?php 
					$page=$go;
					if(strlen($display_check)>0){
						$range=$display_now;
						$start=($page*$range)-$range;
						$next=$page+1;
						$previus=$page-1;
						$limit=" limit $start,$range";
					}else{
						$limit="";
					}
					
					if($stmt_sql = $mysqli->prepare("SELECT product_title,product_id,products_company,unit_price,vendor_serial,	sell_price,warenty_type,warenty_days FROM products_details_onserial WHERE company_username=? and status=1 $vendor_filter ORDER BY sn DESC")){
						
					$stmt_sql->bind_param("s",$company_now);
					$stmt_sql->execute();
					$stmt_sql->store_result();
					$num_of_rows_now = $stmt_sql->num_rows;
					$stmt_sql->fetch();
					echo "<p style=\"margin:0;padding:0;\">Total : ".$num_of_rows_now."</p>";
					}
					if($stmt_sql = $mysqli->prepare("SELECT sn,product_title,product_id,products_company,unit_price,vendor_serial,	sell_price,warenty_type,warenty_days FROM products_details_onserial WHERE company_username=? and status=1 $vendor_filter ORDER BY sn DESC $limit")){
						
					$stmt_sql->bind_param("s",$company_now);
					$stmt_sql->execute();
					$stmt_sql->store_result();
					$num_of_rows_now = $stmt_sql->num_rows;
					
					$stmt_sql->bind_result($sn_pro,$product_title,$product_id,$products_company,$unit_price,$vendor_serial,$sell_price,$warenty_type,$warenty_days);
					if($num_of_rows_now > 0){
					?>
					<div class="tb_header">
						  <div class="cell">
							Sn
						  </div>
						  <div class="cell">
							Product Title
						  </div>
						  <div class="cell">
							Product Id
						  </div>
						  <div class="cell">
							Products Company
						  </div>
						  <div class="cell">
							Unit Price
						  </div>
						  <div class="cell">
							Sell Price
						  </div>
						  <div class="cell">
							Servicing Type
						  </div>
						  <div class="cell">
							Servicing Days
						  </div>
						  <div class="cell">
							Vendor
						  </div>
						  <div class="cell">
							Delete
						  </div>
						</div>
					<?php
						$sn=1;
						
						while($stmt_sql->fetch()){
							echo "<div class=\"tb_row\">";
							echo "<div class=\"cell\">".$sn."</div>";
							echo "<div class=\"cell\">".$product_title."</div>";
							echo "<div class=\"cell\">".$product_id."</div>";
							echo "<div class=\"cell\">".$products_company."</div>";
							echo "<div class=\"cell\">".$unit_price."</div>";
							echo "<div class=\"cell\">".$sell_price."</div>";
							echo "<div class=\"cell\">".$warenty_type."</div>";
							echo "<div class=\"cell\">".$warenty_days."</div>";
							if($stmt_name = $mysqli->prepare("SELECT full_name,$vendor_primary_key FROM company_markenter_onserial WHERE company_username=? and status='1' and sn=? ORDER BY sn DESC")) {
							$stmt_name->bind_param("si",$company_now,$vendor_serial);
							$stmt_name->execute();
							$stmt_name->store_result();
							$stmt_name->bind_result($full_name,$vendor_primary);
							echo "<div class=\"cell\">";
							while($stmt_name->fetch()){
								echo $full_name."<br/>";
								echo $vendor_primary."<br/>";
							}
							echo "</div>";
							}
							echo "<div class=\"cell\">"."<button class=\"remove_product\">".$sn_pro."</button>"."</div>";
							$sn++;
							echo "</div>";
							}
					}else{
						echo "<div class=\"tb_row\">";
							echo "None Entry";
						echo "</div>";
					}
					}
						?>
					  
					</div>
				  
				</div>
			</div>
		</div>
	</div>
	<div class="container">
		<div class="row ">
			<div class="col-md-12">
			<?php 
			if($num_of_rows_now > 0){
			
			}else{
				echo "<h5 class=\"purchase_brief\">"."Have No Product"."</h5>";
			}
			?>
			</div>
		</div>
	</div>
	
	<div class="container-fluid">
		<div class="row ">
			<div class="col-md-12">
				  <div class="wrapper">
					  <div class="table">
						
						
					<?php 
					
					if($stmt_sql = $mysqli->prepare("SELECT * FROM free_products_onserial WHERE company_username=? and status='1' ORDER BY sn DESC")){
						
					$stmt_sql->bind_param("s",$company_now);
					$stmt_sql->execute();
					$stmt_sql->store_result();
					$num_of_free_rows_now = $stmt_sql->num_rows;
					$stmt_sql->fetch();
					echo "<p style=\"margin:0;padding:0;\">Free Item : ".$num_of_free_rows_now."</p>";
					}
					if($stmt_sql = $mysqli->prepare("SELECT sn,product_id,	product_quantity,free_product_id,free_product_quantity FROM free_products_onserial WHERE company_username=? and status='1'  ORDER BY sn DESC $limit")){
						
					$stmt_sql->bind_param("s",$company_now);
					$stmt_sql->execute();
					$stmt_sql->store_result();
					$num_of_rows_now = $stmt_sql->num_rows;
					
					$stmt_sql->bind_result($sn_del,$product_id_free,$product_quantity,$free_product_id,$free_product_quantity);
					if($num_of_rows_now > 0){
					?>
					<div class="tb_header">
						  <div class="cell">
							Sn
						  </div>
						  <div class="cell">
							Product Id
						  </div>
						  <div class="cell">
							Product Quantity
						  </div>
						  <div class="cell">
							Free Product Id
						  </div>
						  <div class="cell">
							Product Product Quantity
						  </div>
						  <div class="cell">
							Delete
						  </div>
						</div>
					<?php
						$fsn=1;
						
						while($stmt_sql->fetch()){
							echo "<div class=\"tb_row\">";
							echo "<div class=\"cell\">".$fsn."</div>";
							echo "<div class=\"cell\">".$product_id_free."</div>";
							echo "<div class=\"cell\">".$product_quantity."</div>";
							echo "<div class=\"cell\">".$free_product_id."</div>";
							echo "<div class=\"cell\">".$free_product_quantity."</div>";
							echo "<div class=\"cell\">"."<button class=\"remove_now\">".$sn_del."</button>"."</div>";
							$fsn++;
							echo "</div>";
							}
					}else{
						echo "<div class=\"tb_row\">";
							echo "None Entry";
						echo "</div>";
					}
					}
						?>
					  
					</div>
				  
				</div>
			</div>
			
		</div>
	</div>
	<div class="container-fluid">
		<div class="modal fade" id="myModalProducts" role="dialog">
			<div class="modal-dialog">
					<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h6 class="modal-title">Products Information</h6>
					</div>
					<div class="modal-body">
			 			<div class="panel-body">
							<!--<form action="software_product_add_list.php" role="form" method="POST">-->
								<div class="row">
									<div class="col-xs-3 col-sm-3 col-md-3">
										<div class="form-group">
											<input type="hidden" name="super_user" id="" class="form-control input-sm super_user" value ="<?php echo $super_email;?>">
											<input type="hidden" name="company_use" id="" class="form-control input-sm company_use" value ="<?php echo $company_now;?>">
											<input type="hidden" name="operator" id="" class="form-control input-sm operator" value ="<?php echo $user_now;?>">
											Code : <select id="vendor_primary_key_add" name="vendor_primary_key_add"  class="" >
											<?php
											if($stmt_sql = $mysqli->prepare("SELECT $vendor_primary_key FROM company_markenter_onserial WHERE company_username=? and type='vendor' ORDER BY sn DESC")){
												
												$stmt_sql->bind_param("s",$company_now);
												$stmt_sql->execute();
												$stmt_sql->store_result();
												$num_of_rows = $stmt_sql->num_rows;
												$stmt_sql->bind_result($vendor_find);
												if($num_of_rows > 0){
													while($stmt_sql->fetch()){
														echo "<option value=\"$vendor_find\">$vendor_find</option>";
														}
												}
												}
												?>
											</select>
										</div>
									</div>
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
											<input type="text" name="product_name_view" id="product_name_view" class="form-control input-sm" placeholder="Product Name" required>
										</div>
									</div>
									<div class="col-xs-3 col-sm-3 col-md-3">
										<div class="form-group">
											<input type="text" name="size_view" id="size_view" class="form-control input-sm" placeholder="Product Size">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
											<input type="text" name="rack_no" id="rack_no" class="form-control input-sm" placeholder="Rack No">
										</div>
									</div>
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
											<input type="text" name="pack_size" id="pack_size" class="form-control input-sm" placeholder="Pack Size">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
											<input type="text" name="product_id_view" id="product_id_view" class="form-control input-sm" placeholder="Product Id">
										</div>
									</div>
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
											<input type="text" name="products_company_view" id="products_company_view" class="form-control input-sm" placeholder="Products Company">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
											<input type="text" name="unit_price_view" id="unit_price_view" class="form-control input-sm" placeholder="Purchase Unit Price" required>
										</div>
									</div>
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
											<input type="number" name="tax_percent_view" id="tax_percent_view" class="form-control input-sm" placeholder="Tax Percent">
										</div>
									</div>
								</div>
								<div class="row">
									
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
											<input type="text" name="sell_price_view" id="sell_price_view" class="form-control input-sm" placeholder="Unit Sell Price">
										</div>
									</div>
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
										
											<input type="number" name="warranty_guarantee_days_view" id="warranty_guarantee_days_view" class="form-control input-sm" placeholder="Service days">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
											<select style="height:24px;" name="warranty_guarantee_type_view" id="warranty_guarantee_type_view" class="form-control input-sm" >
												<option id="warranty_guarantee_type_one" value="None">None</option>
												<option id="warranty_guarantee_type_two" value="Warranty">Warranty</option>
												<option id="warranty_guarantee_type_three" value="Guarantee">Guarantee</option>
											</select>
										</div>
									</div>
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
											<input type="number" name="serial_key_length_view" id="serial_key_length_view" class="form-control input-sm" placeholder="Serial Key Length">
										</div>
									</div>
								</div>
								<div class="row">
									
									<div class="col-xs-12 col-sm-12 col-md-12">
										<div class="form-group">
											<input type="text" name="remarks_p_view" id="remarks_p_view" class="form-control input-sm" placeholder="Remarks">
										</div>
									</div>
								<button type="button"  class="btn btn-info btn-block new_product_Add">Add</button>
							
							<!--</form>-->
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	</div>
	<div class="container-fluid">
		<div class="modal fade" id="myModalFreeProducts" role="dialog">
			<div class="modal-dialog">
					<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h6 class="modal-title">Free Products Information</h6>
					</div>
					<div class="modal-body">
			 			<div class="panel-body">
							<!--<form action="software_free_product_add_list.php" role="form" method="POST">-->
								<div class="row">
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
											<input type="hidden" name="super_user" id="" class="form-control input-sm super_user" value ="<?php echo $super_email;?>">
											<input type="hidden" name="company_use" id="" class="form-control input-sm company_use" value ="<?php echo $company_now;?>">
											<input type="hidden" name="operator" id="" class="form-control input-sm operator" value ="<?php echo $user_now;?>">
											P Id : <select id="product_id_now" name="product_id_now"  class="" >
											<?php
											if($stmt_sql = $mysqli->prepare("SELECT product_id FROM products_details_onserial WHERE company_username=? ORDER BY sn DESC")){
												
												$stmt_sql->bind_param("s",$company_now);
												$stmt_sql->execute();
												$stmt_sql->store_result();
												$num_of_rows = $stmt_sql->num_rows;
												$stmt_sql->bind_result($product_id_now);
												if($num_of_rows > 0){
													while($stmt_sql->fetch()){
														echo "<option value=\"$product_id_now\">$product_id_now</option>";
														}
												}
												}
												?>
											</select>
										</div>
									</div>
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
											<input type="text" name="product_quantity_now" id="product_quantity_now" class="form-control input-sm" placeholder="Product Quantity">
										</div>
									</div>
									
									
								</div>
								<div class="row">
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
											<input type="text" name="free_product_id_now" id="free_product_id_now" class="form-control input-sm" placeholder="Free Product Id">
										</div>
									</div>
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
											<input type="text" name="free_product_quantity_now" id="free_product_quantity_now" class="form-control input-sm" placeholder="Free Product Quantity">
										</div>
									</div>
								<button type="button" class="btn btn-info btn-block free_new_product_Add">Save</button>
							
							<!--</form>-->
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	</div>
	<script>
	$(document).ready(function() {
		var company_find="<?php echo $company_now;?>";
		$(".remove_product").click(function(e) {
			 e.preventDefault();
			var sn_del=$(this).html();
			var data_del_product='sn_del='+ sn_del+'&company_find='+ company_find;
				
			$.ajax({
				type: "POST",
				url: "remove/delete_product.php",
				data: data_del_product,
				success: function(html){
					alert(html);
					}		
			});	
		 })
		 
		 $(".remove_now").click(function(e) {
			 e.preventDefault();
			var sn_del=$(this).html();
			var data_del='sn_del='+ sn_del+'&company_find='+ company_find;
				
			$.ajax({
				type: "POST",
				url: "remove/delete_free_product.php",
				data: data_del,
				success: function(html){
					alert(html);
					}		
			});	
		 })
	})
	</script>
  </body>
</html>
<?php
}else{
echo "You have not permit to access this page";
}
}else{
    echo "Something wrong.Please <a href=\"index.php\">login</a>";
}
?>