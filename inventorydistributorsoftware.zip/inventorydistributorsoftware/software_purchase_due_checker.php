<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include_once('db.php');
session_start();
session_regenerate_id(TRUE);
if(isset($_SESSION['user_session']) and isset($_SESSION['company_username_session']) and isset($_SESSION['sub_user_session'])){
	$user_type_now=$_SESSION['user_session'];
	$company_now=$_SESSION['company_username_session'];
	$user_now=$_SESSION['sub_user_session'];
	$status=1;
	$query = "SELECT email,company_name,company_timezone,vendor_primary_key FROM companies_onserial WHERE company_username=? and status=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param("si",$company_now,$status);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($email,$company_name,$company_timezone,$vendor_primary_key);
	$stmt->fetch();
	$super_email=$email;
	$company=$company_name;
	$company_timezone=$company_timezone;
	$vendor_primary_key=$vendor_primary_key;
	}
	if($user_type_now=='Super'){
	$user_now=$super_email;
	}
	
 date_default_timezone_set($company_timezone);//problem
 $var_date= date('y/m/d') ;
if($user_type_now=="Super" or $user_type_now=="Master" or $user_type_now=="Purchase_Master" or $user_type_now=="Only_Purchase"){

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title><?php echo $company;?></title>
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<script src="auto/jquery-ui.min.js"></script>
	<link href="auto/jquery-ui.min.css" rel="stylesheet">
	<script>
	$(document).ready(function() {
		$(".search_invoice").click(function(e){
		e.preventDefault();
			var invoice_no=$(".invoice_no").val();
			
			var company="<?php echo $company_now;?>";
			var data_key='invoice_no='+ invoice_no+'&company='+ company;
			
			$.ajax({
				type: "POST",
				url: "fill/search_purchase_invoice_now.php",
				data: data_key,
				success: function(html){
					$(".search_purchase_invoice_now").html(html);
					
					}		
				});
		});
		$( function() {
		$( "#datepicker" ).datepicker({ dateFormat: 'yy-mm-dd' });
		$( "#datepickerto" ).datepicker({ dateFormat: 'yy-mm-dd' });
	  } );
		
	})
	</script>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="design.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="../inventory-software.png">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	
  </head>
  <body>
  <?php
	$query = "SELECT pakage,year,date FROM login_onserial WHERE email=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$super_email);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($pakage,$year,$date);
	$stmt->fetch();
	$softpakage=$pakage;
	$year=$year;
	$date=$date;
	$yearto=substr($date,0,4);
	$monthto=substr($date,5,2);
	$dateto=substr($date,8,2);
	$year_num=(int)$yearto;
	$year_up=$year_num+$year;
	if($monthto==2 and $dateto==29){
		$monthto=03;
		$dateto=01;
	}
	$up_date="$year_up"."/"."$monthto"."/"."$dateto";
	$up_to_time=strtotime($up_date);
	$expired_date=date('Y-m-d',$up_to_time);
	$today=date("Y-m-d");
	
	$today_strtotime=strtotime($today);
	$expired_strtotime=strtotime($expired_date);
	if($softpakage=='Free'){
		$warehouse=1;
		$users=1;
	}else if($softpakage=='Standard'){
		$warehouse=1;
		$users=1;
	}else if($softpakage=='Extend'){
		$warehouse=10;
		$users=20;
	}else if($softpakage=='Expand'){
		$warehouse=50;
		$users=100;
	}
	$stmt->free_result();
		$stmt->close();
	}
	$query = "SELECT vendor_primary_key FROM companies_onserial WHERE company_username=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$company_now);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($vendor_primary_key);
	$stmt->fetch();
	if($vendor_primary_key=='Email'){
		$vendor_primary_key='markenter_email';
	}else if($vendor_primary_key=='Mobile'){
		$vendor_primary_key='vendor_mobile_no';
	}else if($vendor_primary_key=='Telephone'){
		$vendor_primary_key='vendor_telephone_no';
	}
	$stmt->free_result();
		$stmt->close();
	}
	
	if(!empty($_POST['company'])){
	$company_filter=$_POST['company'];
	}else{
		$company_filter="empty";
	}
	if(!empty($_POST['datefrom'])and !empty($_POST['dateto'])){
	$datefrom=$_POST['datefrom'];
	$dateto=$_POST['dateto'];
	$datebetween="(due_payment_date BETWEEN '".$datefrom."'"." AND '". $dateto."') and";
	}else{
		$datefrom="";
		$dateto="";
		$datebetween="";
	}
	
	if(!empty($_POST['user'])){
		$user=$_POST['user'];
		if($user=='All Users'){
			$user_filter="";
		}else{
			$user_filter="and sub_user='".$user."'";
		}
	}else{
		$user="";
		$user_filter="";
		
	}
	if(!empty($_POST['vendor_select'])){
		$vendor_select=$_POST['vendor_select'];
		if($vendor_select=='All Vendors'){
			$vendor_filter=" ";
		}else{
			$query_vendor = "SELECT sn FROM company_markenter_onserial WHERE company_username=? and $vendor_primary_key=? and type='vendor'"; 
			if($stmt_vendor = $mysqli->prepare($query_vendor)){
				if($vendor_primary_key=='markenter_email'){
					$stmt_vendor->bind_param('ss',$company_now,$vendor_select);
				}else{
					$stmt_vendor->bind_param('si',$company_now,$vendor_select);
				}
			$stmt_vendor->execute();
			$stmt_vendor->store_result();
			$num_of_rows = $stmt_vendor->num_rows;
			$stmt_vendor->bind_result($vendor_serial);
			$stmt_vendor->fetch();
			$vendor_filter="and  vendor_serial=$vendor_serial";
			}
		}
	}else{
		$vendor_select="";
		$vendor_filter="";
		
	}
	?>
	
	<?php include_once('software_menu.php');?>
	<?php include_once('software_header.php');?>
	<div class="container-fluid border_bottom color z_index">
		<!--<h2>Vendor Management</h2>-->	
	</div>
	
	<div class="container-fluid">
		<div class="row">
		<div class="col-md-12 col-sm-12">
			<div class="webdesigntuts-workshop">
						<form>		    
							<input type="number" class="invoice_no" placeholder="Search Invoice?">		    	
							<button class="search_invoice">Search</button>
						</form>
						
					</div>
		</div>
		<div class="col-md-12 col-sm-12">
			<form action="software_purchase_due_checker.php" method="POST">
			<input type="hidden" name="company" value="<?php echo $company_now;?>">
			<div class="col-md-2">
				<input type="text" id="datepicker" name="datefrom" class="form-control purchase_filter_style" placeholder="Date from" value="<?php echo $datefrom;?>">
			</div>
			<div class="col-md-2">
				<input type="text"  id="datepickerto" name="dateto" class="form-control purchase_filter_style"  placeholder="Date to"  value="<?php echo $dateto;?>">
			</div>
			<select id="secuence" name="user"  class="purchase_filter_style" >
			<?php if(strlen($user)>0){
					echo "<option value=\"$user\">$user</option>";
			}?>
			<?php 
			if($user_type_now=="Super" or $user_type_now=="Master" or $user_type_now=="Purchase_Master" ){
				?>
				<option value="All Users">All Users</option>
				<?php 
				if($stmt_sql = $mysqli->prepare("SELECT sub_username FROM company_users_onserial WHERE company_username=? ORDER BY sn DESC")){
					
					$stmt_sql->bind_param("s",$company_now);
					$stmt_sql->execute();
					$stmt_sql->store_result();
					$num_of_rows = $stmt_sql->num_rows;
					$stmt_sql->bind_result($sub_username);
					if($num_of_rows > 0){
						while($stmt_sql->fetch()){
							echo "<option value=\"$sub_username\">$sub_username</option>";
							}
					}
					}
					?>
				<option value="Super Admin">Super Admin</option>
				<?php
			}else{
				echo "<option value=\"$user_now\">$user_now</option>";
			}
			?>
				
				
			</select>
			<select id="vendor_select" name="vendor_select"  class="purchase_filter_style" >
				<?php if(strlen($vendor_select)>0){
					echo "<option value=\"$vendor_select\">$vendor_select</option>";
				}?>
				<option value="All Vendors">All Vendors</option>
				<?php
				if($stmt_sql = $mysqli->prepare("SELECT $vendor_primary_key FROM company_markenter_onserial WHERE company_username=? and type='vendor' ORDER BY sn DESC")){
					
					$stmt_sql->bind_param("s",$company_now);
					$stmt_sql->execute();
					$stmt_sql->store_result();
					$num_of_rows = $stmt_sql->num_rows;
					$stmt_sql->bind_result($vendor_find);
					if($num_of_rows > 0){
						while($stmt_sql->fetch()){
							echo "<option value=\"$vendor_find\">$vendor_find</option>";
							}
					}
					}
					?>
				</select>
			<input type="submit" class="purchase_filter_style" value="Filter">
			</form>
		</div>
			<div class="col-md-12">
				<div class="search_purchase_invoice_now"></div>
				  <div class="wrapper">
					  <div class="table">
						
					<?php 
		$invoice_type_filter="(invoice_type='purchase_payment')";
	if($stmt_sql_all = $mysqli->prepare("SELECT invoice_type,total,payment,due,net FROM invoice_summary_onserial WHERE  company_username=? and status=1 and $invoice_type_filter $vendor_filter $user_filter ORDER BY sn ASC")){
	
	$stmt_sql_all->bind_param("s",$company_now);
	$stmt_sql_all->execute();
	$stmt_sql_all->store_result();
	$num_of_rows_all = $stmt_sql_all->num_rows;
					
	$stmt_sql_all->bind_result($invoice_type,$total,$payment,$due,$net);
	if($num_of_rows_all > 0){
	$grand_total_now_only_payments=0;
		while($stmt_sql_all->fetch()){
			$grand_total_now_only_payments+=$payment;
			
			
		}
	}else{
		$grand_total_all=0;
		$grand_payment_all=0;
		$grand_due_all=0;
		$grand_net_all=0;
		$grand_total_now_only_payments=0;
	}
	}
	$invoice_type_filter="(invoice_type='purchase_invoice' or invoice_type='purchase_payment' or invoice_type='purchase_return_invoice' or invoice_type='purchase_service')";
	if($stmt_sql_all_continue = $mysqli->prepare("SELECT invoice_no,invoice_type,total,payment,due,due_payment_date,net,date FROM invoice_summary_onserial WHERE company_username=? and status=1 and $invoice_type_filter $vendor_filter $user_filter and due>0 ORDER BY sn ASC")){
						
	$stmt_sql_all_continue->bind_param("s",$company_now);
	$stmt_sql_all_continue->execute();
	$stmt_sql_all_continue->store_result();
	$num_of_rows_continue = $stmt_sql_all_continue->num_rows;
					
	$stmt_sql_all_continue->bind_result($invoice_no_now,$invoice_type_now,$total_now,$payment_now,$due_now,$due_payment_date_all,$net_now,$entry_date);
	if($num_of_rows_continue > 0){
		?>
					<div class="tb_header">
						  <div class="cell">
							Sn
						  </div>
						  <div class="cell">
							Invoice No
						  </div>
						  <div class="cell">
							Type
						  </div>
						  <div class="cell">
							Total
						  </div>
						  <div class="cell">
							Payment
						  </div>
						  <div class="cell">
							Due
						  </div>
						  <div class="cell">
							Due Date
						  </div>
						  <div class="cell">
							Net
						  </div>
						  <div class="cell">
							Date
						  </div>
						</div>
					<?php
			$grand_due_now=0;
			$sn=1;
		while($stmt_sql_all_continue->fetch()){
			$grand_due_now+=$due_now;
					if($grand_due_now>$grand_total_now_only_payments){
						echo "<div class=\"tb_row\">";
						echo "<div class=\"cell\">".$sn."</div>";
						echo "<div class=\"cell\">".$invoice_no_now."</div>";
						echo "<div class=\"cell\">".$invoice_type_now."</div>";
						echo "<div class=\"cell\">".$total_now."</div>";
						echo "<div class=\"cell\">".$payment_now."</div>";
						echo "<div class=\"cell\">".$due_now."</div>";
						echo "<div class=\"cell\">".$due_payment_date_all."</div>";
						echo "<div class=\"cell\">".$net_now."</div>";
						echo "<div class=\"cell\">".$entry_date."</div>";
								
						echo "</div>";
						$sn++;
					}else{
						
					}
		}
	}else{
		echo "<div class=\"tb_row\">";
			echo "Have No Due";
		echo "</div>";
	}
	}
	?>
					  
					</div>
				  
				</div>
			</div>
		</div>
	</div>
	<div class="container">
		<div class="row ">
			<div class="col-md-12">
			<?php 
			if($num_of_rows_continue > 0){
				$total_due=$grand_due_now-$grand_total_now_only_payments;
				if($total_due>0){
					$due_adjusments=$grand_due_now-$total_due;
					echo "<h5 class=\"purchase_brief\">"."Due Adjusments: -".$due_adjusments."</h5>";
					echo "<h5 class=\"purchase_brief\">"."Total Due : ".$total_due."</h5>";
				}
				
			}else{
				echo "<h5 class=\"purchase_brief\">"."Have no Report"."</h5>";
			}
			?>
			</div>
		</div>
	</div>
  </body>
</html>
<?php
}else{
echo "You have not permit to access this page";
}
}else{
    echo "Something wrong.Please <a href=\"index.php\">login</a>";
}
?>