<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include_once('db.php');
session_start();
session_regenerate_id(TRUE);
if(isset($_SESSION['user_session']) and isset($_SESSION['company_username_session']) and isset($_SESSION['sub_user_session'])){
	$user_type_now=$_SESSION['user_session'];
	$company_now=$_SESSION['company_username_session'];
	$user_now=$_SESSION['sub_user_session'];
	$status=1;
	$query = "SELECT email,company_name,company_timezone,vendor_primary_key FROM companies_onserial WHERE company_username=? and status=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param("si",$company_now,$status);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($email,$company_name,$company_timezone,$vendor_primary_key);
	$stmt->fetch();
	$super_email=$email;
	$company=$company_name;
	$company_timezone=$company_timezone;
	$vendor_primary_key=$vendor_primary_key;
	}
	if($user_type_now=='Super'){
	$user_now=$super_email;
	}
	
 date_default_timezone_set($company_timezone);//problem
 $var_date= date('y/m/d') ;
if($user_type_now=="Super" or $user_type_now=="Master" or $user_type_now=="Purchase_Master" or $user_type_now=="Only_Purchase"){
if(isset($_GET["invoice"])){
	$invoice = intval($_GET["invoice"]);
	}
$invoice_type_filter="(invoice_type='purchase_invoice' or invoice_type='purchase_payment' or invoice_type='purchase_return_invoice' or invoice_type='purchase_service')";
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title><?php echo $company;?></title>
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<script src="auto/jquery-ui.min.js"></script>
	<link href="auto/jquery-ui.min.css" rel="stylesheet">
	<script>
	$(document).ready(function() {
		$(".search_invoice").click(function(e){
		e.preventDefault();
			var invoice_no=$(".invoice_no").val();
			
			var company="<?php echo $company_now;?>";
			var data_key='invoice_no='+ invoice_no+'&company='+ company;
			
			$.ajax({
				type: "POST",
				url: "fill/search_purchase_invoice_now.php",
				data: data_key,
				success: function(html){
					$(".search_purchase_invoice_now").html(html);
					
					}		
				});
		});
		$( function() {
		$( "#datepicker" ).datepicker({ dateFormat: 'yy-mm-dd' });
		$( "#datepickerto" ).datepicker({ dateFormat: 'yy-mm-dd' });
	  } );
		
	})
	</script>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="design.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="../inventory-software.png">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	
  </head>
  <body>
	<?php include_once('software_menu.php');?>
	<?php include_once('software_header.php');?>
	<div class="container-fluid border_bottom color z_index">
		<!--<h2>Vendor Management</h2>-->	
	</div>
	<div class="container">
		<div class="row">
		<?php 
		if($stmt_sql = $mysqli->prepare("SELECT invoice_no,invoice_type,bill,discount,total,payment,date,due,due_payment_date,net,vendor_serial,sub_user,payment_method,bank_name,account_no,tax,carring_cost,others_cost,intensive,remarks FROM invoice_summary_onserial WHERE company_username=? and invoice_no=? and $invoice_type_filter")){
			$stmt_sql->bind_param("si",$company_now,$invoice);
			$stmt_sql->execute();
			$stmt_sql->store_result();
			$num_of_rows_now = $stmt_sql->num_rows;
			$stmt_sql->bind_result($invoice_no,$invoice_type,$bill,$discount,$total,$payment,$date,$due,$due_payment_date,$net,$vendor_serial,$sub_user,$payment_method,$bank_name,$account_no,$tax,$carring_cost,$others_cost,$intensive,$remarks);
			$stmt_sql->fetch();
			if($num_of_rows_now > 0){
				if ($stmt = $mysqli->prepare("SELECT full_name,vendor_address,vendor_company_name,markenter_email,vendor_mobile_no,vendor_telephone_no FROM company_markenter_onserial WHERE company_username=? and sn=? and type='vendor'")) {
				$stmt->bind_param("si",$company_now,$vendor_serial);
				$stmt->execute();
				$stmt->store_result();
				$num_of_rows = $stmt->num_rows;
				$stmt->bind_result($full_name,$vendor_address,$vendor_company_name,$markenter_email,$vendor_mobile_no,$vendor_telephone_no);
				$stmt->fetch();
				$name=$full_name;
				}
			}
			if($invoice_type=='purchase_invoice'){
				$type="Purchase";
			}else if($invoice_type=='purchase_payment'){
				$type="Payment";
			}else if($invoice_type=='purchase_return_invoice'){
				$type="Return";
			}else if($invoice_type=='purchase_service'){
				$type="Service";
			}
		}
		?>
		<div class="col-md-9">
		<div style="margin-top:30px;max-width:700px;overflow-x: scroll;" class="">
		<div class="table">
			<div class="tb_row">
				<div class="cell tb_header">Invoice No : <?php echo $invoice_no;?></div><div class="cell tb_header">Invoice Type : <?php echo $type;?></div>
			</div>
			<div class="tb_row">
				<div class="cell">Vendor Name : <?php echo $name;?></div><div class="cell">Vendor Address : <?php echo $vendor_address;?></div>
			</div>
			<div class="tb_row">
				<div class="cell tb_header">Email : <?php echo $markenter_email;?></div><div class="cell tb_header">Mobile : <?php echo $vendor_mobile_no;?></div>
			</div>
			<div class="tb_row">
				<div class="cell">Telephone : <?php echo $vendor_telephone_no;?></div><div class="cell">Company : <?php echo $vendor_company_name;?></div>
			</div>
			<div class="tb_row">
				<div class="cell tb_header">Date : <?php echo $date;?></div><div class="cell tb_header">Operator : <?php echo $sub_user;?></div>
			</div>
		</div>
		</div>
		<div style="max-width:700px;overflow-x: scroll;" class="">
		<div  style="" class="table">
			<div class="tb_header">
				<div class="cell">Serial</div>
				<div class="cell">Invoice No</div>
				<div class="cell">Product Name</div>
				<div class="cell">Size</div>
				<div class="cell">Quantity</div>
				<div class="cell">Serial Keys</div>
				<div class="cell">Unit Price</div>
				<div class="cell">Total</div>
				<div class="cell">Discount</div>
				<div class="cell">Net</div>
			</div>
	
	<?php 
		if($num_of_rows_now > 0){
			
			if($stmt = $mysqli->prepare("SELECT product_name,quantity,size,unit_price,sub_total,discount,net FROM invoice_products_details_onserial WHERE company_username=? and  invoice_no=?  and $invoice_type_filter ORDER BY sn DESC")) {
			$stmt->bind_param("si",$company_now,$invoice);
			$stmt->execute();
			$stmt->store_result();
			$num_of_product_rows = $stmt->num_rows;
			$stmt->bind_result($product_name,$quantity,$size,$unit_price,$sub_total,$discount,$sub_net);
				if($num_of_product_rows>0){
					$sn=1;
					while($stmt->fetch()){
					echo "<div class=\"tb_row\">";
					echo "<div class=\"cell\">".$sn."</div>";
					echo "<div class=\"cell\">".$invoice."</div>";
					echo "<div class=\"cell\">".$product_name."</div>";
					echo "<div class=\"cell\">".$size."</div>";
					echo "<div class=\"cell\">".$quantity."</div>";
					if($stmt_name = $mysqli->prepare("SELECT serial_key FROM invoice_products_serial_details_onserial WHERE company_username=? and invoice_no=? and $invoice_type_filter ORDER BY sn DESC")) {
							$stmt_name->bind_param("si",$company_now,$invoice);
							$stmt_name->execute();
							$stmt_name->store_result();
							$num_of_serial_key_rows = $stmt_name->num_rows;
							$stmt_name->bind_result($serial_key);
							echo "<div class=\"cell\">";
							if($num_of_serial_key_rows>0){
								while($stmt_name->fetch()){
								echo $serial_key.","."<br/>";
							}
							}else{
								
							}
							echo "</div>";
							}
					echo "<div class=\"cell\">".$unit_price."</div>";
					echo "<div class=\"cell\">".$sub_total."</div>";
					echo "<div class=\"cell\">".$discount."</div>";
					echo "<div class=\"cell\">".$sub_net."</div>";
					echo "</div>";
					$sn++;
					}
					
				}
			}
		}else{
			echo "<div class=\"tb_row\">";
				echo "Yet products in stock";
			echo "</div>";
		}
	?>
	</div>
	</div>
		</div>
		<div class="col-md-3">
		<div style="margin-top:30px;max-width:400px;overflow-x: scroll;" class="">
			<div class="table">
				<div class="tb_row">
					<div class="cell tb_header">
						Bill
					</div>
					<div class="cell">
						<?php echo $bill;?>
					</div>
				</div>
				<div class="tb_row">
					<div class="cell tb_header">
						Discount
					</div>
					<div class="cell">
						<?php echo $discount;?>
					</div>
				</div>
				<div class="tb_row">
					<div class="cell tb_header">
						Total
					</div>
					<div class="cell">
						<?php echo $total;?>
					</div>
				</div>
				<div class="tb_row">
					<div class="cell tb_header">
						Payment
					</div>
					<div class="cell">
						<?php echo $payment;?>
					</div>
				</div>
				<div class="tb_row">
					<div class="cell tb_header">
						Due
					</div>
					<div class="cell">
						<?php echo $due;?>
					</div>
				</div>
				<div class="tb_row">
					<div class="cell tb_header">
						Payment date
					</div>
					<div class="cell">
						<?php echo $due_payment_date;?>
					</div>
				</div>
				<div class="tb_row">
					<div class="cell tb_header">
						Payment method
					</div>
					<div class="cell">
						<?php echo $payment_method;?>
					</div>
				</div>
				<div class="tb_row">
					<div class="cell tb_header">
						Bank name
					</div>
					<div class="cell">
						<?php echo $bank_name;?>
					</div>
				</div>
				<div class="tb_row">
					<div class="cell tb_header">
						Account no
					</div>
					<div class="cell">
						<?php echo $account_no;?>
					</div>
				</div>
				<div class="tb_row">
					<div class="cell tb_header">
						Tax
					</div>
					<div class="cell">
						<?php echo $tax;?>
					</div>
				</div>
				<div class="tb_row">
					<div class="cell tb_header">
						Carring cost
					</div>
					<div class="cell">
						<?php echo $carring_cost;?>
					</div>
				</div>
				<div class="tb_row">
					<div class="cell tb_header">
						Others cost
					</div>
					<div class="cell">
						<?php echo $others_cost;?>
					</div>
				</div>
				<div class="tb_row">
					<div class="cell tb_header">
						Intensive
					</div>
					<div class="cell">
						<?php echo $intensive;?>
					</div>
				</div>
				<div class="tb_row">
					<div class="cell tb_header">
						Net
					</div>
					<div class="cell">
						<?php echo $net;?>
					</div>
				</div>
				<div class="tb_row">
					<div class="cell tb_header">
						Remarks
					</div>
					<div class="cell">
						<?php echo $remarks;?>
					</div>
				</div>
			</div>
			</div>
			</div>
		</div>
	</div>
</body>
</html>
<?php
}else{
echo "You have not permit to access this page";
}
}else{
    echo "Something wrong.Please <a href=\"index.php\">login</a>";
}
?>
