<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include_once('db.php');
session_start();
session_regenerate_id(TRUE);
if(isset($_SESSION['user_session']) and isset($_SESSION['company_username_session']) and isset($_SESSION['sub_user_session'])){
	$user_type_now=$_SESSION['user_session'];
	$company_now=$_SESSION['company_username_session'];
	$user_now=$_SESSION['sub_user_session'];
	$status=1;
	$query = "SELECT email,company_name,company_timezone,vendor_primary_key FROM companies_onserial WHERE company_username=? and status=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param("si",$company_now,$status);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($email,$company_name,$company_timezone,$vendor_primary_key);
	$stmt->fetch();
	$super_email=$email;
	$company=$company_name;
	$company_timezone=$company_timezone;
	$vendor_primary_key=$vendor_primary_key;
	}
	if($user_type_now=='Super'){
	$user_now=$super_email;
	}
	
 date_default_timezone_set('Asia/Dhaka');//problem
 $var_date= date('y/m/d') ;
if($user_type_now=="Super" or $user_type_now=="Master" or $user_type_now=="Sell_Master" or $user_type_now=="Only_Sell"){

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title><?php echo $company;?></title>
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<script src="auto/jquery-ui.min.js"></script>
	<link href="auto/jquery-ui.min.css" rel="stylesheet">
	<style>
	table, th, td {
		border: 1px solid black;
		padding:5px;
		text-align:center;
	}
	</style>
	<script>
	$(document).ready(function() {
		$(".search_invoice").click(function(e){
		e.preventDefault();
			var invoice_no=$(".invoice_no").val();
			
			var company="<?php echo $company_now;?>";
			var data_key='invoice_no='+ invoice_no+'&company='+ company;
			
			$.ajax({
				type: "POST",
				url: "fill/search_sell_invoice_now.php",
				data: data_key,
				success: function(html){
					$(".search_purchase_invoice_now").html(html);
					
					}		
				});
		});
		$( function() {
		$( "#datepicker" ).datepicker({ dateFormat: 'yy-mm-dd' });
		$( "#datepickerto" ).datepicker({ dateFormat: 'yy-mm-dd' });
	  } );
		
	})
	</script>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="design.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="../inventory-software.png">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	
  </head>
  <body>
   <?php
	$query = "SELECT pakage,year,date FROM login_onserial WHERE email=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$super_email);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($pakage,$year,$date);
	$stmt->fetch();
	$softpakage=$pakage;
	$year=$year;
	$date=$date;
	$yearto=substr($date,0,4);
	$monthto=substr($date,5,2);
	$dateto=substr($date,8,2);
	$year_num=(int)$yearto;
	$year_up=$year_num+$year;
	if($monthto==2 and $dateto==29){
		$monthto=03;
		$dateto=01;
	}
	$up_date="$year_up"."/"."$monthto"."/"."$dateto";
	$up_to_time=strtotime($up_date);
	$expired_date=date('Y-m-d',$up_to_time);
	$today=date("Y-m-d");
	
	$today_strtotime=strtotime($today);
	$expired_strtotime=strtotime($expired_date);
	if($softpakage=='Free'){
		$warehouse=1;
		$users=1;
	}else if($softpakage=='Standard'){
		$warehouse=1;
		$users=1;
	}else if($softpakage=='Extend'){
		$warehouse=10;
		$users=20;
	}else if($softpakage=='Expand'){
		$warehouse=50;
		$users=100;
	}
	$stmt->free_result();
		$stmt->close();
	}
	$query = "SELECT customer_primary_key FROM companies_onserial WHERE company_username=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$company_now);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($customer_primary_key);
	$stmt->fetch();
	if($customer_primary_key=='Email'){
		$vendor_primary_key='markenter_email';
	}else if($customer_primary_key=='Mobile'){
		$vendor_primary_key='vendor_mobile_no';
	}else if($customer_primary_key=='Telephone'){
		$vendor_primary_key='vendor_telephone_no';
	}
	$stmt->free_result();
		$stmt->close();
	}
	if(!empty($_POST['company'])){
	$company_filter=$_POST['company'];
	}else{
		$company_filter="empty";
	}
	if(!empty($_POST['datefrom'])and !empty($_POST['dateto'])){
	$datefrom=$_POST['datefrom'];
	$dateto=$_POST['dateto'];
	$datebetween="(date BETWEEN '".$datefrom."'"." AND '". $dateto."') and";
	}else{
		$datefrom="";
		$dateto="";
		$datebetween="";
	}
	//echo $datebetween;
	$invoice_type_filter="(invoice_type='sell_invoice')";
	
	if(!empty($_POST['vendor_select'])){
		$vendor_select=$_POST['vendor_select'];
		if($vendor_select=='All SR'){
			$vendor_filter=" ";
		}else{
			$query_vendor = "SELECT sn FROM company_markenter_onserial WHERE company_username=? and $vendor_primary_key=? and type='customer'"; 
			if($stmt_vendor = $mysqli->prepare($query_vendor)){
				if($vendor_primary_key=='markenter_email'){
					$stmt_vendor->bind_param('ss',$company_now,$vendor_select);
				}else{
					$stmt_vendor->bind_param('si',$company_now,$vendor_select);
				}
			$stmt_vendor->execute();
			$stmt_vendor->store_result();
			$num_of_rows = $stmt_vendor->num_rows;
			$stmt_vendor->bind_result($vendor_serial);
			$stmt_vendor->fetch();
			$vendor_filter="and  customer_serial=$vendor_serial";
			}
		}
	}else{
		$vendor_select="";
		$vendor_filter="";
		
	}
	//echo $vendor_filter;

	$num_of_rows_now=0;
	?>
	
	<div class="container-fluid border_bottom color z_index">
		<!--<h2>Vendor Management</h2>-->	
	</div>
	
	<div class="container-fluid print_class_hide">
		<div class="row">
		<?php include_once('software_menu.php');?>
	<?php include_once('software_header.php');?>
			<div style="height:35px;"></div>
			<div style="display:none;"  class="div_padding">
			<div class="col-md-12 col-sm-12">
				<div class="webdesigntuts-workshop">
							<form>		    
								<input type="number" class="invoice_no" placeholder="Search Invoice?">		    	
								<button class="search_invoice">Search</button>
							</form>
							
						</div>
			</div>
			</div>
			<div class="col-md-12 col-sm-12">
				<form action="software_sellsman_report.php" method="POST">
				<input type="hidden" name="company" value="<?php echo $company_now;?>">
				<div class="col-md-2">
					<input type="text" id="datepicker" name="datefrom" class="form-control purchase_filter_style" placeholder="Date from" value="<?php echo $datefrom;?>">
				</div>
				<div class="col-md-2">
					<input type="text"  id="datepickerto" name="dateto" class="form-control purchase_filter_style"  placeholder="Date to"  value="<?php echo $dateto;?>">
				</div>
				
				<select id="vendor_select" name="vendor_select"  class="purchase_filter_style" >
					<?php if(strlen($vendor_select)>0){
						echo "<option value=\"$vendor_select\">$vendor_select</option>";
					}?>
					<option value="All SR">All SR</option>
					<?php
					if($stmt_sql = $mysqli->prepare("SELECT $vendor_primary_key FROM company_markenter_onserial WHERE company_username=? and type='customer' ORDER BY sn DESC")){
						
						$stmt_sql->bind_param("s",$company_now);
						$stmt_sql->execute();
						$stmt_sql->store_result();
						$num_of_rows = $stmt_sql->num_rows;
						$stmt_sql->bind_result($vendor_find);
						if($num_of_rows > 0){
							while($stmt_sql->fetch()){
								echo "<option value=\"$vendor_find\">$vendor_find</option>";
								}
						}
						}
						?>
					</select>
					
					
				<input type="submit" class="purchase_filter_style" value="Filter">
				</form>
			</div>
		</div>
	</div>
	<?php 
					
		$sn=1;
		$total_thousand=0;
		$total_sellout=0;
		$total_carring_cost=0;
		$total_five_hundred=0;
		//$total_sell_amount=0;
		$total_lunch_cost=0;
		$total_one_hundred=0;
		$total_return=0;
		$total_toll=0;
		$total_fifty=0;
		$total_now=0;
		$total_intensive=0;
		$total_tweenty=0;
		//$total_carring_cost=0;
		$total_previous_balance=0;//
		$total_ten=0;
		$total_benefit=0;
		$total_extra_caring_cost=0;
		$total_five=0;
		$total_expense=0;
		$total_other_expense=0;
		$total_two=0;
		$total_due=0;
		$total_cash_short=0;
		$total_coin=0;
		$total_previous_payment=0;
		$total_cash=0;
		$total_free=0;
		$total_damage=0;
		if($stmt_sql = $mysqli->prepare("SELECT invoice_no,invoice_type,bill,discount,total,payment,date,due,due_payment_date,net,dsr_name,market,customer_serial,free_total,take_total,free_return_total,return_total,damage_total,cash_short,previous_payment,extra_caring_cost,toll,dsr_code,thousand,five_hundred,one_hundred,fifty,tweenty,ten,five,two,one,lunch_cost,carring_cost,others_cost,intensive,remarks FROM invoice_summary_onserial WHERE $datebetween company_username=? and status=1 and $invoice_type_filter $vendor_filter ORDER BY sn DESC")){
						
		$stmt_sql->bind_param("s",$company_now);
		$stmt_sql->execute();
		$stmt_sql->store_result();
		$num_of_rows_now = $stmt_sql->num_rows;
					
		$stmt_sql->bind_result($invoice_no,$invoice_type,$bill,$discount,$total,$payment,$date,$due,$due_payment_date,$net,$dsr_name,$market,$customer_serial,$free_total,$take_total,$free_return_total,$return_total,$damage_total,$cash_short,$previous_payment,$extra_caring_cost,$toll,$dsr_code,$thousand,$five_hundred,$one_hundred,$fifty,$tweenty,$ten,$five,$two,$one,$lunch_cost,$carring_cost,$others_cost,$intensive,$remarks);
		if($num_of_rows_now > 0){
			while($stmt_sql->fetch()){
				$total_thousand+=$thousand;	
				$total_sellout+=$take_total;
				$total_carring_cost+=$carring_cost;
				$total_five_hundred+=$five_hundred;
				$total_lunch_cost+=$lunch_cost;
				$total_one_hundred+=$one_hundred;
				$total_return+=$return_total;
				$total_toll+=$toll;
				$total_fifty+=$fifty;
				
				$total_intensive+=$intensive;
				$total_tweenty+=$tweenty;
				
				$total_ten+=$ten;
				
				$total_extra_caring_cost+=$extra_caring_cost;
				
				//$total_expense+=
				$total_other_expense+=$others_cost;
				
				$total_cash_short+=$cash_short;
				
				$total_previous_payment+=$previous_payment;
				
				$total_five+=$five;
				
				$total_two+=$two;
				
				$total_coin+=$one;
		
				$total_damage+=$damage_total;
				$total_now+=$total;
				$total_due+=$due;
				$total_free+=$free_total;
			}
		}
		}
	?>
	<div class="container-fluid">
		<div class="row">
		<div class="col-md-12 col-sm-12">
	<table style="width:96%;margin:0 auto;">
	<tr>
		<th rowspan="2">01</th>
		<th style="text-align:center;font-size:25px;" colspan="23"><?php echo $company;?></th>
	</tr>
	<tr>
		<td colspan="1">SR</td>
		<?php
		if($stmt_sql = $mysqli->prepare("SELECT full_name FROM company_markenter_onserial WHERE company_username=? and sn=?")){
		$stmt_sql->bind_param("si",$company_now,$customer_serial);
		$stmt_sql->execute();
		$stmt_sql->store_result();
		$num_of_rows_now = $stmt_sql->num_rows;
		$stmt_sql->bind_result($full_name);
			if($num_of_rows_now > 0){
				while($stmt_sql->fetch()){
					?>
					<td colspan="5"><?php echo $full_name;?></td>
					<?php
				}
			}
		}
		?>
		<td colspan="1">DSR</td>
		<td colspan="5"><?php echo $dsr_name;?></td>
		<td colspan="2">Market</td>
		<td colspan="4"><?php echo $market;?></td>
		<td colspan="1">Date</td>
		<td colspan="4"><?php echo $date;?></td>
	</tr>
	<tr>
		<th rowspan="2">Sn</th>
		<th rowspan="2">Product Title</th>
		<th colspan="3">Sell Out</th>
		<th colspan="3">Return</th>
		<th colspan="3">Damage</th>
		<th rowspan="2">Sell Quantiry</th>
		<th rowspan="2">Rate</th>
		<th rowspan="2">Sell Amount</th>
		<th rowspan="2">Damage Amount</th>
		<th rowspan="2">Free Product</th>
		<th colspan="3">Free</th>
		<th colspan="3">Free Return</th>
		<th rowspan="2">Free Rate</th>
		<th rowspan="2">Free Amount</th>
	</tr> 
	<tr>
		<th>Cartun</th>
		<th>Loose</th> 
		<th>Total</th>
		<th>Cartun</th>
		<th>Loose</th> 
		<th>Total</th>
		<th>Cartun</th>
		<th>Loose</th> 
		<th>Total</th>
		<th>Cartun</th>
		<th>Loose</th> 
		<th>Total</th>
		<th>Cartun</th>
		<th>Loose</th> 
		<th>Total</th>
	</tr>
	<?php
		//$psn=1;
		
		if($stmt_sql_new = $mysqli->prepare("SELECT DISTINCT product_id FROM invoice_products_details_onserial WHERE $datebetween company_username=? and invoice_type=? and payment_type='Sell Out' $vendor_filter")){
		
		$stmt_sql_new->bind_param("ss",$company_now,$invoice_type);
		$stmt_sql_new->execute();
		$stmt_sql_new->store_result();
		$num_of_rows_now_new = $stmt_sql->num_rows;
									
		$stmt_sql_new->bind_result($product_id);
		if($num_of_rows_now_new > 0){
			while($stmt_sql_new->fetch()){
					$psn=1;
					$sell_out_total_pack=0;
					$sell_out_pack_size=0;
					$sell_out_quantity=0;
					$sell_out_loose_quantity=0;
							
					$free_total_pack=0;
					$free_pack_size=0;
					$free_quantity=0;
					$free_loose_quantity=0;
							
					$return_total_pack=0;
					$return_pack_size=0;
					$return_quantity=0;
					$return_loose_quantity=0;
							
					$free_return_total_pack=0;
					$free_return_pack_size=0;
					$free_return_quantity=0;
					$free_return_loose_quantity=0;
							
					$damage_total_pack=0;
					$damage_pack_size=0;
					$damage_quantity=0;
					$damage_loose_quantity=0;
					$damage_amount=0;
					if($stmt_sql_next = $mysqli->prepare("SELECT product_name,size,total_pack,pack_size,quantity,payment_type,sell_price,free_product,free_with FROM invoice_products_details_onserial WHERE $datebetween company_username=? and invoice_type=? and product_id=? $vendor_filter")){
							
					$stmt_sql_next->bind_param("sss",$company_now,$invoice_type,$product_id);
					$stmt_sql_next->execute();
					$stmt_sql_next->store_result();
					$num_of_rows_now_next = $stmt_sql_next->num_rows;
												
					$stmt_sql_next->bind_result($product_name,$size,$total_pack,$pack_size,$quantity,$payment_type,$sell_price,$free_product,$free_with);
					if($num_of_rows_now_next > 0){
						while($stmt_sql_next->fetch()){
							$product_title=$product_name." ".$size;
							if($payment_type=='Sell Out'){
								$sell_out_total_pack+=$total_pack;
								$sell_out_pack_size=$pack_size;
								$sell_out_quantity+=$quantity;
								$sell_out_loose_quantity_now=$sell_out_quantity-($sell_out_total_pack*$sell_out_pack_size);
								$sell_out_loose_quantity+=$sell_out_loose_quantity_now;
							}else if($payment_type=='Return'){
								$return_total_pack+=$total_pack;
								$return_pack_size=$pack_size;
								$return_quantity+=$quantity;
								$return_loose_quantity_now=$return_quantity-($return_total_pack*$return_pack_size);
								$return_loose_quantity+=$return_loose_quantity_now;
							}else if($payment_type=='Damage'){
								$damage_total_pack+=$total_pack;
								$damage_pack_size=$pack_size;
								$damage_quantity+=$quantity;
								$damage_loose_quantity_now=$damage_quantity-($damage_total_pack*$damage_pack_size);
								$damage_loose_quantity+=$damage_loose_quantity_now;
								$damage_amount_now=$damage_quantity*$sell_price;
								$damage_amount+=$damage_amount_now;
							}
							
						}
						$sell_quantity=$sell_out_quantity-($return_quantity+$damage_quantity);
						$sell_amount=$sell_quantity*$sell_price;
						?>
				<tr> 
					<td>1</td>
					<td><?php echo $product_title;?></td>
					<td><?php echo $sell_out_total_pack;?></td> 
					<td><?php echo $sell_out_loose_quantity;?></td> 
					<td><?php echo $sell_out_quantity;?></td> 
					
					<td><?php echo $return_total_pack;?></td> 
					<td><?php echo $return_loose_quantity;?></td> 
					<td><?php echo $return_quantity;?></td> 
					
					<td><?php echo $damage_total_pack;?></td> 
					<td><?php echo $damage_loose_quantity;?></td> 
					<td><?php echo $damage_quantity;?></td> 
					
					<td><?php echo $sell_quantity;?></td>
					<td><?php echo $sell_price;?></td> 
					<td><?php echo $sell_amount;?></td>
					<td><?php echo $damage_amount;?></td> 
					<?php
					$free_sell_price=0;
					$net_free_amount=0;
					$free_product_title='';
					$free_product_exist=strlen($free_product);
					if($free_product_exist>1){
						//$invoice_type_free='Free';
						if($stmt_sql = $mysqli->prepare("SELECT product_name,size,total_pack,pack_size,quantity,payment_type,sell_price FROM invoice_products_details_onserial WHERE $datebetween company_username=? and free_with=? $vendor_filter")){
						$stmt_sql->bind_param("ss",$company_now,$product_title);
						$stmt_sql->execute();
						$stmt_sql->store_result();
						$num_of_rows_now = $stmt_sql->num_rows;
											
						$stmt_sql->bind_result($product_name,$size,$total_pack,$pack_size,$quantity,$payment_type,$free_sell_price);
						if($num_of_rows_now > 0){
						while($stmt_sql->fetch()){
							$free_product_title=$product_name." ".$size;
							if($payment_type=='Free'){
								$free_total_pack+=$total_pack;
								$free_pack_size=$pack_size;
								$free_quantity+=$quantity;
								$free_loose_quantity_now=$free_quantity-($free_total_pack*$free_pack_size);
								$free_loose_quantity+=$free_loose_quantity_now;
							}else if($payment_type=='Free Return'){
								$free_return_total_pack+=$total_pack;
								$free_return_pack_size=$pack_size;
								$free_return_quantity+=$quantity;
								$free_return_loose_quantity_now=$free_return_quantity-($free_return_total_pack*$free_return_pack_size);
								$free_return_loose_quantity+=$free_return_loose_quantity_now;
							}
						}
						$net_free_quantity=$free_quantity-$free_return_loose_quantity;
						$net_free_amount=$net_free_quantity*$free_sell_price;
						}
						}
					}
					
				?>
				<td><?php echo $free_product_title;?></td>
					
					<td><?php echo $free_total_pack;?></td> 
					<td><?php echo $free_loose_quantity;?></td> 
					<td><?php echo $free_loose_quantity;?></td> 
					
					<td><?php echo $free_return_total_pack;?></td> 
					<td><?php echo $free_return_loose_quantity;?></td> 
					<td><?php echo $free_return_quantity;?></td> 
					
					<td><?php echo $free_sell_price;?></td>
					<td><?php echo $net_free_amount;?></td>
				</tr>
				
				<?php
					}else{
						echo "Empty Products";
					}
					}
			}
		}else{
			echo "Empy row";
		}
		}
		?>
		<tr> 
					<td  colspan="6" rowspan="9"></td>
					<td  colspan="3">1000 Note</td>
					<td  colspan="3"><?php echo $total_thousand;?></td>
					<td  colspan="3">Sell Out</td>
					<td  colspan="3"><?php echo $total_sellout;?></td>
					<td  colspan="3">Expense</td>
					<?php $total_expense=$total_carring_cost+$total_lunch_cost+$total_toll+$total_extra_caring_cost;?>
					<td  colspan="3"><?php  echo $total_expense;?></td>
					
				</tr>
				<tr> 
					<td  colspan="3">500 Note</td>
					<td  colspan="3"><?php echo $total_five_hundred;?></td>
					<td  colspan="3">Sell</td>
					<?php $total_sell_amount=$total_sellout-($total_return+$total_damage);?>
					<td  colspan="3"><?php echo $total_sell_amount;?></td>
					<td  colspan="3">Others Expense</td>
					<td  colspan="3"><?php echo $total_other_expense;?></td>
					
				</tr>
				<tr> 
					<td  colspan="3">100 Note</td>
					<td  colspan="3"><?php echo $total_one_hundred;?></td>
					<td  colspan="3">Return</td>
					<td  colspan="3"><?php echo $total_return;?></td>
					<td  colspan="3">Carring Cost</td>
					<td  colspan="3"><?php echo $total_carring_cost;?></td>
					
				</tr>
				<tr> 
					<td  colspan="3">50 Note</td>
					<td  colspan="3"><?php echo $total_fifty;?></td>
					<td  colspan="3">Cash</td>
					<td  colspan="3"><?php echo $total_now;?></td>
					<td  colspan="3">Extra Carring Cost</td>
					<td  colspan="3"><?php echo $total_extra_caring_cost;?></td>
					
				</tr>
				<tr> 
					<td  colspan="3">20 Note</td>
					<td  colspan="3"><?php echo $total_tweenty;?></td>
					<td  colspan="3">Previus Payment</td>
					<td  colspan="3"><?php echo $total_previous_payment;?></td>
					<td  colspan="3">Lunch Cost</td>
					<td  colspan="3"><?php echo $total_lunch_cost;?></td>
					
				</tr>
				
				<tr> 
					<td  colspan="3">10 Note</td>
					<td  colspan="3"><?php echo $total_ten;?></td>
					<td  colspan="3">Total Damage</td>
					<td  colspan="3"><?php echo $total_damage;?></td>
					<td  colspan="3">Toll</td>
					<td  colspan="3"><?php echo $total_toll;?></td>
				</tr>
				<tr> 
					<td  colspan="3">5 Note</td>
					<td  colspan="3"><?php echo $total_five;?></td>
					<td  colspan="3">Due</td>
					<?php $total_due=$total_due-$total_previous_payment;?>
					<td  colspan="3"><?php  echo $total_due;?></td>
					<td  colspan="3">Intensive</td>
					<td  colspan="3"><?php echo $total_intensive;?></td>
				</tr>
				<tr> 
					<td  colspan="3">2 Note</td>
					<td  colspan="3"><?php echo $total_two;?></td>
					<td  colspan="3">Total Free</td>
					<td  colspan="3"><?php echo $free_total;?></td>
					
					<td  colspan="3">Cash Short</td>
					<td  colspan="3"><?php echo $total_cash_short;?></td>
				</tr>
				<tr> 
					<td  colspan="3">Coin</td>
					<td  colspan="3"><?php echo $total_coin;?></td>
					<td  colspan="3">Benefit</td>
					<td  colspan="3"><?php // echo $free_sell_price;?></td>
					<td  colspan="3">Total Cash</td>
					<?php $total_cash=($total_now+$total_previous_payment)-$total_cash_short;?>
					<td  colspan="3"><?php echo $total_cash;?></td>
				</tr>
	</table>
	</div>
	</div>
	</div>
	<div style="height:50px;" class=""></div>
  </body>
</html>
		<?php
}else{
echo "You have not permit to access this page";
}
}else{
    echo "Something wrong.Please <a href=\"index.php\">login</a>";
}
?>