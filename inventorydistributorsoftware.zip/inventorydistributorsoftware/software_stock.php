<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include_once('db.php');
session_start();
session_regenerate_id(TRUE);
if(isset($_SESSION['user_session']) and isset($_SESSION['company_username_session']) and isset($_SESSION['sub_user_session'])){
	$user_type_now=$_SESSION['user_session'];
	$company_now=$_SESSION['company_username_session'];
	$user_now=$_SESSION['sub_user_session'];
	$status=1;
	$query = "SELECT email,company_name FROM companies_onserial WHERE company_username=? and status=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param("si",$company_now,$status);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($email,$company_name);
	$stmt->fetch();
	$super_email=$email;
	$company=$company_name;
	}

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title><?php echo $company;?></title>
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<script src="auto/jquery-ui.min.js"></script>
	<link href="auto/jquery-ui.min.css" rel="stylesheet">
	<script>
	$(document).ready(function() {
		$(".search_product").click(function(e){
		e.preventDefault();
			var product_search=$(".product_search").val();
			if(product_search.match(/^\d+$/)) {
				var search_type="id";
			}else{
				var search_type="name";
			}
			
			var company="<?php echo $company_now;?>";
			var data_key='product_search='+ product_search+'&search_type='+ search_type+'&company='+ company;
			
			$.ajax({
				type: "POST",
				url: "fill/search_product_stock_now.php",
				data: data_key,
				success: function(html){
					$(".search_product_now").html(html);
					}		
				});
		});
		var com_now="<?php echo $company_now;?>";
		$(function() {
			$("#product_title").autocomplete({
				source: "auto/vendor_product_title_search.php?company="+"'"+com_now+"'",
				minLength: 2
			});				
		});
	})
	</script>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="design.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="../inventory-software.png">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	
  </head>
  <body>
  <?php
	$query = "SELECT pakage,year,date FROM login_onserial WHERE email=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$super_email);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($pakage,$year,$date);
	$stmt->fetch();
	$softpakage=$pakage;
	$year=$year;
	$date=$date;
	$yearto=substr($date,0,4);
	$monthto=substr($date,5,2);
	$dateto=substr($date,8,2);
	$year_num=(int)$yearto;
	$year_up=$year_num+$year;
	if($monthto==2 and $dateto==29){
		$monthto=03;
		$dateto=01;
	}
	$up_date="$year_up"."/"."$monthto"."/"."$dateto";
	$up_to_time=strtotime($up_date);
	$expired_date=date('Y-m-d',$up_to_time);
	$today=date("Y-m-d");
	
	$today_strtotime=strtotime($today);
	$expired_strtotime=strtotime($expired_date);
	if($softpakage=='Free'){
		$warehouse=1;
		$users=1;
	}else if($softpakage=='Standard'){
		$warehouse=1;
		$users=1;
	}else if($softpakage=='Extend'){
		$warehouse=10;
		$users=20;
	}else if($softpakage=='Expand'){
		$warehouse=50;
		$users=100;
	}
	$stmt->free_result();
		$stmt->close();
	}
	$query = "SELECT purchase_default_cursor FROM companies_onserial WHERE company_username=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$company_now);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($purchase_default_cursor);
	$stmt->fetch();
	if($purchase_default_cursor=='Email'){
		$vendor_primary_key='markenter_email';
	}else if($purchase_default_cursor=='Mobile'){
		$vendor_primary_key='vendor_mobile_no';
	}else if($purchase_default_cursor=='Telephone'){
		$vendor_primary_key='vendor_telephone_no';
	}
	$stmt->free_result();
		$stmt->close();
	}
	?>
	<?php include_once('software_menu.php');?>
	<?php include_once('software_header.php');?>
	<div class="container-fluid border_bottom color z_index">
		<!--<h2>Vendor Management</h2>-->	
	</div>
	
	<div class="container-fluid">
		<div class="row">
		<div class="col-md-6 col-sm-6">
			<div class="webdesigntuts-workshop">
						<form>		    
							<input type="text" id="product_title" class="product_search" placeholder="Search Product?">		    	
							<button class="search_product">Search</button>
						</form>
						
					</div>
		</div>
		<div class="col-md-6 col-sm-6">
			<!--<a class="button_style" href="software_stock_low.php">Low</a>
			<a class="button_style" href="software_stock_high.php">High</a>-->
			<form action="software_stock_filter.php" method="POST">
			<input type="hidden" name="company" value="<?php echo $company_now;?>">
			<select id="secuence" name="secuence"  class="filter_style" >
				<option value="General">General</option>
				<option value="Low">Low</option>
				<option value="High">High</option>
			</select>
			<select id="vendor_select" name="vendor_select"  class="filter_style" >
				<option value="All">All</option>
				<?php
				if($stmt_sql = $mysqli->prepare("SELECT $vendor_primary_key FROM company_markenter_onserial WHERE company_username=? ORDER BY sn DESC")){
					
					$stmt_sql->bind_param("s",$company_now);
					$stmt_sql->execute();
					$stmt_sql->store_result();
					$num_of_rows = $stmt_sql->num_rows;
					$stmt_sql->bind_result($vendor_find);
					if($num_of_rows > 0){
						while($stmt_sql->fetch()){
							echo "<option value=\"$vendor_find\">$vendor_find</option>";
							}
					}
					}
					?>
				</select>
			<input type="submit" class="button_style" id="filter_search" value="Search">
			</form>
		</div>
			<div class="col-md-12">
				<div class="search_product_now"></div>
				  <div class="wrapper">
					  <div class="table">
						
						<div class="tb_header">
						  <div class="cell">
							Sn
						  </div>
						  <div class="cell">
							Product id
						  </div>
						  <div class="cell">
							Product title
						  </div>
						  <div class="cell">
							Buy
						  </div>
						  <div class="cell">
							Stock
						  </div>
						  <div class="cell">
							Sell
						  </div>
						  
						  <div class="cell">
							P.Return
						  </div>
						  <div class="cell">
							S.Return
						  </div>
						  <div class="cell">
							Damage
						  </div>
						  <div class="cell">
							Service
						  </div>
						</div>
						<?php 
					if(isset($_GET["page"])){
						$page = intval($_GET["page"]);
					}else{
						$page=1;
					}
					$range=10;
					$start=($page*$range)-$range;
					$next=$page+1;
					$previus=$page-1;
					if($stmt_sql = $mysqli->prepare("SELECT product_id,total_purchase,current_stock,total_sell,purchase_return,sell_return,damage,warranty FROM stock_now_onserial WHERE company_username=? ORDER BY sn DESC  limit $start,$range")){
					
					$stmt_sql->bind_param("s",$company_now);
					$stmt_sql->execute();
					$stmt_sql->store_result();
					$num_of_rows = $stmt_sql->num_rows;
					$stmt_sql->bind_result($product_id,$total_purchase,$current_stock,$total_sell,$purchase_return,$sell_return,$damage,$warranty);
					if($num_of_rows > 0){
						$sn=1;
						while($stmt_sql->fetch()){
							echo "<div class=\"tb_row\">";
							echo "<div class=\"cell\">".$sn."</div>";
							echo "<div class=\"cell\">".$product_id."</div>";
							
							if($stmt_name = $mysqli->prepare("SELECT product_title FROM products_details_onserial WHERE company_username=? and  product_id=? ORDER BY sn DESC")) {
							$stmt_name->bind_param("ss",$company_now,$product_id);
							$stmt_name->execute();
							$stmt_name->store_result();
							$num_of_rows = $stmt_name->num_rows;
							$stmt_name->bind_result($product_title);
							$stmt_name->fetch();
							
							echo "<div class=\"cell\">".$product_title."</div>";
							}
							echo "<div class=\"cell\">".$total_purchase."</div>";
							echo "<div class=\"cell\">".$current_stock."</div>";
							echo "<div class=\"cell\">".$total_sell."</div>";
							echo "<div class=\"cell\">".$purchase_return."</div>";
							echo "<div class=\"cell\">".$sell_return."</div>";
							echo "<div class=\"cell\">".$damage."</div>";
							echo "<div class=\"cell\">".$warranty."</div>";
							echo "</div>";
							$sn++;
							}
					}else{
						echo "<div class=\"tb_row\">";
							echo "Yet products in stock";
						echo "</div>";
					}
					}
						?>
					  
					</div>
				  
				</div>
			</div>
		</div>
	</div>
	<div class="container">
		<div class="row ">
			<div class="col-md-12">
				<div class="float_left;">
					<?php 
					if($page>1){
					echo "<a class='btn btn-success previus'  href=\"software_stock.php?page=$previus\">Previus</a>";
					}
					?>
				</div>
				<div  class="float_right;">
					<?php 
					if($page>1){
					echo "<a class='btn btn-success next'  href=\"software_stock.php?page=$next\">Next</a>";
					}
					?> 
				</div>
			</div>
		</div>	
	</div>
    
  </body>
</html>
<?php
}else{
    echo "Something wrong.Please <a href=\"index.php\">login</a>";
}
?>