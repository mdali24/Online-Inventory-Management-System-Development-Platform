<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include_once('db.php');
session_start();
session_regenerate_id(TRUE);
if(isset($_SESSION['user_session']) and isset($_SESSION['company_username_session']) and isset($_SESSION['sub_user_session'])){
	$user_type_now=$_SESSION['user_session'];
	$company_now=$_SESSION['company_username_session'];
	$user_now=$_SESSION['sub_user_session'];
	$status=1;
	$query = "SELECT email,company_name,company_email,company_mobile,company_telephone,address,company_timezone,vendor_primary_key,purchase_invoice_msg FROM companies_onserial WHERE company_username=? and status=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param("si",$company_now,$status);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($email,$company_name,$company_email,$company_mobile,$company_telephone,$address,$company_timezone,$vendor_primary_key,$purchase_invoice_msg);
	$stmt->fetch();
	$super_email=$email;
	$company=$company_name;
	$company_email=$company_email;
	$company_mobile=$company_mobile;
	$company_telephone=$company_telephone;
	$address=$address;
	$company_timezone=$company_timezone;
	$vendor_primary_key=$vendor_primary_key;
	$purchase_invoice_msg=$purchase_invoice_msg;
	}
	if($user_type_now=='Super'){
	$user_now=$super_email;
	}
	
 date_default_timezone_set($company_timezone);//problem
 $var_date= date('y/m/d') ;
if($user_type_now=="Super" or $user_type_now=="Master" or $user_type_now=="Purchase_Master" or $user_type_now=="Only_Purchase"){

?>
<?php
	$query = "SELECT pakage,year,date FROM login_onserial WHERE email=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$super_email);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($pakage,$year,$date);
	$stmt->fetch();
	$softpakage=$pakage;
	$year=$year;
	$date=$date;
	$yearto=substr($date,0,4);
	$monthto=substr($date,5,2);
	$dateto=substr($date,8,2);
	$year_num=(int)$yearto;
	$year_up=$year_num+$year;
	if($monthto==2 and $dateto==29){
		$monthto=03;
		$dateto=01;
	}
	$up_date="$year_up"."/"."$monthto"."/"."$dateto";
	$up_to_time=strtotime($up_date);
	$expired_date=date('Y-m-d',$up_to_time);
	$today=date("Y-m-d");
	
	$today_strtotime=strtotime($today);
	$expired_strtotime=strtotime($expired_date);
	if($softpakage=='Free'){
		$warehouse=1;
		$users=1;
	}else if($softpakage=='Standard'){
		$warehouse=1;
		$users=1;
	}else if($softpakage=='Extend'){
		$warehouse=10;
		$users=20;
	}else if($softpakage=='Expand'){
		$warehouse=50;
		$users=100;
	}
	$stmt->free_result();
		$stmt->close();
	}
	$query = "SELECT vendor_primary_key,serial_key,barcode,after_purchase_service FROM companies_onserial WHERE company_username=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$company_now);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($purchase_default_cursor,$serial_key,$barcode,$after_purchase_service);
	$stmt->fetch();
	if($serial_key=='Yes'){
		$serial_use='Yes';
	}else{
		$serial_use='No';
	}
	if($purchase_default_cursor=='Email'){
		$onfocus='vendor_email';
	}else if($purchase_default_cursor=='Mobile'){
		$onfocus='mobile_no';
	}else if($purchase_default_cursor=='Telephone'){
		$onfocus='telephone_no';
	}
	$stmt->free_result();
		$stmt->close();
	}
	?>
	<?php if($after_purchase_service=="No"){
		$hide='hide_now';
		}else{
		$hide="";
	}
	?>
	<?php if($barcode=="No"){
		$bar_hide='hide_now';
	}else{
		$bar_hide="";
	}
	?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title><?php echo $company;?></title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="design.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="../inventory-software.png">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<script src="javascript.js"></script>
	<script src="auto/jquery-ui.min.js"></script>
	<link href="auto/jquery-ui.min.css" rel="stylesheet">
	<script type="text/javascript">
	$(document).ready(function() {
		var tk=0;
		var token='tk='+ tk;
		var validity_check=function(validity,character_length){
				if(validity<0 || (validity.length > character_length) || (validity.indexOf('/') > -1)|| (validity.indexOf('*') > -1)|| (validity.indexOf('<') > -1)|| (validity.indexOf('>') > -1)|| (validity.indexOf('var ') > -1)|| (validity.indexOf('$') > -1)|| (validity.indexOf('!') > -1)|| (validity.indexOf('script') > -1)|| (validity.indexOf('&') > -1)|| (validity.indexOf('+') > -1)|| (validity.indexOf('-') > -1)|| (validity.indexOf('(') > -1)|| (validity.indexOf(')') > -1)|| (validity.indexOf('{') > -1)|| (validity.indexOf('}') > -1)|| (validity.indexOf('()') > -1)|| (validity.indexOf('{}') > -1)|| (validity.indexOf('[') > -1)|| (validity.indexOf(']') > -1)|| (validity.indexOf('[]') > -1)|| (validity.indexOf('#') > -1)|| (validity.indexOf('^') > -1)|| (validity.indexOf('?') > -1)){
					alert("Invalid Character");
					throw new Error("An error");
				}else{
					return validity;
				}
			}
		
		$("#product_title").focus();
		var count =0;
		$(document).keydown(function(e) {
			if (e.keyCode == '13'){
			var focus=$(':focus').attr('id');
			var company="<?php echo $company_now;?>";
			var key = $('#'+ focus).val();
			validity_check(key,32);
			if((focus=="vendor_email") || (focus=="mobile_no") || (focus=="telephone_no")){
				
				$.ajax({
				type: "POST",
				url: "token/csrf_token.php",
				data: token,
				success: function(html){
					$("#token_one").val(html);
					var token_one=$("#token_one").val();
					var data_key='token_one='+ token_one+'&key='+ key+'&focus='+ focus+'&company='+ company;
				$.ajax({
					//async: false,
					type: "POST",
					url: "fill/vendor_about.php",
					data: data_key,
					success: function(html){
					$("#vendor_about").html(html);
					if(focus=="vendor_email"){
						var mobile_get=$("#mobile_get").html();
						$("#mobile_no").val(mobile_get);
						var telephone_get=$("#telephone_get").html();
						$("#telephone_no").val(telephone_get);
					}else if(focus=="mobile_no"){
						var email_get=$("#email_get").html();
						$("#vendor_email").val(email_get);
						var telephone_get=$("#telephone_get").html();
						$("#telephone_no").val(telephone_get);
					}else{
						var email_get=$("#email_get").html();
						$("#vendor_email").val(email_get);
						var mobile_get=$("#mobile_get").html();
						$("#mobile_no").val(mobile_get);
					}
					var name_get=$("#name_get").html();
					$("#full_name").val(name_get);
					var address_get=$("#address_get").html();
					$("#vendor_address").val(address_get);
					var company_get=$("#company_get").html();
					$("#company_name").val(company_get);
					var debit_limit_get=$("#debit_limit_get").html();
					$("#debit_limit").val(debit_limit_get);
					var debit_days_get=$("#debit_days_get").html();
					$("#debit_days").val(debit_days_get);
					var serial_id_get=$("#serial_id_get").html();
					$("#serial_id").val(serial_id_get);
					var previous_business=$(".previous_business").html();
					$(".previous_business_show").html(previous_business);
					$(".panel_body").html(previous_business);
					
						}		
					});
				/*var n=0;
				$(".about_vendor").find(":input:enabled").each(function() {
				   if($(this).val() === ""){
					   n++;
				   }
				});
				if(n==0){
					$("#product_name").focus();
				}else{
					$(".about_vendor").find("input:enabled").filter(function () {
						return this.value.trim() == "";
					}).first().focus();
				}*/
				
				$("#product_title").focus();
					}		
				});
				
				
				
			}else if((focus=="invoice_edit")){
				$.ajax({
				type: "POST",
				url: "token/csrf_token.php",
				data: token,
				success: function(html){
					$("#token_two").val(html);
					var token_two=$("#token_two").val();
					var data='token_two='+ token_two+'&key='+ key+'&focus='+ focus+'&company='+ company;
				$.ajax({
				type: "POST",
				url: "fill/adjusments_add_invoice_edit_details.php",
				data: data,
				success: function(html){
					$(".invoice_edit_take").html(html);
					var date_take=$("#date_take").html();
					$(".invoice_date").val(date_take);
					var delivary_date_take=$("#delivary_date_take").html();
					$(".delivary_date").val(delivary_date_take);
					var bill_take=$("#bill_take").html();
					$(".grand_total").val(bill_take);
					var discount_take=$("#discount_take").html();
					$(".discount_total").val(discount_take);
					var total_take=$("#total_take").html();
					$(".total").val(total_take);
					var payment_take=$("#payment_take").html();
					$(".now_payment").val(payment_take);
					var payment_method_take=$("#payment_method_take").html();
					$(".payment_method_one").val(payment_method_take);
					//Select ar jonno kaj korte hobe
					
					var bank_name_take=$("#bank_name_take").html();
					$(".bank_name").val(bank_name_take);
					var account_no_take=$("#account_no_take").html();
					$(".account_no").val(account_no_take);
					var due_take=$("#due_take").html();
					$(".due").val(due_take);
					var due_payment_date_take=$("#due_payment_date_take").html();
					$(".due_payment_date").val(due_payment_date_take);
					var tax_take=$("#tax_take").html();
					$(".tax").val(tax_take);
					var carring_cost_take=$("#carring_cost_take").html();
					$(".caring_cost").val(carring_cost_take);
					var others_cost_take=$("#others_cost_take").html();
					$(".others_cost").val(others_cost_take);
					var intensive_take=$("#intensive_take").html();
					$(".insentive").val(intensive_take);
					var net_take=$("#net_take").html();
					$(".total_net").val(net_take);
					var remarks_take=$("#remarks_take").html();
					$(".remarks").val(remarks_take);
					
					var markenter_email_took=$("#markenter_email_took").html();
					$("#vendor_email").val(markenter_email_took);
					var vendor_mobile_no_took=$("#vendor_mobile_no_took").html();
					$("#mobile_no").val(vendor_mobile_no_took);
					var vendor_telephone_no_took=$("#vendor_telephone_no_took").html();
					$("#telephone_no").val(vendor_telephone_no_took);
					var full_name_took=$("#full_name_took").html();
					$("#full_name").val(full_name_took);
					var vendor_address_took=$("#vendor_address_took").html();
					$("#vendor_address").val(vendor_address_took);
					var vendor_company_name_took=$("#vendor_company_name_took").html();
					$("#company_name").val(vendor_company_name_took);
					var vendor_debit_limit_took=$("#vendor_debit_limit_took").html();
					$("#debit_limit").val(vendor_debit_limit_took);
					var vendor_debit_days_took=$("#vendor_debit_days_took").html();
					$("#debit_days").val(vendor_debit_days_took);
					var vendor_id_took=$("#vendor_id_took").html();
					$("#serial_id").val(vendor_id_took);
					var product_details_take=$(".product_details_take").html();
					$(".products_view").after(product_details_take);
					
					$(".invoice_edit_take").html("");
					load_effects();
					}		
					});
				}
				});
				
			}else if((focus=="search_name") || (focus=="search_company") || (focus=="search_address")){
				$.ajax({
				type: "POST",
				url: "token/csrf_token.php",
				data: token,
				success: function(html){
					$("#token_three").val(html);
					var token_three=$("#token_three").val();
					var data='token_three='+ token_three+'&key='+ key+'&focus='+ focus+'&company='+ company;
					$.ajax({
					type: "POST",
					url: "fill/vendor_search_details.php",
					data: data,
					success: function(html){
					$("#search_details").html(html);
					$(".overflow_top_left").scrollTop(380);
					var total_pickup=$("#total_pickup").val();
					$("#total").html(total_pickup);
					}		
					});
				}
				});
				
			}else if((focus=="product_title") || (focus=="product_id")){  //Product details
			$.ajax({
			type: "POST",
			url: "token/csrf_token.php",
			data: token,
			success: function(html){
				$("#token_four").val(html);
				var token_four=$("#token_four").val();
				var vendor=$('#serial_id').val();
				var data='token_four='+ token_four+'&key='+ key+'&focus='+ focus+'&company='+ company+'&vendor='+ vendor;
				$.ajax({
				type: "POST",
				url: "fill/product_details.php",
				data: data,
				success: function(html){
					$("#product_detail").html(html);
					var product_name_get=$("#product_name_get").html();
					$("#product_name").val(product_name_get);
					var product_id_get=$("#product_id_get").html();
					$("#product_id").val(product_id_get);
					var quantity_get=$("#quantity_get").html();;
					$("#quantity").val(quantity_get);
					var size_get=$("#size_get").html();
					$("#size").val(size_get);
					var products_company_get=$("#products_company_get").html();
					$("#products_company").val(products_company_get);
					var unit_price_get=$("#unit_price_get").html();
					$("#unit_price").val(unit_price_get);
					$("#sub_total").val(unit_price_get);
					var discount_get=$("#discount_get").html();;
					$("#discount").val(discount_get);
					$("#sub_net").val(unit_price_get);
					var product_tax_get=$("#product_tax_get").html();
					$("#product_tax").val(product_tax_get);
					var sell_price_get=$("#sell_price_get").html();
					$("#sell_price").val(sell_price_get);
					var warranty_guarantee_days_get=$("#warranty_guarantee_days_get").html();
					$("#warranty_guarantee_days").val(warranty_guarantee_days_get);
					var warranty_guarantee_type_get=$("#warranty_guarantee_type_get").html();
					$("#warranty_guarantee_type_one").text(warranty_guarantee_type_get);
					var default_option=$("#warranty_guarantee_type_one").text();
					if(default_option=='Warranty'){
							$("#warranty_guarantee_type_two").text('Guarantee');
							$("#warranty_guarantee_type_three").text('None');
						}else if(default_option=='Guarantee'){
							$("#warranty_guarantee_type_two").text('Warranty');
							$("#warranty_guarantee_type_three").text('None');
						}else{
							$("#warranty_guarantee_type_one").text('None');
							$("#warranty_guarantee_type_two").text('Warranty');
							$("#warranty_guarantee_type_three").text('Guarantee');
						}
					var serial_key_length_get=$("#serial_key_length_get").html();
					$("#serial_key_length").val(serial_key_length_get);
					}		
				});
				
				$("#product_name").focus();
				}
			})
				
				
			}else if((focus=="product_name")){
				$("#quantity").focus();
						
					}else if((focus=="quantity")){
						var serial_use=$("#serial_use").html();
						if(serial_use!=='Yes'){
							$("#size").focus();
						}else{
							$("#serial_key").focus();
						}
				
					}else if(focus=="serial_key"){
						var serial_key_length=$("#serial_key_length").val();
						validity_check(serial_key_length,32);
						var serial_key=$("#serial_key").val();
						validity_check(serial_key,32);
						if(serial_key.length==serial_key_length){
							var quantity=$("#quantity").val();
							count = $('.serials').html();
							if(count<quantity){
							var all_serials=$("#all_serials").text();
							if (all_serials.indexOf(serial_key) >= 0){
								alert("Already Added");
							}else{
								var serial_add="<div class='serial_add'>"+"<span class='serial'>"+serial_key+"</span>"+"<span class='serial_remove serial_remove_view'>"+"X"+"</span>"+"</div>";
							$(".serials").after(serial_add);
							count = $('.serial_remove').length;
							$(".serials").html(count);
							}
							}else{
								alert("Please Extend Quantity");
							}
							$("#serial_key").val('');
						}
					}
					}
			
			$(".serial_remove").click(function(e) {
				e.preventDefault(); $(this).parent('div').remove();
				count = $('.serial_remove').length;
				$(".serials").html(count);
				
			});
		})
		var pre_quan_dis=function(){
			var quantity_p = $("#quantity").val();
			validity_check(quantity_p,32);
			if(quantity_p<1){
				var quantity_p=1;
			}
			var unit_p = $("#unit_price").val();
			validity_check(unit_p,32);
			var subtotal_now = unit_p*quantity_p;
			
			$("#sub_total").val(subtotal_now);
			var discount_now = $("#discount").val();
			
			if(discount_now.indexOf('%') > -1){
				var discount_percentage=discount_now.substring(0,discount_now.indexOf("%"));
				var discount_here=(subtotal_now*discount_percentage)/100;
				var now_sub_net = subtotal_now-discount_here;
				$("#sub_net").val(now_sub_net);
			}else{
				var now_sub_net=subtotal_now-discount_now;
				$("#sub_net").val(now_sub_net);
			}
		}
		$("#quantity").keyup(function(e) {
		
			pre_quan_dis();
		});
		$("#discount").keyup(function(e) {
			pre_quan_dis();
		});
		$("#unit_price").keyup(function(e) {
			pre_quan_dis();
		});
		 var com_now= $('#com_now').val();
		
		$(function() {
			$("#mobile_no").autocomplete({
				source: "auto/vendor_mobile_search.php?company="+"'"+com_now+"'",
				minLength: 2
			});				
		});
		$(function() {
			$("#vendor_email").autocomplete({
				source: "auto/vendor_email_search.php?company="+"'"+com_now+"'",
				minLength: 2
			});				
		});
		$(function() {
			$("#telephone_no").autocomplete({
				source: "auto/vendor_telephone_search.php?company="+"'"+com_now+"'",
				minLength: 2
			});				
		});
		
		$(function() {
			$("#search_name").autocomplete({
				source: "auto/vendor_full_name_search.php?company="+"'"+com_now+"'",
				minLength: 2
			});				
		});
		
		$(function() {
			$("#search_company").autocomplete({
				source: "auto/vendor_company_search.php?company="+"'"+com_now+"'",
				minLength: 2
			});				
		});
		$(function() {
			$("#search_address").autocomplete({
				source: "auto/vendor_address_search.php?company="+"'"+com_now+"'",
				minLength: 2
			});				
		});
		
		$("#vendor_search").click(function(){
			$("#vendor_search_toggle").toggle();
			$(".overflow_top_left").scrollTop(250);
			$("#search_name").focus();
		});
		//Vendor details
		
		$(function() {
			$("#product_title").autocomplete({
				source: "auto/vendor_product_title_search.php?company="+"'"+com_now+"'",
				minLength: 2
			});				
		});
		$(document).keydown(function(e) {
			if (e.keyCode == '27') {
				$('#vendor_search').click();
				$(".overflow_top_left").scrollTop(250);
				
			 }else if(e.keyCode == '45'){
				 insert();
				 payment_load();
			 }else if(e.keyCode == '17'){
				 $('.invoice_add').click();
			 }else if(e.keyCode == '36'){
				 $('.invoice_no').focus();
			 }else if(e.keyCode == '46'){
				 $('input').val('');
				 $("#<?php echo $onfocus;?>").focus();
				 var today="<?php echo $var_date;?>";
				 $(".invoice_date").val(today);
				 $(".delivary_date").val(today);
				 $(window).scrollTop(200);
			 }else if(e.keyCode == '35'){
				 $('.delivary_date').focus();
			 }else if(e.keyCode == '123'){
				 $('#product_title').focus();
				 $(window).scrollTop(200);
			 }else if(e.keyCode == '122'){
				 $('#vendor_email').focus();
			 }
			 
		});
		$("#products_add").click(function(e) {
				insert();
				 payment_load();
				
			});
		var insert=function(){
			
						var focus_generate=$(':focus').attr('id');
						validity_check(focus_generate,32);
						var product_name=$("#product_name").val();
						validity_check(product_name,32);
						var product_id=$("#product_id").val();
						validity_check(product_id,32);
						var quantity=$("#quantity").val();
						validity_check(quantity,32);
						var size=$("#size").val();
						validity_check(size,32);
						var products_company=$("#products_company").val();
						validity_check(products_company,32);
						var unit_price=$("#unit_price").val();
						validity_check(unit_price,32);
						var sub_total=$("#sub_total").val();
						validity_check(sub_total,32);
						var discount=$("#discount").val();
						validity_check(discount,32);
						var sub_net=$("#sub_net").val();
						validity_check(sub_net,32);
						var product_tax=$("#product_tax").val();
						validity_check(product_tax,32);
						if(product_tax.indexOf('%') > -1){
							var product_tax_percentage=product_tax.substring(0,product_tax.indexOf("%"));
							var tax_now=(sub_net *product_tax_percentage)/100;
						}else{
							var tax_now=product_tax;
							var product_tax_percentage=(product_tax/sub_net)*100;
						}
						var sell_price=$("#sell_price").val();
						validity_check(sell_price,32);
						var warranty_guarantee_days=$("#warranty_guarantee_days").val();
						validity_check(warranty_guarantee_days,32);
						var warranty_guarantee_type=$("#warranty_guarantee_type").val();
						validity_check(warranty_guarantee_type,32);
						var remarks=$("#remarks").val();
						validity_check(remarks,128);
						if(remarks.length<1){remarks="Empty";}
						var serial_key_length=$("#serial_key_length").val();
						validity_check(serial_key_length,128);
						var all_serials=$("#all_serials").html();
						var product_title=product_name+" "+size;
						validity_check(product_title,128);
						var all_products=$(".item").text();
						var serials_count=$(".serials").html();
						if((product_name.length<1) && (product_id.length<1)){
							alert("Empty Products");
						}else{
						if((quantity.length<1) || (unit_price.length<1) || (sub_total.length<1) || (sub_net.length<1) || (sell_price.length<1)){
							alert("Empty Fields");
						}else{
						if((serial_key_length >0) && (quantity!==serials_count)){
							alert("All products serial key not taken");
						}else{
							
						if (((product_title.length>0) && all_products.indexOf(product_title) > -1)){
							alert("Already Product name Added");
						}else{
							if((product_id.length>0) && (all_products.indexOf(product_id) > -1)){
								alert("Already Product id Added");
							}else{
						var product_title_div="<div class='col-md-12 col-sm-12  product_title_heading'><span class='sn'></span><span class=''> Product Title : </span><span class='product_title_view'>"+product_title+"</span></div>";
						var product_name_div="<div class='col-md-6 col-sm-6 '><div class='title_heading'>Product Name : </div><div class='product_name_view'>"+product_name+"</div></div>";
						var product_id_div="<div class='col-md-6 col-sm-6'><div class='title_heading'>Product Id : </div><div class='product_id_view'>"+product_id+"</div></div>";
						var quantity_div="<div class='col-md-6 col-sm-6 '><div class='title_heading'>Quantity : </div><input class='quantity_view' value='"+quantity+"'></div>";
						var tax_percent="<input type='hidden' class='tax_percent_view' value='"+product_tax_percentage+"'>";
						var size_div="<div class='col-md-6 col-sm-6'><div class='title_heading'>Size : </div><div class='size_view'>"+size+"</div></div>";
						var products_company_div="<div class='col-md-6 col-sm-6 display_none'><div class='title_heading'>Products Company : </div><div class='products_company_view'>"+products_company+"</div></div>";
						var unit_price_div="<div class='col-md-6 col-sm-6 display_none'><div class='title_heading'>Unit Price : </div><div class='unit_price_view'>"+unit_price+"</div></div>";
						var sub_total_div="<div class='col-md-6 col-sm-6 display_none'><div class='title_heading'>Sub Total : </div><div class='sub_total_view'>"+sub_total+"</div></div>";
						var discount_div="<div class='col-md-6 col-sm-6 display_none'><div class='title_heading'>Discount : </div><div class='discount_view'>"+discount+"</div></div>";
						var sub_net_div="<div class='col-md-6 col-sm-6 display_none'><div class='title_heading'>Sub Net : </div><div class='sub_net_view'>"+sub_net+"</div></div>";
						var tax_div="<div class='col-md-6 col-sm-6 display_none'><div class='title_heading'>Tax: </div><div class='tax_view'>"+tax_now+"</div></div>";
						var sell_price_div="<div class='col-md-6 col-sm-6 display_none'><div class='title_heading'>Sell Price : </div><div class='sell_price_view'>"+sell_price+"</div></div>";
						var warranty_guarantee_days_div="<div class='col-md-6 col-sm-6  display_none <?php echo $hide?>'><div class='title_heading'>Service days : </div><div class='warranty_guarantee_days_view'>"+warranty_guarantee_days+"</div></div>";
						var warranty_guarantee_type_div="<div class='col-md-6 col-sm-6  display_none <?php echo $hide?>'><div class='title_heading'>Service Type : </div><div class='warranty_guarantee_type_view'>"+warranty_guarantee_type+"</div></div>";
						var remarks_div="<div class='col-md-6 col-sm-6  display_none'><div class='title_heading'>Remarks : </div><div class='remarks_view'>"+remarks+"</div></div>";
						var serial_key_length_div="<div class='col-md-6 col-sm-6  display_none <?php echo $bar_hide?>'><div class='title_heading'>Serial key length : </div>"+"<div class='serial_key_length_view'>"+serial_key_length+"</div>"+"</div>"+"<div class='col-md-5 col-sm-5  display_none serial_key_add_view  <?php echo $bar_hide?>'>Add new Serial : </div>"+"<input type='text' class='col-md-7 col-sm-7 serial_key_add display_none'>";
						
						var all_serials_div="<div class='col-md-12 col-sm-12 display_none  <?php echo $bar_hide?>'><div class='title_heading'>Serial keys : </div><div class='all_serials_view'>"+all_serials+"</div></div>";
						var all_divs="<div class='product_wrapper'>"+product_title_div+product_name_div+product_id_div+quantity_div+size_div+products_company_div+unit_price_div+sub_total_div+discount_div+sub_net_div+tax_div+tax_percent+sell_price_div+warranty_guarantee_days_div+warranty_guarantee_type_div+remarks_div+serial_key_length_div+"<div class='serials_view'>"+all_serials_div+"</div>"+"<a class='col-md-12 col-sm-12 remove_product'>Remove</a></div>";
						$(".products_view").after(all_divs);
						$(".serials_view").find(".serial_remove_view").removeClass("serial_remove");
						$(".serials_view").find(".serials_insert").removeClass("serials");
						load_effects();
						product_title_refresh();
							}
							}
						}
						}
						}
					}
					var load_effects=function(){
						$('.serial_key_add').keyup(function(e){
							var serial_key_length_view=$(this).parent('div').find('.serial_key_length_view').html();
							validity_check(serial_key_length_view,32);
							var serial_key_add=$(':focus').val();
							validity_check(serial_key_add,32);
							if(serial_key_add.length==serial_key_length_view){
								var quantity_view=$(this).parent('div').find(".quantity_view").val();
								validity_check(quantity_view,32);
								var count_view_now=$(this).parent('div').find('.serials_insert').html();
								count_view_now=Number(count_view_now);
								if(count_view_now<quantity_view){
								var all_serials_view=$(this).parent('div').find('.serials_view').text();
								if (all_serials_view.indexOf(serial_key_add) >= 0){
									alert("Already Added");
								}else{
									var serial_add_view="<div class='serial_add'>"+"<span class='serial'>"+serial_key_add+"</span>"+"<span class='serial_remove_view'>"+"X"+"</span>"+"</div>";
								$(this).parent('div').find(".serials_insert").after(serial_add_view);
								count_view_now=count_view_now+1;
								$(this).parent('div').find('.serials_insert').html(count_view_now);
								}
								}else{
									alert("Please Extend Quantity");
								}
								$(':focus').val('');
								serial_remove_view_call();
							}
						});
						var serial_remove_view_call=function(){
							$(".serial_remove_view").click(function(e) {
							var count_view = $(this).closest('.serials_view').find('.serials_insert').html();
							count_view=Number(count_view);
							count_view=count_view-1;
							$(this).closest('.serials_view').find('.serials_insert').html(count_view);
							e.preventDefault(); $(this).parent('div').remove();
						
							});
						}
						serial_remove_view_call();
						var serial_load=function(){
							var se=0;
							var s=1;
							var serial_count;
							$(".sn").each(function(){
								$('.sn:eq('+se+')').html(s);	
								se++;
								s++;
							});
						}
						$(".remove_product").click(function(e) {
							e.preventDefault(); $(this).parent('div').remove();
							payment_load();
							serial_load();
						});
						
						var pre_quantity_view=function(){
							var quantity_p_view = $(':focus').val();
							if(quantity_p_view.length<1){
								var quantity_p_view=1;
							}
							var unit_p_view = $(':focus').closest('.product_wrapper').find(".unit_price_view").html();
							var subtotal_view = unit_p_view*quantity_p_view;
							$(':focus').closest('.product_wrapper').find(".sub_total_view").html(subtotal_view);
							var discount_view_now =$(':focus').closest('.product_wrapper').find(".discount_view").html();
							var subtotal_view = $(':focus').closest('.product_wrapper').find(".sub_total_view").html();
							if(discount_view_now.indexOf('%') > -1){
								var discount_percentage_view=discount_view_now.substring(0,discount_view_now.indexOf("%"));
								var discount_view_here=(subtotal_view *discount_percentage_view)/100;
								var now_sub_net_view = subtotal_view-discount_view_here;
								$(':focus').closest('.product_wrapper').find(".sub_net_view").html(now_sub_net_view);
							}else{
								var now_sub_net_view=subtotal_view-discount_view_now;
								$(':focus').closest('.product_wrapper').find(".sub_net_view").html(now_sub_net_view);
							}
							var tax_reset_percent=$(':focus').closest('.product_wrapper').find(".tax_percent_view").val();
							var tax_reset_value=(now_sub_net_view/100)*tax_reset_percent;
							$(':focus').closest('.product_wrapper').find(".tax_view").html(tax_reset_value);
						}
						$('.quantity_view').keyup(function(e){
							pre_quantity_view();
							payment_load();
						})
						serial_load();
						
							}
							
							var product_title_refresh=function(){
								$("#product_name").val('');
							$("#product_id").val('');
							$("#quantity").val('');
							$("#size").val('');
							$("#products_company").val('');
							$("#unit_price").val('');
							$("#sub_total").val('');
							$("#discount").val('');
							$("#sub_net").val('');
							$("#product_tax").val('');
							$("#sell_price").val('');
							$("#warranty_guarantee_days").val('');
							$("#warranty_guarantee_type_one").text('None');
							$("#warranty_guarantee_type_two").text('Warranty');
							$("#warranty_guarantee_type_three").text('Guarantee');
							$("#remarks").val('');
							$("#serial_key_length").val('');
							$("#all_serials").html('<div class="serials serials_insert" >0</div>');
							
							$("#product_title").val('');
							$("#product_title").focus();
							}
		var payment_load=function(){
			var numItems = $('.product_wrapper').length;
				var serial=0;
						var tt=0;
						$(".product_wrapper").each(function(){
							var total = $('.product_wrapper:eq('+serial+')').find(".sub_net_view").html();
							total=Number(total);
							tt+=total;
							$(".grand_total").val(tt);
							serial++;							
						});
						var tax_serial=0;
						var tax_total=0;
						$(".product_wrapper").each(function(){
							var total_tax = $('.product_wrapper:eq('+tax_serial+')').find(".tax_view").html();
							total_tax=Number(total_tax);
							tax_total+=total_tax;
							$(".tax").val(tax_total);
							tax_serial++;							
						});
						
						var discount_now = $(".discount_total").val();
						validity_check(discount_now,32);
						var grand_total = $(".grand_total").val();
						validity_check(grand_total,32);
						var tax=$(".tax").val();
						validity_check(tax,32);
						var caring_cost=$(".caring_cost").val();
						validity_check(caring_cost,32);
						var others_cost=$(".others_cost").val();
						validity_check(others_cost,32);
						var insentive=$(".insentive").val();
						validity_check(insentive,32);
						var total_net=$(".total_net").val();	
						validity_check(total_net,32);
						if(discount_now.indexOf('%') > -1){
							var discount_percentage=discount_now.substring(0,discount_now.indexOf("%"));
							var discount_here=(grand_total *discount_percentage)/100;
							var now_net = grand_total-discount_here;
							$(".total").val(now_net);
							$(".now_payment").val(now_net);
							$(".due").val('0');
							if(tax.indexOf('%') > -1){
								var tax_percentage=tax.substring(0,tax.indexOf("%"));
								var tax_here=(grand_total *tax_percentage)/100;
								
								if(insentive.indexOf('%') > -1){
									var insentive_percentage=insentive.substring(0,insentive.indexOf("%"));
									var insentive_here=(grand_total *insentive_percentage)/100;
									
								}else{
									var insentive_here=insentive;
								}
							}else{
								var tax_here=tax;
								if(insentive.indexOf('%') > -1){
									var insentive_percentage=insentive.substring(0,insentive.indexOf("%"));
									var insentive_here=(grand_total *insentive_percentage)/100;

								}else{
									var insentive_here=insentive;
								}
							}
							now_net=Number(now_net);
							caring_cost=Number(caring_cost);
							others_cost=Number(others_cost);
							tax_here=Number(tax_here);
							insentive_here=Number(insentive_here);
							var now_total_here=(now_net+caring_cost+others_cost+tax_here)-insentive_here;
							$(".total_net").val(now_total_here);
						}else{
							var now_net=grand_total-discount_now;
							$(".total").val(now_net);
							$(".now_payment").val(now_net);
							$(".due").val('0');
							if(tax.indexOf('%') > -1){
								var tax_percentage=tax.substring(0,tax.indexOf("%"));
								var tax_here=(grand_total *tax_percentage)/100;
								if(insentive.indexOf('%') > -1){
									var insentive_percentage=insentive.substring(0,insentive.indexOf("%"));
									var insentive_here=(grand_total *insentive_percentage)/100;

								}else{
									var insentive_here=insentive;
								}
							}else{
								var tax_here=tax;
								if(insentive.indexOf('%') > -1){
									var insentive_percentage=insentive.substring(0,insentive.indexOf("%"));
									var insentive_here=(grand_total *insentive_percentage)/100;

								}else{
									var insentive_here=insentive;
								}
							}
							
							now_net=Number(now_net);
							caring_cost=Number(caring_cost);
							others_cost=Number(others_cost);
							tax_here=Number(tax_here);
							insentive_here=Number(insentive_here);
							if(numItems>0){
								var now_total_here=(now_net+caring_cost+others_cost+tax_here)-insentive_here;
							}else{
								var now_total_here=0;
								var zero=0;
								$(".discount_total").val(zero);
								$(".grand_total").val(zero);
								$(".total").val(zero);
								$(".now_payment").val(zero);
								$(".tax").val(zero);
								$(".caring_cost").val(zero);
								$(".others_cost").val(zero);
								$(".insentive").val(zero);
								
								var total_net=$(".total_net").val();
							}
							
						
							$(".total_net").val(now_total_here);
							
						}
					}
					
		$(".discount_total").keyup(function(){
			total_payment();
		})
		
		$(".tax").keyup(function(){
			total_payment();
		})
		$(".caring_cost").keyup(function(){
			total_payment();
		})
		$(".others_cost").keyup(function(){
			total_payment();
		})
		$(".insentive").keyup(function(){
			total_payment();
		})
		var total_payment=function(){
			var discount_now = $(".discount_total").val();
			validity_check(discount_now,32);
			var grand_total = $(".grand_total").val();
			validity_check(grand_total,32);
			var tax=$(".tax").val();
			validity_check(tax,32);
			var caring_cost=$(".caring_cost").val();
			validity_check(caring_cost,32);
			var others_cost=$(".others_cost").val();
			validity_check(others_cost,32);
			var insentive=$(".insentive").val();
			validity_check(insentive,32);
			var total_net=$(".total_net").val();
			validity_check(total_net,32);
			if(discount_now.indexOf('%') > -1){
				var discount_percentage=discount_now.substring(0,discount_now.indexOf("%"));
				var discount_here=(grand_total *discount_percentage)/100;
				var now_net = grand_total-discount_here;
				$(".total").val(now_net);
				
				$(".now_payment").val(now_net);
				$(".due").val('0');
				if(tax.indexOf('%') > -1){
					var tax_percentage=tax.substring(0,tax.indexOf("%"));
					var tax_here=(grand_total *tax_percentage)/100;
					
					if(insentive.indexOf('%') > -1){
						var insentive_percentage=insentive.substring(0,insentive.indexOf("%"));
						var insentive_here=(grand_total *insentive_percentage)/100;
						
					}else{
						var insentive_here=insentive;
					}
				}else{
					var tax_here=tax;
					if(insentive.indexOf('%') > -1){
						var insentive_percentage=insentive.substring(0,insentive.indexOf("%"));
						var insentive_here=(grand_total *insentive_percentage)/100;

					}else{
						var insentive_here=insentive;
					}
				}
				now_net=Number(now_net);
				caring_cost=Number(caring_cost);
				others_cost=Number(others_cost);
				tax_here=Number(tax_here);
				insentive_here=Number(insentive_here);
				var now_total_here=(now_net+caring_cost+others_cost+tax_here)-insentive_here;
				$(".total_net").val(now_total_here);
			}else{
				var now_net=grand_total-discount_now;
				$(".total").val(now_net);
				
				$(".now_payment").val(now_net);
				$(".due").val('0');
				if(tax.indexOf('%') > -1){
					var tax_percentage=tax.substring(0,tax.indexOf("%"));
					var tax_here=(grand_total *tax_percentage)/100;
					if(insentive.indexOf('%') > -1){
						var insentive_percentage=insentive.substring(0,insentive.indexOf("%"));
						var insentive_here=(grand_total *insentive_percentage)/100;

					}else{
						var insentive_here=insentive;
					}
				}else{
					var tax_here=tax;
					if(insentive.indexOf('%') > -1){
						var insentive_percentage=insentive.substring(0,insentive.indexOf("%"));
						var insentive_here=(grand_total *insentive_percentage)/100;

					}else{
						var insentive_here=insentive;
					}
				}
				now_net=Number(now_net);
				caring_cost=Number(caring_cost);
				others_cost=Number(others_cost);
				tax_here=Number(tax_here);
				insentive_here=Number(insentive_here);
				var now_total_here=(now_net+caring_cost+others_cost+tax_here)-insentive_here;
			
				$(".total_net").val(now_total_here);
			}
		}
		$(".now_payment").keyup(function(){
			var grand_total = $(".grand_total").val();
			validity_check(grand_total,32);
			var discount_now = $(".discount_total").val();
			validity_check(discount_now,32);
			var tax=$(".tax").val();
			validity_check(tax,32);
			var caring_cost=$(".caring_cost").val();
			validity_check(caring_cost,32);
			var others_cost=$(".others_cost").val();
			validity_check(others_cost,32);
			var insentive=$(".insentive").val();
			validity_check(insentive,32);
			var total_net=$(".total_net").val();
			validity_check(total_net,32);
			
			if(discount_now.indexOf('%') > -1){
				var discount_percentage=discount_now.substring(0,discount_now.indexOf("%"));
				var discount_here=(grand_total *discount_percentage)/100;
				var now_net = grand_total-discount_here;
				$(".total").val(now_net);
				
				var now_payment=$(".now_payment").val();
				var due=now_net-now_payment
				$(".due").val(due);
				if(tax.indexOf('%') > -1){
					var tax_percentage=tax.substring(0,tax.indexOf("%"));
					var tax_here=(grand_total *tax_percentage)/100;
					
					if(insentive.indexOf('%') > -1){
						var insentive_percentage=insentive.substring(0,insentive.indexOf("%"));
						var insentive_here=(grand_total *insentive_percentage)/100;
						
					}else{
						var insentive_here=insentive;
					}
				}else{
					var tax_here=tax;
					if(insentive.indexOf('%') > -1){
						var insentive_percentage=insentive.substring(0,insentive.indexOf("%"));
						var insentive_here=(grand_total *insentive_percentage)/100;

					}else{
						var insentive_here=insentive;
					}
				}
				now_net=Number(now_net);
				caring_cost=Number(caring_cost);
				others_cost=Number(others_cost);
				tax_here=Number(tax_here);
				insentive_here=Number(insentive_here);
				var now_total_here=(now_net+caring_cost+others_cost+tax_here)-insentive_here;
				$(".total_net").val(now_total_here);
			}else{
				var now_net=grand_total-discount_now;
				$(".total").val(now_net);
				
				var now_payment=$(".now_payment").val();
				var due=now_net-now_payment
				$(".due").val(due);
				if(tax.indexOf('%') > -1){
					var tax_percentage=tax.substring(0,tax.indexOf("%"));
					var tax_here=(grand_total *tax_percentage)/100;
					if(insentive.indexOf('%') > -1){
						var insentive_percentage=insentive.substring(0,insentive.indexOf("%"));
						var insentive_here=(grand_total *insentive_percentage)/100;

					}else{
						var insentive_here=insentive;
					}
				}else{
					var tax_here=tax;
					if(insentive.indexOf('%') > -1){
						var insentive_percentage=insentive.substring(0,insentive.indexOf("%"));
						var insentive_here=(grand_total *insentive_percentage)/100;

					}else{
						var insentive_here=insentive;
					}
				}
				now_net=Number(now_net);
				caring_cost=Number(caring_cost);
				others_cost=Number(others_cost);
				tax_here=Number(tax_here);
				insentive_here=Number(insentive_here);
				var now_total_here=(now_net+caring_cost+others_cost+tax_here)-insentive_here;
			
				$(".total_net").val(now_total_here);
			}
		})
		
		$('.invoice_add').click(function() {
			
			var productcheck=$(".product_wrapper").length;
			if(productcheck<1){
				alert("No Products");
				throw new Error("An error");
			}
			var serial_check=0;
			$(".product_wrapper").each(function(){
				var product_title_view = $('.product_wrapper:eq('+serial_check+')').find(".product_title_view").html();
				var quantity_view = $('.product_wrapper:eq('+serial_check+')').find(".quantity_view").val();
				var total_serial_count = $('.product_wrapper:eq('+serial_check+')').find(".serials_insert").html();
				var serial_key_length_view = $('.product_wrapper:eq('+serial_check+')').find(".serial_key_length_view").html();
				if(serial_key_length_view>0){
					if(quantity_view!==total_serial_count){
						var err_msg=product_title_view+" : Products quantity not equal to serial key products where serial key length greater than zero";
						alert(err_msg);
						throw new Error("An error");
					}
				}
				serial_check++;
			});
			$.ajax({
				type: "POST",
				url: "token/csrf_token.php",
				data: token,
				success: function(html){
					$("#token_five").val(html);
				var token_five=$("#token_five").val();
			var super_user="<?php echo $super_email;?>";
			validity_check(super_user,32);
			var company_use="<?php echo $company_now;?>";
			validity_check(company_use,32);
			var operator="<?php echo $user_now;?>";
			validity_check(operator,32);
			
			var invoice_no_add=$(".invoice_no").val();
			validity_check(invoice_no_add,32);
			var invoice_date_add=$(".invoice_date").val();
			
			
			var vendor_email_add=$("#vendor_email").val();
			validity_check(vendor_email_add,32);
			var mobile_no_add=$("#mobile_no").val();
			validity_check(mobile_no_add,32);
			var telephone_no_add=$("#telephone_no").val();
			validity_check(telephone_no_add,32);
			var full_name_add=$("#full_name").val();
			validity_check(full_name_add,32);
			var vendor_address_add=$("#vendor_address").val();
			validity_check(vendor_address_add,32);
			var company_name_add=$("#company_name").val();
			validity_check(company_name_add,32);
			var debit_limit_add=$("#debit_limit").val();
			validity_check(debit_limit_add,32);
			var debit_days_add=$("#debit_days").val();
			validity_check(debit_days_add,32);
			
			var delivary_date_add=$(".delivary_date").val();
			
			var grand_total_add=$(".grand_total").val();
			validity_check(grand_total_add,32);
			var discount_total_add=$(".discount_total").val();
			validity_check(discount_total_add,32);
			var total_add=$(".total").val();
			validity_check(total_add,32);
			
			var now_payment_add=$(".now_payment").val();
			validity_check(now_payment_add,32);
			var payment_method_add=$(".payment_method").val();
			validity_check(payment_method_add,32);
			var bank_name_add=$(".bank_name").val();
			validity_check(bank_name_add,32);
			var account_no_add=$(".account_no").val();
			validity_check(account_no_add,32);
			var due_add=$(".due").val();
			validity_check(due_add,32);
			var due_payment_date_add=$(".due_payment_date").val();
			
			var tax_add=$(".tax").val();
			validity_check(tax_add,32);
			
			var caring_cost_add=$(".caring_cost").val();
			validity_check(caring_cost_add,32);
			var others_cost_add=$(".others_cost").val();
			validity_check(others_cost_add,32);
			var insentive_add=$(".insentive").val();
			validity_check(insentive_add,32);
			var total_net_add=$(".total_net").val();
			validity_check(total_net_add,32);
			var remarks_add=$(".remarks").val();
			validity_check(remarks_add,32);
			var vendor_id_add=$("#serial_id").val();
			validity_check(vendor_id_add,32);
			var data_add='token_five='+ token_five+'&super_user='+ super_user+'&company_use='+ company_use+'&operator='+ operator+'&invoice_no_add='+ invoice_no_add+'&invoice_date_add='+ invoice_date_add+'&vendor_email_add='+ vendor_email_add+'&mobile_no_add='+ mobile_no_add+'&telephone_no_add='+ telephone_no_add+'&full_name_add='+ full_name_add+'&vendor_address_add='+ vendor_address_add+'&company_name_add='+ company_name_add+'&debit_limit_add='+ debit_limit_add+'&debit_days_add='+ debit_days_add+'&delivary_date_add='+ delivary_date_add+'&grand_total_add='+ grand_total_add+'&discount_total_add='+ discount_total_add+'&total_add='+ total_add+'&now_payment_add='+ now_payment_add+'&payment_method_add='+ payment_method_add+'&bank_name_add='+ bank_name_add+'&account_no_add='+ account_no_add+'&due_add='+ due_add+'&due_payment_date_add='+ due_payment_date_add+'&tax_add='+ tax_add+'&caring_cost_add='+ caring_cost_add+'&others_cost_add='+ others_cost_add+'&insentive_add='+ insentive_add+'&total_net_add='+ total_net_add+'&remarks_add='+ remarks_add+'&vendor_id_add='+ vendor_id_add;
			
			$.ajax({
			type: "POST",
			url: "add/adjusments_add_invoice_data_add.php",
			data: data_add,
			success: function(html){

				$(".check").html(html);
				
					var serial=0;
					$(".product_wrapper").each(function(){
						var product_name_view = $('.product_wrapper:eq('+serial+')').find(".product_name_view").html();
						validity_check(product_name_view,32);
						var product_id_view = $('.product_wrapper:eq('+serial+')').find(".product_id_view").html();
						validity_check(product_id_view,32);
						var products_company_view = $('.product_wrapper:eq('+serial+')').find(".products_company_view").html();
						validity_check(products_company_view,32);
						var quantity_view = $('.product_wrapper:eq('+serial+')').find(".quantity_view").val();
						validity_check(quantity_view,32);
						var size_view = $('.product_wrapper:eq('+serial+')').find(".size_view").html();
						validity_check(size_view,32);
						var unit_price_view = $('.product_wrapper:eq('+serial+')').find(".unit_price_view").html();
						validity_check(unit_price_view,32);
						var sub_total_view = $('.product_wrapper:eq('+serial+')').find(".sub_total_view").html();
						validity_check(sub_total_view,32);
						var discount_view = $('.product_wrapper:eq('+serial+')').find(".discount_view").html();
						validity_check(discount_view,32);
						var sub_net_view = $('.product_wrapper:eq('+serial+')').find(".sub_net_view").html();
						validity_check(sub_net_view,32);
						var tax_view = $('.product_wrapper:eq('+serial+')').find(".tax_view").html();
						validity_check(tax_view,32);
						
						var tax_percent_view = $('.product_wrapper:eq('+serial+')').find(".tax_percent_view").val();
						validity_check(tax_percent_view,32);
						var sell_price_view = $('.product_wrapper:eq('+serial+')').find(".sell_price_view").html();
						validity_check(sell_price_view,32);
						var warranty_guarantee_days_view = $('.product_wrapper:eq('+serial+')').find(".warranty_guarantee_days_view").html();
						validity_check(warranty_guarantee_days_view,32);
						var warranty_guarantee_type_view = $('.product_wrapper:eq('+serial+')').find(".warranty_guarantee_type_view").html();
						validity_check(warranty_guarantee_type_view,32);
						var serial_key_length_view = $('.product_wrapper:eq('+serial+')').find(".serial_key_length_view").html();
						validity_check(serial_key_length_view,32);
						var products_remarks = $('.product_wrapper:eq('+serial+')').find(".remarks_view").html();
						validity_check(products_remarks,32);
						
						var dataStri ='super_user='+ super_user+'&company_use='+ company_use+'&operator='+ operator+'&vendor_email_add='+ vendor_email_add+'&mobile_no_add='+ mobile_no_add+'&telephone_no_add='+ telephone_no_add+'&invoice_no_add='+invoice_no_add+ '&product_name_view='+ product_name_view+'&product_id_view='+ product_id_view+'&products_company_view='+ products_company_view+'&quantity_view='+ quantity_view+'&size_view='+ size_view+'&unit_price_view='+ unit_price_view+'&sub_total_view='+ sub_total_view+'&discount_view='+ discount_view+'&sub_net_view='+ sub_net_view+'&tax_view='+ tax_view+'&tax_percent_view='+ tax_percent_view+'&sell_price_view='+ sell_price_view+'&warranty_guarantee_days_view='+ warranty_guarantee_days_view+'&warranty_guarantee_type_view='+ warranty_guarantee_type_view+'&serial_key_length_view='+ serial_key_length_view+'&products_remarks='+ products_remarks+'&vendor_id_add='+ vendor_id_add;
						var print_sn=serial+1;
						var print_products_title=product_name_view+" "+size_view;
						var print_products="<tr><td>"+print_sn+"</td><td class='text-right'>"+print_products_title+"</td><td class='text-right'>"+quantity_view+"</td><td class='text-right'>"+unit_price_view+"</td><td class='text-right'>"+discount_view+"</td><td class='text-right'>"+tax_view+"</td><td class='text-right'>"+sub_net_view+"</td><td class='text-right'>"+warranty_guarantee_type_view+"</td><td class='text-right'>"+warranty_guarantee_days_view+"</td></tr>";
						$(".print_products_details").append(print_products);
						$.ajax({
							type: "POST",
							url: "add/adjusments_add_invoice_product_add.php",
							data: dataStri,
							success: function(html){
							$(".check").after(html);
							}		
						});
						serial++;
					});
					<?php if($serial_use=='Yes'){?>
					var serial_key_count=0;
					$(".all_serials_view").each(function(){
					
						var product_id_find=$(this).closest('.product_wrapper').find(".product_id_view").html();
						validity_check(product_id_find,32);
						var serial_key_add_now=0;
						$(this).closest('.product_wrapper').find(".serial").each(function(){
							
							var serial_key_find =$(this).closest('.product_wrapper').find('.serial:eq('+serial_key_add_now+')').text();
							validity_check(serial_key_find,32);
							var dataStri ='super_user='+ super_user+'&company_use='+ company_use+'&operator='+ operator+'&invoice_no_add='+ invoice_no_add+'&product_id_find='+ product_id_find +'&serial_key_find='+ serial_key_find + '&vendor_id_add='+ vendor_id_add;
												
							$.ajax({
							type: "POST",
							url: "add/adjusments_add_invoice_serial_key_add.php",
							data: dataStri,
							success: function(html){
								$(".check").after(html);				
								}		
							});
							
							serial_key_add_now++;
						});
						//alert(serial_key_count);
						serial_key_count++;
						
					})
					<?php }?>
					var msg=$(".check").html();
					$(".print_invoice_no").html(msg);
					alert(msg);
				}		
			});
			}
			});
			//$(".purchase_add").attr("disabled", "disabled");
			/*$("body").ajaxStop(function() {
				var success="Success";
				alert(success);
			});*/
			$(".print").click(function(e){
				e.preventDefault();
				var print_vendor_name=$("#full_name").val();
				$(".print_vendor_name").html(print_vendor_name);
				var print_vendor_address=$("#vendor_address").val();
				$(".print_vendor_address").html(print_vendor_name);
				var print_vendor_mobile=$("#mobile_no").val();
				$(".print_vendor_mobile").html(print_vendor_mobile);
				var print_vendor_email=$("#vendor_email").val();
				$(".print_vendor_email").html(print_vendor_email);
				var print_vendor_telephone=$("#telephone_no").val();
				$(".print_vendor_telephone").html(print_vendor_telephone);
				
				var print_grand_total=$(".grand_total").val();
				$(".print_grand_total").html(print_grand_total);
				var print_tax=$(".tax").val();
				$(".print_tax").html(print_tax);
				var print_discount_total=$(".discount_total").val();
				$(".print_discount_total").html(print_discount_total);
				var print_total=$(".total").val();
				$(".print_total").html(print_total);
				var print_now_payment=$(".now_payment").val();
				$(".print_now_payment").html(print_now_payment);
				var print_due=$(".due").val();
				$(".print_due").html(print_due);
				var print_total_net=$(".total_net").val();
				$(".print_total_net").html(print_total_net);
				
				window.print();
			   
				
			});
			$('.reset').click(function() {
				location.reload();
			});
		})
		
	});
	</script>
	
  </head>
  <body>
  <div class="check"></div>
  <div class="invoice_edit_take"></div>
  
	<span class="print_class_hide"><?php include_once('software_menu.php');?></span>
	<span class="print_class_hide"><?php include_once('software_header.php');?></span>
	<div id="vendor_about"></div>
	<div id="product_detail"></div>
	<div id="serial_use"><?php echo $serial_use;?></div>
	<div class="container-fluid border_bottom color z_index print_class_hide">
		<input type="hidden" value="<?php echo $company_now?>" id="com_now">
	</div>
	<div class="container style print_class_hide">
		<div style="color:#f6f6f6;padding-top:15px;padding-bottom:15px;" class="row">
			<div class="col-md-8 col-sm-8 previous_business_show">
				
			</div>
			<div class="col-md-2  col-sm-2">
				
			</div>
			<div class="col-md-2  col-sm-2">
				<button style="width:100% !important;" class="stock_reset purchase_filter_style">Stock Reset</button>
			</div>
		</div>
	</div>
	<div style="display:none;" class="container border_style print_class_hide">
		<div class="row vendor_information">
			<div class="col-md-12 col-sm-12">
					Amount
			</div>
		</div>
		<div class="row input_div_padding">
		<div style="display:none;"  class="col-md-6 col-sm-6">
		<div class="row overflow_top_left back_color">
		<?php if($user_type_now=="Only_Purchase"){
			$edit="readonly";				
		}else{
			$edit="";		
		}
		?>
			<div class="about_vendor">
			<div class="col-md-6 col-sm-6">
				<label class="label_class">Email</label>
				<?php if($vendor_primary_key=="Email"){
				?>
				<input type="email" class="input " id="vendor_email">
				<?php
				}else{
				?>
				<input type="email" class="input" id="vendor_email" <?php $edit;?>>
				<?php
				}
				?>
				
				
			</div>
			<div class="col-md-6 col-sm-6">
				<label class="label_class">Mobile No</label>
				<?php if($vendor_primary_key=="Mobile"){
				?>
				<input type="number" class="input  purchase_m_search" id="mobile_no" >
				<?php
				}else{
				?>
				<input type="number" class="input purchase_m_search" id="mobile_no"  <?php $edit;?>>
				<?php
				}
				?>
			</div>
			<div class="col-md-6 col-sm-6">
				<label class="label_class">Telephone</label>
				<?php if($vendor_primary_key=="Telephone"){
				?>
				<input type="number" class="input"  id="telephone_no"  >
				<?php
				}else{
				?>
				<input type="number" class="input" id="telephone_no"   <?php $edit;?>>
				<?php
				}
				?>
				
			</div>
			<div class="col-md-6 col-sm-6">
				<label class="label_class">Full Name</label>
				
				<input type="text" class="input " id="full_name"   <?php $edit;?>>
			</div>
			<div class="col-md-12 col-sm-12">
				<label class="label_class">Address</label>
				<input type="text" class="address_input " id="vendor_address"   <?php $edit;?>>
			</div>
			<div class="col-md-6 col-sm-6">
				<label class="label_class">Vendors Company Name</label>
				<input type="text" class="input " id="company_name"   <?php $edit;?>>
			</div>
			<div class="col-md-6 col-sm-6">
				<label class="label_class">Debit Limit</label>
				<input type="number" class="input " id="debit_limit"   <?php $edit;?>>
			</div>
			<div class="col-md-6 col-sm-6">
				<label class="label_class">Debit Days</label>
				<input type="number" class="input " id="debit_days"   <?php $edit;?>>
			</div>
			<div class="col-md-6 col-sm-6">
				<input type="hidden" class="input" id="serial_id" value="0">
				<input type="hidden" class="input" id="token_one">
			</div>
			</div>
			<div class="col-md-12 col-sm-12">
				<div class="row" id="vendor_search_toggle">
					<div class="col-xs-12 col-sm-12 col-md-12">
						<h3>Search By : </h3>
					</div>
					<div class="col-xs-12 col-sm-6 col-md-6">
						<input type="text" name="search_name" id="search_name" class="form-control input-sm" placeholder="Full Name">
					</div>
					<div class="col-xs-12 col-sm-6 col-md-6">
						<input type="text" name="search_company" id="search_company" class="form-control input-sm" placeholder="Company Search">
					</div>
					<div class="col-xs-12 col-sm-12 col-md-12">
						<input type="text" name="search_address" id="search_address" class="form-control input-sm" placeholder="Address Search">
					</div>
					<div class="col-xs-12 col-sm-12 col-md-12">
						<div id="search_details"></div>
						<input type="hidden" class="input" id="token_three">
					</div>
				</div>
				<button type="button" class="btn btn-default" id="vendor_search">Search</button>
			</div>
		</div>
		</div>
		<div  class="col-md-12 col-sm-12 color">
		<div class="row padding overflow_top_left">
			<div style="display:none;"  class="col-md-6 col-sm-6">
				<label class="label_class">Delivary date</label>
				<input type="date" class="input delivary_date"  value="<?php echo $var_date;?>">
			</div>
			<div style="display:none;"  class="col-md-6 col-sm-6 color">
				<label  class="label_class">Grand Total</label>
				<input type="text" class="input grand_total"  value="0" readonly>
			</div>
			<div style="display:none;"  class="col-md-6 col-sm-6">
				<label class="label_class">Discount</label>
				<input type="text" class="input discount_total" value="0">
			</div>
			<div class="col-md-6 col-sm-6">
				<label class="label_class">Total</label>
				<input type="text" class="input total" value="0" readonly>
			</div>
			<div style="display:none;"  class="col-md-6 col-sm-6">
				<label class="label_class">Payment</label>
				<input type="number" class="input now_payment" value="0">
			</div>
			<div style="display:none;"  class="col-md-6 col-sm-6">
				<label class="label_class">Payment method</label>
				<select style="height:24px;" class="input payment_method">
					<option class="payment_method_one">Cash Payment</option>
					<option class="payment_method_two">Check Payment</option>
					<option class="payment_method_three">Online Payment</option>
				</select>
			</div>
			<div style="display:none;"  class="col-md-6 col-sm-6">
				<label class="label_class">Bank name</label>
				<input type="text" class="input bank_name"/>
			</div>
			<div style="display:none;"  class="col-md-6 col-sm-6">
				<label class="label_class">Account No</label>
				<input type="text" class="input account_no">
			</div>
			<div style="display:none;"  class="col-md-6 col-sm-6">
				<label class="label_class">Due</label>
				<input type="number" class="input due" value="0" readonly>
			</div>
			<div style="display:none;"  class="col-md-6 col-sm-6">
				<label class="label_class">Due payment date</label>
				<input type="date" class="input due_payment_date" value="<?php echo $var_date;?>">
			</div>
			<div style="display:none;"  class="col-md-6 col-sm-6">
				<label class="label_class">Tax</label>
				<input type="text" class="input tax" value="0" readonly>
			</div>
			<div style="display:none;"  class="col-md-6 col-sm-6">
				<label class="label_class">Caring cost</label>
				<input type="number" class="input caring_cost" value="0">
			</div>
			<div class="col-md-6 col-sm-6">
				<label class="label_class">Others cost</label>
				<input type="number" class="input others_cost" value="0">
			</div>
			<div style="display:none;"  class="col-md-6 col-sm-6">
				<label class="label_class">Intensive</label>
				<input type="text" class="input insentive" value="0">
			</div>
			<div class="col-md-6 col-sm-6">
				<label class="label_class">Total Net</label>
				<input type="text" class="input total_net" value="0" readonly>
			</div>
			<div class="col-md-6 col-sm-6">
				<label class="label_class">Remarks</label>
				<input type="text" class="input remarks">
			</div>
			<input type="hidden" class="input" id="token_four">
		</div>
		</div>
		</div>
	</div>
	<div class="container border_style print_class_hide">
		<div class="row vendor_information">
			<div class="col-md-12 col-sm-12">
					Products
			</div>
		</div>
		<div class="row input_div_padding">
		<div class="col-md-12 col-sm-12">
		<div class="row">
			<div class="col-md-6 col-sm-6">
				<label class="label_class">Product Title</label>
				<input type="text" class="input " id="product_title">
			</div>
			<div class="col-md-6 col-sm-6">
				<label class="label_class">Products id</label>
				<?php if($barcode=="Yes"){
				?>
				<input type="text" class="input" id="product_id" placeholder="Id">
				<?php
				}else{
				?>
				<input type="text" class="input" id="product_id" placeholder="Id generate when submit" <?php echo $edit;?>>
				<?php
				}
				?>
				
			</div>
			<div  class="col-md-6 col-sm-6">
				<label class="label_class">Products name</label>
				<?php if($barcode=="No"){
				?>
				<input type="text" class="input" id="product_name" >
				<?php
				}else{
				?>
				<input type="text" class="input" id="product_name" <?php echo $edit;?>>
				<?php
				}
				?>
				
			</div>
			<div  class="col-md-6 col-sm-6">
				<label class="label_class">Size</label>
				<input type="text" class="input " id="size"  <?php echo $edit;?>>
			</div>
			
			<div class="col-md-6 col-sm-6">
				<label class="label_class">Quantity</label>
				<input type="number" class="input " id="quantity"  <?php echo $edit;?>>
			</div>
			
			<div  style="display:none;" class="col-md-6 col-sm-6">
				<label class="label_class">Products Company</label>
				<input type="text" class="input " id="products_company"  <?php echo $edit;?>>
			</div>
			<div  style="display:none;" class="col-md-6 col-sm-6">
				<label class="label_class">Unit price</label>
				<input type="number" class="input " id="unit_price"  <?php echo $edit;?>>
			</div>
			<div  style="display:none;" class="col-md-6 col-sm-6">
				<label class="label_class">Sub total</label>
				<input type="number" class="input " id="sub_total" readonly>
			</div>
			<div  style="display:none;" class="col-md-6 col-sm-6">
				<label class="label_class">Discount</label>
				<input type="text" class="input " id="discount"  <?php echo $edit;?>>
			</div>
			<div  style="display:none;" class="col-md-6 col-sm-6">
				<label class="label_class">Net</label>
				<input type="text" class="input " id="sub_net" readonly>
			</div>
			<div  style="display:none;" class="col-md-6 col-sm-6">
				<label class="label_class">Tax</label>
				<input type="text" class="input " id="product_tax"  <?php $edit;?>>
			</div>
			<div  style="display:none;" class="col-md-6 col-sm-6">
				<label class="label_class">Sell price</label>
				<input type="text" class="input "  id="sell_price"  <?php echo $edit;?>>
			</div>
			
			
			<div  style="display:none;" class="col-md-6 col-sm-6 <?php echo $hide;?>">
				<label class="label_class">Warranty/Guarantee Days</label>
				<input type="number" class="input "  id="warranty_guarantee_days"  <?php echo $edit;?>>
			</div>
			<div  style="display:none;" class="col-md-6 col-sm-6 <?php echo $hide;?>">
				<label class="label_class">Warranty/Guarantee Type</label>
				<select style="height:24px;" class="input "  id="warranty_guarantee_type"  <?php echo $edit;?>>
					<option id="warranty_guarantee_type_one">None</option>
					<option id="warranty_guarantee_type_two">Warranty</option>
					<option id="warranty_guarantee_type_three">Guarantee</option>
				</select>
			</div>
			<div  style="display:none;" class="col-md-6 col-sm-6">
				<label class="label_class">Remarks</label>
				<input type="text" class="input " id="remarks"  <?php echo $edit;?>>
			</div>
			<?php if($serial_key=="Yes"){
				$hide="";
				}else{
				$hide='hide';
				}
				
			?>
			<div  style="display:none;" class="col-md-6 col-sm-6 <?php echo $hide;?>">
				<label class="label_class">Serial key length</label>
				<input type="number" class="input " id="serial_key_length"  <?php echo $edit;?>>
			</div>
			<div  style="display:none;" class="col-md-6 col-sm-6 <?php echo $hide;?>">
				<label class="label_class">Serial key</label>
				<input type="text" class="input " id="serial_key" >
			</div>
			<div  style="display:none;" class="col-md-6 col-sm-6 serial_key_class <?php echo $hide;?>">
				<div class="all_serials"  id="all_serials" >
					<div class="serials serials_insert" ></div>
				</div>
			</div>
			<div class="serial_key_products_quantity"></div>
			<div class="col-md-12 col-sm-12">
				<button type="button" class="save btn btn-default "  id="products_add" >Add</button>
			</div>
		</div>
		</div>
		<div class="col-md-12 col-sm-12 color">
		<div class="row overflow padding item">
			<div class="products_view"></div>
			<input type="hidden" class="input" id="token_five">
		</div>
		</div>
		</div>
	</div>
	<div class="container">
		<div class="row margin_top">
			<div class="col-md-5 col-sm-5 col-xs-3 print_class_hide">
				<button type="button" class="remove reset btn btn-primary">Reset</button>
			</div>
			<div class="col-md-3 col-sm-3 col-xs-4">
				<button type="button" class="print print_class_hide Addtopurchase btn btn-primary">Print</button>
			</div>
			<div class="col-md-4 col-sm-4 col-xs-4 print_class_hide">
				<button type="button" class="add_order btn btn-primary invoice_add">Invoice</button>
			</div>
		</div>
	
	</div>
	<div class="container print_class">
      <div class="row">
        <div class="col-xs-6">
          <h1>
            <h2><?php echo $company;?></h2>
            <img width="80px" height="80px" src="../inventory-software.png">
            
            </a>
          </h1>
        </div>
        <div class="col-xs-6 text-right">
          <h1>PURCHASE INVOICE</h1>
          <h1><small><span class="print_invoice_no"></span></small></h1>
        </div>
      </div>
      <div class="row">
        <div class="col-xs-5">
          <div class="panel panel-default">
            <div class="panel-heading">
              <h4>From: <span class="print_vendor_name"></span></h4>
            </div>
            <div class="panel-body">
			  <p>
                Mobile : <span class="print_vendor_mobile"></span><br>
                Email : <span class="print_vendor_email"></span><br>
				Telephone : <span class="print_vendor_telephone"></span><br>
				Address : <span class="print_vendor_address"></span><br>
              </p>
            </div>
          </div>
        </div>
        <div class="col-xs-5 col-xs-offset-2 text-right">
          <div class="panel panel-default">
            <div class="panel-heading">
              <h4>To : <?php echo $company;?></h4>
            </div>
            <div class="panel-body">
              <p>
                 Address :	<?php echo $address;?> <br>
              </p>
            </div>
          </div>
        </div>
      </div>
      <!-- / end client details section -->
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>
              <h4>Sn</h4>
            </th>
            <th>
              <h4>Description</h4>
            </th>
            <th>
              <h4>Hrs/Qty</h4>
            </th>
            <th>
              <h4>Rate/Price</h4>
            </th>
			<th>
              <h4>Discount</h4>
            </th>
			<th>
              <h4>Tax</h4>
            </th>
            <th>
              <h4>Sub Total</h4>
            </th>
			<th>
              <h4>Service Type</h4>
            </th>
            <th>
              <h4>Service Days</h4>
            </th>
          </tr>
        </thead>
        <tbody  class="print_products_details">
		<!--<span class="print_products_details"></span>-->
		
          
        </tbody>
      </table>
      <div class="row text-right">
        <div class="col-xs-2 col-xs-offset-8">
          <p>
            <strong>
            Sub Total : <br>
            TAX : <br>
			Discount : <br>
            Total : <br>
			Payments : <br>
			Due : <br>
			Net : <br>
            </strong>
          </p>
        </div>
        <div class="col-xs-2">
          <strong>
          <span class="print_grand_total"></span> <br>
         <span class="print_tax"></span> <br>
          <span class="print_discount_total"></span> <br>
		  <span class="print_total"></span> <br>
         <span class="print_now_payment"></span> <br>
          <span class="print_due"></span> <br>
		  <span class="print_total_net"></span> <br>
          </strong>
        </div>
      </div>
      <div class="row">
        <div class="col-xs-5">
          <div class="panel panel-info">
            <div class="panel-heading">
              <h4>Previous Business</h4>
            </div>
            <div class="panel_body">
              
            </div>
          </div>
        </div>
        <div class="col-xs-7">
          <div class="span7">
            <div class="panel panel-info">
              <div class="panel-heading">
                <h4>Contact Details</h4>
              </div>
              <div class="panel-body">
                <p>
                  Email : <?php echo $company_email;?> 
                  Mobile : <?php echo $company_mobile;?> 
				  Telephone : <?php echo $company_telephone;?> 
				
                </p>
                
              </div>
            </div>
          </div>
        </div>
      </div>
	  <div class="row">
		<h4 class="purchase_invoice_msg"><?php echo $purchase_invoice_msg;?></h4>
	  </div>
    </div>
	<!--<div class="container print_class_hide">
		<div class="row">
			<button class="print btn btn-success">Print</button> 
			
		</div>
	</div>-->
    
  </body>
</html>
<?php
}else{
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Please Login</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="design.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="../inventory-software.png">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<script src="javascript.js"></script>
	
	</head>
  <body>
  <?php include_once('client_header.php');?>
  <h1 class="client_login_title">You have not permit to access this page</h1>
  </body>
</html>
<?php
}
}else{
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Please Login</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="design.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="../inventory-software.png">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<script src="javascript.js"></script>
	
	</head>
  <body>
  <?php include_once('client_header.php');?>
  <h1 class="client_login_title">Something wrong.Please <a href="index.php">login</a></h1>
  </body>
</html>
<?php
}
?>