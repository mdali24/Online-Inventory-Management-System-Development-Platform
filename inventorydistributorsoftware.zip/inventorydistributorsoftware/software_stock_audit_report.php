<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include_once('db.php');
session_start();
session_regenerate_id(TRUE);
if(isset($_SESSION['user_session']) and isset($_SESSION['company_username_session']) and isset($_SESSION['sub_user_session'])){
	$user_type_now=$_SESSION['user_session'];
	$company_now=$_SESSION['company_username_session'];
	$user_now=$_SESSION['sub_user_session'];
	$status=1;
	$query = "SELECT email,company_name,company_timezone,vendor_primary_key FROM companies_onserial WHERE company_username=? and status=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param("si",$company_now,$status);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($email,$company_name,$company_timezone,$vendor_primary_key);
	$stmt->fetch();
	$super_email=$email;
	$company=$company_name;
	$company_timezone=$company_timezone;
	$vendor_primary_key=$vendor_primary_key;
	}
	if($user_type_now=='Super'){
	$user_now=$super_email;
	}
	
 date_default_timezone_set($company_timezone);//problem
 $var_date= date('y/m/d') ;
if($user_type_now=="Super" or $user_type_now=="Master"){//Master Admin bad jabe only For Super Admin

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title><?php echo $company;?></title>
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<script src="auto/jquery-ui.min.js"></script>
	<link href="auto/jquery-ui.min.css" rel="stylesheet">
	<script>
	$(document).ready(function() {
		$(".search_product").click(function(e){
		e.preventDefault();
			var product_search=$(".product_search").val();
			if(product_search.match(/^\d+$/)) {
				var search_type="id";
			}else{
				var search_type="name";
			}
			
			var company="<?php echo $company_now;?>";
			var data_key='product_search='+ product_search+'&search_type='+ search_type+'&company='+ company;
			
			$.ajax({
				type: "POST",
				url: "fill/search_product_stock_now.php",
				data: data_key,
				success: function(html){
					$(".search_product_now").html(html);
					}		
				});
		});
		var com_now="<?php echo $company_now;?>";
		$(function() {
			$("#product_title").autocomplete({
				source: "auto/vendor_product_title_search.php?company="+"'"+com_now+"'",
				minLength: 2
			});				
		});
	})
	</script>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="design.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="../inventory-software.png">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	
  </head>
  <body>
  <?php
	$query = "SELECT pakage,year,date FROM login_onserial WHERE email=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$super_email);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($pakage,$year,$date);
	$stmt->fetch();
	$softpakage=$pakage;
	$year=$year;
	$date=$date;
	$yearto=substr($date,0,4);
	$monthto=substr($date,5,2);
	$dateto=substr($date,8,2);
	$year_num=(int)$yearto;
	$year_up=$year_num+$year;
	if($monthto==2 and $dateto==29){
		$monthto=03;
		$dateto=01;
	}
	$up_date="$year_up"."/"."$monthto"."/"."$dateto";
	$up_to_time=strtotime($up_date);
	$expired_date=date('Y-m-d',$up_to_time);
	$today=date("Y-m-d");
	
	$today_strtotime=strtotime($today);
	$expired_strtotime=strtotime($expired_date);
	if($softpakage=='Free'){
		$warehouse=1;
		$users=1;
	}else if($softpakage=='Silver'){
		$warehouse=1;
		$users=1;
	}else if($softpakage=='Gold'){
		$warehouse=10;
		$users=20;
	}else if($softpakage=='Diamond'){
		$warehouse=50;
		$users=100;
	}
	$stmt->free_result();
		$stmt->close();
	}
	$query = "SELECT vendor_primary_key FROM companies_onserial WHERE company_username=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$company_now);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($vendor_primary_key);
	$stmt->fetch();
	if($vendor_primary_key=='Email'){
		$vendor_primary_key='markenter_email';
	}else if($vendor_primary_key=='Mobile'){
		$vendor_primary_key='vendor_mobile_no';
	}else if($vendor_primary_key=='Telephone'){
		$vendor_primary_key='vendor_telephone_no';
	}
	$stmt->free_result();
		$stmt->close();
	}
	
	if(!empty($_POST['company'])){
	$company_filter=$_POST['company'];
	}else{
		$company_filter="empty";
	}
	if(!empty($_POST['asc_desc'])){
		$asc_desc=$_POST['asc_desc'];
		if($asc_desc=='Low'){
			$asc_desc_check="ASC";
			$serial="current_stock";
		}else if($asc_desc=='High'){
			$asc_desc_check="DESC";
			$serial="current_stock";
		}else{
			$asc_desc_check="ASC";
			$serial="sn";
		}
	}else{
		$asc_desc="";
		$asc_desc_check="ASC";
		$serial="sn";
		
	}

	if(!empty($_POST['display'])){
		$display=$_POST['display'];
		if($display=='Display All'){
			$display_check="";
		}else{
			$display_now=$display;
			$display_check="exist";
		}
	}else{
		$display="";
		$display_now=20;
		$display_check="exist";
		
	}
	if(!empty($_POST['page_no'])){
		$page_no=$_POST['page_no'];
	}else{
		$page_no=1;
		
	}
	if(!empty($_POST['page_filter'])){
		$page_filter=$_POST['page_filter'];
		if($page_filter=='Next'){
			$go=$page_no+1;
		}else if($page_filter=='Previous'){
			$go=$page_no-1;
		}else if($page_filter=='Reset'){
			$go=1;
		}else{
			$go=$page_no;
		}
	}else{
		$page_filter="";
		$go=1;
	}
	if($go<1){
		$go=1;
		$message="This is first page.Can not go to previous.";
	}else{
		$message="";
	}
	$num_of_rows_now=0;
	?>
	<?php include_once('software_menu.php');?>
	<?php include_once('software_header.php');?>
	<div class="container-fluid border_bottom color z_index">
		<!--<h2>Vendor Management</h2>-->	
	</div>
	
	<div class="container-fluid">
		<div class="row">
		<div class="div_padding">
			<form action="software_stock_filter.php" method="POST">
			<input type="hidden" name="company" value="<?php echo $company_now;?>">
			<div style="display:none;" class="col-md-12 col-sm-12">
			<select id="secuence" name="asc_desc"  class="purchase_filter_style" >
				<?php if(strlen($asc_desc)>0){
					echo "<option value=\"$asc_desc_check\">$asc_desc_check</option>";
				}?>
					<option value="General">General</option>
					<option value="Low">Low</option>
					<option value="High">High</option>
					
				</select>
			
				<select id="secuence" name="display"  class="purchase_filter_style" >
				<?php if(strlen($display)>0){
					echo "<option value=\"$display\">$display</option>";
				}?>
					<option value="20">20</option>
					<option value="50">50</option>
					<option value="100">100</option>
					<option value="Display All">Display All</option>
				</select>
				<input type="hidden" name="page_no" value="<?php echo $go;?>">
				<select id="secuence" name="page_filter"  class="purchase_filter_style" >
				<?php if(strlen($page_filter)>0){
					echo "<option value=\"$page_filter\">$page_filter</option>";
				}?>
					<option value="Current">Current</option>
					<option value="Next">Next</option>
					<option value="Previous">Previous</option>
					<option value="Reset">Reset</option>
					
				</select>
				
			<input type="submit" class="purchase_filter_style" value="Filter">
			</form>
		</div>
		</div>
		
			<div class="col-md-12">
				<div class="search_purchase_invoice_now"></div>
				  <div class="wrapper">
					  <div class="table">
						
						
					<?php 
					$page=$go;
					if(strlen($display_check)>0){
						$range=$display_now;
						$start=($page*$range)-$range;
						$next=$page+1;
						$previus=$page-1;
						$limit=" limit $start,$range";
					}else{
						$limit="";
					}
					if($stmt_sql = $mysqli->prepare("SELECT * FROM stock_now_onserial WHERE company_username=? and stock_check>0 ORDER BY $serial $asc_desc_check")){
						
					$stmt_sql->bind_param("s",$company_now);
					$stmt_sql->execute();
					$stmt_sql->store_result();
					$num_of_rows_now = $stmt_sql->num_rows;
					$stmt_sql->fetch();
					
					if($stmt_sql_all_stock = $mysqli->prepare("SELECT * FROM stock_now_onserial WHERE company_username=?  ORDER BY $serial $asc_desc_check")){
						
					$stmt_sql_all_stock->bind_param("s",$company_now);
					$stmt_sql_all_stock->execute();
					$stmt_sql_all_stock->store_result();
					$num_of_rows_now_all_stock = $stmt_sql_all_stock->num_rows;
					$stmt_sql_all_stock->fetch();
					}
					if($num_of_rows_now<1){
						echo "<p style=\"margin:0;padding:0;\">No entry for check : </p>";
					}else{
						echo "<p style=\"margin:0;padding:0;\">Total Stock Item : ".$num_of_rows_now_all_stock." and Total Entry Item : ".$num_of_rows_now."</p>";
					}
					
					}
					if($num_of_rows_now>0){
					if($stmt_sql = $mysqli->prepare("SELECT product_id,total_purchase,current_stock,stock_check,total_sell,purchase_return,sell_return,damage,warranty,sell_warranty FROM stock_now_onserial WHERE company_username=? ORDER BY $serial $asc_desc_check $limit")){
						
					$stmt_sql->bind_param("s",$company_now);
					$stmt_sql->execute();
					$stmt_sql->store_result();
					$num_of_rows_now = $stmt_sql->num_rows;
					
					$stmt_sql->bind_result($product_id,$total_purchase,$current_stock,$stock_check,$total_sell,$purchase_return,$sell_return,$damage,$warranty,$sell_warranty);
					if($num_of_rows_now > 0){
					?>
					<div class="tb_header">
						  <div class="cell">
							Sn
						  </div>
						  <div class="cell">
							Product id
						  </div>
						  <div class="cell">
							Product title
						  </div>
						  <div class="cell">
							Stock Short
						  </div>
						  <div class="cell">
							Stock Over
						  </div>
						  <div class="cell">
							Current Stock
						  </div>
						  <div class="cell">
							Check Entry
						  </div>
						  
						</div>
					<?php
						$sn=1;
						$stock_short_counter=0;
						$stock_short_total=0;
						$stock_over_counter=0;
						$stock_over_total=0;
						$ok_items=0;
						$ok_total=0;
						while($stmt_sql->fetch()){
							if($current_stock!=$stock_check){
							echo "<div class=\"tb_row\">";
							echo "<div class=\"cell\">".$sn."</div>";
							echo "<div class=\"cell\">".$product_id."</div>";
							
							if($stmt_name = $mysqli->prepare("SELECT product_title FROM products_details_onserial WHERE company_username=? and  product_id=? ORDER BY sn DESC")) {
							$stmt_name->bind_param("ss",$company_now,$product_id);
							$stmt_name->execute();
							$stmt_name->store_result();
							$num_of_rows = $stmt_name->num_rows;
							$stmt_name->bind_result($product_title);
							$stmt_name->fetch();
							
							echo "<div class=\"cell\">".$product_title."</div>";
							}
							if($current_stock>$stock_check){
								$stock_short=$current_stock-$stock_check;
								$stock_over=0;
								echo "<div class=\"cell\">".$stock_short."</div>";
								echo "<div class=\"cell\">".$stock_over."</div>";
								$stock_short_counter++;
								$stock_short_total+=$stock_short;
							}
							if($current_stock<$stock_check){
								$stock_short=0;
								$stock_over=$stock_check-$current_stock;
								echo "<div class=\"cell\">".$stock_short."</div>";
								echo "<div class=\"cell\">".$stock_over."</div>";
								$stock_over_counter++;
								$stock_over_total+=$stock_over;
							}
							echo "<div class=\"cell\">".$current_stock."</div>";
							echo "<div class=\"cell\">".$stock_check."</div>";
						
							echo "</div>";
							$sn++;
							}else{
								$ok_items++;
								$ok_total+=$current_stock;
							}
							}
					}else{
						echo "<div class=\"tb_row\">";
							echo "No stock entry";
						echo "</div>";
					}
					}
					echo "Stock match : ".$ok_items." items And ".$ok_total." piches</br>";
					echo "Stock short : ".$stock_short_counter." items And ".$stock_short_total." piches</br>";
					echo "Stock over : ".$stock_over_counter." items And ".$stock_over_total." piches";
					}else{
	
					}
					
						?>
					  
					</div>
				  
				</div>
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<div class="row">
			<div style="padding:30px;" class="">
				<div class="col-md-6 col-sm-6">
					 <textarea class="form-control" id="stock_audit_remarks" rows="4">Remarks : Max 400 character</textarea>
				</div>
				<div class="col-md-6 col-sm-6">
					 <button style="margin-top:35px;" class="form-control purchase_filter_style" id="stock_audit_end">Adjust and Complete Audit</button>
				</div>
			</div>
		</div>
	</div>
  </body>
</html>
<?php
}else{
echo "You have not permit to access this page";
}
}else{
    echo "Something wrong.Please <a href=\"index.php\">login</a>";
}
?>