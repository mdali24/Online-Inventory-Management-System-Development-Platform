<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include_once('db.php');
session_start();
session_regenerate_id(TRUE);
if(isset($_SESSION['user_session']) and isset($_SESSION['company_username_session']) and isset($_SESSION['sub_user_session'])){
	$user_type_now=$_SESSION['user_session'];
	$company_now=$_SESSION['company_username_session'];
	$user_now=$_SESSION['sub_user_session'];
	$status=1;
	$query = "SELECT email,company_name,company_timezone,vendor_primary_key FROM companies_onserial WHERE company_username=? and status=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param("si",$company_now,$status);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($email,$company_name,$company_timezone,$vendor_primary_key);
	$stmt->fetch();
	$super_email=$email;
	$company=$company_name;
	$company_timezone=$company_timezone;
	$vendor_primary_key=$vendor_primary_key;
	}
	if($user_type_now=='Super'){
	$user_now=$super_email;
	}
	
 date_default_timezone_set('Asia/Dhaka');//problem
 $var_date= date('y/m/d') ;
if($user_type_now=="Super" or $user_type_now=="Master" or $user_type_now=="Purchase_Master"){

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title><?php echo $company;?></title>
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<script src="auto/jquery-ui.min.js"></script>
	<link href="auto/jquery-ui.min.css" rel="stylesheet">
	<script>
	$(document).ready(function() {
		$(".search_product").click(function(e){
		e.preventDefault();
			var product_search=$(".product_search").val();
			if(product_search.match(/^\d+$/)) {
				var search_type="id";
			}else{
				var search_type="name";
			}
			
			var company="<?php echo $company_now;?>";
			var data_key='product_search='+ product_search+'&search_type='+ search_type+'&company='+ company;
			
			$.ajax({
				type: "POST",
				url: "fill/search_product_stock_now.php",
				data: data_key,
				success: function(html){
					$(".search_product_now").html(html);
					}		
				});
		});
		var com_now="<?php echo $company_now;?>";
		$(function() {
			$("#product_title").autocomplete({
				source: "auto/vendor_product_title_search.php?company="+"'"+com_now+"'",
				minLength: 2
			});				
		});
		$(".free_new_product_Add").click(function(e) {
			 e.preventDefault();
		 
			var super_user=$(".super_user").val();
			var company_use=$(".company_use").val();
			var operator=$(".operator").val();
			var product_id_now=$("#product_id_now").val();
			var product_quantity_now=$("#product_quantity_now").val();
			var product_pack_size_now=$("#product_pack_size_now").val();
			
					var data='super_user='+ super_user+'&company_use='+ company_use+'&operator='+ operator+'&product_id_now='+ product_id_now+'&product_quantity_now='+ product_quantity_now+'&product_pack_size_now='+ product_pack_size_now;
				$.ajax({
				type: "POST",
				url: "software_unpack_products.php",
				data: data,
				success: function(html){
					$('.close').click();
					alert(html);
					}		
			});	
		 })
	})
	</script>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="design.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="../inventory-software.png">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	
  </head>
  <body>
  <?php
	$query = "SELECT pakage,year,date FROM login_onserial WHERE email=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$super_email);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($pakage,$year,$date);
	$stmt->fetch();
	$softpakage=$pakage;
	$year=$year;
	$date=$date;
	$yearto=substr($date,0,4);
	$monthto=substr($date,5,2);
	$dateto=substr($date,8,2);
	$year_num=(int)$yearto;
	$year_up=$year_num+$year;
	if($monthto==2 and $dateto==29){
		$monthto=03;
		$dateto=01;
	}
	$up_date="$year_up"."/"."$monthto"."/"."$dateto";
	$up_to_time=strtotime($up_date);
	$expired_date=date('Y-m-d',$up_to_time);
	$today=date("Y-m-d");
	
	$today_strtotime=strtotime($today);
	$expired_strtotime=strtotime($expired_date);
	if($softpakage=='Free'){
		$warehouse=1;
		$users=1;
	}else if($softpakage=='Silver'){
		$warehouse=1;
		$users=1;
	}else if($softpakage=='Gold'){
		$warehouse=10;
		$users=20;
	}else if($softpakage=='Diamond'){
		$warehouse=50;
		$users=100;
	}
	$stmt->free_result();
		$stmt->close();
	}
	$query = "SELECT vendor_primary_key FROM companies_onserial WHERE company_username=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$company_now);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($vendor_primary_key);
	$stmt->fetch();
	if($vendor_primary_key=='Email'){
		$vendor_primary_key='markenter_email';
	}else if($vendor_primary_key=='Mobile'){
		$vendor_primary_key='vendor_mobile_no';
	}else if($vendor_primary_key=='Telephone'){
		$vendor_primary_key='vendor_telephone_no';
	}
	$stmt->free_result();
		$stmt->close();
	}
	
	if(!empty($_POST['company'])){
	$company_filter=$_POST['company'];
	}else{
		$company_filter="empty";
	}
	if(!empty($_POST['asc_desc'])){
		$asc_desc=$_POST['asc_desc'];
		if($asc_desc=='Low'){
			$current_stock_check='';
			$asc_desc_check="ASC";
			$serial="current_stock";
			$current_stock_check_now="ASC";
		}else if($asc_desc=='High'){
			$current_stock_check='';
			$asc_desc_check="DESC";
			$serial="current_stock";
			$current_stock_check_now="DESC";
		}else if($asc_desc=='Zero'){
			$current_stock_check="and current_stock=0";
			$asc_desc_check="DESC";
			$serial="current_stock";
			$current_stock_check_now="Zero";
		}else if($asc_desc=='Not Zero'){
			$current_stock_check="and current_stock!=0";
			$asc_desc_check="DESC";
			$serial="current_stock";
			$current_stock_check_now="Not Zero";
		}else{
			$current_stock_check='';
			$asc_desc_check="ASC";
			$serial="sn";
			$current_stock_check_now="ASC";
		}
	}else{
		$current_stock_check='';
		$asc_desc="";
		$asc_desc_check="ASC";
		$serial="sn";
		$current_stock_check_now="ASC";
	}
	if(!empty($_POST['vendor_select'])){
		$vendor_select=$_POST['vendor_select'];
		if($vendor_select=='All Vendors'){
			$vendor_filter=" ";
		}else{
			$query_vendor = "SELECT sn FROM company_markenter_onserial WHERE company_username=? and $vendor_primary_key=? and type='vendor'"; 
			if($stmt_vendor = $mysqli->prepare($query_vendor)){
				if($vendor_primary_key=='markenter_email'){
					$stmt_vendor->bind_param('ss',$company_now,$vendor_select);
				}else{
					$stmt_vendor->bind_param('si',$company_now,$vendor_select);
				}
			$stmt_vendor->execute();
			$stmt_vendor->store_result();
			$num_of_rows = $stmt_vendor->num_rows;
			$stmt_vendor->bind_result($vendor_serial);
			$stmt_vendor->fetch();
			$vendor_filter="and vendor_sn=$vendor_serial";
			}
		}
	}else{
		$vendor_select="";
		$vendor_filter="";
		
	}
	if(!empty($_POST['display'])){
		$display=$_POST['display'];
		if($display=='Display All'){
			$display_check="";
		}else{
			$display_now=$display;
			$display_check="exist";
		}
	}else{
		$display="";
		$display_now=50;
		$display_check="exist";
		
	}
	if(!empty($_POST['page_no'])){
		$page_no=$_POST['page_no'];
	}else{
		$page_no=1;
		
	}
	if(!empty($_POST['page_filter'])){
		$page_filter=$_POST['page_filter'];
		if($page_filter=='Next'){
			$go=$page_no+1;
		}else if($page_filter=='Previous'){
			$go=$page_no-1;
		}else if($page_filter=='Reset'){
			$go=1;
		}else{
			$go=$page_no;
		}
	}else{
		$page_filter="";
		$go=1;
	}
	if($go<1){
		$go=1;
		$message="This is first page.Can not go to previous.";
	}else{
		$message="";
	}
	$num_of_rows_now=0;
	?>
	<?php include_once('software_menu.php');?>
	<?php include_once('software_header.php');?>
	<div class="container-fluid border_bottom color z_index">
		<!--<h2>Vendor Management</h2>-->	
	</div>
	
	<div class="container-fluid">
		<div class="row">
		<div class="div_padding">
			<form action="software_stock_filter.php" method="POST">
			<input type="hidden" name="company" value="<?php echo $company_now;?>">
			<div class="col-md-12 col-sm-12">
			<select id="secuence" name="asc_desc"  class="purchase_filter_style" >
				<?php if(strlen($asc_desc)>0){
					echo "<option value=\"$current_stock_check_now\">$current_stock_check_now</option>";
				}?>
					<option value="General">General</option>
					<option value="Low">Low</option>
					<option value="High">High</option>
					<option value="Zero">Zero</option>
					<option value="Not Zero">Not Zero</option>
				</select>
			
				<select id="secuence" name="display"  class="purchase_filter_style" >
				<?php if(strlen($display)>0){
					echo "<option value=\"$display\">$display</option>";
				}?>
					<option value="50">50</option>
					<option value="100">100</option>
					<option value="Display All">Display All</option>
				</select>
				<select id="vendor_select" name="vendor_select"  class="purchase_filter_style" >
				<?php if(strlen($vendor_select)>0){
					echo "<option value=\"$vendor_select\">$vendor_select</option>";
				}?>
				<option value="All Vendors">All Vendors</option>
				<?php
				if($stmt_sql = $mysqli->prepare("SELECT $vendor_primary_key FROM company_markenter_onserial WHERE company_username=? and type='vendor' ORDER BY sn DESC")){
					
					$stmt_sql->bind_param("s",$company_now);
					$stmt_sql->execute();
					$stmt_sql->store_result();
					$num_of_rows = $stmt_sql->num_rows;
					$stmt_sql->bind_result($vendor_find);
					if($num_of_rows > 0){
						while($stmt_sql->fetch()){
							echo "<option value=\"$vendor_find\">$vendor_find</option>";
							}
					}
					}
					?>
				</select>
				<input type="hidden" name="page_no" value="<?php echo $go;?>">
				<select id="secuence" name="page_filter"  class="purchase_filter_style" >
				<?php if(strlen($page_filter)>0){
					echo "<option value=\"$page_filter\">$page_filter</option>";
				}?>
					<option value="Current">Current</option>
					<option value="Next">Next</option>
					<option value="Previous">Previous</option>
					<option value="Reset">Reset</option>
					
				</select>
				
			<input type="submit" class="purchase_filter_style" value="Filter">
			<button style="float:right;" type="button" class="btn btn-outline-primary add_company purchase_filter_style" data-toggle="modal" data-target="#myModalFreeProducts">Unpack</button>	
			</form>
		</div>
		</div>
		
			<div class="col-md-12">
				<div class="search_purchase_invoice_now"></div>
				  <div class="wrapper">
					  <div class="table">
						
						
					<?php 
					$page=$go;
					if(strlen($display_check)>0){
						$range=$display_now;
						$start=($page*$range)-$range;
						$next=$page+1;
						$previus=$page-1;
						$limit=" limit $start,$range";
					}else{
						$limit="";
					}
					if($stmt_sql = $mysqli->prepare("SELECT product_id,total_purchase,current_stock,total_sell,purchase_return,sell_return,damage,warranty,sell_warranty FROM stock_now_onserial WHERE company_username=? ORDER BY $serial $current_stock_check $vendor_filter $asc_desc_check")){
						
					$stmt_sql->bind_param("s",$company_now);
					$stmt_sql->execute();
					$stmt_sql->store_result();
					$num_of_rows_now = $stmt_sql->num_rows;
					$stmt_sql->fetch();
					echo "<p style=\"margin:0;padding:0;\">Items : ".$num_of_rows_now."</p>";
					}
					if($stmt_sql = $mysqli->prepare("SELECT product_id,opening_stock,total_purchase,current_stock,total_sell,purchase_return,sell_return,damage,warranty,sell_warranty FROM stock_now_onserial WHERE company_username=? $current_stock_check $vendor_filter ORDER BY $serial $asc_desc_check $limit")){
						
					$stmt_sql->bind_param("s",$company_now);
					$stmt_sql->execute();
					$stmt_sql->store_result();
					$num_of_rows_now = $stmt_sql->num_rows;
					
					$stmt_sql->bind_result($product_id,$opening_stock,$total_purchase,$current_stock,$total_sell,$purchase_return,$sell_return,$damage,$warranty,$sell_warranty);
					$total_product_value=0;
					if($num_of_rows_now > 0){
					?>
					<div class="tb_header">
						  <div class="cell">
							Sn
						  </div>
						  <div class="cell">
							Product id
						  </div>
						  <div class="cell">
							Product title
						  </div>
						  <div class="cell">
							Opening
						  </div>
						  
						  <div class="cell">
							Purchase
						  </div>
						  <div class="cell">
							Stock
						  </div>
						  <div class="cell">
							Packs,Stock
						  </div>
						  <div class="cell">
							Sell
						  </div>
						  
						  <div class="cell">
							P.Return
						  </div>
						  <div class="cell">
							S.Return
						  </div>
						  <div class="cell">
							Damage
						  </div>
						  <div class="cell">
							Product Value
						  </div>
						  <div class="cell">
							Stock Value
						  </div>
						  <!--<div class="cell">
							Purchase Service
						  </div>
						  <div class="cell">
							Sell Service
						  </div>-->
						</div>
					<?php
						$sn=1;
						while($stmt_sql->fetch()){
							echo "<div class=\"tb_row\">";
							echo "<div class=\"cell\">".$sn."</div>";
							echo "<div class=\"cell\">".$product_id."</div>";
							
							if($stmt_name = $mysqli->prepare("SELECT product_title,unit_price FROM products_details_onserial WHERE company_username=? and  product_id=? ORDER BY sn DESC")) {
							$stmt_name->bind_param("si",$company_now,$product_id);
							$stmt_name->execute();
							$stmt_name->store_result();
							$num_of_rows = $stmt_name->num_rows;
							$stmt_name->bind_result($product_title,$unit_price);
							$stmt_name->fetch();
							
							echo "<div class=\"cell\">".$product_title."</div>";
							}
							echo "<div class=\"cell\">".$opening_stock."</div>";
							echo "<div class=\"cell\">".$total_purchase."</div>";
							echo "<div class=\"cell\">".$current_stock."</div>";
							echo "<div class=\"cell\">";
							
							if($stmt_name = $mysqli->prepare("SELECT pack_size,total_pack FROM stock_pack_details WHERE company_username=? and  stock_sn=? ORDER BY sn DESC")) {
							$stmt_name->bind_param("si",$company_now,$product_id);
							$stmt_name->execute();
							$stmt_name->store_result();
							$num_of_rows_packs = $stmt_name->num_rows;
							$stmt_name->bind_result($pack_size,$total_pack);
							if($num_of_rows_packs>0){
								while($stmt_name->fetch()){
								echo $pack_size." , ".$total_pack."<br>";
								}
							}else{
								echo "";
							}
							}
							echo "</div>";
							echo "<div class=\"cell\">".$total_sell."</div>";
							echo "<div class=\"cell\">".$purchase_return."</div>";
							echo "<div class=\"cell\">".$sell_return."</div>";
							echo "<div class=\"cell\">".$damage."</div>";
							
							//echo "<div class=\"cell\">".$warranty."</div>";
							//echo "<div class=\"cell\">".$sell_warranty."</div>";
							echo "<div class=\"cell\">".$unit_price."</div>";
							$stock_value=$unit_price*$current_stock;
							echo "<div class=\"cell\">".$stock_value."</div>";
							echo "</div>";
							$total_product_value+=$stock_value;
							$sn++;
							}
					}else{
						echo "<div class=\"tb_row\">";
							echo "No stock now";
						echo "</div>";
					}
					
					}
						?>
					  
					</div>
				  <?php 
				  echo "<p style=\"margin:0;padding:0;border-top:1px solid #666;border-right:1px solid #666;\">Total Market Value : ".$total_product_value." Taka Only"."</p>";
				  ?>
				</div>
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<div class="modal fade" id="myModalFreeProducts" role="dialog">
			<div class="modal-dialog">
					<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h6 class="modal-title">Unpack Products</h6>
					</div>
					<div class="modal-body">
			 			<div class="panel-body">
							<!--<form action="software_free_product_add_list.php" role="form" method="POST">-->
								<div class="row">
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
											<input type="hidden" name="super_user" id="" class="form-control input-sm super_user" value ="<?php echo $super_email;?>">
											<input type="hidden" name="company_use" id="" class="form-control input-sm company_use" value ="<?php echo $company_now;?>">
											<input type="hidden" name="operator" id="" class="form-control input-sm operator" value ="<?php echo $user_now;?>">
											P Id : <select id="product_id_now" name="product_id_now"  class="" >
											<?php
											if($stmt_sql = $mysqli->prepare("SELECT product_id FROM products_details_onserial WHERE company_username=? ORDER BY sn DESC")){
												
												$stmt_sql->bind_param("s",$company_now);
												$stmt_sql->execute();
												$stmt_sql->store_result();
												$num_of_rows = $stmt_sql->num_rows;
												$stmt_sql->bind_result($product_id_now);
												if($num_of_rows > 0){
													while($stmt_sql->fetch()){
														echo "<option value=\"$product_id_now\">$product_id_now</option>";
														}
												}
												}
												?>
											</select>
										</div>
									</div>
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
											<input type="text" name="product_quantity_now" id="product_quantity_now" class="form-control input-sm" placeholder="Total Pack">
										</div>
									</div>
									
									
								</div>
								<div class="row">
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
											<input type="text" name="product_pack_size_now" id="product_pack_size_now" class="form-control input-sm" placeholder="Pack Size">
										</div>
									</div>
									
								<button type="button" class="btn btn-info btn-block free_new_product_Add">Save</button>
							
							<!--</form>-->
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	</div>
</html>
<?php
}else{
echo "You have not permit to access this page";
}
}else{
    echo "Something wrong.Please <a href=\"index.php\">login</a>";
}
?>