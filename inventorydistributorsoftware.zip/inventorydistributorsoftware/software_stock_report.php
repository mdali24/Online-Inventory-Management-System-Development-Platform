<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include_once('db.php');
session_start();
session_regenerate_id(TRUE);
if(isset($_SESSION['user_session']) and isset($_SESSION['company_username_session']) and isset($_SESSION['sub_user_session'])){
	$user_type_now=$_SESSION['user_session'];
	$company_now=$_SESSION['company_username_session'];
	$user_now=$_SESSION['sub_user_session'];
	$status=1;
	$query = "SELECT email,company_name,company_timezone,vendor_primary_key FROM companies_onserial WHERE company_username=? and status=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param("si",$company_now,$status);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($email,$company_name,$company_timezone,$vendor_primary_key);
	$stmt->fetch();
	$super_email=$email;
	$company=$company_name;
	$company_timezone=$company_timezone;
	$vendor_primary_key=$vendor_primary_key;
	}
	if($user_type_now=='Super'){
	$user_now=$super_email;
	}
	
 date_default_timezone_set($company_timezone);//problem
 $var_date= date('y/m/d') ;
if($user_type_now=="Super" or $user_type_now=="Master"){

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title><?php echo $company;?></title>
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<script src="auto/jquery-ui.min.js"></script>
	<link href="auto/jquery-ui.min.css" rel="stylesheet">
	<script>
	$(document).ready(function() {
		$(".search_invoice").click(function(e){
		e.preventDefault();
			var invoice_no=$(".invoice_no").val();
			
			var company="<?php echo $company_now;?>";
			var data_key='invoice_no='+ invoice_no+'&company='+ company;
			
			$.ajax({
				type: "POST",
				url: "fill/search_purchase_invoice_now.php",
				data: data_key,
				success: function(html){
					$(".search_purchase_invoice_now").html(html);
					
					}		
				});
		});
		$( function() {
		$( "#datepicker" ).datepicker({ dateFormat: 'yy-mm-dd' });
		$( "#datepickerto" ).datepicker({ dateFormat: 'yy-mm-dd' });
	  } );
		
	})
	</script>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="design.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="../inventory-software.png">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	
  </head>
  <body>
  <?php
	$query = "SELECT pakage,year,date FROM login_onserial WHERE email=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$super_email);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($pakage,$year,$date);
	$stmt->fetch();
	$softpakage=$pakage;
	$year=$year;
	$date=$date;
	$yearto=substr($date,0,4);
	$monthto=substr($date,5,2);
	$dateto=substr($date,8,2);
	$year_num=(int)$yearto;
	$year_up=$year_num+$year;
	if($monthto==2 and $dateto==29){
		$monthto=03;
		$dateto=01;
	}
	$up_date="$year_up"."/"."$monthto"."/"."$dateto";
	$up_to_time=strtotime($up_date);
	$expired_date=date('Y-m-d',$up_to_time);
	$today=date("Y-m-d");
	
	$today_strtotime=strtotime($today);
	$expired_strtotime=strtotime($expired_date);
	if($softpakage=='Free'){
		$warehouse=1;
		$users=1;
	}else if($softpakage=='Standard'){
		$warehouse=1;
		$users=1;
	}else if($softpakage=='Extend'){
		$warehouse=10;
		$users=20;
	}else if($softpakage=='Expand'){
		$warehouse=50;
		$users=100;
	}
	$stmt->free_result();
		$stmt->close();
	}
	$query = "SELECT vendor_primary_key FROM companies_onserial WHERE company_username=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$company_now);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($vendor_primary_key);
	$stmt->fetch();
	if($vendor_primary_key=='Email'){
		$vendor_primary_key='markenter_email';
	}else if($vendor_primary_key=='Mobile'){
		$vendor_primary_key='vendor_mobile_no';
	}else if($vendor_primary_key=='Telephone'){
		$vendor_primary_key='vendor_telephone_no';
	}
	$stmt->free_result();
		$stmt->close();
	}
	
	if(!empty($_POST['company'])){
	$company_filter=$_POST['company'];
	}else{
		$company_filter="empty";
	}
	if(!empty($_POST['datefrom'])and !empty($_POST['dateto'])){
	$datefrom=$_POST['datefrom'];
	$dateto=$_POST['dateto'];
	$datebetween="(date BETWEEN '".$datefrom."'"." AND '". $dateto."') and";
	}else{
		$datefrom="";
		$dateto="";
		$datebetween="";
	}
	if(!empty($_POST['invoice_type_now'])){
		$invoice_type_now=$_POST['invoice_type_now'];
		if($invoice_type_now=='All'){
			$invoice_type_filter="(invoice_type='purchase_invoice' or invoice_type='purchase_return_invoice' or invoice_type='sell_invoice' or invoice_type='sell_return_invoice' or invoice_type='adjusment_product_add' or invoice_type='adjusment_product_lost')";
		}else if($invoice_type_now=='Stock In'){
			$invoice_type_filter="(invoice_type='purchase_invoice' or invoice_type='sell_return_invoice' or invoice_type='adjusment_product_add')";
		}else if($invoice_type_now=='Stock Out'){
			$invoice_type_filter="(invoice_type='purchase_return_invoice' or invoice_type='sell_invoice' or invoice_type='adjusment_product_lost')";
		}else if($invoice_type_now=='All Adjusment'){
			$invoice_type_filter="(invoice_type='adjusment_product_add' or invoice_type='adjusment_product_lost')";
		}else if($invoice_type_now=='Adjusment In'){
			$invoice_type_filter="(invoice_type='adjusment_product_add')";
		}else if($invoice_type_now=='Adjusment Out'){
			$invoice_type_filter="(invoice_type='adjusment_product_lost')";
		}else{
			$invoice_type_filter="(invoice_type='purchase_invoice' or invoice_type='purchase_return_invoice' or invoice_type='sell_invoice' or invoice_type='sell_return_invoice' or invoice_type='adjusment_product_add' or invoice_type='adjusment_product_lost')";
		}
	}else{
		$invoice_type_now="";
		$invoice_type_filter="(invoice_type='purchase_invoice' or invoice_type='purchase_return_invoice' or invoice_type='sell_invoice' or invoice_type='sell_return_invoice' or invoice_type='adjusment_product_add' or invoice_type='adjusment_product_lost')";
		
	}
	if(!empty($_POST['user'])){
		$user=$_POST['user'];
		if($user=='All Users'){
			$user_filter="";
		}else{
			$user_filter="and sub_user='".$user."'";
		}
	}else{
		$user="";
		$user_filter="";
		
	}
	if(!empty($_POST['vendor_select'])){
		$vendor_select=$_POST['vendor_select'];
		if($vendor_select=='All Vendors'){
			$vendor_filter=" ";
		}else{
			$query_vendor = "SELECT sn FROM company_markenter_onserial WHERE company_username=? and $vendor_primary_key=? and type='vendor'"; 
			if($stmt_vendor = $mysqli->prepare($query_vendor)){
				if($vendor_primary_key=='markenter_email'){
					$stmt_vendor->bind_param('ss',$company_now,$vendor_select);
				}else{
					$stmt_vendor->bind_param('si',$company_now,$vendor_select);
				}
			$stmt_vendor->execute();
			$stmt_vendor->store_result();
			$num_of_rows = $stmt_vendor->num_rows;
			$stmt_vendor->bind_result($vendor_serial);
			$stmt_vendor->fetch();
			$vendor_filter="and  vendor_serial=$vendor_serial";
			}
		}
	}else{
		$vendor_select="";
		$vendor_filter="";
		
	}
	if(!empty($_POST['display'])){
		$display=$_POST['display'];
		if($display=='Display All'){
			$display_check="";
		}else{
			$display_now=$display;
			$display_check="exist";
		}
	}else{
		$display="";
		$display_now=20;
		$display_check="exist";
		
	}
	if(!empty($_POST['page_no'])){
		$page_no=$_POST['page_no'];
	}else{
		$page_no=1;
		
	}
	if(!empty($_POST['page_filter'])){
		$page_filter=$_POST['page_filter'];
		if($page_filter=='Next'){
			$go=$page_no+1;
		}else if($page_filter=='Previous'){
			$go=$page_no-1;
		}else if($page_filter=='Reset'){
			$go=1;
		}else{
			$go=$page_no;
		}
	}else{
		$page_filter="";
		$go=1;
	}
	if($go<1){
		$go=1;
		$message="This is first page.Can not go to previous.";
	}else{
		$message="";
	}
	?>
	<?php include_once('software_menu.php');?>
	<?php include_once('software_header.php');?>
	<div class="container-fluid border_bottom color z_index">
		<!--<h2>Vendor Management</h2>-->	
	</div>
	
	<div class="container-fluid">
		<div class="row">
		<div class="div_padding">
		<div class="col-md-12 col-sm-12">
			<div class="webdesigntuts-workshop">
						<form>		    
							<input type="number" class="invoice_no" placeholder="Search Invoice?">		    	
							<button class="search_invoice">Search</button>
						</form>
						
					</div>
		</div>
		</div>
		<div class="col-md-12 col-sm-12">
			<!--<a class="button_style" href="software_stock_low.php">Low</a>
			<a class="button_style" href="software_stock_high.php">High</a>-->
			<form action="software_stock_report.php" method="POST">
			<input type="hidden" name="company" value="<?php echo $company_now;?>">
			<div class="col-md-2">
				<input type="text" id="datepicker" name="datefrom" class="form-control purchase_filter_style" placeholder="Date from" value="<?php echo $datefrom;?>">
			</div>
			<div class="col-md-2">
				<input type="text"  id="datepickerto" name="dateto" class="form-control purchase_filter_style"  placeholder="Date to"  value="<?php echo $dateto;?>">
			</div>
			<select id="secuence" name="invoice_type_now"  class="purchase_filter_style" >
			<?php if(strlen($invoice_type_now)>0){
				echo "<option value=\"$invoice_type_now\">$invoice_type_now</option>";
			}?>
				<option value="All">All</option>
				<option value="Stock In">Stock In</option>
				<option value="Stock Out">Stock Out</option>
				<option value="All Adjusment">All Adjusment</option>
				<option value="Adjusment In">Adjusment In</option>
				<option value="Adjusment Out">Adjusment Out</option>
			</select>
			<select id="secuence" name="user"  class="purchase_filter_style" >
			<?php if(strlen($user)>0){
					echo "<option value=\"$user\">$user</option>";
			}?>
			<?php 
			if($user_type_now=="Super" or $user_type_now=="Master" or $user_type_now=="Purchase_Master" ){
				?>
				<option value="All Users">All Users</option>
				<?php 
				if($stmt_sql = $mysqli->prepare("SELECT sub_username FROM company_users_onserial WHERE company_username=? ORDER BY sn DESC")){
					
					$stmt_sql->bind_param("s",$company_now);
					$stmt_sql->execute();
					$stmt_sql->store_result();
					$num_of_rows = $stmt_sql->num_rows;
					$stmt_sql->bind_result($sub_username);
					if($num_of_rows > 0){
						while($stmt_sql->fetch()){
							echo "<option value=\"$sub_username\">$sub_username</option>";
							}
					}
					}
					?>
				<option value="Super Admin">Super Admin</option>
				<?php
			}else{
				echo "<option value=\"$user_now\">$user_now</option>";
			}
			?>
				
				
			</select>
			<select id="vendor_select" name="vendor_select"  class="purchase_filter_style" >
				<?php if(strlen($vendor_select)>0){
					echo "<option value=\"$vendor_select\">$vendor_select</option>";
				}?>
				<option value="All Vendors">All Vendors</option>
				<?php
				if($stmt_sql = $mysqli->prepare("SELECT $vendor_primary_key FROM company_markenter_onserial WHERE company_username=? and type='vendor' ORDER BY sn DESC")){
					
					$stmt_sql->bind_param("s",$company_now);
					$stmt_sql->execute();
					$stmt_sql->store_result();
					$num_of_rows = $stmt_sql->num_rows;
					$stmt_sql->bind_result($vendor_find);
					if($num_of_rows > 0){
						while($stmt_sql->fetch()){
							echo "<option value=\"$vendor_find\">$vendor_find</option>";
							}
					}
					}
					?>
				</select>
				<select id="secuence" name="display"  class="purchase_filter_style" >
				<?php if(strlen($display)>0){
					echo "<option value=\"$display\">$display</option>";
				}?>
					
					<option value="20">20</option>
					<option value="50">50</option>
					<option value="100">100</option>
					<option value="Display All">Display All</option>
				</select>
				<input type="hidden" name="page_no" value="<?php echo $go;?>">
				<select id="secuence" name="page_filter"  class="purchase_filter_style" >
				<?php if(strlen($page_filter)>0){
					echo "<option value=\"$page_filter\">$page_filter</option>";
				}?>
					<option value="Current">Current</option>
					<option value="Next">Next</option>
					<option value="Previous">Previous</option>
					<option value="Reset">Reset</option>
					
				</select>
				
			<input type="submit" class="purchase_filter_style" value="Filter">
			</form>
		</div>
			<div class="col-md-12">
				<div class="search_purchase_invoice_now"></div>
				  <div class="wrapper">
					  <div class="table">
						
						
					<?php 
					$page=$go;
					if(strlen($display_check)>0){
						$range=$display_now;
						$start=($page*$range)-$range;
						$next=$page+1;
						$previus=$page-1;
						$limit=" limit $start,$range";
					}else{
						$limit="";
					}
					$stock_in=0;
					$stock_out=0;
					if($stmt_sql = $mysqli->prepare("SELECT invoice_no,debit_credit_invoice,invoice_type,date FROM invoice_summary_onserial WHERE $datebetween company_username=? and status='1' and $invoice_type_filter $vendor_filter $user_filter ORDER BY sn DESC $limit")){
						
					$stmt_sql->bind_param("s",$company_now);
					$stmt_sql->execute();
					$stmt_sql->store_result();
					$num_of_rows_now = $stmt_sql->num_rows;
					
					$stmt_sql->bind_result($invoice_no,$debit_credit_invoice,$invoice_type,$date);
					
					if($num_of_rows_now > 0){
						
						
					?>
					<div class="tb_header">
							  <div class="cell">
								Sn
							  </div>
							  <div class="cell">
								Invoice No
							  </div>
							  <div class="cell">
								Type
							  </div>
							  <div class="cell">
								Products
							  </div>
							  <div class="cell">
								Stock In
							  </div>
							  <div class="cell">
								Stock Out
							  </div>
							  <div class="cell">
								Date
							  </div>
							  
							</div>
					<?php
						while($stmt_sql->fetch()){
							
							if(($invoice_type=='adjusment_product_add') or ($invoice_type=='adjusment_product_add')){
								$stmt_name = $mysqli->prepare("SELECT product_name,size,quantity FROM invoice_products_details_onserial WHERE company_username=? and debit_credit_invoice=? and invoice_type=? ORDER BY sn DESC");
								$stmt_name->bind_param("sis",$company_now,$debit_credit_invoice,$invoice_type);
							  }else{
								 $stmt_name = $mysqli->prepare("SELECT product_name,size,quantity FROM invoice_products_details_onserial WHERE company_username=? and invoice_no=? and invoice_type=? ORDER BY sn DESC");
								$stmt_name->bind_param("sis",$company_now,$invoice_no,$invoice_type);
							  }
							$stmt_name->execute();
							$stmt_name->store_result();
							$num_of_rows = $stmt_name->num_rows;
							$stmt_name->bind_result($product_name,$size,$quantity);
							if(isset($_SESSION['sn'])){
								$sn=$sn;
							}else{
								$sn=1;
							}
							while($stmt_name->fetch()){
								echo "<div class=\"tb_row\">";
								echo "<div class=\"cell\">".$sn."</div>";
								if(($invoice_type=='adjusment_product_add') or ($invoice_type=='adjusment_product_add')){
									echo "<div class=\"cell\">".$debit_credit_invoice."</div>";
								}else{
									echo "<div class=\"cell\">".$invoice_no."</div>";
								}
								
								if($invoice_type=='purchase_invoice'){
									$type="Purchase";
								}else if($invoice_type=='purchase_return_invoice'){
									$type="Purchase Return";
								}else if($invoice_type=='sell_invoice'){
									$type="Sell";
								}else if($invoice_type=='sell_return_invoice'){
									$type="Sell Return";
								}else if($invoice_type=='adjusment_product_add'){
									$type="Adjusment In";
								}else if($invoice_type=='adjusment_product_lost'){
									$type="Adjusment Out";
								}
								
								echo "<div class=\"cell\">".$type."</div>";
								echo "<div class=\"cell\">".$product_name." ".$size."</div>";
								if($invoice_type=='purchase_invoice' or $invoice_type=='sell_return_invoice' or $invoice_type=='adjusment_product_add'){
									echo "<div class=\"cell\">".$quantity."</div>";
									$stock_in+=$quantity;
								}else{
									echo "<div class=\"cell\">"."0"."</div>";
								}
								if($invoice_type=='purchase_return_invoice' or $invoice_type=='sell_invoice' or $invoice_type=='adjusment_product_lost'){
									echo "<div class=\"cell\">".$quantity."</div>";
									$stock_out+=$quantity;
								}else{
									echo "<div class=\"cell\">"."0"."</div>";
								}
								echo "<div class=\"cell\">".$date."</div>";
								echo "</div>";
								$sn++;
								$_SESSION['sn']=$sn;
								}
							
							}
					}else{
						echo "<div class=\"tb_row\">";
							echo "None report created";
						echo "</div>";
					}
					unset($_SESSION['sn']);
					}
						?>
					  
					</div>
				  
				</div>
			</div>
		</div>
	</div>
	<div class="container">
		<div class="row ">
			<div class="col-md-12">
			<?php 
			echo "<h5 class=\"purchase_brief\">"."Total Stock In : ".$stock_in." and Total Stock Out : ".$stock_out."</h5>";
			?>
			</div>
		</div>
	</div>
	
  </body>
</html>
<?php
}else{
echo "You have not permit to access this page";
}
}else{
    echo "Something wrong.Please <a href=\"index.php\">login</a>";
}
?>