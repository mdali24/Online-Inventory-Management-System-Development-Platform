<?php 
ob_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include_once('db.php');
include_once('method.php');
session_start();
session_regenerate_id(TRUE);
?>
<?php
if(isset($_SESSION['user_session']) and isset($_SESSION['company_username_session']) and isset($_SESSION['sub_user_session'])){
	$user_type_now=$_SESSION['user_session'];
	$company_now=$_SESSION['company_username_session'];
	$user_now=$_SESSION['sub_user_session'];
	$status=1;
	$query = "SELECT email,company_name,company_timezone,vendor_primary_key FROM companies_onserial WHERE company_username=? and status=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param("si",$company_now,$status);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($email,$company_name,$company_timezone,$vendor_primary_key);
	$stmt->fetch();
	$super_email=$email;
	$company=$company_name;
	$company_timezone=$company_timezone;
	$vendor_primary_key=$vendor_primary_key;
	}
	if($user_type_now=='Super'){
	$user_now=$super_email;
	}
	
 date_default_timezone_set('Asia/Dhaka');//problem
 $var_date= date('y/m/d') ;
if($user_type_now=="Super" or $user_type_now=="Master" or $user_type_now=="Purchase_Master" or $user_type_now=="Only_Purchase"){
$type="vendor";
$status="1";
if(!empty($_POST['super_user'])){
	$super_user=$_POST['super_user'];
}else{
	$super_user="";
}
if(!empty($_POST['company_use'])){
	$company_use=$_POST['company_use'];
}else{
	$company_use="";
}
if(!empty($_POST['product_id_now'])){
	$product_id_now=$_POST['product_id_now'];
	
}else{
	$product_id_now="";
}

if(!empty($_POST['product_quantity_now'])){
	$product_quantity_now=$_POST['product_quantity_now'];
}else{
	$product_quantity_now="";
}
echo $product_quantity_now;
if(!empty($_POST['product_pack_size_now'])){
	$product_pack_size_now=$_POST['product_pack_size_now'];
}else{
	$product_pack_size_now="";
}

if(!empty($_POST['product_id_now']) and !empty($_POST['product_quantity_now']) and !empty($_POST['product_pack_size_now'])){
	if ($stmt = $mysqli->prepare("SELECT * FROM stock_pack_details WHERE stock_sn=? and pack_size=?  and company_username=?")) {
			$stmt->bind_param("sss",$product_id_now,$product_pack_size_now,$company_use);
			$stmt->execute();
			$stmt->store_result();
			$rows_num=$stmt->num_rows;
			if($rows_num > 0){
				$stmt_sql = $mysqli->prepare("SELECT total_pack FROM stock_pack_details WHERE stock_sn=? and pack_size=? and  company_username=?");
				$stmt_sql->bind_param("sss",$product_id_now,$product_pack_size_now,$company_use);
				$stmt_sql->execute();
				$stmt_sql->store_result();
				$num_of_rows = $stmt_sql->num_rows;
				$stmt_sql->bind_result($total_pack);
				$stmt_sql->fetch();
				$total_pack=$total_pack;
				$total_pack_now=$total_pack-$product_quantity_now;
				
				$stmt_update = $mysqli->prepare("UPDATE stock_pack_details SET 
								  `total_pack`=?
								   WHERE `stock_sn`=? and `pack_size`=? and `company_username`=?");
						
				$stmt_update->bind_param('isss', $total_pack_now,$product_id_now, $product_pack_size_now, $company_use);
				$update_status = $stmt_update->execute();
				if($update_status==1){
					echo "Unpaked Succesfully";
				}
			}else{
				
							
			}  
		}
}else{
	echo "Empty Fields";
}
		
}else{
echo "You have not permit to access this page";
}
}else{
    echo "Something wrong.Please <a href=\"index.php\">login</a>";
}
?>