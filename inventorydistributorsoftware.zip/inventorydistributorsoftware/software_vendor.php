<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include_once('db.php');
session_start();
session_regenerate_id(TRUE);
if(isset($_SESSION['user_session']) and isset($_SESSION['company_username_session']) and isset($_SESSION['sub_user_session'])){
	$user_type_now=$_SESSION['user_session'];
	$company_now=$_SESSION['company_username_session'];
	$user_now=$_SESSION['sub_user_session'];
	$status=1;
	$query = "SELECT email,company_name FROM companies_onserial WHERE company_username=? and status=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param("si",$company_now,$status);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($email,$company_name);
	$stmt->fetch();
	$super_email=$email;
	$company=$company_name;
	}

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title><?php echo $company;?></title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="../inventory-software.png">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	<style>
	.menu{
		list-style:none;
		margin-top:50px;
		margin-bottom:0;
		padding-bottom:0;
	}
	.menu>li{
		display:inline-block;
		border-left:1px solid #55e353;
	}
	.menu>li>a{
		text-decoration:none;
		padding:15px;
		background-color:#e15226;
		border-radius:1px;
		color:#ffffff;
	}
	.color{
		color:#666;
		background-color:#eee;
	}
	.h1_color{
		color:#e040df;
	}
	.white_color{
		color:#ffffff;
	}
	.features{
		list-style:none;
	}
	.feature{
		color:#ffffff;
	}
	.company_border{
		border:1px solid #ffffff;
		padding-bottom:10px;
		width:140px;
		float:left;
		margin-right:5px;
	}
	.company_con{
		margin:2px;
		background-color:#888888;
	}
	.company{
		color:#ffffff;
		padding:5px;
	}
	.add_company{
		padding:7px;
		margin-top:15px;
		float:right;
	}
	.update{
		margin:10px;
		width:150px;
		text-align:center;
	}
	
	.vendor_add{
		margin:10px;
	}
	.vendor_save{
		margin-top:10px;
	}
	.vendor_edit{
		margin-top:10px;
	}
	h1{
		color:#666;
	}
	.search_asc_desc{
		width:120px;
		border-radius:5px;
		margin-right:10px;
		margin-top:52px;
		background: #222;
		background: linear-gradient(#333, #222);
		border: 1px solid #444;
		border-left-color: #000;
		box-shadow: 0 2px 0 #000;
		color: #fff;
		display: block;
		float: left;
		font-family: 'Cabin', helvetica, arial, sans-serif;
		font-size: 13px;
		font-weight: 400;
		height: 40px;
		line-height: 40px;
		padding: 0;
		position: relative;
		text-shadow: 0 -1px 0 #000;
	}
	</style>
  </head>
  <body>
  <?php
	$query = "SELECT pakage,year,date FROM login_onserial WHERE email=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$super_email);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($pakage,$year,$date);
	$stmt->fetch();
	$softpakage=$pakage;
	$year=$year;
	$date=$date;
	$yearto=substr($date,0,4);
	$monthto=substr($date,5,2);
	$dateto=substr($date,8,2);
	$year_num=(int)$yearto;
	$year_up=$year_num+$year;
	if($monthto==2 and $dateto==29){
		$monthto=03;
		$dateto=01;
	}
	$up_date="$year_up"."/"."$monthto"."/"."$dateto";
	$up_to_time=strtotime($up_date);
	$expired_date=date('Y-m-d',$up_to_time);
	$today=date("Y-m-d");
	
	$today_strtotime=strtotime($today);
	$expired_strtotime=strtotime($expired_date);
	if($softpakage=='Free'){
		$warehouse=1;
		$users=1;
	}else if($softpakage=='Standard'){
		$warehouse=1;
		$users=1;
	}else if($softpakage=='Extend'){
		$warehouse=10;
		$users=20;
	}else if($softpakage=='Expand'){
		$warehouse=50;
		$users=100;
	}
	$stmt->free_result();
		$stmt->close();
	}
	?>
	<?php include_once('software_menu.php');?>
	<?php include_once('software_header.php');?>
	<div class="container-fluid border_bottom color z_index">
		<!--<h2>Vendor Management</h2>-->	
	</div>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-3 col-sm-3">
					<h1 class="register-title">Vendor</h1>
					  <form class="register" action="add_new_vendor.php" method="POST">
						<div class="register-switch">
						  <input type="radio" name="sex" value="F" id="sex_f" class="register-switch-input" checked>
						  <label for="sex_f" class="register-switch-label">Add</label>
						  <input type="radio" name="sex" value="M" id="sex_m" class="register-switch-input">
						  <label for="sex_m" class="register-switch-label"  data-toggle="modal" data-target="#myModalVendors">New</label>
						</div>
						<input type="email" class="register-input" name="vendor_email" placeholder="Email address">
						<!--<input type="password" class="register-input" placeholder="Password">-->
						<input type="submit" value="Add Vendor" class="register-button">
					  </form>
					<!--<h3>Add new vendor</h3>
					<form class="vendor_add" action="" method="post">
						<div class="">
							<label class="label_class">Vendor id</label>
							<input type="number" class="input vendor_id" placeholder="Generate When submit">
						</div>
						<div class="">
							<label class="label_class">Email</label>
							<input type="email" class="input vendor_email">
						</div>
						<div class="">
							<label class="label_class">Mobile No</label>
							<input type="number" class="input mobile_no purchase_m_search">
						</div>
						<div class="">
							<label class="label_class">Full Name</label>
							<input type="text" class="input full_name">
						</div>
						<div class="">
							<label class="label_class">Address</label>
							<input type="text" class="address_input vendor_address">
						</div>
						<div class="">
							<label class="label_class">Suplier Company</label>
							<input type="text" class="input company_name">
						</div>
						<div class="">
							<label class="label_class">Display Name</label>
							<input type="text" class="input display_name">
						</div>
						<div class="">
							<label class="label_class">Telephone</label>
							<input type="number" class="input telephone_no">
						</div>
						<div class="">
							<label class="label_class">Credit Limit</label>
							<input type="number" class="input credit_limit">
						</div>
						<div class="">
							<label class="label_class">Credit Days</label>
							<input type="number" class="input credit_days">
						</div>
						<div class="">
							<button type="button" class="btn btn-default vendor_save">Save</button>
							<button type="button" class="btn btn-default vendor_edit">Edit</button>
						</div>
					</form>
				
				<div class="">
					<button style="float:left;margin-bottom:30px;" type="button" class="btn btn-outline-primary add_company extended_edition" data-toggle="modal" data-target="#myModalVendors">Add Vendor</button>	
				</div>-->
			</div>
			<div class="col-md-9  col-sm-9">
				<div class="row">
					<div class="col-md-2">
							<button class="search_asc_desc" >Balance ASC</button>
					</div>
					<div class="col-md-2">
						<button  class="search_asc_desc">Balance DESC</button>
					</div>
					<div class="col-md-8">
						<section class="webdesigntuts-workshop">
							<form action="" method="">		    
								<input type="search" placeholder="Vendor search?">		    	
								<button>Search</button>
							</form>
						</section>
					</div>
				</div>
				<div class="row">
				  <div class="wrapper">
					  <div class="table">
						
						<div class="tb_header">
						  <div class="cell">
							Name
						  </div>
						  <div class="cell">
							Id
						  </div>
						  <div class="cell">
							Email
						  </div>
						  <div class="cell">
							Mobile
						  </div>
						  <div class="cell">
							Balance
						  </div>
						</div>
						
						<div class="tb_row">
						  <div class="cell">
							Mohammad Ali
						  </div>
						  <div class="cell">
							1000001
						  </div>
						  <div class="cell">
							mdaliceous@gmail.com
						  </div>
						  <div class="cell">
							8801722038493
						  </div>
						  <div class="cell">
							-20000
						  </div>
						</div>
						
						<div class="tb_row">
						  <div class="cell">
							Leather iPhone wallet
						  </div>
						  <div class="cell">
							$45
						  </div>
						  <div class="cell">
							120
						  </div>
						  <div class="cell">
							02/28/2014
						  </div>
						  <div class="cell">
							In Transit
						  </div>
						</div>
						
						<div class="tb_row">
						  <div class="cell">
							27" Apple Thunderbolt displays
						  </div>
						  <div class="cell">
							$1000
						  </div>
						  <div class="cell">
							25
						  </div>
						  <div class="cell">
							02/10/2014
						  </div>
						  <div class="cell">
							Delivered
						  </div>
						</div>
						
						<div class="tb_row">
						  <div class="cell">
							Bose studio headphones
						  </div>
						  <div class="cell">
							$60
						  </div>
						  <div class="cell">
							90
						  </div>
						  <div class="cell">
							01/14/2014
						  </div>
						  <div class="cell">
							Delivered
						  </div>
						</div>
						
					  </div>
					</div>
				  </div>
				</div>
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<div class="modal fade" id="myModalVendors" role="dialog">
			<div class="modal-dialog">
					<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h6 class="modal-title">About Vendors </h6>
					</div>
					<div class="modal-body">
			 			<div class="panel-body">
							<form action="software_vendor_add_new.php" role="form" method="POST">
								<div class="row">
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
											<input type="text" name="full_name" id="full_name" class="form-control input-sm" placeholder="Vendor Name">
										</div>
									</div>
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
											<input type="email" name="vendor_email" id="vendor_email" class="form-control input-sm" placeholder="Vendor Email">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
											<input type="number" name="vendor_mobile_no" id="vendor_mobile_no" class="form-control input-sm" placeholder="Vendor Mobile">
										</div>
									</div>
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
											<input type="number" name="vendor_telephone_no" id="vendor_telephone_no" class="form-control input-sm" placeholder="Vendor Telephone">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-xs-12 col-sm-12 col-md-12">
										<div class="form-group">
											<input type="text" name="vendor_company_name" id="vendor_company_name" class="form-control input-sm" placeholder="Vendor Company Name">
										</div>
									</div>
									
								</div>
								<div class="row">
									<div class="col-xs-12 col-sm-12 col-md-12">
										<div class="form-group">
											<input type="text" name="vendor_address" id="vendor_address" class="form-control input-sm" placeholder="Vendor Address">
										</div>
									</div>
									
								</div>
								<div class="row">
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
											<input type="number" name="vendor_debit_limit" id="vendor_debit_limit" class="form-control input-sm" placeholder="Vendor Debit limit">
										</div>
									</div>
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
											<input type="number" name="vendor_debit_days" id="vendor_debit_days" class="form-control input-sm" placeholder="Vendor Debit days">
										</div>
									</div>
								</div>
								<input type="submit" value="Add" class="btn btn-info btn-block new_vendor_Add">
							
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<script src="javascript.js"></script>
  </body>
</html>
<?php
}else{
    echo "Something wrong.Please <a href=\"index.php\">login</a>";
}
?>