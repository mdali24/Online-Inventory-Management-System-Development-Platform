<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include_once('db.php');
include_once('method.php');
session_start();
session_regenerate_id(TRUE);
if(isset($_SESSION['user_session']) and isset($_SESSION['company_username_session']) and isset($_SESSION['sub_user_session'])){
	$user_type_now=$_SESSION['user_session'];
	$company_now=$_SESSION['company_username_session'];
	$user_now=$_SESSION['sub_user_session'];
	$status=1;
	$query = "SELECT email,company_name,company_timezone FROM companies_onserial WHERE company_username=? and status=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param("si",$company_now,$status);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($email,$company_name,$company_timezone);
	$stmt->fetch();
	$super_email=$email;
	$company=$company_name;
	$company_timezone=$company_timezone;
	}
	if($user_type_now=='Super'){
	$user_now=$super_email;
	}
 date_default_timezone_set("$company_timezone");
 $var_date= date('Y-M-D') ;
	
$empty_check=array();

if(!empty($_POST['full_name'])){
$full_name=$_POST['full_name'];
}else{
$empty_check[]="Empty full_name";
}
if(!empty($_POST['vendor_email'])){
$vendor_email=$_POST['vendor_email'];
}else{
$empty_check[]="Empty vendor_email";
}
if(!empty($_POST['vendor_mobile_no'])){
$vendor_mobile_no=$_POST['vendor_mobile_no'];
}else{
$empty_check[]="Empty vendor_mobile_no";
}
if(!empty($_POST['vendor_telephone_no'])){
$vendor_telephone_no=$_POST['vendor_telephone_no'];
}else{
$vendor_telephone_no="";
}
if(!empty($_POST['vendor_company_name'])){
$vendor_company_name=$_POST['vendor_company_name'];
}else{
$empty_check[]="Empty vendor_email";
}
if(!empty($_POST['vendor_address'])){
$vendor_address=$_POST['vendor_address'];
}else{
$empty_check[]="Empty vendor_address";
}
if(!empty($_POST['vendor_debit_limit'])){
$vendor_debit_limit=$_POST['vendor_debit_limit'];
}else{
$vendor_debit_limit=1000000000;
}
if(!empty($_POST['vendor_debit_days'])){
$vendor_debit_days=$_POST['vendor_debit_days'];
}else{
$vendor_debit_days=3650;
}


$status=1;

if(empty($empty_check)){
		if($stmt_sql = $mysqli->prepare("SELECT * FROM markenter_onserial WHERE email=?")){
		
		$stmt_sql->bind_param("s",$vendor_email);
		$stmt_sql->execute();
		$stmt_sql->store_result();
		$rows_num=$stmt_sql->num_rows;
		$f=0;
		if($rows_num<1){
		
		$email_c=md5($vendor_email.time());
		$markenter_pass=md5($email_c);
		$new_markenter_add=new data;
		$new_markenter_add->insert(
		"markenter_onserial",
		['user_type'=>"Markenter",
		'email'=>"$vendor_email",
		'password'=>"$markenter_pass",
		'email_con'=>"$email_c",
		'forgot_pass'=>"0",
		'status'=>"$f",
		'full_name'=>"$full_name",
		'vendor_mobile_no'=>"$vendor_mobile_no",
		'vendor_telephone_no'=>"$vendor_telephone_no",
		'vendor_company_name'=>"$vendor_company_name",
		'vendor_address'=>"$vendor_address",
		'vendor_debit_limit'=>"$vendor_debit_limit",
		'vendor_debit_days'=>"$vendor_debit_days",
		'date'=>"$var_date"],
		"sssssisiissiis",
		['',
		'']);
			$c_url="http://inventorysoftwareservices.com/new/markenter_emailconfarmation.php?token=$email_c";
			$msg="Confirm your email $c_url.And your password $email_c";
			if(mail($vendor_email,"inventorysoftwareservices.com email confarmation",$msg,"Do not Reply")){
					echo "You are registered Successfully"."<br/>";
					echo "Please confirm your email.";
					
				}
		}else{
		  echo "This email already has an account. Please <a href=\"markenter_login.php\">login</a>";
		}
	}
		if($stmt_sql = $mysqli->prepare("SELECT * FROM 	company_markenter_onserial WHERE company_username=? and markenter_email=? and status=?")){
			
			$stmt_sql->bind_param("ssi",$company_now,$vendor_email,$status);
			$stmt_sql->execute();
			$stmt_sql->store_result();
			$rows_num=$stmt_sql->num_rows;
			if($rows_num<1){
				$new_vendor_add=new data;
				$new_vendor_add->insert(
				"company_markenter_onserial",
				['super_admin_email'=>"$super_email",
				'company_username'=>"$company_now",
				'markenter_email'=>"$vendor_email",
				'status'=>"$status",
				'date'=>"$var_date",
				'full_name'=>"$full_name",
				'vendor_mobile_no'=>"$vendor_mobile_no",
				'vendor_telephone_no'=>"$vendor_telephone_no",
				'vendor_company_name'=>"$vendor_company_name",
				'vendor_address'=>"$vendor_address",
				'vendor_debit_limit'=>"$vendor_debit_limit",
				'vendor_debit_days'=>"$vendor_debit_days",
				'sub_username'=>"$user_now"],
				"sssissiissiis",
				['',
				'']);
			}else{
				$stmt = $mysqli->prepare("UPDATE company_markenter_onserial SET 
				full_name=?,
				vendor_company_name=?,
				vendor_mobile_no=?,
				vendor_telephone_no=?,
				vendor_address=?,
				vendor_debit_limit=?,
				vendor_debit_days=? 
				 WHERE markenter_email=?");
				$ok=1;		
				$stmt->bind_param('ssiisiis', $full_name, $vendor_company_name, $vendor_mobile_no, $vendor_telephone_no, $vendor_address, $vendor_debit_limit, $vendor_debit_days, $vendor_email);
					$update_status = $stmt->execute();
				if($update_status==1){
					 echo "Updated Successfully";
				}
			}
		}
	
}else{
   echo "Some Fields Empty";
}

header( "refresh:2;url=software_vendor.php" );
}else{
    echo "Please <a href=\"markenter_about.php\" >Login</a>";
}
?>