<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include_once('db.php');
session_start();
session_regenerate_id(TRUE);
if(isset($_SESSION['user_session']) and isset($_SESSION['company_username_session']) and isset($_SESSION['sub_user_session'])){
	$user_type_now=$_SESSION['user_session'];
	$company_now=$_SESSION['company_username_session'];
	$user_now=$_SESSION['sub_user_session'];
	$status=1;
	$query = "SELECT email,company_name,company_timezone,vendor_primary_key FROM companies_onserial WHERE company_username=? and status=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param("si",$company_now,$status);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($email,$company_name,$company_timezone,$vendor_primary_key);
	$stmt->fetch();
	$super_email=$email;
	$company=$company_name;
	$company_timezone=$company_timezone;
	$vendor_primary_key=$vendor_primary_key;
	}
	if($user_type_now=='Super'){
	$user_now=$super_email;
	}
	
 date_default_timezone_set($company_timezone);//problem
 $var_date= date('y/m/d') ;
if($user_type_now=="Super" or $user_type_now=="Master" or $user_type_now=="Purchase_Master"){

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title><?php echo $company;?></title>
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<script src="auto/jquery-ui.min.js"></script>
	<link href="auto/jquery-ui.min.css" rel="stylesheet">
	
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="design.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="../inventory-software.png">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	
  </head>
  <body>
  <?php
	$query = "SELECT pakage,year,date FROM login_onserial WHERE email=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$super_email);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($pakage,$year,$date);
	$stmt->fetch();
	$softpakage=$pakage;
	$year=$year;
	$date=$date;
	$yearto=substr($date,0,4);
	$monthto=substr($date,5,2);
	$dateto=substr($date,8,2);
	$year_num=(int)$yearto;
	$year_up=$year_num+$year;
	if($monthto==2 and $dateto==29){
		$monthto=03;
		$dateto=01;
	}
	$up_date="$year_up"."/"."$monthto"."/"."$dateto";
	$up_to_time=strtotime($up_date);
	$expired_date=date('Y-m-d',$up_to_time);
	$today=date("Y-m-d");
	
	$today_strtotime=strtotime($today);
	$expired_strtotime=strtotime($expired_date);
	if($softpakage=='Free'){
		$warehouse=1;
		$users=1;
	}else if($softpakage=='Silver'){
		$warehouse=1;
		$users=1;
	}else if($softpakage=='Gold'){
		$warehouse=10;
		$users=20;
	}else if($softpakage=='Diamond'){
		$warehouse=50;
		$users=100;
	}
	$stmt->free_result();
		$stmt->close();
	}
	$query = "SELECT vendor_primary_key FROM companies_onserial WHERE company_username=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$company_now);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($vendor_primary_key);
	$stmt->fetch();
	if($vendor_primary_key=='Email'){
		$vendor_primary_key='markenter_email';
	}else if($vendor_primary_key=='Mobile'){
		$vendor_primary_key='vendor_mobile_no';
	}else if($vendor_primary_key=='Telephone'){
		$vendor_primary_key='vendor_telephone_no';
	}
	$stmt->free_result();
		$stmt->close();
	}
	
	if(!empty($_POST['company'])){
	$company_filter=$_POST['company'];
	}else{
		$company_filter="empty";
	}
	if(!empty($_POST['amount_start'])){
	$amount_start=$_POST['amount_start'];
	}else{
		$amount_start=1;
	}
	$order_included_status=0;
	if(!empty($_POST['invoice_type_now'])){
		$invoice_type_now=$_POST['invoice_type_now'];
		if($invoice_type_now=='Without Order'){
			$invoice_type_filter="(invoice_type='purchase_invoice' or invoice_type='purchase_payment' or invoice_type='purchase_return_invoice' or invoice_type='purchase_service' or invoice_type='vendor_opening_amount')";
		}else{
			$invoice_type_filter=$invoice_type_filter="(invoice_type='purchase_invoice' or invoice_type='purchase_payment' or invoice_type='purchase_return_invoice' or invoice_type='purchase_service' or invoice_type='vendor_opening_amount')";
			$order_included_status=1;
		}
	}else{
		$invoice_type_now="";
		$invoice_type_filter="(invoice_type='purchase_invoice' or invoice_type='purchase_payment' or invoice_type='purchase_return_invoice' or invoice_type='purchase_service' or invoice_type='vendor_opening_amount')";
		
	}
	if(!empty($_POST['display'])){
		$display=$_POST['display'];
		if($display=='Display All'){
			$display_check="";
		}else{
			$display_now=$display;
			$display_check="exist";
		}
	}else{
		$display="";
		$display_now=20;
		$display_check="exist";
		
	}
	if(!empty($_POST['asc_desc'])){
		$asc_desc=$_POST['asc_desc'];
		if($asc_desc=='ASC'){
			$asc_desc_check="ASC";
		}else{
			$asc_desc_check="DESC";
		}
	}else{
		$asc_desc="";
		$asc_desc_check="DESC";
		
	}
	
	if(!empty($_POST['page_no'])){
		$page_no=$_POST['page_no'];
	}else{
		$page_no=1;
		
	}
	if(!empty($_POST['page_filter'])){
		$page_filter=$_POST['page_filter'];
		if($page_filter=='Next'){
			$go=$page_no+1;
		}else if($page_filter=='Previous'){
			$go=$page_no-1;
		}else if($page_filter=='Reset'){
			$go=1;
		}else{
			$go=$page_no;
		}
	}else{
		$page_filter="";
		$go=1;
	}
	if($go<1){
		$go=1;
		$message="This is first page.Can not go to previous.";
	}else{
		$message="";
	}
	$num_of_rows_now=0;
	?>
	<?php include_once('software_menu.php');?>
	<?php include_once('software_header.php');?>
	<div class="container-fluid border_bottom color z_index">
		<!--<h2>Vendor Management</h2>-->	
	</div>
	
	<div class="container-fluid">
		<div class="row">
		<div class="col-md-12">
		<div class="div_padding">
			<form action="software_vendor_balance.php" method="POST">
			<input type="hidden" name="company" value="<?php echo $company_now;?>">
			<div class="col-md-1">
			Starting Amount : 
			</div>
			<div class="col-md-2">
			<?php if(strlen($amount_start)>0){
				?>
				<input type="text" id="secuence" name="amount_start" class="form-control purchase_filter_style_input" placeholder="Amount Start" value="<?php echo $amount_start;?>">
				<?php
				}else{?>
				<input type="text" id="secuence" name="amount_start" class="form-control purchase_filter_style_input" placeholder="Amount Start" value="0">
				<?php } ?>
			</div>
			
			<select id="secuence" name="invoice_type_now"  class="purchase_filter_style" >
			<?php if(strlen($invoice_type_now)>0){
				echo "<option value=\"$invoice_type_now\">$invoice_type_now</option>";
			}?>
				<option value="Without Order">Without Order</option>
				<option value="With Order">With Order</option>
				
			</select>
			
			<select id="secuence" name="asc_desc"  class="purchase_filter_style" >
				<?php if(strlen($asc_desc)>0){
					echo "<option value=\"$asc_desc\">$asc_desc</option>";
				}?>
					<option value="ASC">DESC</option>
					<option value="ASC">ASC</option>
					
				</select>
				<select id="secuence" name="display"  class="purchase_filter_style" >
				<?php if(strlen($display)>0){
					echo "<option value=\"$display\">$display</option>";
				}?>
					
					<option value="20">20</option>
					<option value="50">50</option>
					<option value="100">100</option>
					<option value="Display All">Display All</option>
				</select>
				<input type="hidden" name="page_no" value="<?php echo $go;?>">
				<select id="secuence" name="page_filter"  class="purchase_filter_style" >
				<?php if(strlen($page_filter)>0){
					echo "<option value=\"$page_filter\">$page_filter</option>";
				}?>
					<option value="Current">Current</option>
					<option value="Next">Next</option>
					<option value="Previous">Previous</option>
					<option value="Reset">Reset</option>
					
				</select>
				
			<input type="submit" class="purchase_filter_style" value="Filter">
			</form>
			</div>
		</div>
			<div class="col-md-12">
				<div class="search_purchase_invoice_now"></div>
				  <div class="wrapper">
					  <div class="table">
						
					<?php 
					$page=$go;
					if(strlen($display_check)>0){
						$range=$display_now;
						$start=($page*$range)-$range;
						$next=$page+1;
						$previus=$page-1;
						$limit=" limit $start,$range";
					}else{
						$limit="";
					}
					if($order_included_status==1){
					$invoice_type_filter_order="(invoice_type='order_invoice' and order_to_invoice_status='no')";
					if($stmt_order = $mysqli->prepare("SELECT invoice_no,invoice_type,bill,discount,total,payment,date,due,due_payment_date,net FROM invoice_summary_onserial WHERE company_username=? and status=1 and $invoice_type_filter_order ORDER BY sn DESC")){
					$stmt_order->bind_param("s",$company_now);
					$stmt_order->execute();
					$stmt_order->store_result();
					$num_of_order_rows = $stmt_order->num_rows;
					$stmt_order->bind_result($order_no,$invoice_type,$bill,$discount,$total,$payment,$date,$due,$due_payment_date,$net);
						$grand_payment_order=0;
						if($num_of_order_rows > 0){
							while($stmt_order->fetch()){
								$grand_payment_order+=$payment;
							}
						}
					}
					}else{
						$grand_payment_order=0;
					}
					$display = array();
							$stmt_name = $mysqli->prepare("SELECT DISTINCT vendor_serial FROM invoice_summary_onserial WHERE  company_username=? and $invoice_type_filter and status='1' ORDER BY sn DESC $limit");
							$stmt_name->bind_param("s",$company_now);
							 
							$stmt_name->execute();
							$stmt_name->store_result();
							$num_of_rows = $stmt_name->num_rows;
							$stmt_name->bind_result($vendor_serial);
							if($num_of_rows > 0){
								while($stmt_name->fetch()){
								$stmt_name_new = $mysqli->prepare("SELECT 	invoice_type,total,payment,due,net,debit_or_credit FROM invoice_summary_onserial WHERE company_username=? and vendor_serial=? ORDER BY sn DESC");
								$stmt_name_new->bind_param("si",$company_now,$vendor_serial);
								$stmt_name_new->execute();
								$stmt_name_new->store_result();
								$num_of_rows_now = $stmt_name_new->num_rows;
								$stmt_name_new->bind_result($invoice_type,$total,$payment,$due,$net,$debit_or_credit);
								$total_amount=0;
								$total_payment_amount=0;
								$return_amount=0;
								$total_credit_amount=0;
								while($stmt_name_new->fetch()){
									if($invoice_type=='purchase_return_invoice'){
										$return_amount+=$payment;
									}else if($invoice_type=='vendor_opening_amount'){
										if($debit_or_credit=='debit'){
											$total_payment_amount+=$net;
										}else {
											
											$total_credit_amount+=$net;
										}
										
									}else{
										$total_amount+=$total;
										$total_payment_amount+=$payment;
									}
								}
								$balance=($total_payment_amount+$grand_payment_order)-(($total_amount+$total_credit_amount)-$return_amount);
								if($balance<$amount_start){
									$balance=abs($balance);
									$display[$vendor_serial]=$balance;
								}
								}
								if($asc_desc_check=="ASC"){
									asort($display);
								}else{
									arsort($display);
								}
								$sn=1;
								?>
								<div class="tb_header">
								  <div class="cell">
									Sn
								  </div>
								  <div class="cell">
									Name
								  </div>
								  <div class="cell">
									Contact
								  </div>
								   <div class="cell">
									Due
								  </div>
								</div>
								<?php
								$array_length=sizeof($display);
								if($array_length>0){
									foreach ($display as $key => $value) {
									echo "<div class=\"tb_row\">";
									echo "<div class=\"cell\">".$sn."</div>";
									$query_vendor = "SELECT full_name,$vendor_primary_key FROM company_markenter_onserial WHERE company_username=? and sn=? and type='vendor'"; 
									if($stmt_vendor = $mysqli->prepare($query_vendor)){
										$stmt_vendor->bind_param('si',$company_now,$key);
									$stmt_vendor->execute();
									$stmt_vendor->store_result();
									$num_of_rows = $stmt_vendor->num_rows;
									$stmt_vendor->bind_result($full_name,$vendor_primary);
									$stmt_vendor->fetch();
									echo "<div class=\"cell\">".$full_name."</div>";
									echo "<div class=\"cell\">".$vendor_primary."</div>";
									}
									
									echo "<div class=\"cell\">".$value."</div>";
									echo "</div>";
									$sn++;
								}
								}else{
									//echo "<div class=\"tb_row\">";
										echo "None report created";
									//echo "</div>";
								}
								
							}else{
								//echo "<div class=\"tb_row\">";
									echo "None report created";
								//echo "</div>";
							}
							?>
							
					</div>
				  
				</div>
			</div>
		</div>
	</div>
	
  </body>
</html>
<?php
}else{
echo "You have not permit to access this page";
}
}else{
    echo "Something wrong.Please <a href=\"index.php\">login</a>";
}
?>