<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include_once('db.php');
session_start();
session_regenerate_id(TRUE);
if(isset($_SESSION['user_session']) and isset($_SESSION['company_username_session']) and isset($_SESSION['sub_user_session'])){
	$user_type_now=$_SESSION['user_session'];
	$company_now=$_SESSION['company_username_session'];
	$user_now=$_SESSION['sub_user_session'];
	$status=1;
	$query = "SELECT email,company_name,company_timezone,vendor_primary_key FROM companies_onserial WHERE company_username=? and status=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param("si",$company_now,$status);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($email,$company_name,$company_timezone,$vendor_primary_key);
	$stmt->fetch();
	$super_email=$email;
	$company=$company_name;
	$company_timezone=$company_timezone;
	$vendor_primary_key=$vendor_primary_key;
	}
	if($user_type_now=='Super'){
	$user_now=$super_email;
	}
	
 date_default_timezone_set('Asia/Dhaka');//problem
 $var_date= date('y/m/d') ;
if($user_type_now=="Super" or $user_type_now=="Master" or $user_type_now=="Purchase_Master"){

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title><?php echo $company;?></title>
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<script src="auto/jquery-ui.min.js"></script>
	<link href="auto/jquery-ui.min.css" rel="stylesheet">
	<script>
	$(document).ready(function() {
		
		$( function() {
			$( "#datepicker" ).datepicker({ dateFormat: 'yy-mm-dd' });
			$( "#datepickerto" ).datepicker({ dateFormat: 'yy-mm-dd' });
		  } );
		  $(".new_vendor_Add").click(function(e) {
			 e.preventDefault();
		 
			var super_user=$("#super_user").val();
			var company_use=$("#company_use").val();
			var operator=$("#operator").val();
			var full_name_add=$("#full_name_add").val();
			var vendor_email_add=$("#vendor_email_add").val();
			var mobile_no_add=$("#mobile_no_add").val();
			var telephone_no_add=$("#telephone_no_add").val();
			var company_name_add=$("#company_name_add").val();
			var vendor_address_add=$("#vendor_address_add").val();
			var opening_blance_type=$("#opening_blance_type").val();
			var opening_amount=$("#opening_amount").val();
			var debit_limit_add=$("#debit_limit_add").val();
			var debit_days_add=$("#debit_days_add").val();
					var data='super_user='+ super_user+'&company_use='+ company_use+'&operator='+ operator+'&full_name_add='+ full_name_add+'&vendor_email_add='+ vendor_email_add+'&mobile_no_add='+ mobile_no_add+'&telephone_no_add='+ telephone_no_add+'&company_name_add='+ company_name_add+'&vendor_address_add='+ vendor_address_add+'&opening_blance_type='+ opening_blance_type+'&opening_amount='+ opening_amount+'&debit_limit_add='+ debit_limit_add+'&debit_days_add='+ debit_days_add;
				
				$.ajax({
				type: "POST",
				url: "software_vendor_add_list.php",
				data: data,
				success: function(html){
					$('.close').click();
					alert(html);
					}		
			});	
		 })
	})
	</script>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="design.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="../inventory-software.png">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	
  </head>
  <body>
  <?php
	$query = "SELECT pakage,year,date FROM login_onserial WHERE email=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$super_email);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($pakage,$year,$date);
	$stmt->fetch();
	$softpakage=$pakage;
	$year=$year;
	$date=$date;
	$yearto=substr($date,0,4);
	$monthto=substr($date,5,2);
	$dateto=substr($date,8,2);
	$year_num=(int)$yearto;
	$year_up=$year_num+$year;
	if($monthto==2 and $dateto==29){
		$monthto=03;
		$dateto=01;
	}
	$up_date="$year_up"."/"."$monthto"."/"."$dateto";
	$up_to_time=strtotime($up_date);
	$expired_date=date('Y-m-d',$up_to_time);
	$today=date("Y-m-d");
	
	$today_strtotime=strtotime($today);
	$expired_strtotime=strtotime($expired_date);
	if($softpakage=='Free'){
		$warehouse=1;
		$users=1;
	}else if($softpakage=='Silver'){
		$warehouse=1;
		$users=1;
	}else if($softpakage=='Gold'){
		$warehouse=10;
		$users=20;
	}else if($softpakage=='Diamond'){
		$warehouse=50;
		$users=100;
	}
	$stmt->free_result();
		$stmt->close();
	}
	$query = "SELECT vendor_primary_key FROM companies_onserial WHERE company_username=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$company_now);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($vendor_primary_key);
	$stmt->fetch();
	if($vendor_primary_key=='Email'){
		$vendor_primary_key='markenter_email';
	}else if($vendor_primary_key=='Mobile'){
		$vendor_primary_key='vendor_mobile_no';
	}else if($vendor_primary_key=='Telephone'){
		$vendor_primary_key='vendor_telephone_no';
	}
	$stmt->free_result();
		$stmt->close();
	}
	
	if(!empty($_POST['company'])){
	$company_filter=$_POST['company'];
	}else{
		$company_filter="empty";
	}
	if(!empty($_POST['datefrom'])and !empty($_POST['dateto'])){
	$datefrom=$_POST['datefrom'];
	$dateto=$_POST['dateto'];
	$datebetween="(date BETWEEN '".$datefrom."'"." AND '". $dateto."') and";
	}else{
		$datefrom="";
		$dateto="";
		$datebetween="";
	}
	if(!empty($_POST['name_search'])){
		$name_search=trim($_POST['name_search']);
		
		$name_filter="and  full_name='$name_search'";
	}else{
		$name_search="";
		$name_filter="";
	}
	if(!empty($_POST['mobile_search'])){
		$mobile_search=trim($_POST['mobile_search']);
		$mobile_filter="and  vendor_mobile_no='$mobile_search'";
	}else{
		$mobile_search="";
		$mobile_filter="";
	}
	if(!empty($_POST['email_search'])){
		$email_search=trim($_POST['email_search']);
		$email_filter="and  markenter_email='$email_search'";
	}else{
		$email_search="";
		$email_filter="";
	}
	if(!empty($_POST['telephone_search'])){
		$telephone_search=trim($_POST['telephone_search']);
		$telephone_filter="and  vendor_telephone_no=$telephone_search";
	}else{
		$telephone_search="";
		$telephone_filter="";
	}

	if(!empty($_POST['display'])){
		$display=$_POST['display'];
		if($display=='Display All'){
			$display_check="";
		}else{
			$display_now=$display;
			$display_check="exist";
		}
	}else{
		$display="";
		$display_now=50;
		$display_check="exist";
		
	}
	if(!empty($_POST['page_no'])){
		$page_no=$_POST['page_no'];
	}else{
		$page_no=1;
		
	}
	if(!empty($_POST['page_filter'])){
		$page_filter=$_POST['page_filter'];
		if($page_filter=='Next'){
			$go=$page_no+1;
		}else if($page_filter=='Previous'){
			$go=$page_no-1;
		}else if($page_filter=='Reset'){
			$go=1;
		}else{
			$go=$page_no;
		}
	}else{
		$page_filter="";
		$go=1;
	}
	if($go<1){
		$go=1;
		$message="This is first page.Can not go to previous.";
	}else{
		$message="";
	}
	$num_of_rows_now=0;
	?>
	<?php include_once('software_menu.php');?>
	<?php include_once('software_header.php');?>
	<div class="container-fluid border_bottom color z_index">
		<!--<h2>Vendor Management</h2>-->	
	</div>
	
	<div class="container-fluid">
		<div class="row">
		<div class="div_padding">
			
			<!--<a class="button_style" href="software_stock_low.php">Low</a>
			<a class="button_style" href="software_stock_high.php">High</a>-->
			<form action="software_vendor_list.php" method="POST">
			<input type="hidden" name="company" value="<?php echo $company_now;?>">
			<div class="col-md-2">
				<input type="text" id="datepicker" name="datefrom" class="form-control purchase_filter_style_input" placeholder="Date from" value="<?php echo $datefrom;?>">
			</div>
			<div class="col-md-2">
				<input type="text"  id="datepickerto" name="dateto" class="form-control purchase_filter_style_input"  placeholder="Date to"  value="<?php echo $dateto;?>">
			</div>
			<div class="col-md-2">
				<?php if(strlen($name_search)>0){
				?>
				<input type="text" id="name_search" name="name_search" class="form-control purchase_filter_style_input" placeholder="Name" value="<?php echo $name_search;?>">
				<?php
				}else{?>
				<input type="text" id="name_search" name="name_search" class="form-control purchase_filter_style_input" placeholder="Name" value="">
				<?php } ?>
			</div>
			<div class="col-md-2">
				<?php if(strlen($mobile_search)>0){
				?>
				<input type="text" id="mobile_search" name="mobile_search" class="form-control purchase_filter_style_input" placeholder="Code" value="<?php echo $mobile_search;?>">
				<?php
				}else{?>
				<input type="text" id="mobile_search" name="mobile_search" class="form-control purchase_filter_style_input" placeholder="Code" value="">
				<?php } ?>
			</div>
			<div class="col-md-2">
				<?php if(strlen($email_search)>0){
				?>
				<input type="text" id="email_search" name="email_search" class="form-control purchase_filter_styl_inpute" placeholder="Email" value="<?php echo $email_search;?>">
				<?php
				}else{?>
				<input type="text" id="email_search" name="email_search" class="form-control purchase_filter_style_input" placeholder="Email" value="">
				<?php } ?>
			</div>
			<div class="col-md-2">
				<?php if(strlen($telephone_search)>0){
				?>
				<input type="text" id="telephone_search" name="telephone_search" class="form-control purchase_filter_style_input" placeholder="Telephone" value="<?php echo $telephone_search;?>">
				<?php
				}else{?>
				<input type="text" id="telephone_search" name="telephone_search" class="form-control purchase_filter_style_input" placeholder="Telephone" value="">
				<?php } ?>
			</div>
			<div class="col-md-12 col-sm-12">
				<select id="secuence" name="display"  class="purchase_filter_style" >
				<?php if(strlen($display)>0){
					echo "<option value=\"$display\">$display</option>";
				}?>
					<option value="50">50</option>
					<option value="100">100</option>
					<option value="Display All">Display All</option>
				</select>
				<input type="hidden" name="page_no" value="<?php echo $go;?>">
				<select id="secuence" name="page_filter"  class="purchase_filter_style" >
				<?php if(strlen($page_filter)>0){
					echo "<option value=\"$page_filter\">$page_filter</option>";
				}?>
					<option value="Current">Current</option>
					<option value="Next">Next</option>
					<option value="Previous">Previous</option>
					<option value="Reset">Reset</option>
					
				</select>
				
			<input type="submit" class="purchase_filter_style" value="Filter">
			</form>
			<button style="float:right;" type="button" class="btn btn-outline-primary add_company purchase_filter_style" data-toggle="modal" data-target="#myModalVendors">Add New</button>	
		</div>
		</div>
		
			<div class="col-md-12">
				<div class="search_purchase_invoice_now"></div>
				  <div class="wrapper">
					  <div class="table">
						
						
					<?php 
					$page=$go;
					if(strlen($display_check)>0){
						$range=$display_now;
						$start=($page*$range)-$range;
						$next=$page+1;
						$previus=$page-1;
						$limit=" limit $start,$range";
					}else{
						$limit="";
					}
					if($stmt_sql_num_rows = $mysqli->prepare("SELECT 	full_name,vendor_mobile_no,markenter_email,vendor_telephone_no,vendor_company_name,vendor_address,vendor_debit_limit,vendor_debit_days,date FROM 	company_markenter_onserial WHERE $datebetween company_username=? and status=1 and type='vendor' $name_filter $mobile_filter $email_filter $telephone_filter ORDER BY sn DESC")){
						
					$stmt_sql_num_rows->bind_param("s",$company_now);
					$stmt_sql_num_rows->execute();
					$stmt_sql_num_rows->store_result();
					$num_of_stmt_sql_num_rows = $stmt_sql_num_rows->num_rows;
					$stmt_sql_num_rows->fetch();
					echo "<p style=\"margin:0;paddig:0;\">Total : ".$num_of_stmt_sql_num_rows."</p>";
					}
					if($stmt_sql = $mysqli->prepare("SELECT 	sn,full_name,vendor_mobile_no,markenter_email,vendor_telephone_no,vendor_company_name,vendor_address,vendor_debit_limit,vendor_debit_days,date FROM company_markenter_onserial WHERE $datebetween company_username=? and status=1 and type='vendor' $name_filter $mobile_filter $email_filter $telephone_filter ORDER BY sn DESC $limit")){
						
					$stmt_sql->bind_param("s",$company_now);
					$stmt_sql->execute();
					$stmt_sql->store_result();
					$num_of_rows_now = $stmt_sql->num_rows;
					
					$stmt_sql->bind_result($sn_del,$full_name,$vendor_mobile_no,$markenter_email,$vendor_telephone_no,$vendor_company_name,$vendor_address,$vendor_debit_limit,$vendor_debit_days,$date);
					if($num_of_rows_now > 0){
					?>
					<div class="tb_header">
						  <div class="cell">
							Sn
						  </div>
						  <div class="cell">
							Name
						  </div>
						  <div class="cell">
							Code
						  </div>
						  <div class="cell">
							Email
						  </div>
						  <div class="cell">
							Telephone
						  </div>
						  <div class="cell">
							Company
						  </div>
						  <div class="cell">
							Address
						  </div>
						  <div class="cell">
							Debit Limit
						  </div>
						  <div class="cell">
							Debit Days
						  </div>
						  <div class="cell">
							Register Date
						  </div>
						  <div class="cell">
							Delete
						  </div>
						</div>
					<?php
						$sn=1;
						
						$grand_total=0;
						$grand_payment=0;
						$grand_due=0;
						$grand_net=0;
						while($stmt_sql->fetch()){
							echo "<div class=\"tb_row\">";
							echo "<div class=\"cell\">".$sn."</div>";
							echo "<div class=\"cell\">".$full_name."</div>";
							echo "<div class=\"cell\">".$vendor_mobile_no."</div>";
							echo "<div class=\"cell\">".$markenter_email."</div>";
							echo "<div class=\"cell\">".$vendor_telephone_no."</div>";
							echo "<div class=\"cell\">".$vendor_company_name."</div>";
							echo "<div class=\"cell\">".$vendor_address."</div>";
							echo "<div class=\"cell\">".$vendor_debit_limit."</div>";
							echo "<div class=\"cell\">".$vendor_debit_days."</div>";
							echo "<div class=\"cell\">".$date."</div>";
							echo "<div class=\"cell\">"."<button class=\"remove_vendor\">".$sn_del."</button>"."</div>";
							echo "</div>";
							$sn++;
							}
					}else{
						echo "<div class=\"tb_row\">";
							echo "None report created";
						echo "</div>";
					}
					}
						?>
					  
					</div>
				  
				</div>
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<div class="modal fade" id="myModalVendors" role="dialog">
			<div class="modal-dialog">
					<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h6 class="modal-title">Distributor Information</h6>
					</div>
					<div class="modal-body">
			 			<div class="panel-body">
							<!--<form action="software_vendor_add_list.php" role="form" method="POST">-->
								<div class="row">
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
											<input type="hidden" name="super_user" id="super_user" class="form-control input-sm" value ="<?php echo $super_email;?>">
											<input type="hidden" name="company_use" id="company_use" class="form-control input-sm" value ="<?php echo $company_now;?>">
											<input type="hidden" name="operator" id="operator" class="form-control input-sm" value ="<?php echo $user_now;?>">
											<input type="text" name="full_name_add" id="full_name_add" class="form-control input-sm" placeholder="Vendor Name">
										</div>
									</div>
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
											<input type="email" name="vendor_email_add" id="vendor_email_add" class="form-control input-sm" placeholder="Vendor Email">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
											<input type="text" name="mobile_no_add" id="mobile_no_add" class="form-control input-sm" placeholder="Distributor Code" required>
										</div>
									</div>
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
											<input type="text" name="telephone_no_add" id="telephone_no_add" class="form-control input-sm" placeholder="Vendor Telephone">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-xs-12 col-sm-12 col-md-12">
										<div class="form-group">
											<input type="text" name="company_name_add" id="company_name_add" class="form-control input-sm" placeholder="Vendor Company Name">
										</div>
									</div>
									
								</div>
								<div class="row">
									<div class="col-xs-12 col-sm-12 col-md-12">
										<div class="form-group">
											<input type="text" name="vendor_address_add" id="vendor_address_add" class="form-control input-sm" placeholder="Vendor Address">
										</div>
									</div>
									
								</div>
								<div class="row">
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
											<select class="form-control input_t" name="opening_blance_type" id="opening_blance_type"  class="form-control input-sm" >
												<option value="balance" class="balance">Balance</option>
												<option value="due"  class="due">Due</option>	
											</select>
											
										</div>
									</div>
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
											<input type="number" name="opening_amount" id="opening_amount" class="form-control input-sm" placeholder="Amount">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
											<input type="text" name="debit_limit_add" id="debit_limit_add" class="form-control input-sm" placeholder="Vendor Debit limit">
										</div>
									</div>
									<div class="col-xs-6 col-sm-6 col-md-6">
										<div class="form-group">
											<input type="text" name="debit_days_add" id="debit_days_add" class="form-control input-sm" placeholder="Vendor Debit days">
										</div>
									</div>
								</div>
								<button type="button" value="Add" class="btn btn-info btn-block new_vendor_Add">Save</button>
							
							<!--</form>-->
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
  </body>
  <script>
	$(document).ready(function() {
		
		$(".remove_vendor").click(function(e) {
			 e.preventDefault();
		 
			var sn_del=$(this).html();
			var company_find="<?php echo $company_now;?>";
				var data_del='sn_del='+ sn_del+'&company_find='+ company_find;
				
			$.ajax({
				type: "POST",
				url: "remove/delete_vendor_now.php",
				data: data_del,
				success: function(html){
					alert(html);
					}		
			});	
		 })
	})
	</script>
</html>
<?php
}else{
echo "You have not permit to access this page";
}
}else{
    echo "Something wrong.Please <a href=\"index.php\">login</a>";
}
?>