<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Super Admin</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="design.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="../inventory-software.png">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	<style>
	
	</style>
  </head>
  <body>
  <div class="container-fluid header_class_2">
		<div class="row">
			<div class="col-md-6 col-sm-6">
				
					<h1 class="main_h1_2">itBangla Inventory</h1>
				
				
			</div>
			<div class="col-md-5  col-sm-5">
				<p style="color:#fff;" class="tagline">Outstanding Business Management</p>
			</div>
			<div class="col-md-1 col-sm-1">
				<a class="logout" style="color:#fff;" href="logout.php">logout</a>
			</div>
			
		</div>
	</div>
	<div class="container-fluid border_bottom">
			
	</div>
<?php 
include_once('db.php');
session_start();
session_regenerate_id(TRUE);
if(isset($_SESSION['user_email_session']) and isset($_SESSION['user_type_session'])){
	$user_email=$_SESSION['user_email_session'];
	$user_type=$_SESSION['user_type_session'];

?>

  <?php
	$query = "SELECT pakage,year,date FROM login_onserial WHERE email=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$user_email);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($pakage,$year,$date);
	$stmt->fetch();
	$softpakage=$pakage;
	$year=$year;
	$date=$date;
	$yearto=substr($date,0,4);
	$monthto=substr($date,5,2);
	$dateto=substr($date,8,2);
	$year_num=(int)$yearto;
	$year_up=$year_num+$year;
	if($monthto==2 and $dateto==29){
		$monthto=03;
		$dateto=01;
	}
	$up_date="$year_up"."/"."$monthto"."/"."$dateto";
	$up_to_time=strtotime($up_date);
	$expired_date=date('Y-m-d',$up_to_time);
	$today=date("Y-m-d");
	$today_strtotime=strtotime($today);
	$expired_strtotime=strtotime($expired_date);
	if($softpakage=='Free'){
		$warehouse=1;
		$users=1;
		$features="<li>Upto 10 purchase invoice per month</li>
						<li>Upto 10 sell invoice per month</li>
						<li>Unlimited order</li>
						<li>1 users</li>
						<li>1 warehouse</li>
						<li>Unlimited access</li>";
	}else if($softpakage=='Silver'){
		$warehouse=1;
		$users=5;
		$features="<li>Upto 3000 purchase invoice per month</li>
						<li>Upto 3000 sell invoice per month</li>
						<li>Unlimited order</li>
						<li>Upto 5 users</li>
						<li>1 warehouse</li>
						<li>Unlimited access</li>";
	}else if($softpakage=='Gold'){
		$warehouse=5;
		$users=50;
		$features="<li>Upto 30000 purchase invoice per month</li>
						<li>Upto 30000 sell invoice per month</li>
						<li>Unlimited order</li>
						<li>Upto 50 users</li>
						<li>Upto 5 warehouse</li>
						<li>Unlimited access</li>";
	}else if($softpakage=='Diamond'){
		$warehouse=50;
		$users=1000;
		$features="<li>Upto 1000000 purchase invoice per month</li>
						<li>Upto 1000000 sell invoice per month</li>
						<li>Unlimited order</li>
						<li>Upto 50 warehourse</li>
						<li>Upto 1000 users</li>
						<li>Unlimited access</li>";
	}
	$stmt->free_result();
		$stmt->close();
	}
	?>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-3 col-sm-3">
				<div class="pakage">
					<h3 class="client_super_sub_title  "><?php echo $softpakage;?></h3>
					<h4 class="pakage_sub_title">Features</h4>
					<ol class="create_account_feature">
						<?php echo $features;?>
					</ol>
					<h4 class="pakage_sub_title">Expared : <?php echo $expired_date;?></h4>
					
				</div>
				<div class="pakage">
					<h3 class="client_super_sub_title ">Update</h3>
					
					<button type="button" class="update" data-toggle="modal" data-target="#myModalUpdateYear">Update Year</button>
					<?php if($softpakage!=='Diamond'){
					?>
					<button type="button" class="update" data-toggle="modal" data-target="#myModalUpdatePakage">Update Pakage</button>
					<?php
						}
					?>
				</div>
			</div>
			<div class="col-md-9  col-sm-9">
				<div class="row">
					<div class="col-md-8  col-sm-8">
						<h1 class="super_sub_title ">Your companies</h1>
					</div>
					<div class="col-md-4  col-sm-4">
						<button type="button" class="add_new  add_company" data-toggle="modal" data-target="#myModal">New Company</button>
					</div>
				</div>
				<div class="row">
					
					<?php
					$status=1;
					if($stmt_sql = $mysqli->prepare("SELECT * FROM companies_onserial WHERE email=?")){
		
					$stmt_sql->bind_param("s",$user_email);
					$stmt_sql->execute();
					$stmt_sql->store_result();
					$rows_num=$stmt_sql->num_rows;
					if($rows_num>0){
						$stmt = $mysqli->prepare("SELECT company_name,company_username FROM companies_onserial WHERE email=? and status=?");
						$stmt->bind_param("si",$user_email,$status);
						$stmt->execute();
						$stmt->store_result();
						$num_of_rows = $stmt->num_rows;
						$stmt->bind_result($company_name,$company_username);
						while($stmt->fetch()){
							echo "<div class=\"company_border\">
									<div class=\"company_con\">
										<div class=\"company\">
											<p>"."Company Name : <br>".$company_name."</p>"."<hr>"."<p>"."Username : <br>".$company_username."</p>".
														"<form action=\"software.php\" method=\"POST\">
														<input type=\"hidden\" name=\"company_user\" id=\"company_user\" value=\"$company_username\">
														<input type=\"submit\" value=\"Go\" name=\"go\">
														</form>
														"."
										</div>
									</div>	
								</div>";
						}
						
					}else{
						echo "<div class=\"company_border\">
								<div class=\"company_con\">
									<div class=\"company\">
										<p>No Company Yet </p>
									</div>
								</div>	
							</div>";
					}
				}
				?>
					
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="row">
							<div class="col-md-8  col-sm-8">
								<h1 class="super_sub_title ">Your users</h1>
							</div>
							<div class="col-md-4  col-sm-4">
								<button type="button" class="add_new  add_company extended_edition" data-toggle="modal" data-target="#myModalUsers">New User</button>
							</div>
						</div>
						<div class="row">
							<?php
							$status=1;
								if($stmt_sql = $mysqli->prepare("SELECT * FROM company_users_onserial WHERE email=?")){
					
								$stmt_sql->bind_param("s",$user_email);
								$stmt_sql->execute();
								$stmt_sql->store_result();
								$rows_num=$stmt_sql->num_rows;
								if($rows_num>0){
									$stmt = $mysqli->prepare("SELECT company_username,sub_username FROM company_users_onserial WHERE email=? and status=?");
									$stmt->bind_param("si",$user_email,$status);
									$stmt->execute();
									$stmt->store_result();
									$num_of_rows = $stmt->num_rows;
									$stmt->bind_result($company_username,$sub_username);
									while($stmt->fetch()){
										echo "<div class=\"company_border\">
												<div class=\"company_con\">
													<div class=\"company\">
														<p>"."Company Username : <br>".$company_username."</p>"."<hr>"."<p>"."Sub Username : <br>".$sub_username."</p>".
														"</div>
												</div>	
											</div>";
									}
									
								}else{
									echo "<div class=\"company_border\">
											<div class=\"company_con\">
												<div class=\"company\">
													<p>No User Yet </p>
												</div>
											</div>	
										</div>";
								}
							}
							?>
						</div>
					</div>
				</div>
				<!--<div class="row">
					<div class="col-md-6">
						<button style="float:left;margin-bottom:30px;" type="button" class="btn btn-outline-primary add_company extended_edition" data-toggle="modal" data-target="#myModalVendors">Add New Vendor</button>	
					</div>
					<div class="col-md-6">
						<button  style="margin-bottom:30px;" type="button" class="btn btn-outline-primary add_company extended_edition" data-toggle="modal" data-target="#myModalCustomers">Add New Customer</button>	
					</div>
				</div>-->
			</div>
		</div>
	</div>
	
	<div class="container-fluid">
		<!-- Modal -->
		<div class="modal fade" id="myModal" role="dialog">
			<div class="modal-dialog">
			
				<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h6 class="modal-title">Soft19 Inventory </h6>
					</div>
					<div class="modal-body">
						<!--<div class="panel-heading">
			    		<h3 class="panel-title"></h3>
			 			</div>-->
			 			<div class="panel-body">
			    		<form action="add_new_company.php" role="form" method="POST">
							<div class="row">
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<h6>Software Pakage : <span class="pakage_name"><?php echo $softpakage;?></span></h6>
			    				</div>
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<h6>Warhouse Limit: <span class="pakage_year"><?php echo $warehouse;?></span></h6>
			    				</div>
			    			</div>
							
							<div class="row">
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
			                <input type="text" name="company_name" id="company_name_add_com" class="form-control input-sm" placeholder="Company Name">
			    					</div>
			    				</div>
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
			    						<input type="text" name="company_username" id="company_username_add_com" class="form-control input-sm" placeholder="Company Username">
			    					</div>
			    				</div>
			    			</div>
							
							<div class="row">
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
										<select class="form-control" name="barcode">
											<option value="Yes">Barcode Yes</option>
											<option value="No">No</option>
											
										</select> 
									</div>
			    				</div>
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
										<select class="form-control" name="serial_key">
											<option value="Yes">Serial Key Add</option>
											<option value="No">Not Add</option>
											
										</select> 
									</div>
			    				</div>
			    			</div>
							
							<div class="row">
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
										<select class="form-control" name="vendor_register_required">
											<option value="Yes">Vendor Register Required</option>
											<option value="No">Not Required</option>
											
										</select> 
									</div>
			    				</div>
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
										<select class="form-control" name="customer_register_required">
											<option value="Yes">Customer Register Required</option>
											<option value="No">Not Required</option>
											
										</select> 
									</div>
			    				</div>
			    			</div>
							
							<div class="row">
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
										<select class="form-control" name="customer_product_discount">
											<option value="Yes">Customer Product Discount</option>
											<option value="No">Not Show</option>
											
										</select> 
									</div>
			    				</div>
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
										<select class="form-control" name="customer_final_discount">
											<option value="Yes">Customer Final Discount</option>
											<option value="No">Not Show</option>
											
										</select> 
									</div>
			    				</div>
			    			</div>
							
							<div class="row">
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
										<select class="form-control" name="vendor_tax">
											<option value="Yes">Vendor Tax Included</option>
											<option value="No">Not Included</option>
											
										</select> 
									</div>
			    				</div>
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
										<select class="form-control" name="customer_tax">
											<option value="Yes">Customer Tax Included</option>
											<option value="No">Not Included</option>
											
										</select> 
									</div>
			    				</div>
			    			</div>
							
							<div class="row">
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
										<select class="form-control" name="vendor_primary_key">
											<option value="Email">Vendor Primary key Email</option>
											<option value="Mobile">Mobile</option>
											<option value="Telephone">Telephone</option>
										</select> 
									</div>
			    				</div>
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
										<select class="form-control" name="customer_primary_key">
											<option value="Email">Customer Primary Key Email</option>
											<option value="Mobile">Mobile</option>
											<option value="Telephone">Telephone</option>
											
										</select> 
									</div>
			    				</div>
			    			</div>
			    			<div class="row">
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
										<select class="form-control" name="customer_debit_limit">
											<option value="Yes">Customer Debit Limit</option>
											<option value="No">No</option>
											
										</select> 
									</div>
			    				</div>
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
										<select class="form-control" name="customer_debit_days">
											<option value="Yes">Customer Debit Days</option>
											<option value="No">No</option>
											
										</select> 
									</div>
			    				</div>
			    			</div>
							<div class="row">
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
										<select class="form-control" name="customer_online_order_on">
											<option value="Yes">Customer Online Order Yes</option>
											<option value="No">No</option>
											
										</select> 
									</div>
			    				</div>
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
										<select class="form-control" name="customer_online_auto_approved">
											<option value="Yes">Customer Online Auto Approved</option>
											<option value="No">No</option>
											
										</select> 
									</div>
			    				</div>
			    			</div>
							<div class="row">
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
										Timezone Set : 
									</div>
			    				</div>
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
										<select class="form-control" name="company_timezone">
										<?php $tzlist = DateTimeZone::listIdentifiers(DateTimeZone::ALL);
										foreach ($tzlist as $key => $value) {
											echo $key." : ".$value."<br>";
											if($value=='Asia/Dhaka'){
												$select=' selected';
												}else{
												$select=' ';
												}
											echo "<option value=\"$value\" $select>$value</option>";
										}?>
										
										</select>  
									</div>
									
			    				</div>
			    			</div>
			    			<input type="submit" value="Add" class="btn btn-info btn-block add_new_company">
			    		
			    		</form>
			    	</div>
	    		</div>
				</div>
				
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<!-- Modal -->
		<div class="modal fade" id="myModalUsers" role="dialog">
			<div class="modal-dialog">
			
				<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h6 class="modal-title">Soft19 Inventory </h6>
					</div>
					<div class="modal-body">
						<!--<div class="panel-heading">
			    		<h3 class="panel-title"></h3>
			 			</div>-->
			 			<div class="panel-body">
			    		<form action="add_new_user.php" role="form" method="POST">
							<div class="row">
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<h6>Pakage : <span class="pakage_name"><?php echo $softpakage;?></span></h6>
			    				</div>
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<h6>User Limit/warehouse  : <span class="pakage_year"><?php echo $users;?></span></h6>
			    				</div>
			    			</div>
			    			<div class="row">
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
			                <input type="text" name="name" id="name" class="form-control input-sm" placeholder="Name">
			    					</div>
			    				</div>
								<div class="col-xs-6 col-sm-6 col-md-6">
									<div class="form-group">
										<select class="form-control" name="company">
											<?php 
											$stmt_com = $mysqli->prepare("SELECT company_username FROM companies_onserial WHERE email=? and status=?");
											$stmt_com->bind_param("si",$user_email,$status);
											$stmt_com->execute();
											$stmt_com->store_result();
											$num_of_rows = $stmt_com->num_rows;
											$stmt_com->bind_result($company_username);
											if($num_of_rows>0){
												while($stmt_com->fetch()){
													echo "<option value=\"$company_username\">".$company_username."</option>";
												}
											}else{
												echo "<option value=\"$value\">"."Please add company first"."</option>";
											}
											
											?>
										</select> 
									</div>
			    				</div>
			    				
			    			</div>
			    			<div class="row">
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
										<input type="text" name="post" id="post" class="form-control input-sm" placeholder="Post">
			    					</div>
			    				</div>
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
			    						<input type="text" name="id_no" id="id_no" class="form-control input-sm" placeholder="Id No">
			    					</div>
			    				</div>
			    			</div>
							<div class="row">
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
										<select class="form-control" name="user_type">
											<option value="Master">Master</option>
											<option value="Only_Purchase">Only Purchase</option>
											<option value="Purchase_Master">Purchase Master</option>
											<option value="Only_Seller">Only Seller</option>
											<option value="Seller_Master">Seller Master</option>
											
										</select> 
									</div>
			    				</div>
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
			    						<input type="text" name="sub_username" id="sub_username" class="form-control input-sm" placeholder="Sub username">
			    					</div>
			    				</div>
			    			</div>
			    			<div class="row">
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
			    						<input type="password" name="password" id="password" class="form-control input-sm" placeholder="Password">
			    					</div>
			    				</div>
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
			    						<input type="password" name="password_confirmation" id="password_confirmation" class="form-control input-sm" placeholder="Confirm Password">
			    					</div>
			    				</div>
			    			</div>
			    			
			    			<input type="submit" value="Add" class="btn btn-info btn-block add_user">
			    		
			    		</form>
			    	</div>
	    		</div>
				</div>
				
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<!-- Modal -->
		<div class="modal fade" id="myModalUpdateYear" role="dialog">
			<div class="modal-dialog">
			
				<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h6 class="modal-title">Soft19 Inventory </h6>
					</div>
					<div class="modal-body">
						<!--<div class="panel-heading">
			    		<h3 class="panel-title"></h3>
			 			</div>-->
			 			<div class="panel-body">
			    		<form action="update_year.php" role="form" method="POST">
							<div class="row">
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<h6>Software Pakage : <span class="pakage_name"><?php echo $softpakage;?></span></h6>
			    				</div>
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<h6>Expired Date : <span class="pakage_year"><?php echo $expired_date;?></span></h6>
			    				</div>
			    			</div>
							
							<div class="row">
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					Add Year : 
			    				</div>
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
										<select class="form-control" name="add_year">
											<option value="1">1</option>
											<option value="2">2</option>
											<option value="3">3</option>
											<option value="4">4</option>
											<option value="5">5</option>
											<option value="6">6</option>
											<option value="7">7</option>
											<option value="8">8</option>
											<option value="9">9</option>
											<option value="10">10</option>
											<option value="11">11</option>
											<option value="12">12</option>
											<option value="13">13</option>
											<option value="14">14</option>
											<option value="15">15</option>
											<option value="16">16</option>
											<option value="17">17</option>
											<option value="18">18</option>
											<option value="19">19</option>
											<option value="20">20</option>
										</select> 
			    						
			    					</div>
			    				</div>
			    			</div>
			    			
			    			<input type="submit" value="Add" class="btn btn-info btn-block">
			    		
			    		</form>
			    	</div>
	    		</div>
				</div>
				
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<!-- Modal -->
		<div class="modal fade" id="myModalUpdatePakage" role="dialog">
			<div class="modal-dialog">
			
				<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h6 class="modal-title">Soft19 Inventory </h6>
					</div>
					<div class="modal-body">
						<!--<div class="panel-heading">
			    		<h3 class="panel-title"></h3>
			 			</div>-->
			 			<div class="panel-body">
			    		<form action="update_pakage.php" role="form" method="POST">
							<div class="row">
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<h6>Software Pakage : <span class="pakage_name"><?php echo $softpakage;?></span></h6>
			    				</div>
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<h6>Expired Date : <span class="pakage_year"><?php echo $expired_date;?></span></h6>
			    				</div>
			    			</div>
							
							<div class="row">
								<div class="col-xs-6 col-sm-6 col-md-6">
									Update Pakage : 
								</div>
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
										<select class="form-control" name="update_pakage">
										<?php 
										if($softpakage=='Free'){
										?>
											<option value="Standard">Standard</option>
											<option value="Silver">Silver</option>
											<option value="Gold">Gold</option>
											<option value="Diamond">Diamond</option>
										<?php
										}else if($softpakage=='Silver'){
										?>
											<option value="Gold">Gold</option>
											<option value="Diamond">Diamond</option>
										<?php
										}else if($softpakage=='Gold'){
										?>
											<option value="Diamond">Diamond</option>
										<?php
										}
										?>
											
										</select> 
			    					</div>
			    				</div>
			    			</div>
			    			
			    			<input type="submit" value="Add" class="btn btn-info btn-block">
			    		
			    		</form>
			    	</div>
	    		</div>
				</div>
				
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<!-- Modal -->
		<div class="modal fade" id="myModalVendors" role="dialog">
			<div class="modal-dialog">
			
				<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h6 class="modal-title">Soft19 Inventory </h6>
					</div>
					<div class="modal-body">
						<!--<div class="panel-heading">
			    		<h3 class="panel-title"></h3>
			 			</div>-->
			 			<div class="panel-body">
			    		<form action="add_new_vendor.php" role="form" method="POST">
							<div class="row">
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<h6>Company Username : </h6>
			    				</div>
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<h6>Vendor Email Address</h6>
			    				</div>
			    			</div>
							
							<div class="row">
								<div class="col-xs-6 col-sm-6 col-md-6">
									<div class="form-group">
										<select class="form-control" name="company_select">
											<?php 
											$stmt_com = $mysqli->prepare("SELECT company_username FROM companies_onserial WHERE email=? and status=?");
											$stmt_com->bind_param("si",$user_email,$status);
											$stmt_com->execute();
											$stmt_com->store_result();
											$num_of_rows = $stmt_com->num_rows;
											$stmt_com->bind_result($company_username);
											if($num_of_rows>0){
												while($stmt_com->fetch()){
													echo "<option value=\"$company_username\">".$company_username."</option>";
												}
											}else{
												echo "<option value=\"$value\">"."Please add company first"."</option>";
											}
											
											?>
										</select> 
									</div>
			    				</div>
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
			    						<input type="email" name="vendor_email" id="vendor_email" class="form-control input-sm" placeholder="Vendor Email">
			    					</div>
			    				</div>
			    			</div>
			    			
			    			<input type="submit" value="Add" class="btn btn-info btn-block">
			    		
			    		</form>
			    	</div>
	    		</div>
				</div>
				
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<!-- Modal -->
		<div class="modal fade" id="myModalCustomers" role="dialog">
			<div class="modal-dialog">
			
				<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h6 class="modal-title">Soft19 Inventory </h6>
					</div>
					<div class="modal-body">
						<!--<div class="panel-heading">
			    		<h3 class="panel-title"></h3>
			 			</div>-->
			 			<div class="panel-body">
			    		<form action="add_new_customer.php" role="form" method="POST">
							<div class="row">
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<h6>Company Username : </h6>
			    				</div>
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<h6>Customer Email Address</h6>
			    				</div>
			    			</div>
							
							<div class="row">
								<div class="col-xs-6 col-sm-6 col-md-6">
									<div class="form-group">
										<select class="form-control" name="company_select_customer">
											<?php 
											$stmt_com = $mysqli->prepare("SELECT company_username FROM companies_onserial WHERE email=? and status=?");
											$stmt_com->bind_param("si",$user_email,$status);
											$stmt_com->execute();
											$stmt_com->store_result();
											$num_of_rows = $stmt_com->num_rows;
											$stmt_com->bind_result($company_username);
											if($num_of_rows>0){
												while($stmt_com->fetch()){
													echo "<option value=\"$company_username\">".$company_username."</option>";
												}
											}else{
												echo "<option value=\"$value\">"."Please add company first"."</option>";
											}
											
											?>
										</select> 
									</div>
			    				</div>
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
			    						<input type="email" name="customer_email" id="customer_email" class="form-control input-sm" placeholder="Customer Email">
			    					</div>
			    				</div>
			    			</div>
			    			
			    			<input type="submit" value="Add" class="btn btn-info btn-block">
			    		
			    		</form>
			    	</div>
	    		</div>
				</div>
				
			</div>
		</div>
	</div>
    
<?php 
}else{
    echo "<h1 class=\"client_login_title\">Please <a href=\"client_login.php\">login</a></h1>";
}
?>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<script src="javascript.js"></script>
  </body>
</html>