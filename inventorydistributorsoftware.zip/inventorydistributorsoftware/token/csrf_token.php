<?php
session_start();
session_regenerate_id(TRUE);
 $_SESSION['csrf_token']=md5(rand().time());
					$token_now=$_SESSION['csrf_token'];
					echo $token_now;
				?>