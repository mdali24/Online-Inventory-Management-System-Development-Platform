<?php 
include_once('db.php');
session_start();
if(isset($_SESSION['user_email_session']) and isset($_SESSION['user_type_session'])){
	$user_email=$_SESSION['user_email_session'];
	$user_type=$_SESSION['user_type_session'];
	$empty_check=array();
	if(!empty($_POST['update_pakage'])){
	$update_pakage=$_POST['update_pakage'];
	}else{
	$empty_check[]="Empty Year";
	}
	if(empty($empty_check)){
		if($stmt_sql = $mysqli->prepare("SELECT * FROM login_onserial WHERE user_type=? and email=?")){
			
			$stmt_sql->bind_param("ss",$user_type,$user_email);
			$stmt_sql->execute();
			$stmt_sql->store_result();
			$rows_num=$stmt_sql->num_rows;
			if($rows_num>0){
				$query = "SELECT pakage,year FROM login_onserial WHERE email=?"; 
				if($stmt = $mysqli->prepare($query)){
					$stmt->bind_param('s',$user_email);
					$stmt->execute();
					$stmt->store_result();
					$num_of_rows = $stmt->num_rows;
					$stmt->bind_result($pakage,$year);
					$stmt->fetch();
					$softpakage=$pakage;
					$softyear=$year;
					
					if($softpakage=='Free'){
						$pre_peryear=0;
					}else if($softpakage=='Silver'){
						$pre_peryear=299;
					}else if($softpakage=='Gold'){
						$pre_peryear=599;
					}else if($softpakage=='Diamond'){
						$pre_peryear=999;
					}
					
					if($update_pakage=='Free'){
						$peryear=0;
					}else if($update_pakage=='Silver'){
						$peryear=299;
					}else if($update_pakage=='Gold'){
						$peryear=599;
					}else if($update_pakage=='Diamond'){
						$peryear=999;
					}
					$stmt->free_result();
					$stmt->close();
				}
				$total=$peryear*$year;
				$discount=$total*($year/100);
				$total_cost=$total-$discount;
				
				$previous_total=$pre_peryear*$year;
				$pre_discount=$previous_total*($year/100);
				$pre_total_cost=$total-$discount;
				
				$total_now=$total_cost-$previous_total;
				$discount_now=$discount-$pre_discount;
				$pay_now=$total_now-$discount_now;
				echo "Total:".$total_now;
				echo "Discount:".$discount_now;
				echo "Pay:".$pay_now;
				$_SESSION['udpade_pakage_session']=$update_pakage;
				?>
<!DOCTYPE html>
<html>
<head>
<title>Paypal Payments</title>
</head>
<body>
<form action="https://www.paypal.com/cgi-bin/webscr" method="post">

  <input type="hidden" name="business" value="paytonow@gmail.com">

  <input type="hidden" name="cmd" value="_xclick">

  <input type="hidden" name="currency_code" value="USD">

  <input type="hidden" name="item_name" value="<?php echo $update_pakage;?>" />

  <input type="hidden" name="amount" value="<?php echo $pay_now;?>" />

  <!--<input type="hidden" name="notify_url" value="http://inventorysoftwareservices.com/new/update_pakage_listener.php">-->
  <input type="hidden" name="return" value="http://inventorysoftwareservices.com/inventorymanagementsoftware/update_pakage_payment_successfully.php">
  <input type="hidden" name="cancel_return" value="http://inventorysoftwareservices.com/inventorymanagementsoftware/update_pakage_payment_cancel.php">
  
  <input type="image" name="submit" border="0"
  src="Paypal-Button.jpg"
  alt="Buy Now">
  <img alt="" border="0" width="1" height="1"
  src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" >

</form>

</body>
</html>
				<?php
				
			}else{
				echo "No client";
			}
		}
	}else{
	 echo "Empty Field";
	}
}else{
    echo "Please <a href=\"login.php\" >Login</a>";
}
?>