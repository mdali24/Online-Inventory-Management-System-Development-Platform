<?php 
include_once('db.php');
if(isset($_SESSION['user_email_session']) and isset($_SESSION['user_type_session']) and isset($_SESSION['update_pakage_session'])){
	$user_email=$_SESSION['user_email_session'];
	$user_type=$_SESSION['user_type_session'];
	$update_pakage=$_SESSION['update_pakage_session'];
	
	$status=1;
	$stmt_update = $mysqli->prepare("UPDATE login_onserial SET 
                      `pakage`=?,
                      `status`=?
                       WHERE `email`=?");
			
			$stmt_update->bind_param('sis', $update_pakage, $status, $user_email);
			$update_status = $stmt_update->execute();
			if($update_status==1){
				echo "Updated Successfully";
			}
unset($_SESSION['update_pakage_session']);
}else{
    echo "Please <a href=\"login.php\" >Login</a>";
}
?>