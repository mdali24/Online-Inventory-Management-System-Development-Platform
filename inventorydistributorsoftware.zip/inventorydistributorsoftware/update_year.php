<?php 

?>
<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Customer Login Form</title>
  	<!-- Bootstrap -->
    	<link href="css/bootstrap.min.css" rel="stylesheet">
      <link rel="stylesheet" href="design.css">
     
</head>

<body>
  <?php include_once('client_header.php');?>
<?php 
include_once('db.php');
session_start();
if(isset($_SESSION['user_email_session']) and isset($_SESSION['user_type_session'])){
	$user_email=$_SESSION['user_email_session'];
	$user_type=$_SESSION['user_type_session'];
	$empty_check=array();
	if(!empty($_POST['add_year'])){
	$add_year=$_POST['add_year'];
	}else{
	$empty_check[]="Empty Year";
	}
	if(empty($empty_check)){
		if($stmt_sql = $mysqli->prepare("SELECT * FROM login_onserial WHERE user_type=? and email=?")){
			
			$stmt_sql->bind_param("ss",$user_type,$user_email);
			$stmt_sql->execute();
			$stmt_sql->store_result();
			$rows_num=$stmt_sql->num_rows;
			if($rows_num>0){
				$query = "SELECT pakage FROM login_onserial WHERE email=? ORDER BY sn DESC"; 
				if($stmt = $mysqli->prepare($query)){
					$stmt->bind_param('s',$user_email);
					$stmt->execute();
					$stmt->store_result();
					$num_of_rows = $stmt->num_rows;
					$stmt->bind_result($pakage);
					$stmt->fetch();
					$softpakage=$pakage;
					if($softpakage=='Free'){
						$peryear=0;
					}else if($softpakage=='Silver'){
						$peryear=299;
					}else if($softpakage=='Gold'){
						$peryear=599;
					}else if($softpakage=='Diamond'){
						$peryear=999;
					}
					$stmt->free_result();
					$stmt->close();
				}
				$total=$peryear*$add_year;
				$discount=$total*($add_year/100);
				$total_cost=$total-$discount;
				echo "Total:".$total;
				echo "Discount:".$discount;
				echo "Pay:".$total_cost;
				$_SESSION['add_year_session']=$add_year;
				?>

<form action="https://www.paypal.com/cgi-bin/webscr" method="post">

  <input type="hidden" name="business" value="paytonow@gmail.com">

  <input type="hidden" name="cmd" value="_xclick">

  <input type="hidden" name="item_name" value="">
  <input type="hidden" name="amount" value="">
  <input type="hidden" name="currency_code" value="USD">

  <input type="hidden" name="item_name" value="<?php echo $softpakage;?>" />

  <input type="hidden" name="amount" value="<?php echo $total_cost;?>" />

  <!--<input type="hidden" name="notify_url" value="http://inventorysoftwareservices.com/new/update_year_listener.php">-->
  <input type="hidden" name="return" value="http://inventorysoftwareservices.com/inventorymanagementsoftware/update_year_payment_successfully.php">
  <input type="hidden" name="cancel_return" value="http://inventorysoftwareservices.com/inventorymanagementsoftware/update_year_payment_cancel.php">
  
  <input type="image" name="submit" border="0"
  src="Paypal-Button.jpg"
  alt="Buy Now">
  <img alt="" border="0" width="1" height="1"
  src="Paypal-Button.jpg" >

</form>

				<?php
				
			}else{
				echo "No client";
			}
		}
	}else{
	 echo "Empty Field";
	}
}else{
    echo "Please <a href=\"login.php\" >Login</a>";
}
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="javascript.js"></script>
</body>
</html>