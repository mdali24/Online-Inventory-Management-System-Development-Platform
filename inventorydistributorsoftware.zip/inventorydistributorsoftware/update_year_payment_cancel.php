<?php 
if(isset($_SESSION['user_email_session']) and isset($_SESSION['user_type_session']) and isset($_SESSION['add_year_session'])){
	$user_email=$_SESSION['user_email_session'];
	$user_type=$_SESSION['user_type_session'];
	$add_year=$_SESSION['add_year_session'];
	
unset($_SESSION['add_year_session']);
}else{
    echo "Please <a href=\"login.php\" >Login</a>";
}
?>