<?php 
include_once('db.php');
if(isset($_SESSION['user_email_session']) and isset($_SESSION['user_type_session']) and isset($_SESSION['add_year_session'])){
	$user_email=$_SESSION['user_email_session'];
	$user_type=$_SESSION['user_type_session'];
	$add_year=$_SESSION['add_year_session'];
	$query = "SELECT year FROM login_onserial WHERE email=?"; 
	if($stmt = $mysqli->prepare($query)){
	$stmt->bind_param('s',$user_email);
	$stmt->execute();
	$stmt->store_result();
	$num_of_rows = $stmt->num_rows;
	$stmt->bind_result($year);
	$stmt->fetch();
	$year=$year;
					
	$stmt->free_result();
	$stmt->close();
	}
	$now_year=$year+$add_year;
	$status=1;
	$stmt_update = $mysqli->prepare("UPDATE login_onserial SET 
                      `year`=?,
                      `status`=?
                       WHERE `email`=?");
			
			$stmt_update->bind_param('iis', $now_year, $status, $user_email);
			$update_status = $stmt_update->execute();
			if($update_status==1){
				echo "Updated Successfully";
			}
unset($_SESSION['add_year_session']);
}else{
    echo "Please <a href=\"login.php\" >Login</a>";
}
?>